﻿using static RCDService.Code.EnumerateManager;

namespace RCDService.Code
{
    public class UtilityManager
    {
        public static ENVIRONMENT_TYPE CurrentEnvironment(String url)
        {
            ENVIRONMENT_TYPE environmentType = ENVIRONMENT_TYPE.UNKNOWN;

            if (url.ToLower().Contains("firprod") || url.ToLower().Contains("fondoindennizzorisparmiatori"))
            {
                environmentType = ENVIRONMENT_TYPE.PRODUZIONE;
            }
            else if (url.ToLower().Contains("firpreprod"))
            {
                environmentType = ENVIRONMENT_TYPE.PRE_PRODUZIONE;
            }
            else
            {
                environmentType = ENVIRONMENT_TYPE.LOCALHOST;
            }

            return environmentType;
        }

        public static String PrefixEnvironment(ENVIRONMENT_TYPE environmentType)
        {
            String prefixEnvironment = String.Empty;

            switch (environmentType)
            {
                case ENVIRONMENT_TYPE.LOCALHOST:
                    prefixEnvironment = "Local-" + Environment.MachineName;
                    break;

                case ENVIRONMENT_TYPE.PRE_PRODUZIONE:
                    prefixEnvironment = "PreProd";
                    break;

                case ENVIRONMENT_TYPE.PRODUZIONE:
                    prefixEnvironment = "Prod";
                    break;

                default:
                    prefixEnvironment = String.Empty;
                    break;
            }

            return prefixEnvironment;
        }

    }
}
