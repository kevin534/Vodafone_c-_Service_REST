﻿using Microsoft.AspNetCore.Mvc;
using RCDContracts.Request;
using RCDContracts.Response;

namespace RCDService.Controllers
{
	[ApiController]
	[Route("[controller]")]
	public class DomainUserCheckController : _BaseController
	{
		private readonly ILogger<DomainUserCheckController> _logger;
		private IConfigurationRoot _configuration;
		private readonly IHttpContextAccessor _httpContextAccessor;

		public DomainUserCheckController(ILogger<DomainUserCheckController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor) : base(logger, configuration, httpContextAccessor)
		{
			_logger = logger;
			_configuration = (IConfigurationRoot)configuration;
			_httpContextAccessor = httpContextAccessor;

			
		}

		[HttpGet]
		public async Task<IEnumerable<WeatherForecast>> Get()
		{
			String pippo = _configuration["AppSettings:Local-PAOLOW10:DatabaseName"];

			//var utente = await _RCDDbContext.Utente.ToListAsync();


			return Enumerable.Range(1, 5).Select(index => new WeatherForecast
			{
				Date = DateTime.Now.AddDays(index),
				TemperatureC = Random.Shared.Next(-20, 55),
				Summary = pippo, // Summaries[Random.Shared.Next(Summaries.Length)]
				Utente = ""
			})
			.ToArray();
		}

		[HttpPost]
		[Route("Validation")]
		public async Task<IActionResult> Login([FromBody] LoginRequest input)
		{
	

			JsonResult jsonResult = new JsonResult(null);
			jsonResult.StatusCode = 200;

            try
            {
				if (String.IsNullOrEmpty(input.Username) || String.IsNullOrEmpty(input.Password))
				{
					string error = "Impossibile procedere con l'operazione richiesta. Dati in input mancanti: ";
					if (String.IsNullOrEmpty(input.Username))
					{
						error += "Username ";
					}
					if (String.IsNullOrEmpty(input.Password))
					{
						error += "Password";
					}
					jsonResult = new JsonResult("")
					{
						StatusCode = 500,
					};
					_logger.LogError("Error in Login " + error);
				}
				else
				{
					ServiceReference1.UtenzeADClient utenzeAD = new ServiceReference1.UtenzeADClient();
					Boolean isAuth = await utenzeAD.ValidationAsync(input.Username, input.Password, input.Application);
					jsonResult = new JsonResult(new LoginResponse { Result = "SUCCESS", IsAuthenticateOnLDAP = isAuth })
					{
						StatusCode = 200,
					};
					_logger.LogInformation("Login finish at: {time}", DateTimeOffset.Now);
				}

			}
			catch(Exception ex)
            {
				jsonResult = new JsonResult(new LoginResponse { Result = "ERROR", Message = " Errore nel Login LDAP " + ex.Message})
				{
					StatusCode = 500,
				};
				_logger.LogError("Error in Login " + ex.Message);

			}

			


			return jsonResult;
		}
	}
}
