using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication;

using RCD.Code;
using RCD.Code.Main;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddAuthentication("bearer").AddScheme<AuthenticationSchemeOptions, AuthenticationTokenHandler>("bearer", null);

builder.Services.AddHttpContextAccessor();
builder.Services.AddControllers();

builder.Services.AddDbContext<RCDEngine.RCDDbContext>(options =>
{
	options.UseSqlServer();
    options.EnableSensitiveDataLogging();
});

builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "CODE Web Services", Version = "v1" });
});

builder.WebHost.ConfigureKestrel(options => options.AddServerHeader = false);

var app = builder.Build();


// Configure the HTTP request pipeline.
app.UseSwagger();
app.UseSwaggerUI(c => c.SwaggerEndpoint("../swagger/v1/swagger.json", "CODE"));


app.UseHttpsRedirection();

app.UseCookiePolicy();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
