﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code.Amministrazione;
using RCD.Code.Rda;
using RCD.Code.RdaNcl;
using RCD.Controllers;
using RCDContracts;
using RCDContracts.Request;
namespace RCD.Controllers.RdaNcl
{
    [ApiController]
    [Route("rdaNcl/[controller]")]
    public class RdaNclController : _BaseController
    {
        private readonly ILogger<RdaNclController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public RdaNclController(ILogger<RdaNclController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        #region LISTA RDA BY ID FORNITORE

        [HttpPost]
        [Route("getListaRdAByIdFornitore")]
        public async Task<IActionResult> GetListaRdAByIdFornitore(ViewRdaRequestFull rda)
        {
            JsonResult jsonResult = new JsonResult(null);

            Int64 idDitta = 19;

            RdaNclManager rdaNclManager = new RdaNclManager(_RCDDbContext);

            var rdaIdFornitore = await rdaNclManager.GetListaRdAByIdFornitore(rda, idDitta);
            Int32 rdaIdFornitoreTot = await rdaNclManager.GetListaRdAByIdFornitoreTot(rda, idDitta);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = rdaIdFornitore.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = rdaIdFornitoreTot, List = rdaIdFornitore.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetListaRdAByIdFornitore finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetListaRdAByIdFornitore" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetListaRdAByIdFornitore " + ex.Message);
            }

            return jsonResult;
        }

        #endregion LISTA RDA BY ID FORNITORE


        [HttpPost]
        [Route("getRichiesteAttesaRdA")]
        public async Task<IActionResult> GetRichiesteAttesaRdA(RichiestaRequestFull richiesta)
        {
            JsonResult jsonResult = new JsonResult(null);

            Int64 idDitta = 21;

            RdaNclManager rdaNclManager = new RdaNclManager(_RCDDbContext);

            var richieste = await rdaNclManager.GetRichiesteAttesaRdA(richiesta, idDitta);
            Int32 richiesteTot = await rdaNclManager.GetRichiesteAttesaRdATot(richiesta, idDitta);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesteTot, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiesteAttesaRdA finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRichiesteAttesaRdA" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteAttesaRdA " + ex.Message);
            }

            return jsonResult;

        }

        [HttpPost]
        [Route("getRecuperiAttesaRdA")]
        public async Task<IActionResult> GetRecuperiAttesaRdA(RecuperiRequestFull recupero)
        {
            JsonResult jsonResult = new JsonResult(null);

            Int64 idDitta = 1;

            RdaNclManager rdaNclManager = new RdaNclManager(_RCDDbContext);

            var recuperi = await rdaNclManager.GetRecuperiAttesaRdA(recupero, idDitta);
            Int32 recuperiTot = await rdaNclManager.GetRecuperiAttesaRdATot(recupero, idDitta);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = recuperi.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = recuperiTot, List = recuperi.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRecuperiAttesaRdA finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRecuperiAttesaRdA" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRecuperiAttesaRdA " + ex.Message);
            }

            return jsonResult;

        }

        [HttpPost]
        [Route("getManutenzioniAttesaRdA")]
        public async Task<IActionResult> GetManutenzioniAttesaRdA(RecuperiRequestFull recupero)
        {
            JsonResult jsonResult = new JsonResult(null);

            Int64 idDitta = 1;

            RdaNclManager rdaNclManager = new RdaNclManager(_RCDDbContext);

            var recuperi = await rdaNclManager.GetManutenzioniAttesaRdA(recupero, idDitta);
            Int32 recuperiTot = await rdaNclManager.GetManutenzioniAttesaRdATot(recupero, idDitta);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = recuperi.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = recuperiTot, List = recuperi.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetManutenzioniAttesaRdA finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetManutenzioniAttesaRdA" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetManutenzioniAttesaRdA " + ex.Message);
            }

            return jsonResult;

        }



    }
}
