﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Location;
using RCD.Code.TargheTecniche;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Controllers.TargheTecniche
{

    [ApiController]
    [Route("targheTecniche/[controller]")]
    public class TargheTecnicheController : _BaseController
    {
        private readonly ILogger<TargheTecnicheController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        private Int32 counterDiRisposteAsync = 0;

        public TargheTecnicheController(ILogger<TargheTecnicheController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("getLoadTargheTecnicheSopralluogo")]
        public async Task<IActionResult> LoadTargheTecnicheSopralluogo([FromBody] EntityRichiesta richiesta)
        {
            List<string?> listTarghe = new List<string?>();

            TargheTecnicheManager targheTecnicheManagerManager = new TargheTecnicheManager(_RCDDbContext);
            
            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                if (richiesta.Location.IdOffice.HasValue)
                {
                    List<string?> listTT = new List<string?>() { "0073PICPE1", "1-BG-R1085", "tre", "quatro" };
                    var elementi = targheTecnicheManagerManager.GetTargheTecnicheByIdOffice(richiesta.Location.IdOffice.Value,null);
                    

                    if (elementi.Count() > 0)
                    {
                        (elementi as IEnumerable<EntityElement>).ToList().ForEach(item => listTarghe.Add(item.TargaTecnicaSap));

                    }

                }
                else if (richiesta.Location.Office != null)
                {
                    var elementi = targheTecnicheManagerManager.GetTargheTecnicheBySiglaOffice(richiesta.Location.Office);


                    if (elementi.Count() > 0)
                    {
                        (elementi as IEnumerable<EntityElement>).ToList().ForEach(item => listTarghe.Add(item.TargaTecnicaSap));

                    }
                }
                else
                {
                    var elementi = targheTecnicheManagerManager.GetTargheTecnicheBySiglaOffice(richiesta.Location.Office);


                    if (elementi.Count() > 0)
                    {
                        (elementi as IEnumerable<EntityElement>).ToList().ForEach(item => listTarghe.Add(item.TargaTecnicaSap));

                    }
                }

                jsonResult.Value = listTarghe.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = listTarghe.Count(), List = listTarghe.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("LoadTargheTecnicheSopralluogo finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero  LoadTargheTecnicheSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in LoadTargheTecnicheSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        #region TargheTechnicheBidone

        [HttpPost]
        [Route("getLoadTargheTechnicheBidone")]
        public async Task<IActionResult> LoadTargheTechnicheBidone([FromBody] EntityRichiesta richiesta)
        {
            List<string?> listTarghe = new List<string?>();

            TargheTecnicheManager targheTecnicheManagerManager = new TargheTecnicheManager(_RCDDbContext);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;

                    var elementi = targheTecnicheManagerManager.GetTargheTecnicheBidoneByIdZona(richiesta.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id);

                    if (elementi.Count() > 0)
                    {
                            (elementi as IEnumerable<EntityTargheTechnicheBidone>).ToList().ForEach(item => listTarghe.Add(item.TargaTecnica));

                            List<EntityInstallazioneApparati>? listaApparati = new List<EntityInstallazioneApparati>();
                            string[] daScartare = new string[2];

                            daScartare[0] = "mini";//Mini

                            daScartare[1] = "femto";

                        var entityInsApparati = targheTecnicheManagerManager.GetInstallApparati(richiesta.IdInstallazione);

                        foreach (EntityInstallazioneApparati item in entityInsApparati)
                        {

                            if (!daScartare.Contains((item.Apparati.TipologiaApparato.TipologiaApparato).ToLower()))
                            {
                                listaApparati.Add(item);
                            }

                        }

                        if (listaApparati.Count() > 0)

                        {
                                if (richiesta.Location.IdOffice.HasValue)
                                {
                                    var element = targheTecnicheManagerManager.GetTargheTecnicheByIdOffice(richiesta.Location.IdOffice.Value, null);
                                    if (element.Count() > 0)
                                    {
                                        (element as IEnumerable<EntityElement>).ToList().ForEach(item => listTarghe.Add(item.TargaTecnicaSap));
                                    }
                                }
                        }
                    }

                jsonResult.Value = listTarghe.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = listTarghe.Count(), List = listTarghe.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTargheTecnicheBidoneByIdZona finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero  GetTargheTecnicheBidoneByIdZona" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetTargheTecnicheBidoneByIdZona " + ex.Message);
            }

            return jsonResult;
        }
        #endregion TargheTechnicheBidone

    }
}
