﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Location;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;


namespace RCD.Controllers.Locationi
{

    [ApiController]
    [Route("location/[controller]")]
    public class DettaglioCostiLocationController : _BaseController
    {
        private readonly ILogger<DettaglioCostiLocationController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        private Int32 counterDiRisposteAsync = 0;

        public DettaglioCostiLocationController(ILogger<DettaglioCostiLocationController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("GetLocationCME")]
        public async Task<IActionResult> GetLocationCME([FromBody] LocationCmeRequestFull location)
        {
            DettaglioCostiLocationManager dettaglioCostoLocationManager = new DettaglioCostiLocationManager(_RCDDbContext);

            var locations = await dettaglioCostoLocationManager.GetCostiLocationCME(location);
            Int32 totLocations = await dettaglioCostoLocationManager.GetCostiLocationCMETot(location);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = locations.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totLocations, List = locations.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetLocationCME finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero  LocationCME" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetLocationCME " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addLocationCME")]
        public async Task<IActionResult> AddCostiLocationCME([FromBody] LocationCmeRequest location)
        {

            DettaglioCostiLocationManager dettaglioCostoLocationManager = new DettaglioCostiLocationManager(_RCDDbContext);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioCostoLocationManager.AddCostiLocationCME(location);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " CostiLocationCME aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddCostiLocationCME finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento CostiLocationCME" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddCostiLocationCME " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editLocationCME")]
        public async Task<IActionResult> UpdateLocationCME([FromBody] LocationCmeRequest location)
        {

            DettaglioCostiLocationManager dettaglioCostoLocationManager = new DettaglioCostiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioCostoLocationManager.UpdateLocationCME(location);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationCME modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editLocationCMEE finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica  LocationCME" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editLocationCME " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteLocationCME")]
        public async Task<IActionResult> DeleteLocationCME([FromBody] LocationCmeRequest location)
        {

            DettaglioCostiLocationManager dettaglioCostoLocationManager = new DettaglioCostiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioCostoLocationManager.DeleteLocationCME(location);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationCME cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteLocationCME finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione  LocationCME" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteLocationCME " + ex.Message);
            }

            return jsonResult;
        }



    }
}
