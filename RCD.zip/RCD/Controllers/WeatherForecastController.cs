using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace RCD.Controllers
{
	[ApiController]
	[Route("[controller]")]
	public class WeatherForecastController : ControllerBase
	{
		private static readonly string[] Summaries = new[]
		{
		"Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
	};

		//modifica Daniela

		private readonly ILogger<WeatherForecastController> _logger;
		private IConfigurationRoot _configuration;
		private readonly IHttpContextAccessor _httpContextAccessor;

		private readonly RCDEngine.RCDDbContext? _RCDDbContext;

		public WeatherForecastController(ILogger<WeatherForecastController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext)
		{
			_logger = logger;
			_configuration = (IConfigurationRoot)configuration;
			_httpContextAccessor = httpContextAccessor;

			_RCDDbContext = RCDDbContext;
			//_RCDDbContext.RequestUrl = _httpContextAccessor.HttpContext.Request.Path;
		}

		[HttpGet]
		public async Task<IEnumerable<WeatherForecast>> Get()
		{
			String pippo = _configuration["AppSettings:Local-PAOLOW10:DatabaseName"];

			//var utente = await _RCDDbContext.Utente.ToListAsync();


			return Enumerable.Range(1, 5).Select(index => new WeatherForecast
			{
				Date = DateTime.Now.AddDays(index),
				TemperatureC = Random.Shared.Next(-20, 55),
				Summary = pippo, // Summaries[Random.Shared.Next(Summaries.Length)]
				Utente = ""
			})
			.ToArray();
		}
	}
}