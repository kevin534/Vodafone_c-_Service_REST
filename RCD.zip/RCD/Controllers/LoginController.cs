﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code;
using RCD.Code.Main;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDContracts.Response;
using RCDEngine.Entities;
using System.Security.Claims;

namespace RCD.Controllers
{
	[ApiController]
	[Route("[controller]")]
	public class LoginController : _BaseController
	{
		private readonly ILogger<LoginController> _logger;
		private IConfigurationRoot _configuration;
		private readonly IHttpContextAccessor _httpContextAccessor;

		private readonly RCDEngine.RCDDbContext? _RCDDbContext;

		public LoginController(ILogger<LoginController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
		{
			_logger = logger;
			_configuration = (IConfigurationRoot)configuration;
			_httpContextAccessor = httpContextAccessor;

			_RCDDbContext = RCDDbContext;
		}

   //     [HttpGet]
   //     public async Task<IActionResult> Get()
   //     {
			//_logger.LogInformation("Login: {time}", DateTimeOffset.Now); 
			//JsonResult jsonResult = new JsonResult(null);
   //         jsonResult.StatusCode = 200;
   //         try
   //         {
			//	var utente = await _RCDDbContext.Utente.ToListAsync();



			//	//DataResponse dataResponse = new DataResponse();
			//	//dataResponse.Code = "Ciao da Paolo " + DateTime.UtcNow.ToString("yyyy-MM-dd HH.mm.ss");
			//	//dataResponse.Message = "CIAO";


			//	jsonResult.Value = utente[0]; //dataResponse
			//}
			//catch (Exception e)
   //         {
			//	jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di login utente" })
			//	{
			//		StatusCode = 500,
			//	};
			//	_logger.LogError("Error in Login " + e.Message);
			//}
			

   //         return jsonResult;
   //     }
        [HttpPost]
		[Route("Login")]
		public async Task<IActionResult> Login([FromBody] LoginRequest input)
		{
			
			JsonResult jsonResult = new JsonResult(null);
			jsonResult.StatusCode = 200;


			if (String.IsNullOrEmpty(input.Username) || String.IsNullOrEmpty(input.Password))
			{
				string error = "Impossibile procedere con l'operazione richiesta. Dati in input mancanti: ";
				if (String.IsNullOrEmpty(input.Username))
				{
					error += "Username ";
				}
				if (String.IsNullOrEmpty(input.Password))
				{
					error += "Password";
				}
				jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = error })
				{
					StatusCode = 200,
				};
				_logger.LogError("Error in Login " + error);
			}
            else
            {
                try
                {
					EnumerateManager.ENVIRONMENT_TYPE environmentType = UtilityManager.CurrentEnvironment(_httpContextAccessor.HttpContext.Request.Host.Host);
					LoginManager loginManager = new LoginManager(environmentType, _configuration, _RCDDbContext);
					EntityUtente resUtente = await loginManager.Login(input);
					List<ContractMenuUtente> privilegiRuolo = await loginManager.GetMenuByUtente(resUtente);
					LoginResultData resultData = new LoginResultData();
					String token = loginManager.CreateTokenAuthenticatedContext(resUtente);
					resultData.Result = "SUCCESS";
					bool checkIdentity = resUtente.AreaVendita != null && (bool)(resUtente.TipologiaUtente.IsVendita);
					
					

					LoginPayloadAuthUserDetails payloadAuthUserDetails = new LoginPayloadAuthUserDetails
					{
						UserId = resUtente.Id,
						Username = resUtente.Username,
						Nome = resUtente.Nome,
						Cognome = resUtente.Cognome,
						Mail = resUtente.Mail,
						Dipartimento= (resUtente.TipologiaUtente != null ? resUtente.TipologiaUtente.TipologiaUtente: ""),
						Direzione= (resUtente.AreaVendita != null ? resUtente.AreaVendita.CanaleVenditaDettaglio.CanaleVendita.Canale : ""),
						Divisione = (resUtente.AreaVendita != null ? resUtente.AreaVendita.CanaleVenditaDettaglio.Descrizione : ""),
						AreaVendita= (resUtente.AreaVendita != null ? resUtente.AreaVendita.Descrizione : ""),
						CheckIdentity = checkIdentity,
						ListaFunzioni = privilegiRuolo,
						Ruoli = new List<string> { resUtente.Ruolo.NoteRuolo }

					};
					LoginPayloadAccount payloadAccount = new LoginPayloadAccount { Username = resUtente.Username };

					LoginPayload loginPayload = new LoginPayload
					{
						Account = payloadAccount,
						AuthUserDetails = payloadAuthUserDetails,
						AuthorizationHeader = "bearer " + token,
						Error_code = 0
					};
					resultData.Payload = loginPayload;
					jsonResult = new JsonResult(resultData)
					{
						StatusCode = 200
					};
					_logger.LogInformation("Login finish at: {time}", DateTimeOffset.Now);
				}
				catch (Exception ex)
                {
					jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = ex.Message })
					{
						StatusCode = 200,
					};
					_logger.LogError("Error in Login " + ex.Message);
				}
				
			}
			

			return jsonResult;
		}

		[HttpPost]
		[Authorize]
		[Route("Logout")]
		public async Task<IActionResult> Logout()
        {
			var identity = User.Identity as ClaimsIdentity;
			Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
			string idUtente = claim.Value;
			
			
			JsonResult jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Logout user eseguito con successo." });
			jsonResult.StatusCode = 200;
			return jsonResult;
		}
        
	}
}
