﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Request;

namespace RCD.Controllers
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class ZoneController : _BaseController
    {
        private readonly ILogger<LoginController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public ZoneController(ILogger<LoginController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("getZone")]
        public async Task<IActionResult> GetUtenti([FromBody] ZonaRequestFull zona)
        {

            ZoneManager zoneManager = new ZoneManager(_RCDDbContext);

            var zone = await zoneManager.GetZone(zona);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = zone.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = zone.ToList().Count, List = zone.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtenti finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utenti" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getUtenti " + ex.Message);
            }

            return jsonResult;
        }
    }
}
