﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Data;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class DitteController : _BaseController
    {

        private readonly ILogger<DitteController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public DitteController(ILogger<DitteController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("getDitte")]
        public async Task<IActionResult> GetDitte([FromBody] DittaRequestFull ditta)
        {
            DitteManager ditteManager = new DitteManager(_RCDDbContext);

            var ditte = await ditteManager.GetDitte(ditta);
            Int32 totDitte = await ditteManager.GetDitteTot(ditta);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = ditte.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totDitte, List = ditte.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetDitte finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero ditte" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getDitte " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddDitte([FromBody] DittaRequest ditta)
        {

            DitteManager ditteManager = new DitteManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                ditteManager.AddDitta(ditta);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Ditta aggiunta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetDitte finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento ditta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddDitta " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditDitta([FromBody] DittaRequest ditta)
        {

            DitteManager ditteManager = new DitteManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                ditteManager.UpdateDitta(ditta);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Ditta modificata con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetDitte finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica ditta:" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditDitta " + ex.Message);
            }

            return jsonResult;
        }

        /// <summary>
        /// cancellazione logica dell'antenna (abilitato = false)
        /// </summary>
        /// <param name="antenna"></param>
        /// <returns></returns>
        //[Route("delete")]
        [HttpPost]
        [Route("delete")]
        public async Task<IActionResult> DeleteDitta([FromBody] DittaRequest ditta)
        {

            DitteManager ditteManager = new DitteManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                ditteManager.DeleteDitta(ditta);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Ditta eliminata con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetDitte finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di eliminazione ditta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteDitta " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("getAnagraficaFornitoriSts")]
        public async Task<IActionResult> GetAnagraficaFornitoriSts([FromBody] AnagraficaFornitoriRequestFull  anagraficaFornitore)
        {
            DitteManager anagraficaFornitoriStsManager = new DitteManager(_RCDDbContext);

            // var idDitteCode = _RCDDbContext.Ditta.Include("Zona").Select(q => q.IdVendor).Distinct().ToList();
            var idDitteCode = _RCDDbContext.Ditta.Select(q => q.IdVendor).Distinct().ToList();

            var anagraficaFornitoriSts = await anagraficaFornitoriStsManager.GetAnagraficaFornitoriSts(anagraficaFornitore, idDitteCode);
            Int32 totAnagraficaFornitoriSts = await anagraficaFornitoriStsManager.GetAnagraficaFornitoriStsTot(anagraficaFornitore, idDitteCode);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = anagraficaFornitoriSts.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totAnagraficaFornitoriSts, List = anagraficaFornitoriSts.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAnagraficaFornitoriSts finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero anagrafica fornitori" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getAnagraficaFornitoriSts " + ex.Message);
            }

            return jsonResult;
        }
    }
}
