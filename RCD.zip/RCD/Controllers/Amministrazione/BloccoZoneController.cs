﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class BloccoZoneController : _BaseController
    {
        private readonly ILogger<BloccoZoneController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public BloccoZoneController(ILogger<BloccoZoneController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditBloccoZone([FromBody] List<ZonaRequest> listZona)
        {

            BloccoZoneManager bloccozoneManager = new BloccoZoneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {             
               foreach (ZonaRequest varElenco in listZona)
                {
                    bloccozoneManager.UpdateBloccoZone(varElenco);
                }

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "BloccoZona modificata con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("BloccoZona finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica bloccaZona" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditZona " + ex.Message);
            }

            return jsonResult;
        }
    }
}
