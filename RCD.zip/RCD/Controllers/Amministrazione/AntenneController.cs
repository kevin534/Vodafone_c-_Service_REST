﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Data;
using RCD.Code;
using RCDContracts.Request;


namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class AntenneController : _BaseController
    {

        private readonly ILogger<AntenneController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public AntenneController(ILogger<AntenneController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("getAntenne")]
        public async Task<IActionResult> GetAntenne([FromBody] AntennaRequestFull antenna)
        {
            AntenneManager antenneManager = new AntenneManager(_RCDDbContext);

            var antenne = await antenneManager.GetAntenne(antenna);
            Int32 totAntenne = await antenneManager.GetAntenneTot(antenna);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = antenne.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totAntenne, List = antenne.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAntenne finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero antenne" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getAntenne " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getAccessibilitaAntenne")]
        public async Task<IActionResult> GetAccessibilitaAntenne()
        {

            AntenneManager antenneManager = new AntenneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);

            try
            {
                var ant1 = await antenneManager.GetAccessibilitaAntenne();
                jsonResult.StatusCode = 200;
                jsonResult.Value = ant1.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = ant1.ToList().Count, List = ant1.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAccessibilitaAntenne finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetAccessibilitaAntenne" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetAccessibilitaAntenne " + ex.Message);
            }

            return jsonResult;
        }


        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddAntenne([FromBody] AntennaRequest antenna)
        {

            AntenneManager antenneManager = new AntenneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                antenneManager.AddAntenna(antenna);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Antenna aggiunta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAntenne finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento antenna" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddAntenna " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditAntenna([FromBody] AntennaRequest antenna)
        {

            AntenneManager antenneManager = new AntenneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                antenneManager.UpdateAntenna(antenna);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Antenna modificata con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAntenne finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica antenna" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditAntenna " + ex.Message);
            }

            return jsonResult;
        }

        /// <summary>
        /// cancellazione logica dell'antenna (abilitato = false)
        /// </summary>
        /// <param name="antenna"></param>
        /// <returns></returns>
        //[Route("delete")]
        [HttpPost]
        [Route("delete")]
        public async Task<IActionResult> DeleteAntenna([FromBody] AntennaRequest antenna)
        {

            AntenneManager antenneManager = new AntenneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                antenneManager.DeleteAntenna(antenna);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Antenna eliminato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAntenne finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di eliminazione antenna" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteAntenna " + ex.Message);
            }

            return jsonResult;
        }
        [HttpGet]
        [Route("getFrequenzaLTE")]
        public async Task<IActionResult> GetFrequenzaLTE()
        {
            AntenneManager areaVenditaManager = new AntenneManager(_RCDDbContext);

            var freq = await areaVenditaManager.GetFrequenzaLTE();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = freq.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = freq.ToList().Count, List = freq.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetFrequenzaLTE finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetFrequenzaLTE" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetFrequenzaLTE " + ex.Message);
            }

            return jsonResult;
        }
        [HttpGet]
        [Route("getLocalizzazioneAntenna")]
        public async Task<IActionResult> GetLocalizzazioneAntenna()
        {
            AntenneManager areaVenditaManager = new AntenneManager(_RCDDbContext);

            var loc = await areaVenditaManager.GetLocalizzazioneAntenna();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = loc.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = loc.ToList().Count, List = loc.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetLocalizzazioneAntenna finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetLocalizzazioneAntenna" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetLocalizzazioneAntenna " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getTTInstallazioneAntenna")]
        public async Task<IActionResult> GetTTInstallazioneAntenna()
        {
            AntenneManager areaVenditaManager = new AntenneManager(_RCDDbContext);

            var install = await areaVenditaManager.GetTTInstallazioneAntenna();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = install.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = install.ToList().Count, List = install.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTTInstallazioneAntenna finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetTTInstallazioneAntenna" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetTTInstallazioneAntenna " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getTipologiaCopertura")]
        public async Task<IActionResult> GetTipologiaCopertura()
        {
            AntenneManager areaVenditaManager = new AntenneManager(_RCDDbContext);

            var tipCopertura = await areaVenditaManager.GetTipologiaCopertura();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = tipCopertura.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = tipCopertura.ToList().Count, List = tipCopertura.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaCopertura finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetTipologiaCopertura" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetTipologiaCopertura " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getTipologiaLan")]
        public async Task<IActionResult> GetTipologiaLan()
        {
            AntenneManager areaVenditaManager = new AntenneManager(_RCDDbContext);

            var tipLan = await areaVenditaManager.GetTipologiaLan();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = tipLan.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = tipLan.ToList().Count, List = tipLan.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaLan finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetTipologiaLan" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetTipologiaLan " + ex.Message);
            }

            return jsonResult;
        }
        [HttpGet]
        [Route("getTipologiaSegnaleAntenna")]
        public async Task<IActionResult> GetTipologiaSegnaleAntenna()
        {
            AntenneManager areaVenditaManager = new AntenneManager(_RCDDbContext);

            var tipSegnale = await areaVenditaManager.GetTipologiaSegnaleAntenna();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = tipSegnale.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = tipSegnale.ToList().Count, List = tipSegnale.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaSegnaleAntenna finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetTipologiaSegnaleAntenna" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetTipologiaSegnaleAntenna " + ex.Message);
            }


            return jsonResult;
        }
        [HttpGet]
        [Route("getSistemaMisure")]
        public async Task<IActionResult> GetSistemaMisure()
        {
            AntenneManager areaVenditaManager = new AntenneManager(_RCDDbContext);

            var sistemaMisure = await areaVenditaManager.GetSistemaMisure();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = sistemaMisure.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = sistemaMisure.ToList().Count, List = sistemaMisure.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetSistemaMisure finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetSistemaMisure" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetSistemaMisure " + ex.Message);
            }

            return jsonResult;
        }
        [HttpGet]
        [Route("getTipologiaMisura")]
        public async Task<IActionResult> GetTipologiaMisura()
        {
            AntenneManager areaVenditaManager = new AntenneManager(_RCDDbContext);

            var tipologiaMisure = await areaVenditaManager.GetTipologiaMisura();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = tipologiaMisure.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = tipologiaMisure.ToList().Count, List = tipologiaMisure.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaMisura finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetTipologiaMisura" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetTipologiaMisura " + ex.Message);
            }

            return jsonResult;
        }

    }
}
