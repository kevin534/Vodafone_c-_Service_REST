﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCD.Code;
using RCDContracts;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class TipologiaApparatoController : _BaseController
    {
        private readonly ILogger<LoginController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public TipologiaApparatoController(ILogger<LoginController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }
        [HttpPost]
        [Route("getTipologiaApparato")]
        public async Task<IActionResult> GetTipologiaApparato([FromBody] TipologiaApparatoRequestFull tipologiaApparato)
        {
            TipologiaApparatoManager tipologiaApparatiManager = new TipologiaApparatoManager(_RCDDbContext);

            var tipologiaApparati = await tipologiaApparatiManager.GetTipologiaApparato(tipologiaApparato);
            Int32 totTipologiaApparati = await tipologiaApparatiManager.GetTipologiaApparatoTot(tipologiaApparato);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = tipologiaApparati.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totTipologiaApparati, List = tipologiaApparati.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaApparato finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero tipologiaApparati" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getTipologiaApparati " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddTipologiaApparato([FromBody] TipologiaApparatoRequest tipologiaApparato)
        {

            TipologiaApparatoManager tipologiaApparatiManager = new TipologiaApparatoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaApparatiManager.AddTipologiaApparato(tipologiaApparato);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaApparato aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaApparati finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento tipologiaApparato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddTipologiaApparato " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditTipologiaApparato([FromBody] TipologiaApparatoRequest tipologiaApparato)
        {

            TipologiaApparatoManager tipologiaApparatiManager = new TipologiaApparatoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaApparatiManager.UpdateTipologiaApparato(tipologiaApparato);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaApparato modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaApparati finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica tipologiaApparato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditTipologiaApparato " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("delete")]
        public async Task<IActionResult> DeleteTipologiaApparato([FromBody] TipologiaApparatoRequest tipologiaApparato)
        {

            TipologiaApparatoManager tipologiaApparatiManager = new TipologiaApparatoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaApparatiManager.DeleteTipologiaApparato(tipologiaApparato);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaApparato cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaApparati finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di delete tipologiaApparato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteTipologiaApparato " + ex.Message);
            }

            return jsonResult;
        }



    }
}
