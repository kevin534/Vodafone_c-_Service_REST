﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class AreaVenditaController : _BaseController
    {
        private readonly ILogger<AreaVenditaController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public AreaVenditaController(ILogger<AreaVenditaController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }
        [HttpGet]
        [Route("getAreaVendita")]
        public async Task<IActionResult> GetAreaVendita()
        {

            AreaVenditaManager areaVenditaManager = new AreaVenditaManager(_RCDDbContext);

            var areeVendita = await areaVenditaManager.GetAreeVendita();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = areeVendita.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = areeVendita.ToList().Count, List = areeVendita.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtenti finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utenti" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getUtenti " + ex.Message);
            }

            return jsonResult;
        }
        [HttpGet]
        [Route("getProvince")]
        public async Task<IActionResult> GetProvince()
        {
            AreaVenditaManager areaVenditaManager = new AreaVenditaManager(_RCDDbContext);

            var province = await areaVenditaManager.GetProvince();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = province.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = province.ToList().Count, List = province.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtenti finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utenti" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getUtenti " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("getProvinceUtente")]
        public async Task<IActionResult> GetProvinceUtente(UtenteRequest utente)
        {
            AreaVenditaManager areaVenditaManager = new AreaVenditaManager(_RCDDbContext);

            var province = await areaVenditaManager.GetProvinceUtente(utente);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = province.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = province.ToList().Count, List = province.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtenti finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utenti" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getUtenti " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getCanaleVendita")]
        public async Task<IActionResult> GetCanaleVendita()
        {

            AreaVenditaManager areaVenditaManager = new AreaVenditaManager(_RCDDbContext);

            var canaleVendita = await areaVenditaManager.GetCanaleVendita();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = canaleVendita.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = canaleVendita.ToList().Count, List = canaleVendita.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetCanaleVendita finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetCanaleVendita" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetCanaleVendita " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("getCanaleVenditaDettaglioByIdCanaleV")]
        public async Task<IActionResult> GetCanaleVenditaDettaglioByIdCanaleV(CanaleVenditaDettaglioRequestFull canale)
        {
            AreaVenditaManager areaVenditaManager = new AreaVenditaManager(_RCDDbContext);

            var canali = await areaVenditaManager.GetCanaleVenditaDettaglioByIdCanaleV(canale);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = canali.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = canali.ToList().Count, List = canali.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetCanaleVenditaDettaglioByIdCanaleV finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetCanaleVenditaDettaglioByIdCanaleV" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetCanaleVenditaDettaglioByIdCanaleV " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("getDistrettoByIdCanaleV")]
        public async Task<IActionResult> GetDistrettoByIdCanaleV(DistrettoRequestFull distretto)
        {
            AreaVenditaManager areaVenditaManager = new AreaVenditaManager(_RCDDbContext);

            var distretti = await areaVenditaManager.GetDistrettoByIdCanaleV(distretto);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = distretti.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = distretti.ToList().Count, List = distretti.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetDistrettoByIdCanaleV finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetDistrettoByIdCanaleV" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetDistrettoByIdCanaleV " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("getAreaByIdCanaleV")]
        public async Task<IActionResult> GetAreaByIdCanaleV(AreaRequestFull area)
        {
            AreaVenditaManager areaVenditaManager = new AreaVenditaManager(_RCDDbContext);

            var arei = await areaVenditaManager.GetAreaByIdCanaleV(area);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = arei.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = arei.ToList().Count, List = arei.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAreaByIdCanaleV finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetAreaByIdCanaleV" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetAreaByIdCanaleV " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("getAreaVenditeByIdCanaleV")]
        public async Task<IActionResult> GetAreaVenditeByIdCanaleV(AreaVenditaRequestFull area)
        {
            AreaVenditaManager areaVenditaManager = new AreaVenditaManager(_RCDDbContext);

            var arei = await areaVenditaManager.GetAreaVenditeByIdCanaleV(area);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = arei.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = arei.ToList().Count, List = arei.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAreaVenditeByIdCanaleV finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetAreaVenditeByIdCanaleV" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetAreaVenditeByIdCanaleV " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getTipologiaCliente")]
        public async Task<IActionResult> GetTipologiaCliente()
        {
            AreaVenditaManager areaVenditaManager = new AreaVenditaManager(_RCDDbContext);

            var tipClient = await areaVenditaManager.GetTipologiaCliente();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = tipClient.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = tipClient.ToList().Count, List = tipClient.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaCliente finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetTipologiaCliente" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetTipologiaCliente " + ex.Message);
            }

            return jsonResult;
        }
        [HttpGet]
        [Route("getStsRegione")]
        public async Task<IActionResult> GetStsRegione()
        {
            AreaVenditaManager areaVenditaManager = new AreaVenditaManager(_RCDDbContext);

            var regione = await areaVenditaManager.GetStsRegione();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = regione.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = regione.ToList().Count, List = regione.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetStsRegione finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetStsRegione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetStsRegione " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("getStsProvinciaByIdRegioneSts")]
        public async Task<IActionResult> GetStsProvinciaByIdRegioneSts(StsProvinciaRequestFull provincia)
        {
            AreaVenditaManager areaVenditaManager = new AreaVenditaManager(_RCDDbContext);

            var province = await areaVenditaManager.GetStsProvinciaByIdRegioneSts(provincia);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = province.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = province.ToList().Count, List = province.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetStsProvinciaByIdRegioneSts finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetStsProvinciaByIdRegioneSts" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetStsProvinciaByIdRegioneSts " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("getStsCommuneByIdProvinciaSts")]
        public async Task<IActionResult> GetStsCommuneByIdProvinciaSts(StsComuneRequestFull comune)
        {
            AreaVenditaManager areaVenditaManager = new AreaVenditaManager(_RCDDbContext);

            var comuni = await areaVenditaManager.GetStsCommuneByIdProvinciaSts(comune);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = comuni.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = comuni.ToList().Count, List = comuni.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetStsCommuneByIdProvinciaSts finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetStsCommuneByIdProvinciaSts" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetStsCommuneByIdProvinciaSts " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("getOfficeByIdComune")]
        public async Task<IActionResult> GetOfficeByIdComune(OfficeRequestFull office)
        {
            AreaVenditaManager areaVenditaManager = new AreaVenditaManager(_RCDDbContext);

            var offici = await areaVenditaManager.GetOfficeByIdComune(office);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = offici.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = offici.ToList().Count, List = offici.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetOfficeByIdComune finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetOfficeByIdComune" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetOfficeByIdComune " + ex.Message);
            }

            return jsonResult;
        }
    }
}
