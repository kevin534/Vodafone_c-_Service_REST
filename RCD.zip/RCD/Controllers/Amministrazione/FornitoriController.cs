﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Request;
using RCD.Code;

namespace RCD.Controllers.Amministrazione
{
    //[Route("api/[controller]")]
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class FornitoriController : _BaseController
    {
        private readonly ILogger<FornitoriController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public FornitoriController(ILogger<FornitoriController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("getFornitori")]
        public async Task<IActionResult> GetFornitori([FromBody] FornitoreRequestFull fornitore)
        {

            FornitoriManager fornitoriManager = new FornitoriManager(_RCDDbContext);

            var fornitori = await fornitoriManager.GetFornitori(fornitore);
            Int32 totFornitori = await fornitoriManager.GetFornitoriTot(fornitore);
        
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = fornitori.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totFornitori, List = fornitori.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetFornitori finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero fornitori" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getFornitori " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddFornitore([FromBody] FornitoreRequest fornitore)
        {

            FornitoriManager fornitoriManager = new FornitoriManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                fornitoriManager.AddFornitore(fornitore);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Fornitore aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetFornitori finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento fornitore" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddFornitore " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditFornitore([FromBody] FornitoreRequest fornitore)
        {

            FornitoriManager fornitoriManager = new FornitoriManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                fornitoriManager.UpdateFornitore(fornitore);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Fornitore modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetFornitori finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica fornitore" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditFornitore " + ex.Message);
            }

            return jsonResult;
        }

        /// <summary>
        /// cancellazione logica del fornitore (abilitato = false)
        /// </summary>
        /// <param name="fornitore"></param>
        /// <returns></returns>
        //[Route("delete")]
        [HttpPost]
        [Route("delete")]    
        public async Task<IActionResult> DeleteFornitore([FromBody] FornitoreRequest fornitore)
        {

            FornitoriManager fornitoriManager = new FornitoriManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                fornitoriManager.DeleteFornitore(fornitore);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Fornitore eliminato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetFornitori finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di eliminazione fornitore" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteFornitore " + ex.Message);
            }

            return jsonResult;
        }
    }
}
