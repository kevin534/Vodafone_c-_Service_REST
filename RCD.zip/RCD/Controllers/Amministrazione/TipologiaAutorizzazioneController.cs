﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class TipologiaAutorizzazioneController : _BaseController
    {
        private readonly ILogger<TipologiaAutorizzazioneController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public TipologiaAutorizzazioneController(ILogger<TipologiaAutorizzazioneController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }
        [HttpPost]
        [Route("getTipologiaAutorizzazione")]
        public async Task<IActionResult> GetTipologiaAutorizzazione([FromBody] TipologiaAutorizzazioneRequestFull tipologiaAutorizzazione)
        {

            TipologiaAutorizzazioneManager tipologiaManager = new TipologiaAutorizzazioneManager(_RCDDbContext);

            var tipologiaAutorizzazioni = await tipologiaManager.GetTipologiaAutorizzazione(tipologiaAutorizzazione);
            Int32 tottipologia = await tipologiaManager.GetTipologiaAutorizzazioneTot(tipologiaAutorizzazione);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = tipologiaAutorizzazioni.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = tottipologia, List = tipologiaAutorizzazioni.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaAutorizzazioni finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero tipologiaAutorizzazioni" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getTipologiaAutorizzazioni " + ex.Message);
            }

            return jsonResult;
        }

    }
}
