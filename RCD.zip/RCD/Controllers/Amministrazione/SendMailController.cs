﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCD.Code;
using RCDContracts.Data;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class SendMailController : _BaseController
    {
        private readonly ILogger<UtentiController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public SendMailController(ILogger<UtentiController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }
        [HttpPost]
        [Route("send")]
        public async Task<IActionResult> SendMail([FromBody] SendMailRequest mail)
        {        
            JsonResult jsonResult = new JsonResult(null);
            try
            {
              
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Email inviata con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("SendMail finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di invio mail" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in SendMail " + ex.Message);
            }
            return jsonResult;
        }
       

    }
}
