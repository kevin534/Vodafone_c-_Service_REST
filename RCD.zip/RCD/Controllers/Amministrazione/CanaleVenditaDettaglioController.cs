﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class CanaleVenditaDettaglioController : _BaseController
    {
        private readonly ILogger<CanaleVenditaDettaglioController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public CanaleVenditaDettaglioController(ILogger<CanaleVenditaDettaglioController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }
        [HttpPost]
        [Route("getCanaleVenditaDettaglio")]
        public async Task<IActionResult> GetCanaleVenditaDettaglio([FromBody] CanaleVenditaDettaglioRequestFull canaleVenditaDettaglio)
        {

            CanaleVenditaDettaglioManager canaleManager = new CanaleVenditaDettaglioManager(_RCDDbContext);

            var canaleVenditaDettagli = await canaleManager.GetCanaleVenditaDettaglio(canaleVenditaDettaglio);
            Int32 totcanali = await canaleManager.GetCanaleVenditaDettaglioTot(canaleVenditaDettaglio);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = canaleVenditaDettagli.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totcanali, List = canaleVenditaDettagli.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetCanaleVenditaDettaglio finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero canaleVenditaDettaglio" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getCanaleVenditaDettagli " + ex.Message);
            }

            return jsonResult;
        }
       
    }
}
