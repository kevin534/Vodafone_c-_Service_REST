﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCD.Code;
using RCDContracts.Data;
using RCDContracts.Request;

namespace RCD.Controllers
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class SoglieMaterialiController : _BaseController
    {
        private readonly ILogger<SoglieMaterialiController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public SoglieMaterialiController(ILogger<SoglieMaterialiController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        #region "MAGAZZINO SOGLIE"

        [HttpPost]
        [Route("getMagazzinoSoglie")]
        public async Task<IActionResult> GetMagazzinoSoglie([FromBody] MagazzinoSogliaRequestFull magazzinoSoglie)
        {
            MagazziniSoglieManager magazziniSoglieManager = new MagazziniSoglieManager(_RCDDbContext);

            var magazziniSoglie = await magazziniSoglieManager.GetMagazzinoSoglieById(magazzinoSoglie);
            Int32 magazziniSoglieTot = await magazziniSoglieManager.GetMagazzinoSoglieTot(magazzinoSoglie);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = magazziniSoglie.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = magazziniSoglieTot, List = magazziniSoglie.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetMagazziniSoglie finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero Magazzini Soglie" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getMagazziniSoglie " + ex.Message);
            }

            return jsonResult;
        }

        #endregion  "Magazzino Soglie"

        #region "TIPOLOGIA APPARATO SOGLIA"
        [HttpPost]
        [Route("addTipologiaApparatoSoglia")]
        public async Task<IActionResult> AddTipologiaApparatoSoglia([FromBody] TipologiaApparatoSogliaRequest tipologiaApparatoSoglia)
        {

            MagazziniSoglieManager tipologiaApparatoSogliaManager = new MagazziniSoglieManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaApparatoSogliaManager.AddTipologiaApparatoSoglia(tipologiaApparatoSoglia);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaApparatoSoglia aggiunta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddTipologiaApparatoSoglia finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento tipologiaApparatoSoglia" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddTipologiaApparatoSoglia " + ex.Message);
            }

            return jsonResult;
        }
        
        [HttpPost]
        [Route("editTipologiaApparatoSoglia")]
        public async Task<IActionResult> EditTipologiaApparatoSoglia([FromBody] TipologiaApparatoSogliaRequest tipologiaApparatoSoglia)
        {

            MagazziniSoglieManager tipologiaApparatiSogliaManager = new MagazziniSoglieManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaApparatiSogliaManager.UpdateTipologiaApparatoSoglia(tipologiaApparatoSoglia);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaApparatoSoglia modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("EditTipologiaApparatiSoglia finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica tipologiaApparatoSoglia" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditTipologiaApparatoSoglia " + ex.Message);
            }

            return jsonResult;
        }
        
        [HttpPost]
        [Route("deleteTipologiaApparatoSoglia")]
        public async Task<IActionResult> DeleteTipologiaApparatoSoglia([FromBody] TipologiaApparatoSogliaRequest tipologiaApparatoSoglia)
        {

            MagazziniSoglieManager tipologiaApparatiSogliaManager = new MagazziniSoglieManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaApparatiSogliaManager.DeleteTipologiaApparatoSoglia(tipologiaApparatoSoglia);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaApparatoSoglia cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteTipologiaApparatiSoglia finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di delete tipologiaApparatoSoglia" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteTipologiaApparatoSoglia " + ex.Message);
            }

            return jsonResult;
        }
        #endregion

        #region "TIPOLOGIA ANTENNA SOGLIA"
        [HttpPost]
        [Route("addTipologiaAntennaSoglia")]
        public async Task<IActionResult> AddTipologiaAntennaSoglia([FromBody] TipologiaAntennaSogliaRequest tipologiaAntennaSoglia)
        {

            MagazziniSoglieManager tipologiaAntennaSogliaManager = new MagazziniSoglieManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaAntennaSogliaManager.AddTipologiaAntennaSoglia(tipologiaAntennaSoglia);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaAntennaSoglia aggiunta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddTipologiaAntennaSoglia finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento tipologiaApparatoSoglia" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddTipologiaAntennaSoglia " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("editTipologiaAntennaSoglia")]
        public async Task<IActionResult> EditTipologiaAntennaSoglia([FromBody] TipologiaAntennaSogliaRequest tipologiaAntennaSoglia)
        {

            MagazziniSoglieManager tipologiaAntennaSogliaManager = new MagazziniSoglieManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaAntennaSogliaManager.UpdateTipologiaAntennaSoglia(tipologiaAntennaSoglia);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaAntennaSoglia modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("EditTipologiaAntennaSoglia finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica tipologiaAntennaSoglia" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditTipologiaAntennaSoglia " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteTipologiaAntennaSoglia")]
        public async Task<IActionResult> DeleteTipologiaAntennaSoglia([FromBody] TipologiaAntennaSogliaRequest tipologiaAntennaSoglia)
        {

            MagazziniSoglieManager tipologiaAntennaSogliaManager = new MagazziniSoglieManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaAntennaSogliaManager.DeleteTipologiaAntennaSoglia(tipologiaAntennaSoglia);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaAntennaSoglia cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteTipologiaAntennaSoglia finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di delete tipologiaAntennaSoglia" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteTipologiaAntennaSoglia " + ex.Message);
            }

            return jsonResult;
        }
        #endregion

        #region "TIPOLOGIA ACCESSORIO SOGLIA"
        [HttpPost]
        [Route("addTipologiaAccessorioSoglia")]
        public async Task<IActionResult> AddTipologiaAccessorioSoglia([FromBody] TipologiaAccessorioSogliaRequest tipologiaAccessorioSoglia)
        {

            MagazziniSoglieManager tipologiaAccessorioSogliaManager = new MagazziniSoglieManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaAccessorioSogliaManager.AddTipologiaAccessorioSoglia(tipologiaAccessorioSoglia);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaAccessorioSoglia aggiunta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddTipologiaAccessorioSoglia finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento tipologiaAccessorioSoglia" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddTipologiaAccessorioSoglia " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("editTipologiaAccessorioSoglia")]
        public async Task<IActionResult> EditTipologiaAccessorioSoglia([FromBody] TipologiaAccessorioSogliaRequest tipologiaAccessorioSoglia)
        {

            MagazziniSoglieManager tipologiaAccessorioSogliaManager = new MagazziniSoglieManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaAccessorioSogliaManager.UpdateTipologiaAccessorioSoglia(tipologiaAccessorioSoglia);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaAccessorioSoglia modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("EditTipologiaAccessorioSoglia finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica tipologiaAccessorioSoglia" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditTipologiaAccessorioSoglia " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteTipologiaAccessorioSoglia")]
        public async Task<IActionResult> DeleteTipologiaAccessorioSoglia([FromBody] TipologiaAccessorioSogliaRequest tipologiaAccessorioSoglia)
        {

            MagazziniSoglieManager tipologiaAccessorioSogliaManager = new MagazziniSoglieManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaAccessorioSogliaManager.DeleteTipologiaAccessorioSoglia(tipologiaAccessorioSoglia);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaAccessorioSoglia cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteTipologiaAccessorioSoglia finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di delete tipologiaAccessorioSoglia" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteTipologiaAccessorioSoglia " + ex.Message);
            }

            return jsonResult;
        }
        #endregion 
    }
}
