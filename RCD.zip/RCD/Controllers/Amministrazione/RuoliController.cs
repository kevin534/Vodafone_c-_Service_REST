﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCD.Code;
using RCDContracts;
using RCDContracts.Request;


namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class RuoliController : _BaseController
    {
        private readonly ILogger<LoginController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public RuoliController(ILogger<LoginController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }
        [HttpPost]
        [Route("getRuoli")]
        public async Task<IActionResult> GetRuoli([FromBody] RuoloRequestFull ruolo)
        {
            RuoliManager ruoliManager = new RuoliManager(_RCDDbContext);

            var ruoli = await ruoliManager.GetRuoli(ruolo);
            Int32 totRuoli = await ruoliManager.GetRuoliTot(ruolo);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = ruoli.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totRuoli, List = ruoli.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRuoli finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero ruoli" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getRuoli " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddRuolo([FromBody] RuoloRequest ruolo)
        {

            RuoliManager ruoliManager = new RuoliManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                ruoliManager.AddRuolo(ruolo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Ruolo aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRuoli finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento ruolo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddRuolo " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditRuolo([FromBody] RuoloRequest ruolo)
        {

            RuoliManager ruoliManager = new RuoliManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                ruoliManager.UpdateRuolo(ruolo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Ruolo modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRuoli finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica ruolo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditRuolo " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("delete")]
        public async Task<IActionResult> DeleteRuolo([FromBody] RuoloRequest ruolo)
        {

            RuoliManager ruoliManager = new RuoliManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                ruoliManager.DeleteRuolo(ruolo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Ruolo modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRuoli finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica ruolo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditRuolo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("getPrivilegi")]
        public async Task<IActionResult> PrivilegiByRuolo([FromBody] RuoloRequest ruolo)
        {

            RuoliManager ruoliManager = new RuoliManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                var ruoli = await ruoliManager.GetPrivilegiByRuolo(ruolo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = ruoli.Count(), List = ruoli.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("getPrivilegi finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica ruolo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getPrivilegi " + ex.Message);
            }

            return jsonResult;
        }
    }
}
