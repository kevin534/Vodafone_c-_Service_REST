﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class MailController : _BaseController
    {
        private readonly ILogger<MailController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public MailController(ILogger<MailController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }
        [HttpPost]
        [Route("getMail")]
        public async Task<IActionResult> GetMail([FromBody] MailRequestFull mail)
        {

            MailManager mailiManager = new MailManager(_RCDDbContext);

            var mails = await mailiManager.GetMail(mail);
            Int32 totMails = await mailiManager.GetMailTot(mail);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = mails.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totMails, List = mails.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetMail finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero delle mails" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getMail " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddMail([FromBody] MailRequest mail)
        {

            MailManager mailManager = new MailManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                mailManager.AddMail(mail);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Mail aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetMail finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento di mail" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddMail " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditMail([FromBody] MailRequest mail)
        {

            MailManager mailManager = new MailManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                mailManager.UpdateMail(mail);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Mail modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetMail finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica mail" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditMail " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("delete")]
        public async Task<IActionResult> DeleteMail([FromBody] MailRequest mail)
        {

            MailManager mailManager = new MailManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                mailManager.DeleteMail(mail);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Mail cancellata con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetMail finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di cancellazione mail" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteMail " + ex.Message);
            }

            return jsonResult;
        }
    }
}
