﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class AreaVenditaUtenteController : _BaseController
    {
        private readonly ILogger<AreaVenditaUtenteController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public AreaVenditaUtenteController(ILogger<AreaVenditaUtenteController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("getAreaVenditaUtente")]
        public async Task<IActionResult> GetAreaVenditaUtente([FromBody] AreaVenditaUtenteRequestFull areaVenditaUtente)
        {

            AreaVenditaUtenteManager areaVenditaUtenteManager = new AreaVenditaUtenteManager(_RCDDbContext);

            var areeVenditaUtente = await areaVenditaUtenteManager.GetAreeVenditaUtente(areaVenditaUtente);
            Int32 areeVenditaUtenteCount = await areaVenditaUtenteManager.GetAreeVenditaUtenteTot(areaVenditaUtente);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = areeVenditaUtente.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = areeVenditaUtenteCount, List = areeVenditaUtente.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAreaVenditaUtente finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero aree vendita utenti" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetAreaVenditaUtente " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("getUtentiAreaVendita")]
        public async Task<IActionResult> GetUtentiAreaVendita([FromBody] AreaVenditaUtenteRequest areaVenditaUtente)
        {
            AreaVenditaUtenteManager areaVenditaUtenteManager = new AreaVenditaUtenteManager(_RCDDbContext);

            var utentiAreaVendita = await areaVenditaUtenteManager.GetUtentiAreaVendita(areaVenditaUtente);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = utentiAreaVendita.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = utentiAreaVendita.ToList().Count, List = utentiAreaVendita.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtenti finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utenti" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getUtenti " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddAreaVenditaUtente([FromBody] AreaVenditaUtenteRequest areaVenditaUtente)
        {

            AreaVenditaUtenteManager areaVenditaUtenteManager = new AreaVenditaUtenteManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                areaVenditaUtenteManager.AddAreaVenditaUtente(areaVenditaUtente);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Area vendita utente aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddAreaVenditaUtente finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento area vendita utente" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddAreaVenditaUtente " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditAreaVenditaUtente([FromBody] AreaVenditaUtenteRequest areaVenditaUtente)
        {

            AreaVenditaUtenteManager accessoriManager = new AreaVenditaUtenteManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                accessoriManager.UpdateAreaVenditaUtente(areaVenditaUtente);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Area vendita utente modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("EditAreaVenditaUtente finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica area vendita utente" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditAreaVenditaUtente " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("delete")]
        public async Task<IActionResult> DeleteAreaVenditaUtente([FromBody] AreaVenditaUtenteRequest areaVenditaUtente)
        {

            AreaVenditaUtenteManager accessoriManager = new AreaVenditaUtenteManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                accessoriManager.DeleteAreaVenditaUtente(areaVenditaUtente);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Area vendita utente eliminato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteAreaVenditaUtente finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di rimozione area vendita utente" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteAreaVenditaUtente " + ex.Message);
            }

            return jsonResult;
        }
    }
}
