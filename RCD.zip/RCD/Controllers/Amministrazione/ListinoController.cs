﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class ListinoController : _BaseController
    {
        private readonly ILogger<ListinoController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public ListinoController(ILogger<ListinoController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }
        [HttpPost]
        [Route("getListino")]
        public async Task<IActionResult> GetListino([FromBody] ListinoRequestFull listino)
        {

            ListinoManager listiniManager = new ListinoManager(_RCDDbContext);

            var listini = await listiniManager.GetListino(listino);
            Int32 totListini = await listiniManager.GetListinoTot(listino);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = listini.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totListini, List = listini.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetListini finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero listini" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getListini " + ex.Message);
            }

            return jsonResult;
        }
        
       
        
    }
}
