﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCD.Code;
using RCDContracts;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class TipologiaAccessorioController : _BaseController
    {
        private readonly ILogger<LoginController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public TipologiaAccessorioController(ILogger<LoginController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }
        [HttpPost]
        [Route("getTipologiaAccessorio")]
        public async Task<IActionResult> GetTipologiaAccessorio([FromBody] TipologiaAccessarioRequestFull tipologiaAccessorio)
        {
            TipologiaAccessorioManager tipologiaAccessorioManager = new TipologiaAccessorioManager(_RCDDbContext);

            var tipologiaAccessori = await tipologiaAccessorioManager.GetTipologiaAccessorio(tipologiaAccessorio);
            Int32 totTipologiaAccessorio = await tipologiaAccessorioManager.GetTipologiaAccessorioTot(tipologiaAccessorio);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = tipologiaAccessori.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totTipologiaAccessorio, List = tipologiaAccessori.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaAccessorio finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero tipologiaAccessori" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getTipologiaAccessorio " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddTipologiaAccessorio([FromBody] TipologiaAccessorioRequest tipologiaAccessorio)
        {

            TipologiaAccessorioManager tipologiaAccessoriManager = new TipologiaAccessorioManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaAccessoriManager.AddTipologiaAccessorio(tipologiaAccessorio);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaAccessorio aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaAccessorio finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento tipologiaAccessorio" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddTipologiaAccessorio " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditTipologiaAccessorio([FromBody] TipologiaAccessorioRequest tipologiaAccessorio)
        {

            TipologiaAccessorioManager tipologiaAccessoriManager = new TipologiaAccessorioManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaAccessoriManager.UpdateTipologiaAccessorio(tipologiaAccessorio);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaAccessorio modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaAccessorio finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica tipologiaAccessorio" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditTipologiaAccessorio " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("delete")]
        public async Task<IActionResult> DeleteTipologiaAccessorio([FromBody] TipologiaAccessorioRequest tipologiaAccessorio)
        {

            TipologiaAccessorioManager tipologiaAccessoriManager = new TipologiaAccessorioManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaAccessoriManager.DeleteTipologiaAccessorio(tipologiaAccessorio);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "TipologiaAccessorio cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaAccessorio finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di delete tipologiaAccessorio" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteTipologiaAccessorio " + ex.Message);
            }

            return jsonResult;
        }



    }
}

