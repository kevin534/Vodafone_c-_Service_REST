﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class UtentiController : _BaseController
    {
        private readonly ILogger<UtentiController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public UtentiController(ILogger<UtentiController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }
        [HttpPost]
        [Route("getUtenti")]
        public async Task<IActionResult> GetUtenti([FromBody] UtenteRequestFull utente)
        {

            UtentiManager utentiManager = new UtentiManager(_RCDDbContext);

            var utenti = await utentiManager.GetUtenti(utente);
            Int32 totUtenti = await utentiManager.GetUtentiTot(utente);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = utenti.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totUtenti, List = utenti.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtenti finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utenti" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getUtenti " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddUtente([FromBody] UtenteRequest utente)
        {

            UtentiManager utentiManager = new UtentiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                utentiManager.AddUtente(utente);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Utente aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtenti finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento utente" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddUtente " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditUtente([FromBody] UtenteRequest utente)
        {

            UtentiManager utentiManager = new UtentiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                utentiManager.UpdateUtente(utente);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Utente modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtenti finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica utente" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditUtente " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("delete")]
        public async Task<IActionResult> DeleteUtente([FromBody] UtenteRequest utente)
        {

            UtentiManager utentiManager = new UtentiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                utentiManager.DeleteUtente(utente);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Utente modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtenti finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica utente" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditUtente " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getTipologia")]
        public async Task<IActionResult> GetTiplogia()
        {

            UtentiManager utentiManager = new UtentiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            
            try
            {
                var tipologie = await utentiManager.GetTipologia();
                jsonResult.StatusCode = 200;
                jsonResult.Value = tipologie.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = tipologie.ToList().Count, List = tipologie.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTiplogia finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero tipologie utenti" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetTiplogia " + ex.Message);
            }

            return jsonResult;
        }
    }
}
