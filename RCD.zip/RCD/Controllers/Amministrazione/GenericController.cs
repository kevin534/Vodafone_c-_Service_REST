﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Data;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class GenericController : _BaseController
    {

        private readonly ILogger<GenericController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public GenericController(ILogger<GenericController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("getSistema")]
        public async Task<IActionResult> GetSistema([FromBody] SistemaRequestFull sistema)
        {
            SistemiManager sistemiManager = new SistemiManager(_RCDDbContext);

            var sistemi = await sistemiManager.GetSistemi(sistema);
            Int32 totSistemi = await sistemiManager.GetSistemiTot(sistema);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = sistemi.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totSistemi, List = sistemi.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetSistemi finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero sistemi" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getSistemi " + ex.Message);
            }

            return jsonResult;
        }
    }
}
    
