﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class AccessorioController : _BaseController
    {
        private readonly ILogger<AccessorioController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public AccessorioController(ILogger<AccessorioController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }
        [HttpPost]
        [Route("getAccessorio")]
        public async Task<IActionResult> GetAccessorio([FromBody] AccessorioRequestFull accessorio)
        {

            AccessorioManager accessoriManager = new AccessorioManager(_RCDDbContext);

            var accessori = await accessoriManager.GetAccessori(accessorio);
            Int32 totAccessori = await accessoriManager.GetAccessoriTot(accessorio);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = accessori.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totAccessori, List = accessori.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAccessori finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero accessori" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getAccessori " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddAccessorio([FromBody] AccessorioRequest accessorio)
        {

            AccessorioManager accessoriManager = new AccessorioManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                accessoriManager.AddAccessorio(accessorio);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Accessorio aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAccessorio finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento accessorio" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddAccessorio " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditAccessorioe([FromBody] AccessorioRequest accessorio)
        {

            AccessorioManager accessoriManager = new AccessorioManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                accessoriManager.UpdateAccessorio(accessorio);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Accessorio modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAccessorio finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica accessorio" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditAccessorio " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("delete")]
        public async Task<IActionResult> DeleteAccessorio([FromBody] AccessorioRequest accessorio)
        {

            AccessorioManager accessoriManager = new AccessorioManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                accessoriManager.DeleteAccessorio(accessorio);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Accessorio modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAccessori finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica accessorio" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditAccessorio " + ex.Message);
            }

            return jsonResult;
        }
    }
}
