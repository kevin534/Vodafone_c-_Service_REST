﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCD.Code;
using RCDContracts.Data;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class AlertController : _BaseController
    {

        private readonly ILogger<AlertController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;


        public AlertController(ILogger<AlertController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }


        [HttpPost]
        [Route("getEventiZonaById")]
        public async Task<IActionResult> GetEventiZonaById([FromBody] AlertRequestFull eventiZona)
        {
            AlertManager alertManager = new AlertManager(_RCDDbContext);

            var eventiZone = await alertManager.GetEventiZonaById(eventiZona);
            Int32 totEventiZone = await alertManager.GetEventiZoneTot(eventiZona);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = eventiZone.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totEventiZone, List = eventiZone.ToList() } }) 
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("getEventiZonaById finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero eventi-zone" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getEventiZonaById " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("getEventi")]
        public async Task<IActionResult> GetEventi([FromBody] AlertRequestFull evento)
        {
            AlertManager alertManager = new AlertManager(_RCDDbContext);

            var eventi = await alertManager.GetEventi(evento);
            Int32 totEventi = await alertManager.GetEventiTot(evento);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = eventi.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totEventi, List = eventi.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetEventi finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero eventi" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetEventi " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addAlert")]
        public async Task<IActionResult> AddAlert([FromBody] AlertRequestEventoZona eventoZona)
        {

            AlertManager tipologiaApparatoSogliaManager = new AlertManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaApparatoSogliaManager.AddAlert(eventoZona);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "alert aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("addAlert finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento alert" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in addAlert " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("editAlert")]
        public async Task<IActionResult> EditAlert([FromBody] AlertRequestEventoZona eventoZona)
        {

            AlertManager alertManager = new AlertManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                alertManager.UpdateAlert(eventoZona);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Alert modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("EditAlert finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica alert" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditAlert " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteAlert")]
        public async Task<IActionResult> DeleteAlert([FromBody] AlertRequestEventoZona eventoZona)
        {

            AlertManager alertManager = new AlertManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                alertManager.DeleteAlert(eventoZona);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Alert cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteAlert finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di delete alert" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteAlert " + ex.Message);
            }

            return jsonResult;
        }
    }
}
