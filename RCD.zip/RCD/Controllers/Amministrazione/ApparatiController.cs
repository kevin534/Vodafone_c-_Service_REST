﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCD.Code;
using RCDContracts.Data;
using RCDContracts.Request;


namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class ApparatiController : _BaseController
    {

        private readonly ILogger<ApparatiController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public ApparatiController(ILogger<ApparatiController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("getApparati")]
        public async Task<IActionResult> GetApparati([FromBody] ApparatiRequestFull apparato)
        {
            ApparatiManager apparatiManager = new ApparatiManager(_RCDDbContext);

            var apparati = await apparatiManager.GetApparato(apparato);
            Int32 totApparati = await apparatiManager.GetApparatoTot(apparato);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = apparati.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totApparati, List = apparati.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetApparati finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero apparato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getApparati " + ex.Message);
            }

            return jsonResult;
        }
        [HttpGet]
        [Route("getCriticita")]
        public async Task<IActionResult> GetCriticitaEMF()
        {

            ApparatiManager apparatiManager = new ApparatiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);

            try
            {
                var criticita = await apparatiManager.GetCritcitaEMF();
                jsonResult.StatusCode = 200;
                jsonResult.Value = criticita.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = criticita.ToList().Count, List = criticita.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetCriticitaEMF finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetCriticitaEMF" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetCriticitaEMF " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getInstallazioneApp")]
        public async Task<IActionResult> GetInstallazioneApp()
        {

            ApparatiManager apparatiManager = new ApparatiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);

            try
            {
                var app = await apparatiManager.GetInstallazioneApparato();
                jsonResult.StatusCode = 200;
                jsonResult.Value = app.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = app.ToList().Count, List = app.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetInstallazioneApp finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetInstallazioneApp" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetInstallazioneApp " + ex.Message);
            }

            return jsonResult;
        }
        [HttpGet]
        [Route("getRaggiungibilitaApp")]
        public async Task<IActionResult> GetRaggiungibilitaApp()
        {

            ApparatiManager apparatiManager = new ApparatiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);

            try
            {
                var app = await apparatiManager.GetRaggiungibilitaApparato();
                jsonResult.StatusCode = 200;
                jsonResult.Value = app.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = app.ToList().Count, List = app.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRaggiungibilitaApp finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRaggiungibilitaApp" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRaggiungibilitaApp " + ex.Message);
            }

            return jsonResult;
        }
        [HttpGet]
        [Route("getPosizioneApp")]
        public async Task<IActionResult> GetPosizioneApp()
        {

            ApparatiManager apparatiManager = new ApparatiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);

            try
            {
                var app = await apparatiManager.GetPosizioneApparato();
                jsonResult.StatusCode = 200;
                jsonResult.Value = app.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = app.ToList().Count, List = app.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetPosizioneApp finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetPosizioneApp" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetPosizioneApp " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddApparti([FromBody] ApparatiRequest apparato)
        {

            ApparatiManager apparatiManager = new ApparatiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                apparatiManager.AddApparato(apparato);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Apparato aggiunta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetApparato finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento apparato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddApparato " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditApparati([FromBody] ApparatiRequest apparato)
        {

            ApparatiManager apparatiManager = new ApparatiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                apparatiManager.UpdateApparato(apparato);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Apparato modificata con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetApparato finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica apparato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditApparato " + ex.Message);
            }

            return jsonResult;
        }

        /// <summary>
        /// cancellazione logica dell'antenna (abilitato = false)
        /// </summary>
        /// <param name="antenna"></param>
        /// <returns></returns>
        //[Route("delete")]
        [HttpPost]
        [Route("delete")]
        public async Task<IActionResult> DeleteApparati([FromBody] ApparatiRequest apparato)
        {

            ApparatiManager apparatiManager = new ApparatiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                apparatiManager.DeleteApparato(apparato);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Apparato eliminato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetApparati finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di eliminazione apparato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteApparato " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getStatoApparati")]
        public async Task<IActionResult> GetStatoApparati()
        {

            ApparatiManager apparatiManager = new ApparatiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);

            try
            {
                var apparato = await apparatiManager.GetStatoApparati();
                jsonResult.StatusCode = 200;
                jsonResult.Value = apparato.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = apparato.ToList().Count, List = apparato.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetStatoApparati finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero StatoApparati" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetStatoApparati " + ex.Message);
            }

            return jsonResult;
        }

    }
}
