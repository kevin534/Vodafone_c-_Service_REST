﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Data;
using RCD.Code;
using RCDContracts.Request;


namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class GovernanceController : _BaseController
    {

        private readonly ILogger<GovernanceController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public GovernanceController(ILogger<GovernanceController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("getGovernance")]
        public async Task<IActionResult> GetGovernance([FromBody] GovernanceRequestFull governance)
        {
            GovernanceManager governanceManager = new GovernanceManager(_RCDDbContext);

            var governances = await governanceManager.GetGovernance(governance);
            Int32 totGovernance = await governanceManager.GetGovernanceTot(governance);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = governances.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totGovernance, List = governances.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetGovernance finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero governance" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getGovernance " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddGovernance([FromBody] GovernanceRequest governance)
        {

            GovernanceManager governanceManager = new GovernanceManager(_RCDDbContext); 
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                governanceManager.AddGovernance(governance);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Governance aggiunta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetGovernance finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento governance" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddGovernance " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditGovernance([FromBody] GovernanceRequest governance)
        {

            GovernanceManager governanceManager = new GovernanceManager(_RCDDbContext); 
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                governanceManager.UpdateGovernance(governance);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Governance modificata con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetGovernance finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica governance" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditGovernance " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("delete")]
        public async Task<IActionResult> DeleteGovernance([FromBody] GovernanceRequest governance)
        {

            GovernanceManager governanceManager = new GovernanceManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                governanceManager.DeleteGovernance(governance);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Governance eliminato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetGovernance finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di eliminazione governance" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteGovernance " + ex.Message);
            }

            return jsonResult;
        }

    }
}
