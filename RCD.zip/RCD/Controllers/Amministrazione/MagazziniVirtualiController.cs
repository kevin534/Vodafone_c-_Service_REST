﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    //[Route("api/[controller]")]
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class MagazziniVirtualiController : _BaseController
    {
        private readonly ILogger<MagazziniVirtualiController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public MagazziniVirtualiController(ILogger<MagazziniVirtualiController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;
            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("getMagazziniVirtuali")]
        public async Task<IActionResult> GetMagazziniVirtuali([FromBody] MagazzinoVirtualeRequestFull magazzinoVirtuale)
        {
            MagazziniVirtualiManager magazziniVirtualiManager = new MagazziniVirtualiManager(_RCDDbContext);
            var magazziniVirtuali = await magazziniVirtualiManager.GetMagazziniVirtuali(magazzinoVirtuale);
            Int32 totMagazziniVirtuali = await magazziniVirtualiManager.GetMagazziniVirtualiTot(magazzinoVirtuale);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = magazziniVirtuali.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totMagazziniVirtuali, List = magazziniVirtuali.ToList() } })
                {
                    StatusCode = 200,
                };

                _logger.LogInformation("GetMagazziniVirtuali finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero magazzini virtuali" })
                {
                    StatusCode = 500,
                };

                _logger.LogError("Error in getMagazziniVirtuali " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddMagazzinoVirtuale([FromBody] MagazzinoVirtualeRequest magazzinoVirtuale)
        {
            MagazziniVirtualiManager magazziniVirtualiManager = new MagazziniVirtualiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);

            try
            {
                magazziniVirtualiManager.AddMagazzinoVirtuale(magazzinoVirtuale);

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Magazzino virtuale aggiunto con successo!" })
                {
                    StatusCode = 200,
                };

                _logger.LogInformation("GetMagazziniVirtuali finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento magazzino virtuale" })
                {
                    StatusCode = 500,
                };

                _logger.LogError("Error in AddMagazzinoVirtuale " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditMagazzinoVirtuale([FromBody] MagazzinoVirtualeRequest magazzinoVirtuale)
        {
            MagazziniVirtualiManager magazziniVirtualiManager = new MagazziniVirtualiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);

            try
            {
                magazziniVirtualiManager.UpdateMagazzinoVirtuale(magazzinoVirtuale);

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Magazzino virtuale modificato con successo!" })
                {
                    StatusCode = 200,
                };

                _logger.LogInformation("GetMagazziniVirtuali finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica magazzino virtuale" })
                {
                    StatusCode = 500,
                };

                _logger.LogError("Error in EditMagazzinoVirtuale " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("delete")]    
        public async Task<IActionResult> DeleteMagazzinoVirtuale([FromBody] MagazzinoVirtualeRequest magazzinoVirtuale)
        {
            MagazziniVirtualiManager magazziniVirtualiManager = new MagazziniVirtualiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);

            try
            {
                magazziniVirtualiManager.DeleteMagazzinoVirtuale(magazzinoVirtuale);

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Magazzino virtuale eliminato con successo!" })
                {
                    StatusCode = 200,
                };

                _logger.LogInformation("GetMagazziniVirtuali finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di eliminazione magazzino virtuale" })
                {
                    StatusCode = 500,
                };

                _logger.LogError("Error in DeleteMagazzinoVirtuale " + ex.Message);
            }

            return jsonResult;
        }
    }
}