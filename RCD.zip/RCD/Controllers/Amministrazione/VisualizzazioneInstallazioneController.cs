﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    
        [ApiController]
        [RenewToken]
        [Route("gestione/[controller]")]
        public class VisualizzazioneInstallazioneController : _BaseController
        {
            private readonly ILogger<VisualizzazioneInstallazioneController> _logger;
            private IConfigurationRoot _configuration;
            private readonly IHttpContextAccessor _httpContextAccessor;

            private readonly RCDEngine.RCDDbContext? _RCDDbContext;

            public VisualizzazioneInstallazioneController(ILogger<VisualizzazioneInstallazioneController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
            {
                _logger = logger;
                _configuration = (IConfigurationRoot)configuration;
                _httpContextAccessor = httpContextAccessor;

                _RCDDbContext = RCDDbContext;
            }


        [HttpPost]
        [Route("getVisualizzazione")]
        public async Task<IActionResult> GetVisualizzazione([FromBody] UtenteRequestFull utente)
        {
            VisualizzazioneInstallazioneManager utenteManager = new VisualizzazioneInstallazioneManager(_RCDDbContext);

            var utenti = await utenteManager.GetUtenteId(utente);
            Int32 utentiTot = await utenteManager.GetUtenteTot(utente);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = utenti.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = utentiTot, List = utenti.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtenti By Id finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero Utenti By Id" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getUtenteById " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
            [Route("getIdProvinciaByIdUtente")]
            public async Task<IActionResult> GetIdProvinciaByIdUtente([FromBody] UtenteProvinciaRequestFull utente)
            {
                VisualizzazioneInstallazioneManager utenteManager = new VisualizzazioneInstallazioneManager(_RCDDbContext);

                var utenti = await utenteManager.GetIdProvinciaByIdUtente(utente);
                

                JsonResult jsonResult = new JsonResult(null);
                try
                {
                    jsonResult.StatusCode = 200;
                    jsonResult.Value = utenti.ToList(); //dataResponse

                    jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = utenti.Count(), List = utenti.ToList() } })
                    {
                        StatusCode = 200,
                    };
                    _logger.LogInformation("GetIdProvincia By Id finish at: {time}", DateTimeOffset.Now);
                }
                catch (Exception ex)
                {
                    jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetIdProvincia By Id" })
                    {
                        StatusCode = 500,
                    };
                    _logger.LogError("Error in GetIdProvinciaByIdUtente " + ex.Message);
                }

                return jsonResult;
            }
        }

    
}


