﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCD.Code;
using RCDContracts;
using RCDContracts.Request;

namespace RCD.Controllers.Amministrazione
{
    //[Route("api/[controller]")]
    [ApiController]
    [RenewToken]
    [Route("gestione/[controller]")]
    public class TipologiaAntenneController : _BaseController
    {
        private readonly ILogger<TipologiaAntenneController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public TipologiaAntenneController(ILogger<TipologiaAntenneController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("getTipologiaAntenna")]
        public async Task<IActionResult> GetTipologiaAntenna([FromBody] TipologiaAntennaRequestFull tipologiaAntenna)
        {

            TipologiaAntenneManager tipologiaAntennaManager = new TipologiaAntenneManager(_RCDDbContext);

            var tipologiaAntenne = await tipologiaAntennaManager.GetTipologiaAntenne(tipologiaAntenna);
            Int32 totTipologiaAntenne = await tipologiaAntennaManager.GetTipologiaAntenneTot(tipologiaAntenna);

            JsonResult jsonResult = new JsonResult(null);
            try
            { 
                jsonResult.StatusCode = 200;
                jsonResult.Value = tipologiaAntenne.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totTipologiaAntenne, List = tipologiaAntenne.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaAntenna finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero tipologia antenna" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getTipologiaAntenna " + ex.Message);
            }

            return jsonResult;
        }



        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddTipologiaAntenna([FromBody] TipologiaAntennaRequest tipologiaAntennaR)
        {

            TipologiaAntenneManager tipologiaAntenneManager = new TipologiaAntenneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaAntenneManager.AddTipologiaAntenna(tipologiaAntennaR);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Tipologia antenna aggiunta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddTipologiaAntenna finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento tipologia antenna" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddTipologiaAntenna " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditTipologiaAntenna([FromBody] TipologiaAntennaRequest tipologiaAntenna)
        {

            TipologiaAntenneManager tipologiaAntenneManager = new TipologiaAntenneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaAntenneManager.UpdateTipologiaAntenna(tipologiaAntenna);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Tipologia antenna modificata con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaAntenna finish at: {time}", DateTimeOffset.Now);    

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica tipologia antenna" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditTipologiaAntenna " + ex.Message);
            }

            return jsonResult;
        }

        /// <summary>
        /// cancellazione logica della tipologia antenna (abilitato = false)
        /// </summary>
        /// <param name="tipologiaAntenna"></param>
        /// <returns></returns>
        //[Route("delete")]
        [HttpPost]
        [Route("delete")]
        public async Task<IActionResult> DeleteTipologiaAntenna([FromBody] TipologiaAntennaRequest tipologiaAntenna)
        {

            TipologiaAntenneManager tipologiaAntenneManager = new TipologiaAntenneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                tipologiaAntenneManager.DeleteTipologiaAntenna(tipologiaAntenna);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Tipologia antenna eliminato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaAntenne finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di eliminazione tipologia antenna" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteTipologiaAntenna " + ex.Message);
            }

            return jsonResult;
        }
    }
}
