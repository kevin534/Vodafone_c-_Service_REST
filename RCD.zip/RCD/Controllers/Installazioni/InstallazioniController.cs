﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code.Amministrazione;
using RCD.Controllers;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;
using System.Security.Claims;

namespace RCD.Code.Installazione
{
    [ApiController]
    [Route("installazione/[controller]")]
    public class InstallazioniController : _BaseController
    {
        private readonly ILogger<InstallazioniController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public InstallazioniController(ILogger<InstallazioniController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }
        [HttpPost]
        [Route("getRichiedente")]
        public async Task<IActionResult> GetRichiedente(RichiedenteRequestFull richiedente)
        {
            InstallazioniManager installazioniManager = new InstallazioniManager(_RCDDbContext);

            var richiedenti = await installazioniManager.GetRichiedente(richiedente);
            Int32 richiedentiTot = await installazioniManager.GetRichiedenteTot(richiedente);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richiedenti.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiedentiTot, List = richiedenti.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiedente finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRichiedente" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiedente " + ex.Message);
            }

            return jsonResult;
        }

        #region INSTALLAZIONE COMPLETE

        [HttpPost]
        [Route("getInstallazioniComplete")]
        public async Task<IActionResult> GetInstallazioni(LocationRequestFull location)
        {
            JsonResult jsonResult = new JsonResult(null);
            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            Int64 idUtente = Convert.ToInt64(claim.Value);
           // Int64 idUtente =  11397; //1395;//

            if (idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetInstallazioni nel recupero utente loggato");
            }
            InstallazioniManager installazioniManager = new InstallazioniManager(_RCDDbContext);

            var installazione = await installazioniManager.GetInstallazioniComplete(location , idUtente);
            Int32 installazioneTot = await installazioniManager.GetInstallazioniCompleteTot(location, idUtente);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = installazione.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = installazioneTot, List = installazione.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetInstallazioni finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetInstallazioni" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetInstallazioni " + ex.Message);
            }

            return jsonResult;
        }

        #endregion INSTALLAZIONE COMPLETE

        #region RICHIESTE BY IDLOCATION

        [HttpPost]
        [Route("getRichiestaByIdLocation")]
        public async Task<IActionResult> GetRichiestaByIdLocation(RichiestaRequestFull richiesta)
        {
            InstallazioniManager installazioniManager = new InstallazioniManager(_RCDDbContext);

            var richieste = await installazioniManager.GetRichiestaByIdLocation(richiesta);
            Int32 richiesteTot = await installazioniManager.GetRichiestaByIdLocationTot(richiesta);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesteTot, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiestaByIdLocation finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRichiestaByIdLocation" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiestaByIdLocation " + ex.Message);
            }

            return jsonResult;
        }

        #endregion RICHIESTE BY IDLOCATION

        [HttpPost]
        [Route("addInstallazione")]
        public async Task<IActionResult> CreaNuovaInstallazione([FromBody] EntityLocation installazione)
        {

            InstallazioniManager installazioneManager = new InstallazioniManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                installazioneManager.CreaNuovaInstallazione(installazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Installazione aggiunta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddCostiInstallazioneCME finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento Installazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in CreaNuovaInstallazione " + ex.Message);
            }

            return jsonResult;
        }
    }
}
