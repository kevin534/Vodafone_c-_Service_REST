﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Installazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;


namespace RCD.Controllers.Installazioni
{
    [ApiController]
    [Route("installazione/[controller]")]
    public class DocumentazioneInstallazioneController : _BaseController
    {
        private readonly ILogger<DocumentazioneInstallazioneController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public DocumentazioneInstallazioneController(ILogger<DocumentazioneInstallazioneController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }


        [HttpPost]
        [Route("getDocInstallazioneById")]
        public async Task<IActionResult> GetDocInstallazioneById([FromBody] DocumentazioneInstallazioneRequestFull docInstallazione)
        {
            DocumentazioneInstallazioneManager docManager = new DocumentazioneInstallazioneManager(_RCDDbContext);

            var docInstallazioni = await docManager.GetDocumentazioneInstallazionebyInstallazioneId(docInstallazione);
            Int32 docInstallazioneTot = await docManager.GetDocumentazioneInstallazionebyInstallazioneIdTot(docInstallazione);


            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = docInstallazioni.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = docInstallazioneTot, List = docInstallazioni.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetDocInstallazioneById By Id finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetDocInstallazioneById" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetDocInstallazioneById " + ex.Message);
            }

            return jsonResult;
        }
    }

}
