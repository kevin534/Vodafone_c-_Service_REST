﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Installazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;


namespace RCD.Controllers.Installazioni
{

    [ApiController]
    [Route("installazione/[controller]")]
    public class DettaglioApparatiLocationController : _BaseController
    {
        private readonly ILogger<DettaglioApparatiLocationController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        private Int32 counterDiRisposteAsync = 0;

        public DettaglioApparatiLocationController(ILogger<DettaglioApparatiLocationController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        #region LOCATION ACCESSORIO

        [HttpPost]
        [Route("getLocationAccessori")]
        public async Task<IActionResult> GetLocationAccessorio([FromBody] LocationAccessorioRequestFull accessorio)
        {
            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);

            var accessori = await dettaglioApparatiLocationManager.GetLocationAccessori(accessorio);
            Int32 totAccessori = await dettaglioApparatiLocationManager.GetLocationAccessoriTot(accessorio);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = accessori.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totAccessori, List = accessori.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetLocationAccessorio finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel LocationAccessorio" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetLocationAccessorio " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addLocationAccessorio")]
        public async Task<IActionResult> AddLocationAccessorio([FromBody] LocationAccessorioRequest accessorio)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.AddLocationAccessori(accessorio);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationAccessorio aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddLocationAccessorio finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento LocationAccessorio" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddLocationAccessorio " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editLocationAccessorio")]
        public async Task<IActionResult> UpdateLocationAccessorio([FromBody] LocationAccessorioRequest accessorio)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.UpdateLocationAccessori(accessorio);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationAccessorio modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editLocationAccessorio finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica LocationAccessorio" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in UpdateLocationAccessorio " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteLocationAccessorio")]
        public async Task<IActionResult> DeleteLocationAccessorio([FromBody] LocationAccessorioRequest accessorio)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.DeleteLocationAccessori(accessorio);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationAccessorio cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteLocationAccessorio finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione LocationAccessorio" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteLocationAccessorio " + ex.Message);
            }

            return jsonResult;
        }

        #endregion LOCATION ACCESSORIO

        #region LOCATION ANTENNE

        [HttpPost]
        [Route("getLocationAntenne")]
        public async Task<IActionResult> GetLocationAntenne([FromBody] LocationAntenneRequestFull antenna)
        {
            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);

            var antenne = await dettaglioApparatiLocationManager.GetLocationAntenne(antenna);
            Int32 totAntenne = await dettaglioApparatiLocationManager.GetLocationAntenneTot(antenna);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = antenne.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totAntenne, List = antenne.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetLocationAntenne finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel  LocationAntenne" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetLocationAntenne " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addLocationAntenne")]
        public async Task<IActionResult> AddLocationAntenne([FromBody] LocationAntenneRequest antenna)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.AddLocationAntenne(antenna);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationAntenne aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddLocationAntenne finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento LocationAntenne" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddLocationAntenne " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editLocationAntenne")]
        public async Task<IActionResult> UpdateLocationAntenne([FromBody] LocationAntenneRequest antenna)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.UpdateLocationAntenne(antenna);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationAntenne modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editLocationAntenne finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica  LocationAntenne" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editLocationAntenne " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteLocationAntenne")]
        public async Task<IActionResult> DeleteLocationAntenne([FromBody] LocationAntenneRequest antenna)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.DeleteLocationAntenne(antenna);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationAntenne cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteLocationAntenne finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione LocationAntenne" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteLocationAntenne " + ex.Message);
            }

            return jsonResult;
        }

        #endregion LOCATION ANTENNE

        #region LOCATION APPARATI

        [HttpPost]
        [Route("getLocationApparati")]
        public async Task<IActionResult> GetLocationApparati([FromBody] LocationApparatiRequestFull apparato)
        {
            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);

            var apparati = await dettaglioApparatiLocationManager.GetLocationApparati(apparato);
            Int32 totApparato = await dettaglioApparatiLocationManager.GetLocationApparatiTot(apparato);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = apparati.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totApparato, List = apparati.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetLocationApparati finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel  LocationApparati" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetLocationApparati " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addLocationApparati")]
        public async Task<IActionResult> AddLocationApparati([FromBody] LocationApparatiRequest apparato)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.AddLocationApparati(apparato);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationApparati aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddLocationApparati finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento LocationApparati" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddLocationApparati " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editLocationApparati")]
        public async Task<IActionResult> UpdateLocationApparati([FromBody] LocationApparatiRequest apparato)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.UpdateLocationApparati(apparato);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "LocationApparati modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editLocationApparati finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica LocationApparati" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editLocationApparati " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteLocationApparati")]
        public async Task<IActionResult> DeleteLocationApparati([FromBody] LocationApparatiRequest apparato)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.DeleteLocationApparati(apparato);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationApparati cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteLocationApparati finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione LocationApparati" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteLocationApparati " + ex.Message);
            }

            return jsonResult;
        }

        #endregion LOCATION APPARATI


        #region LOCATION FEMTO

        [HttpPost]
        [Route("getLocationFemto")]
        public async Task<IActionResult> GetLocationFemto([FromBody] LocationFemtoRequestFull femto)
        {
            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);

            var apparati = await dettaglioApparatiLocationManager.GetLocationFemto(femto);
            Int32 totApparato = await dettaglioApparatiLocationManager.GetLocationFemtoTot(femto);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = apparati.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totApparato, List = apparati.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetLocationFemto finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel LocationFemto" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetLocationFemto " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addLocationFemto")]
        public async Task<IActionResult> AddLocationFemto([FromBody] LocationFemtoRequest femto)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.AddLocationFemto(femto);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationFemto aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddLocationFemto finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento LocationFemto" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddLocationFemto " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editLocationFemto")]
        public async Task<IActionResult> UpdateLocationFemto([FromBody] LocationFemtoRequest femto)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.UpdateLocationFemto(femto);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "LocationFemto modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editLocationFemto finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica  LocationFemto" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editLocationFemto " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteLocationFemto")]
        public async Task<IActionResult> DeleteLocationFemto([FromBody] LocationFemtoRequest femto)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.DeleteLocationFemto(femto);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationFemto cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteLocationFemto finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione  LocationFemto" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteLocationFemto " + ex.Message);
            }

            return jsonResult;
        }

        #endregion LOCATION FEMTO

        #region LOCATION MISURE

        [HttpPost]
        [Route("getLocationMisure")]
        public async Task<IActionResult> GetLocationMisure([FromBody] LocationMisureRequestFull misure)
        {
            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);

            var apparati = await dettaglioApparatiLocationManager.GetLocationMisure(misure);
            Int32 totApparato = await dettaglioApparatiLocationManager.GetLocationMisureTot(misure);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = apparati.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totApparato, List = apparati.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetLocationMisure finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel LocationMisure" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetLocationMisure " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addLocationMisure")]
        public async Task<IActionResult> AddLocationMisure([FromBody] LocationMisureRequest misure)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.AddLocationMisure(misure);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationMisure aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddLocationMisure finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento LocationMisure" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddLocationMisure " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editLocationMisure")]
        public async Task<IActionResult> UpdateLocationMisure([FromBody] LocationMisureRequest misure)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.UpdateLocationMisure(misure);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationMisure modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editLocationMisure finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica LocationMisure" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editLocationMisure " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteLocationMisure")]
        public async Task<IActionResult> DeleteLocationMisure([FromBody] LocationMisureRequest misure)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.DeleteLocationMisure(misure);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationMisure cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteLocationMisure finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione LocationMisure" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteLocationMisure " + ex.Message);
            }

            return jsonResult;
        }

        #endregion LOCATION MISURE

        #region LOCATION CROWDCELL

        [HttpPost]
        [Route("getLocationCrowdcell")]
        public async Task<IActionResult> GetLocationCrowdcell([FromBody] LocationCrowdcellRequestFull crowdcell)
        {
            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);

            var crowdcells = await dettaglioApparatiLocationManager.GetLocationCrowdcell(crowdcell);
            Int32 totCrowdcell = await dettaglioApparatiLocationManager.GetLocationCrowdcellTot(crowdcell);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = crowdcells.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totCrowdcell, List = crowdcells.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetLocationCrowdcell finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel LocationCrowdcell" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetLocationCrowdcell " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addLocationCrowdcell")]
        public async Task<IActionResult> AddLocationCrowdcell([FromBody] LocationCrowdcellRequest crowdcell)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.AddLocationCrowdcell(crowdcell);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationCrowdcell aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddLocationCrowdcell finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento LocationCrowdcell" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddLocationCrowdcell " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editLocationCrowdcell")]
        public async Task<IActionResult> UpdateLocationCrowdcell([FromBody] LocationCrowdcellRequest crowdcell)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.UpdateLocationCrowdcell(crowdcell);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationCrowdcell modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editLocationCrowdcell finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica  LocationCrowdcell" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editLocationCrowdcell " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteLocationCrowdcell")]
        public async Task<IActionResult> DeleteLocationCrowdcell([FromBody] LocationCrowdcellRequest crowdcell)
        {

            DettaglioApparatiLocationManager dettaglioApparatiLocationManager = new DettaglioApparatiLocationManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatiLocationManager.DeleteLocationCrowdcell(crowdcell);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " LocationCrowdcell cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteLocationCrowdcell finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione  LocationCrowdcell" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteLocationCrowdcell " + ex.Message);
            }

            return jsonResult;
        }

        #endregion LOCATION CROWDCELL


    }
}

