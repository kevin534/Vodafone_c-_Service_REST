﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Installazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;

namespace RCD.Controllers.Installazioni
{
    [ApiController]
    [Route("installazione/[controller]")]
    public class DettaglioApparatiInstallazioneController : _BaseController
    {
        private readonly ILogger<DettaglioApparatiInstallazioneController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        private Int32 counterDiRisposteAsync = 0;

        public DettaglioApparatiInstallazioneController(ILogger<DettaglioApparatiInstallazioneController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        #region TARGHE TECNICHE

        [HttpPost]
        [Route("getTargheTecnicheByIdOffice")]
        public async Task<IActionResult> GetTargheTecnicheByIdOffice([FromBody] DettaglioApparatiInstallazioneRequestFull elemento)
        {
            DettaglioApparatiInstallazioneManager TargheTecnicheByIdOfficeManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);

            var TargheTecnicheByIdOffice = await TargheTecnicheByIdOfficeManager.GetTargheTecnicheByIdOffice(elemento);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = TargheTecnicheByIdOffice.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = 1, List = TargheTecnicheByIdOffice.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTargheTecnicheByIdOffice By Id finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetTargheTecnicheByIdOffice" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetTargheTecnicheByIdOffice " + ex.Message);
            }

            return jsonResult;
        }
        #endregion TARGHE TECNICHE

        #region APPARATI DETTAGLIO
        [HttpPost]
        [Route("GetApparatiInstallazioneDettaglio")]
        public async Task<IActionResult> GetApparatiInstallazioneDettaglio([FromBody] ApparatiInstallazioneRequestFull apparatoInstallazione)
        {
            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);

            var apparatiInstallazione = await dettaglioApparatoInstallazioneManager.GetApparatiInstallazione(apparatoInstallazione);
            Int32 totApparatiInstallazione = await dettaglioApparatoInstallazioneManager.GetApparatiInstallazioneTot(apparatoInstallazione);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = apparatiInstallazione.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totApparatiInstallazione, List = apparatiInstallazione.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetApparatiInstallazione finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero apparati installazioni" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getApparatiInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addApparatiInstallazione")]
        public async Task<IActionResult> AddApparatiInstallazione([FromBody] ApparatiInstalazioneRequest apparatoInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.AddApparatiInstallazione(apparatoInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AddApparatiInstallazione aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddApparatiInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento ApparatiInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddApparatiInstallazione " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editApparatiInstallazione")]
        public async Task<IActionResult> UpdateApparatiInstallazione([FromBody] ApparatiInstalazioneRequest apparatoInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.UpdateApparatiInstallazione(apparatoInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "ApparatiInstallazione modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editApparatiInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica ApparatiInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editApparatiInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteApparatiInstallazione")]
        public async Task<IActionResult> DeleteApparatiInstallazione([FromBody] ApparatiInstalazioneRequest apparatoInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.DeleteApparatiInstallazione(apparatoInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "ApparatiInstallazione cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteApparatiInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione ApparatiInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteApparatiInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        #endregion APPARATI DETTAGLIO

        #region ANTENNE DETTAGLIO
        [HttpPost]
        [Route("GetAntennaInstallazioneDettaglio")]
        public async Task<IActionResult> GetAntennaInstallazioneDettaglio([FromBody] AntennaInstallazioneRequestFull antennaInstallazione)
        {
            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);

            var antenneInstallazioni = await dettaglioApparatoInstallazioneManager.GetAntenneInstallazione(antennaInstallazione);
            Int32 totAntennaInstallazioni = await dettaglioApparatoInstallazioneManager.GetAntenneInstallazioneTot(antennaInstallazione);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = antenneInstallazioni.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totAntennaInstallazioni, List = antenneInstallazioni.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAntenneInstallazioni finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero antenne installazioni" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getAntenneInstallazioni " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addAntenneInstallazione")]
        public async Task<IActionResult> AddAntenneInstallazione([FromBody] AntennaInstallazioneRequest antennaInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.AddAntenneInstallazione(antennaInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AddAntenneInstallazione aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddAntenneInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento AntenneInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddAntenneInstallazione " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editAntenneInstallazione")]
        public async Task<IActionResult> UpdateAntenneInstallazione([FromBody] AntennaInstallazioneRequest antennaInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.UpdateAntenneInstallazione(antennaInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AntenneInstallazione modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editAntenneInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica AntenneInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editAntenneInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteAntenneInstallazione")]
        public async Task<IActionResult> DeleteAntenneInstallazione([FromBody] AntennaInstallazioneRequest antennaInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.DeleteAntenneInstallazione(antennaInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AntenneInstallazione cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteAntenneInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione AntenneInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteAntenneInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        #endregion ANTENNE DETTAGLIO

        #region ACCESSORIO DETTAGLIO
        [HttpPost]
        [Route("GetAccessorioInstallazioneDettaglio")]
        public async Task<IActionResult> GetAccessorioInstallazioneDettaglio([FromBody] AccessorioInstallazioneRequestFull accessorioInstallazione)
        {
            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);

            var accessoriInstallazioni = await dettaglioApparatoInstallazioneManager.GetAccessoriInstallazione(accessorioInstallazione);
            Int32 totAccessorioInstallazioni = await dettaglioApparatoInstallazioneManager.GetAccessoriInstallazioneTot(accessorioInstallazione);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = accessoriInstallazioni.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totAccessorioInstallazioni, List = accessoriInstallazioni.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAccessoriInstallazione finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero accessori" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getAccessoriInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addAccessoriInstallazione")]
        public async Task<IActionResult> AddAccessoriInstallazione([FromBody] AccessorioInstallazioneRequest accessorioInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.AddAccessoriInstallazione(accessorioInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AddAccessoriInstallazione aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddAccessoriInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento AccessoriInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddAccessoriInstallazione " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editAccessoriInstallazione")]
        public async Task<IActionResult> UpdateAccessoriInstallazione([FromBody] AccessorioInstallazioneRequest accessorioInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.UpdateAccessoriInstallazione(accessorioInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AccessoriInstallazione modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editAccessoriInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica  AccessoriInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editAccessoriInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteAccessoriInstallazione")]
        public async Task<IActionResult> DeleteAccessoriInstallazione([FromBody] AccessorioInstallazioneRequest accessorioInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.DeleteAccessoriInstallazione(accessorioInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " AccessoriInstallazione cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteAccessoriInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione  AccessoriInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteAccessoriInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        #endregion ACCESSORIO DETTAGLIO


        #region MISURA DETTAGLIO
        [HttpPost]
        [Route("GetMisuraInstallazioneDettaglio")]
        public async Task<IActionResult> GetMisuraInstallazioneDettaglio([FromBody] MisuraInstallazioneRequestFull misuraInstallazione)
        {
            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);

            var misureInstallazioni = await dettaglioApparatoInstallazioneManager.GetMisureInstallazione(misuraInstallazione);
            Int32 totMisuraInstallazioni = await dettaglioApparatoInstallazioneManager.GetMisureInstallazioneTot(misuraInstallazione);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = misureInstallazioni.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totMisuraInstallazioni, List = misureInstallazioni.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetMisureInstallazione finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero accessori" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getMisureInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addMisureInstallazione")]
        public async Task<IActionResult> AddMisureInstallazione([FromBody] MisuraInstallazioneRequest misuraInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.AddMisureInstallazione(misuraInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " MisureInstallazione aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddMisureInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento   MisureInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddMisureInstallazione " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editMisureInstallazione")]
        public async Task<IActionResult> UpdateMisureInstallazione([FromBody] MisuraInstallazioneRequest misuraInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.UpdateMisureInstallazione(misuraInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " MisureInstallazione modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editMisureInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica  MisureInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editMisureInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteMisureInstallazione")]
        public async Task<IActionResult> DeleteMisureInstallazione([FromBody] MisuraInstallazioneRequest misuraInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.DeleteMisureInstallazione(misuraInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "  MisureInstallazione cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteMisureInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione  MisureInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteMisureInstallazione " + ex.Message);
            }

            return jsonResult;
        }
        #endregion MISURA DETTAGLIO

        #region CROWDCELL DETTAGLIO
        [HttpPost]
        [Route("GetCrowdcellInstallazioneDettaglio")]
        public async Task<IActionResult> GetCrowdcellInstallazioneDettaglio([FromBody] CrowdcellInstallazioneRequestFull CrowdcellInstallazione)
        {
            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);

            var crowdcellInstallazioni = await dettaglioApparatoInstallazioneManager.GetCrowdcellInstallazione(CrowdcellInstallazione);
            Int32 totCrowdcellInstallazioni = await dettaglioApparatoInstallazioneManager.GetCrowdcellInstallazioneTot(CrowdcellInstallazione);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = crowdcellInstallazioni.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totCrowdcellInstallazioni, List = crowdcellInstallazioni.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetCrowdcellInstallazione finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero installazioni crowdcell" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getCrowdcellInstallazione " + ex.Message);
            }

            return jsonResult;
        }


        [HttpPost]
        [Route("addCrowdcellInstallazione")]
        public async Task<IActionResult> AddCrowdcellInstallazione([FromBody] CrowdcellInstallazioneRequest crowdcellInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.AddCrowdcellInstallazione(crowdcellInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "  CrowdcellInstallazione aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddCrowdcellInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento   CrowdcellInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddCrowdcellInstallazione " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editCrowdcellInstallazione")]
        public async Task<IActionResult> UpdateCrowdcellInstallazione([FromBody] CrowdcellInstallazioneRequest crowdcellInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.UpdateCrowdcellInstallazione(crowdcellInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " CrowdcellInstallazione modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editCrowdcellInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica  CrowdcellInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editCrowdcellInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteCrowdcellInstallazione")]
        public async Task<IActionResult> DeleteCrowdcellInstallazione([FromBody] CrowdcellInstallazioneRequest crowdcellInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.DeleteCrowdcellInstallazione(crowdcellInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "  CrowdcellInstallazione cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteCrowdcellInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione   CrowdcellInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteCrowdcellInstallazione " + ex.Message);
            }

            return jsonResult;
        }
        #endregion CROWDCELL DETTAGLIO

        #region FEMTO DETTAGLIO
        [HttpPost]
        [Route("GetFemtoInstallazioneDettaglio")]
        public async Task<IActionResult> GetFemtoInstallazioneDettaglio([FromBody] FemtoInstallazioneRequestFull FemtoInstallazione)
        {
            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);

            var femtoInstallazioni = await dettaglioApparatoInstallazioneManager.GetFemtoCelleInstallazione(FemtoInstallazione);
            Int32 totFemtoInstallazioni = await dettaglioApparatoInstallazioneManager.GetFemtoInstallazioneTot(FemtoInstallazione);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = femtoInstallazioni.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totFemtoInstallazioni, List = femtoInstallazioni.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetFemtoInstallazione finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero installazioni femto" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getFemtoInstallazione " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("addFemtoInstallazione")]
        public async Task<IActionResult> AddFemtoInstallazione([FromBody] FemtoInstallazioneRequest femtoInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.AddFemtoInstallazione(femtoInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "  FemtoInstallazione aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddFemtoInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento   FemtoInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddFemtoInstallazione " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editFemtoInstallazione")]
        public async Task<IActionResult> UpdateFemtoInstallazione([FromBody] FemtoInstallazioneRequest femtoInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.UpdateFemtoInstallazione(femtoInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " FemtoInstallazione modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editFemtoInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica  FemtoInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editFemtoInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteFemtoInstallazione")]
        public async Task<IActionResult> DeleteFemtoInstallazione([FromBody] FemtoInstallazioneRequest femtoInstallazione)
        {

            DettaglioApparatiInstallazioneManager dettaglioApparatoInstallazioneManager = new DettaglioApparatiInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoInstallazioneManager.DeleteFemtoInstallazione(femtoInstallazione);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " FemtoInstallazione cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteFemtoInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione  FemtoInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteFemtoInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        #endregion FEMTO DETTAGLIO
    }
}
