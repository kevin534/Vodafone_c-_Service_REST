﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code.Amministrazione;
using RCD.Controllers;
using RCDContracts;
using RCDContracts.Request;

namespace RCD.Code.Installazione
{
    [ApiController]
    [Route("installazione/[controller]")]
    public class TipologieInstallazioniController : _BaseController
    {
        private readonly ILogger<TipologieInstallazioniController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public TipologieInstallazioniController(ILogger<TipologieInstallazioniController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }
        [HttpGet]
        [Route("getTipologiaStabile")]
        public async Task<IActionResult> GetTipologiaStabilea()
        {

            TipologieInstallazioneManager tipologieInstallazioneManager = new TipologieInstallazioneManager(_RCDDbContext);

            var tipoStabile = await tipologieInstallazioneManager.GetTipologiaStabilea();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = tipoStabile.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = tipoStabile.ToList().Count, List = tipoStabile.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaStabilea finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetTipologiaStabilea" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetTipologiaStabilea " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getAccessibilitaTetto")]
        public async Task<IActionResult> GetAccessibilitaTetto()
        {

            TipologieInstallazioneManager tipologieInstallazioneManager = new TipologieInstallazioneManager(_RCDDbContext);

            var AccesTetto = await tipologieInstallazioneManager.GetAccessibilitaTetto();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = AccesTetto.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = AccesTetto.ToList().Count, List = AccesTetto.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAccessibilitaTetto finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetAccessibilitaTetto" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetAccessibilitaTetto " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getGestori")]
        public async Task<IActionResult> GetGestori()
        {

            TipologieInstallazioneManager tipologieInstallazioneManager = new TipologieInstallazioneManager(_RCDDbContext);

            var gestore = await tipologieInstallazioneManager.GetGestori();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = gestore.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = gestore.ToList().Count, List = gestore.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetGestori finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetGestori" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetGestori " + ex.Message);
            }

            return jsonResult;
        }
    }
}
