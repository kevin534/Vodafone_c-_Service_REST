﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Installazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;


namespace RCD.Controllers.Installazioni
{

    [ApiController]
    [Route("installazione/[controller]")]
    public class DettaglioCostiInstallazioneController : _BaseController
    {
        private readonly ILogger<DettaglioCostiInstallazioneController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        private Int32 counterDiRisposteAsync = 0;

        public DettaglioCostiInstallazioneController(ILogger<DettaglioCostiInstallazioneController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("GetCostiInstallazioneCME")]
        public async Task<IActionResult> GetCostiInstallazioneCME([FromBody] InstallazioneCMERequestFull installazioneCME)
        {
            DettaglioCostoInstallazioneManager dettaglioCostoInstallazioneManager = new DettaglioCostoInstallazioneManager(_RCDDbContext);

            var richieste = await dettaglioCostoInstallazioneManager.GetCostiInstallazioneCME(installazioneCME);
            Int32 totRichieste = await dettaglioCostoInstallazioneManager.GetCostiInstallazioneCMETot(installazioneCME);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totRichieste, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetCostiInstallazioneCME finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero installazione costi" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getCostiInstallazioneCME " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addCostiInstallazioneCME")]
        public async Task<IActionResult> AddCostiInstallazioneCME([FromBody] InstallazioneCMERequest installazioneCme)
        {

            DettaglioCostoInstallazioneManager dettaglioCostoInstallazioneManager = new DettaglioCostoInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioCostoInstallazioneManager.AddCostiInstallazioneCME(installazioneCme);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "  CostiInstallazioneCME aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddCostiInstallazioneCME finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento  CostiInstallazioneCME" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddCostiInstallazioneCME " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editCostiInstallazioneCME")]
        public async Task<IActionResult> UpdateCostiInstallazioneCME([FromBody] InstallazioneCMERequest installazioneCme)
        {

            DettaglioCostoInstallazioneManager dettaglioCostoInstallazioneManager = new DettaglioCostoInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioCostoInstallazioneManager.UpdateCostiInstallazioneCME(installazioneCme);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "  CostiInstallazioneCME modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editCostiInstallazioneCME finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica  CostiInstallazioneCME" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editCostiInstallazioneCME " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteCostiInstallazioneCME")]
        public async Task<IActionResult> DeleteCostiInstallazioneCME([FromBody] InstallazioneCMERequest installazioneCme)
        {

            DettaglioCostoInstallazioneManager dettaglioCostoInstallazioneManager = new DettaglioCostoInstallazioneManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioCostoInstallazioneManager.DeleteCostiInstallazioneCME(installazioneCme);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = " CostiInstallazioneCME cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteCostiInstallazioneCME finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione  CostiInstallazioneCME" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteCostiInstallazioneCME " + ex.Message);
            }

            return jsonResult;
        }



    }
}
