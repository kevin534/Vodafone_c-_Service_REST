﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code.Amministrazione;
using RCD.Code.Rda;
using RCD.Controllers;
using RCDContracts;
using RCDContracts.Request;
namespace RCD.Controllers.Rda
{
    [ApiController]
    [Route("rda/[controller]")]
    public class RdaController : _BaseController
    {
        private readonly ILogger<RdaController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public RdaController(ILogger<RdaController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        #region DITTE ABILITATE BY ID UTENTE

        [HttpPost]
        [Route("getDitteAbilitateByIdUtente")]
        public async Task<IActionResult> GetDitteAbilitateByIdUtente(DittaRequestFull ditta)
        {
            JsonResult jsonResult = new JsonResult(null);

            Int64 idUtente = 25; //1395;//       

            if (idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetInstallazioni nel recupero utente loggato");
            }
            RdaManager installazioniManager = new RdaManager(_RCDDbContext);

            var ditte = await installazioniManager.GetDitteAbilitateByIdUtente(ditta, idUtente);
            Int32 ditteTot = await installazioniManager.GetDitteAbilitateByIdUtenteTot(ditta, idUtente);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = ditte.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = ditteTot, List = ditte.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetDitteAbilitateByIdUtente finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetDitteAbilitateByIdUtente" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetDitteAbilitateByIdUtente " + ex.Message);
            }

            return jsonResult;
        }

        #endregion DITTE ABILITATE BY ID UTENTE


    }
}
