﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCD.Code.Richieste;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;
using System.Security.Claims;

namespace RCD.Controllers.Amministrazione
{
    [ApiController]
    [Route("pianificazioni/[controller]")]
    public class PianificazioniController : _BaseController
    {

        private readonly ILogger<PianificazioniController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public PianificazioniController(ILogger<PianificazioniController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("getPianificazioni")]
        public async Task<IActionResult> GetPianificazioni([FromBody] PianificazioneRequestFull pianificazione)
        {
            JsonResult jsonResult = new JsonResult(null);
            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            Int64 idUtente = Convert.ToInt64(claim.Value);
            if(idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetPianificazioni nel recupero utente loggato");
            }

            PianificazioniManager pianificazioniManager = new PianificazioniManager(_RCDDbContext);

            var pianificazioni = await pianificazioniManager.GetPianificazioni(pianificazione, idUtente);
            Int32 totPianificazioni = await pianificazioniManager.GetPianificazioniTot(pianificazione, idUtente);

          
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = pianificazioni.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totPianificazioni, List = pianificazioni.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetPianificazioni finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero pianificazioni" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetPianificazioni " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("onConfirmSave")]
        public async Task<IActionResult> OnConfirmSave([FromBody] EntityRichiesta richiesta)
        {

            PianificazioniManager pianificazioneManager = new PianificazioniManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                long idUtente = 928;
                //var identity = User.Identity as ClaimsIdentity;
                //Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                //long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                pianificazioneManager.OnConfirmSave(richiesta, idUtente);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "onConfirmSave: Pianificazione salvata con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("OnConfirmSave finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "OnConfirmSave: Errore in fase di aggiornamento stato pianificazione " + ex.Message })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in OnConfirmSave " + ex.Message);
            }

            return jsonResult;
        }

    }
}