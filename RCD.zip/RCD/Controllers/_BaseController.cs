﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code;

namespace RCD.Controllers
{
	public class _BaseController : Controller
	{
		private readonly ILogger<_BaseController> _logger;
		private IConfigurationRoot _configurationRoot;
		private readonly IHttpContextAccessor _httpContextAccessor;

		private readonly RCDEngine.RCDDbContext? _RCDDbContext;


		public EnumerateManager.ENVIRONMENT_TYPE CurrentEnviroment { get; private set; }
		public String PrefixEnvironment { get; private set; }

		public _BaseController(ILogger<_BaseController> logger, IConfiguration configurationRoot, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext)
		{
			_logger = logger;
			_configurationRoot = (IConfigurationRoot)configurationRoot;
			_httpContextAccessor = httpContextAccessor;

			this.CurrentEnviroment = UtilityManager.CurrentEnvironment(_httpContextAccessor.HttpContext.Request.Path);
			this.PrefixEnvironment = UtilityManager.PrefixEnvironment(this.CurrentEnviroment);



			_RCDDbContext = RCDDbContext;
			_RCDDbContext.ConnectionString = _configurationRoot.GetConnectionString(UtilityManager.GetConnectionStringName(this.PrefixEnvironment));
		}
	}
}
