﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code.Amministrazione;
using RCD.Controllers;
using RCDContracts;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Recuperi
{
    [ApiController]
    [Route("recuperi/[controller]")]
    public class RecuperiController : _BaseController
    {
        private readonly ILogger<RecuperiController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public RecuperiController(ILogger<RecuperiController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        #region GET VIEW RECUPERI

        [HttpPost]
        [Route("getViewRecuperi")]
        public async Task<IActionResult> GetViewRecuperi(ViewRecuperiRequestFull recuperi)
        {
            RecuperiManager recuperiManager = new RecuperiManager(_RCDDbContext);
            var recupero = await recuperiManager.GetViewRecuperi(recuperi);
            Int32 recuperoTot = await recuperiManager.GetViewRecuperiTot(recuperi);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = recupero.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = recuperoTot, List = recupero.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetViewRecuperi finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetViewRecuperi" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetViewRecuperi " + ex.Message);
            }

            return jsonResult;
        }
        #endregion GET VIEW RECUPERI

        #region GET VIEW RECUPERI WITH ISCHIUSO

        [HttpPost]
        [Route("getViewRecuperiWithIsChiusoTrue")]
        public async Task<IActionResult> GetViewRecuperiWithIsChiusoTrue(ViewRecuperiRequestFull recuperi)
        {
            RecuperiManager recuperiManager = new RecuperiManager(_RCDDbContext);
            var recupero = await recuperiManager.GetViewRecuperiWithIsChiusoTrue(recuperi);
            Int32 recuperoTot = await recuperiManager.GetViewRecuperiWithIsChiusoTrueTot(recuperi);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = recupero.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = recuperoTot, List = recupero.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetViewRecuperiWithIsChiusoTrue finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetViewRecuperiWithIsChiusoTrue" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetViewRecuperiWithIsChiusoTrue " + ex.Message);
            }

            return jsonResult;
        }

        #endregion GET VIEW RECUPERI WITH ISCHIUSO

        #region GET RECUPERO LOCATION BY ID

        [HttpPost]
        [Route("getRecuperoLocationById")]
        public async Task<IActionResult> GetRecuperoLocationById(RecuperiRequestFull recuperi)
        {
            RecuperiManager recuperiManager = new RecuperiManager(_RCDDbContext);
            var recupero = await recuperiManager.getRecuperoLocationById(recuperi);
            Int32 recuperoTot = await recuperiManager.getRecuperoLocationByIdTot(recuperi);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = recupero.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = recuperoTot, List = recupero.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRecuperoLocationById finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRecuperoLocationById" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRecuperoLocationById " + ex.Message);
            }

            return jsonResult;
        }

        #endregion  GET RECUPERO LOCATION BY ID

        #region RECUPERO DETAILS BY ID

        [HttpPost]
        [Route("getRecuperoDetailsById")]
        public async Task<IActionResult> getRecuperoDetailsById(RecuperiRequestFull recuperi)
        {
            RecuperiManager recuperiManager = new RecuperiManager(_RCDDbContext);
            var recupero = await recuperiManager.getRecuperoDetailsById(recuperi);
            Int32 recuperoTot = await recuperiManager.getRecuperoDetailsByIdTot(recuperi);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = recupero.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = recuperoTot, List = recupero.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRecuperoLocationByIdOLD finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRecuperoLocationByIdOLD" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRecuperoLocationByIdOLD " + ex.Message);
            }

            return jsonResult;
        }

        #endregion RECUPERO DETAILS BY ID

        #region RECUPERO CME BY ID

        [HttpPost]
        [Route("getRecuperoCMEById")]
        public async Task<IActionResult> GetRecuperoCMEById(RecuperoCMERequestFull recuperi)
        {
            RecuperiManager recuperiManager = new RecuperiManager(_RCDDbContext);
            var recupero = await recuperiManager.getRecuperoCMEById(recuperi);
            Int32 recuperoTot = await recuperiManager.getRecuperoCMEByIdTot(recuperi);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = recupero.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = recuperoTot, List = recupero.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRecuperoCMEById finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRecuperoCMEById" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRecuperoCMEById " + ex.Message);
            }

            return jsonResult;
        }

        #endregion RECUPERO CME BY ID

        #region DOCUMENTAZIONE RECUPERO BY ID

        [HttpPost]
        [Route("getDocumentazioneRecuperoById")]
        public async Task<IActionResult> GetDocumentazioneRecuperoById(DocumentazioneRecuperoRequestFull doc)
        {
            RecuperiManager recuperiManager = new RecuperiManager(_RCDDbContext);
            var document = await recuperiManager.getDocumentazioneRecuperoById(doc);
            Int32 documentTot = await recuperiManager.getDocumentazioneRecuperoByIdTot(doc);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = document.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = documentTot, List = document.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetDocumentazioneRecuperoById finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetDocumentazioneRecuperoById" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetDocumentazioneRecuperoById " + ex.Message);
            }

            return jsonResult;
        }

        #endregion DOCUMENTAZIONE RECUPERO BY ID

        #region GET RECUPERO BY ID

        [HttpPost]
        [Route("getRecuperoById")]
        public async Task<IActionResult> GetRecuperoById(RecuperiRequestFull recuperi)
        {
            RecuperiManager recuperiManager = new RecuperiManager(_RCDDbContext);

            var recupero = await recuperiManager.GetRecuperoById(recuperi);
            Int32 recuperoTot = await recuperiManager.GetRecuperoByIdTot(recuperi);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = recupero.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = recuperoTot, List = recupero.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRecuperoById finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRecuperoById" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRecuperoById " + ex.Message);
            }

            return jsonResult;
        }

        #endregion  GET RECUPERO BY ID

        #region GET SELECT DETTAGLIO

        [HttpGet]
        [Route("getProvenienzaRichiesta")]
        public async Task<IActionResult> GetProvenienzaRichiesta()
        {

            RecuperiManager recuperiManager = new RecuperiManager(_RCDDbContext);

            var cantiere = await recuperiManager.GetProvenienzaRichiesta();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = cantiere.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = cantiere.ToList().Count, List = cantiere.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetProvenienzaRichiesta finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetProvenienzaRichiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetProvenienzaRichiesta " + ex.Message);
            }

            return jsonResult;
        }
        #endregion

        #region UPDATE / INSERT RECUPERI

        [HttpPost]
        [Route("editRecuperiManutenzione")]
        public async Task<IActionResult> UpdateRecuperiManutenzione(RecuperiRequest recupero)
        {
            RecuperiManager recuperiManager = new RecuperiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //Boolean isManutenzione = false;
                //if(recupero.IsManutenzione == true)
                //    isManutenzione = true;

                recuperiManager.UpdateRecuperiManutenzione(recupero);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Recupero modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("UpdateRecuperi finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica recupero" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in UpdateRecupero " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("onConfirmCreaRecupero")]
        public async Task<IActionResult> OnConfirmCreaRecupero(RecuperiRequest recupero)
        {
            RecuperiManager recuperiManager = new RecuperiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                long? idUtente = 928;
                //var identity = User.Identity as ClaimsIdentity;
                //Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                //long idUtente = Convert.ToInt64(claim.Value);
                recuperiManager.CreaRecuperoManutenzione(recupero,idUtente);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Recupero creato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("OnConfirmCreaRecupero finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di creazione recupero" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in UpdateRecupero " + ex.Message);
            }

            return jsonResult;
        }

        #endregion  UPDATE / INSERT RECUPERI

        #region CANCELLAZIONE RECUPERO/MANUTENZIONE

        [HttpPost]
        [Route("OnConfirmDelete")]
        public async Task<IActionResult> DeleteRecuperoManutenzione(RecuperiRequest recupero)
        {
            RecuperiManager recuperiManager = new RecuperiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                recuperiManager.DeleteRecuperoManutenzione(recupero);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Recupero/Manutenzione cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteRecuperoManutenzione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di cancellazione del recupero/manutenzione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteRecuperoManutenzione " + ex.Message);
            }

            return jsonResult;
        }

        #endregion CANCELLAZIONE RECUPERO/MANUTENZIONE

        #region "COMPLETA RECUPERO"

        [HttpPost]
        [Route("OnConfirmChiudiRecupero")]
        public async Task<IActionResult> OnConfirmChiudiRecupero([FromBody] EntityRecuperi recupero)
        {
            RecuperiManager recuperiManager = new RecuperiManager(_RCDDbContext);
            //_RCDDbContext.Database.SetCommandTimeout(400);
            //var identity = User.Identity as ClaimsIdentity;
            //Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            //long idUtente = Convert.ToInt64(claim.Value);
            long idUtente = 11397;

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                recuperiManager.OnConfirmChiudiRecupero(recupero,idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Recupero chiuso con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("OnConfirmChiudiRecupero finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di chiusura recupero" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in OnConfirmChiudiRecupero " + ex.Message);
            }

            return jsonResult;
        }


        #endregion "COMPLETA RECUPERO"
    }

}
