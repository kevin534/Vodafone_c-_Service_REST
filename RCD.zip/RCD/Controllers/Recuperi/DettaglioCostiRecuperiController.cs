﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code.Amministrazione;
using RCD.Code.Recuperi;
using RCD.Controllers;
using RCDContracts;
using RCDContracts.Request;
using RCDEngine.Entities;
namespace RCD.Controllers.Recuperi
{
    [ApiController]
    [Route("recuperi/[controller]")]
    public class DettaglioCostiRecuperiController : _BaseController
    {
        private readonly ILogger<DettaglioCostiRecuperiController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public DettaglioCostiRecuperiController(ILogger<DettaglioCostiRecuperiController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        #region RECUPERO CME BY IDRECUPERO

        [HttpPost]
        [Route("getRecuperoCMEbyRecuperoId")]
        public async Task<IActionResult> GetRecuperoCMEbyRecuperoId(RecuperoCMERequestFull recupero)
        {
            DettaglioCostiRecuperiManager recuperiManager = new DettaglioCostiRecuperiManager(_RCDDbContext);
            var docRecuperi = await recuperiManager.GetRecuperoCMEbyRecuperoId(recupero);
            Int32 recuperoTot = await recuperiManager.GetRecuperoCMEbyRecuperoIdTot(recupero);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = docRecuperi.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = recuperoTot, List = docRecuperi.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRecuperoCMEbyRecuperoId finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRecuperoCMEbyRecuperoId" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRecuperoCMEbyRecuperoId " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addRecuperoCME")]
        public async Task<IActionResult> AddRecuperoCME([FromBody] RecuperoCMERequest recupero)
        {

            DettaglioCostiRecuperiManager recuperiManager = new DettaglioCostiRecuperiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                recuperiManager.AddRecuperoCME(recupero);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "RecuperoCME aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddRecuperoCME finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento RecuperoCME" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddRecuperoCME " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editRecuperoCME")]
        public async Task<IActionResult> UpdateRecuperoCME([FromBody] RecuperoCMERequest recupero)
        {

            DettaglioCostiRecuperiManager recuperiManager = new DettaglioCostiRecuperiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                recuperiManager.UpdateRecuperoCME(recupero);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "RecuperoCME modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("edit RecuperoCME finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica RecuperoCME" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in edit RecuperoCME " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteRecuperoCME")]
        public async Task<IActionResult> DeleteRecuperoCME([FromBody] RecuperoCMERequest recupero)
        {

            DettaglioCostiRecuperiManager recuperiManager = new DettaglioCostiRecuperiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                recuperiManager.DeleteRecuperoCME(recupero);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "RecuperoCME cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteRecuperoCME finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione RecuperoCME" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteRecuperoCME " + ex.Message);
            }

            return jsonResult;
        }

        #endregion RECUPERO CME BY IDRECUPERO
    }
}
