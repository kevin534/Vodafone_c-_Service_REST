﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code.Amministrazione;
using RCD.Code.Recuperi;
using RCD.Controllers;
using RCDContracts;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Controllers.Recuperi
{
    [ApiController]
    [Route("recuperi/[controller]")]
    public class DettaglioApparatiRecuperiController : _BaseController
    {
        private readonly ILogger<DettaglioApparatiRecuperiController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public DettaglioApparatiRecuperiController(ILogger<DettaglioApparatiRecuperiController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        #region APPARATI RECUPERO BY IdLocation

        [HttpPost]
        [Route("getApparatiRecuperoByIdLocation")]
        public async Task<IActionResult> GetApparatiRecuperoByIdLocation(LocationApparatiRequestFull apparato)
        {
            DettaglioApparatiRecuperiManager recuperiManager = new DettaglioApparatiRecuperiManager(_RCDDbContext);
            var recupero = await recuperiManager.GetApparatiRecuperoByIdLocation(apparato);
            Int32 recuperoTot = await recuperiManager.GetApparatiRecuperoByIdLocationTot(apparato);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = recupero.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = recuperoTot, List = recupero.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetApparatiRecuperoByIdLocation finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetApparatiRecuperoByIdLocation" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetApparatiRecuperoByIdLocation " + ex.Message);
            }

            return jsonResult;
        }

        #endregion  APPARATI RECUPERO BY IdLocation

        #region FEMTO RECUPERO BY IdLocation

        [HttpPost]
        [Route("getFemtoRecuperoByIdLocation")]
        public async Task<IActionResult> GetFemtoRecuperoByIdLocation(LocationFemtoRequestFull apparato)
        {
            DettaglioApparatiRecuperiManager recuperiManager = new DettaglioApparatiRecuperiManager(_RCDDbContext);
            var recupero = await recuperiManager.GetFemtoRecuperoByIdLocation(apparato);
            Int32 recuperoTot = await recuperiManager.GetFemtoRecuperoByIdLocationTot(apparato);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = recupero.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = recuperoTot, List = recupero.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetFemtoRecuperoByIdLocation finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetFemtoRecuperoByIdLocation" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetFemtoRecuperoByIdLocation " + ex.Message);
            }

            return jsonResult;
        }

        #endregion  FEMTO RECUPERO BY IdLocation

        #region LOCATION ANTENNE RECUPERO BY IdLocation

        [HttpPost]
        [Route("getAntenneRecuperoByIdLocation")]
        public async Task<IActionResult> GetAntenneRecuperoByIdLocation(LocationAntenneRequestFull antenne)
        {
            DettaglioApparatiRecuperiManager recuperiManager = new DettaglioApparatiRecuperiManager(_RCDDbContext);
            var antenna = await recuperiManager.GetAntenneRecuperoByIdLocation(antenne);
            Int32 antennaTot = await recuperiManager.GetAntenneRecuperoByIdLocationTot(antenne);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = antenna.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = antennaTot, List = antenna.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAntenneRecuperoByIdLocation finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetAntenneRecuperoByIdLocation" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetAntenneRecuperoByIdLocation " + ex.Message);
            }

            return jsonResult;
        }

        #endregion LOCATION ANTENNE RECUPERO BY IdLocation

        #region ACCESSORI RECUPERO BY IdLocation

        [HttpPost]
        [Route("getAccessoriRecuperoByIdLocation")]
        public async Task<IActionResult> GetAccessoriRecuperoByIdLocation(LocationAccessorioRequestFull accessorio)
        {
            DettaglioApparatiRecuperiManager recuperiManager = new DettaglioApparatiRecuperiManager(_RCDDbContext);
            var accessori = await recuperiManager.GetAccessoriRecuperoByIdLocation(accessorio);
            Int32 accessoriTot = await recuperiManager.GetAccessoriRecuperoByIdLocationTot(accessorio);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = accessori.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = accessoriTot, List = accessori.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAccessoriRecuperoByIdLocation finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetAccessoriRecuperoByIdLocation" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetAccessoriRecuperoByIdLocation " + ex.Message);
            }

            return jsonResult;
        }

        #endregion ACCESSORI RECUPERO BY IdLocation

        #region CODICE BIDONE RIPETITORE

        [HttpGet]
        [Route("getCodiciBidoneByRipetitori")]
        public async Task<IActionResult> GetCodiciBidoneByRipetitori()
        {

            DettaglioApparatiRecuperiManager recuperiManager = new DettaglioApparatiRecuperiManager(_RCDDbContext);

            var codiceRipetitore = await recuperiManager.GetCodiciBidoneByRipetitori();
            Int32 codiceRipetitoreTot = await recuperiManager.GetCodiciBidoneByRipetitoriTot();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = codiceRipetitore.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = codiceRipetitoreTot, List = codiceRipetitore.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetCodiciBidoneByRipetitori finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetCodiciBidoneByRipetitori" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetCodiciBidoneByRipetitori " + ex.Message);
            }

            return jsonResult;
        }
        #endregion CODICE BIDONE RIPETITORE
    }

}
