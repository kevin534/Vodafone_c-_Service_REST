﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code;
using RCD.Code.Recuperi;
using RCDContracts;
using RCDContracts.Request;

namespace RCD.Controllers.Recuperi
{
    [ApiController]
    [RenewToken]
    [Route("recuperi/[controller]")]
    public class NuovoRecuperoController : _BaseController
    {
            private readonly ILogger<NuovoRecuperoController> _logger;
            private IConfigurationRoot _configuration;
            private readonly IHttpContextAccessor _httpContextAccessor;

            private readonly RCDEngine.RCDDbContext? _RCDDbContext;

            public NuovoRecuperoController(ILogger<NuovoRecuperoController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
            {
                _logger = logger;
                _configuration = (IConfigurationRoot)configuration;
                _httpContextAccessor = httpContextAccessor;

                _RCDDbContext = RCDDbContext;
            }

        #region INSTALLAZIONE RECUPERO

        [HttpPost]
        [Route("getInstallazioniPerRecuperoCustom")]
        public async Task<IActionResult> GetInstallazioniPerRecuperoCustom(LocationRequestFull location)
        {
            JsonResult jsonResult = new JsonResult(null);

            Int64 idUtente = 25; //1395;//       

            if (idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetInstallazioniPerRecuperoCustom nel recupero utente loggato");
            }
            NuovoRecuperoManager recuperiManager = new NuovoRecuperoManager(_RCDDbContext);

            var installazioneRecupero = await recuperiManager.GetInstallazioniPerRecuperoCustom(location, idUtente);
            Int32 installazioneRecuperoTot = await recuperiManager.GetInstallazioniPerRecuperoCustomTot(location, idUtente);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = installazioneRecupero.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = installazioneRecuperoTot, List = installazioneRecupero.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetInstallazioniPerRecuperoCustom finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetInstallazioniPerRecuperoCustom" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetInstallazioniPerRecuperoCustom " + ex.Message);
            }

            return jsonResult;
        }

     # endregion INSTALLAZIONE RECUPERO

    }
}
