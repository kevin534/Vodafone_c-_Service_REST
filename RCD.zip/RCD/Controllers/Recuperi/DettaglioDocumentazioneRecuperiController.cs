﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code.Amministrazione;
using RCD.Code.Recuperi;
using RCD.Controllers;
using RCDContracts;
using RCDContracts.Request;
using RCDEngine.Entities;
namespace RCD.Controllers.Recuperi
{
    [ApiController]
    [Route("recuperi/[controller]")]
    public class DettaglioDocumentazioneRecuperiController : _BaseController
    {
        private readonly ILogger<DettaglioDocumentazioneRecuperiController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public DettaglioDocumentazioneRecuperiController(ILogger<DettaglioDocumentazioneRecuperiController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        #region DOCUMENTAZIONE RECUPERO BY IDRECUPERO

        [HttpPost]
        [Route("getDocumentazioneRecuperobyRecuperoId")]
        public async Task<IActionResult> GetDocumentazioneRecuperobyRecuperoId(DocumentazioneRecuperoRequestFull recupero)
        {
            DettaglioDocumentazioneRecuperiManager recuperiManager = new DettaglioDocumentazioneRecuperiManager(_RCDDbContext);
            var docRecuperi = await recuperiManager.GetDocumentazioneRecuperobyRecuperoId(recupero);
            Int32 recuperoTot = await recuperiManager.GetDocumentazioneRecuperobyRecuperoIdTot(recupero);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = docRecuperi.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = recuperoTot, List = docRecuperi.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetDocumentazioneRecuperobyRecuperoId finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetDocumentazioneRecuperobyRecuperoId" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetDocumentazioneRecuperobyRecuperoId " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("addDocumentazioneRecuperobyRecuperoId")]
        public async Task<IActionResult> AddDocumentazioneRecuperobyRecuperoId([FromBody] DocumentazioneRecuperoRequest recupero)
        {

            DettaglioDocumentazioneRecuperiManager recuperiManager = new DettaglioDocumentazioneRecuperiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                recuperiManager.AddDocumentazioneRecuperobyRecuperoId(recupero);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "DocumentazioneRecuperobyRecuperoId aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddDocumentazioneRecuperobyRecuperoId finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento DocumentazioneRecuperobyRecuperoId" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddDocumentazioneRecuperobyRecuperoId " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editDocumentazioneRecuperobyRecuperoId")]
        public async Task<IActionResult> UpdateDocumentazioneRecuperobyRecuperoId([FromBody] DocumentazioneRecuperoRequest recupero)
        {

            DettaglioDocumentazioneRecuperiManager recuperiManager = new DettaglioDocumentazioneRecuperiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                recuperiManager.UpdateDocumentazioneRecuperobyRecuperoId(recupero);

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "UpdateDocumentazioneRecuperobyRecuperoId modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("edit UpdateDocumentazioneRecuperobyRecuperoId finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica DocumentazioneRecuperobyRecuperoId" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in edit DocumentazioneRecuperobyRecuperoId " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteDocumentazioneRecuperobyRecuperoId")]
        public async Task<IActionResult> DeleteDocumentazioneRecuperobyRecuperoId([FromBody] DocumentazioneRecuperoRequest recupero)
        {

            DettaglioDocumentazioneRecuperiManager recuperiManager = new DettaglioDocumentazioneRecuperiManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                recuperiManager.DeleteDocumentazioneRecuperobyRecuperoId(recupero);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "DocumentazioneRecuperobyRecuperoId cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteDocumentazioneRecuperobyRecuperoId finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione DocumentazioneRecuperobyRecuperoId" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteDocumentazioneRecuperobyRecuperoId " + ex.Message);
            }

            return jsonResult;
        }


        #endregion DOCUMENTAZIONE RECUPERO BY IDRECUPERO
    }
}
