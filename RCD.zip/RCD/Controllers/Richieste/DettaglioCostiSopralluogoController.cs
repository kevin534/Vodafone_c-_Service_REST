﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Richieste;
using RCDContracts;
using RCDContracts.Data;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers.Richieste
{

    [ApiController]
    [RenewToken]
    [Route("richieste/[controller]")]
    public class DettaglioCostiSopralluogoController : _BaseController
    {

        private readonly ILogger<DettaglioCostiSopralluogoController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        private Int32 counterDiRisposteAsync = 0;

        public DettaglioCostiSopralluogoController(ILogger<DettaglioCostiSopralluogoController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("getCostiSopralluogoCME")]
        public async Task<IActionResult> GetCostiSopralluogoCME([FromBody] SopralluogoCMERequestFull sopralluogoCME)
        {
            DettaglioCostoSopralluogoManager dettaglioCostoSopralluogoManager = new DettaglioCostoSopralluogoManager(_RCDDbContext);

            var richieste = await dettaglioCostoSopralluogoManager.GetCostiSopralluogoCME(sopralluogoCME);
            Int32 totRichieste = await dettaglioCostoSopralluogoManager.GetCostiSopralluogoCMETot(sopralluogoCME);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totRichieste, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetReportRichieste finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero richieste" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getReportRichieste " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addCostiSopralluogoCME")]
        public async Task<IActionResult> AddCostiSopralluogoCME([FromBody] SopralluogoCMERequest sopralluogoCME)
        {

            DettaglioCostoSopralluogoManager dettaglioCostoSopralluogoManager = new DettaglioCostoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioCostoSopralluogoManager.AddCostiSopralluogoCME(sopralluogoCME);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AddCostiSopralluogoCME aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddCostiSopralluogoCME finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento CostiSopralluogoCME" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddCostiSopralluogoCME " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("editCostiSopralluogoCME")]
        public async Task<IActionResult> EditCostiSopralluogoCME([FromBody] SopralluogoCMERequest sopralluogoCME)
        {

            DettaglioCostoSopralluogoManager dettaglioCostoSopralluogoManager = new DettaglioCostoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioCostoSopralluogoManager.UpdateCostiSopralluogoCME(sopralluogoCME);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "SopralluogoCME modificato con EditCostiSopralluogoCME!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("EditCostiSopralluogoCME finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica CostiSopralluogoCME" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditCostiSopralluogoCME " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteCostiSopralluogoCME")]
        public async Task<IActionResult> DeleteCostiSopralluogoCME([FromBody] SopralluogoCMERequest sopralluogoCME)
        {

            DettaglioCostoSopralluogoManager dettaglioCostoSopralluogoManager = new DettaglioCostoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioCostoSopralluogoManager.DeleteCostiSopralluogoCME(sopralluogoCME);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "CostiSopralluogoCME cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteCostiSopralluogoCME finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione CostiSopralluogoCME" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteCostiSopralluogoCME " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("GetDescrizioneFiscalYearByListinoPreconfigurato")]
        public async Task<IActionResult> GetDescrizioneFiscalYearByListinoPreconfigurato([FromBody] ListinoPreconfiguratoRequestFull listinoPreconfigurato)
        {
            DettaglioCostoSopralluogoManager dettaglioCostoSopralluogoManager = new DettaglioCostoSopralluogoManager(_RCDDbContext);

            var richieste = await dettaglioCostoSopralluogoManager.GetDescrizioneFiscalYearByListinoPreconfigurato(listinoPreconfigurato);
            Int32 totRichieste = await dettaglioCostoSopralluogoManager.GetDescrizioneFiscalYearByListinoPreconfiguratoTot(listinoPreconfigurato);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totRichieste, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetReportRichieste finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero richieste" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getReportRichieste " + ex.Message);
            }

            return jsonResult;
        }
    }
}
