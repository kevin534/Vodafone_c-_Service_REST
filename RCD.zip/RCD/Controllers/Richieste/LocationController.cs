﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Richieste;
using RCDContracts;
using RCDContracts.Data;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers.Richieste
{

    [ApiController]
    [RenewToken]
    [Route("richieste/[controller]")]
    public class LocationController : _BaseController
    {
        private readonly ILogger<LocationController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public LocationController(ILogger<LocationController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }


        [HttpPost]
        [Route("getLocationByIdRichiedente")]
        public async Task<IActionResult> GetLocationByIdRichiedente([FromBody] LocationRequestFull location)
        {
            LocationManager locationManager = new LocationManager(_RCDDbContext);

            var locations = await locationManager.GetLocationByIdRichiedente(location);
            Int32 locationTot = await locationManager.GetLocationByIdRichiedenteTot(location);


            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = locations.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = locationTot, List = locations.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetLocationByIdRichiedente By Id finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetLocationByIdRichiedente" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetLocationByIdRichiedente " + ex.Message);
            }

            return jsonResult;
        }
    }


}


