﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Richieste;
using RCDContracts;
using RCDContracts.Data;
using RCD.Code;
using RCDContracts.Request;
using RCDEngine.Entities;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace RCD.Controllers.Richieste
{
    [ApiController]
    [RenewToken]
    [Route("richieste/[controller]")]
    public class ListaRichiesteController : _BaseController
    {

        private readonly ILogger<ListaRichiesteController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        private Int32 counterDiRisposteAsync = 0;

        public ListaRichiesteController(ILogger<ListaRichiesteController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        #region GET RICHIESTE"

        [HttpPost]
        [Route("getRichiesteKO")]
        public async Task<IActionResult> GetRichiesteKO([FromBody] ViewRichiesteRequestFull richiesta)
        {
            ListaRichiesteManager listaRichiestaManager = new ListaRichiesteManager(_RCDDbContext);

            //_RCDDbContext.Database.SetCommandTimeout(400);
            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            long idUtente = Convert.ToInt64(claim.Value);
            //long idUtente = 928;

            var richieste = await listaRichiestaManager.GetViewReportRichieste(richiesta, true, idUtente);
            Int32 totRichieste = await listaRichiestaManager.GetViewReportRichiesteTot(richiesta, true, idUtente);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totRichieste, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiesteKO finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero richieste" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getRichiesteKO " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("GetRichiesteAttesaOkSopralluogo")]
        public async Task<IActionResult> GetRichiesteAttesaOkSopralluogo([FromBody] RichiestaRequestFull richiesta)
        {
            ListaRichiesteManager listaRichiestaManager = new ListaRichiesteManager(_RCDDbContext);

            //_RCDDbContext.Database.SetCommandTimeout(400);
            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            long idUtente = Convert.ToInt64(claim.Value);
           // long idUtente = 11397; 25
           //long idUtente = 34;

            var richieste = await listaRichiestaManager.GetRichiesteAttesaOkSopralluogo(richiesta, idUtente);
            Int32 totRichieste = await listaRichiestaManager.GetRichiesteAttesaOkSopralluogoTot(richiesta,idUtente);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totRichieste, List = richieste.ToList() } })
                //jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiesteKO finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero richieste" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getRichiesteKO " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("getReportRichieste")]
        public async Task<IActionResult> GetReportRichieste([FromBody] ViewRichiesteRequestFull richiesta)
        {
            ListaRichiesteManager listaRichiestaManager = new ListaRichiesteManager(_RCDDbContext);
            //DA VERIFICARE -- idUtente = 0
            var richieste = await listaRichiestaManager.GetViewReportRichieste(richiesta, false,0);
            Int32 totRichieste = await listaRichiestaManager.GetViewReportRichiesteTot(richiesta,false,0);
           
            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totRichieste, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetReportRichieste finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero richieste" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getReportRichieste " + ex.Message);
            }
            
            return jsonResult;
        }

        [HttpPost]
        [Route("getRichiestaInstallazioneById")]
        public async Task<IActionResult> GetRichiestaInstallazioneById([FromBody] RichiestaRequestFull richiestaR)
        {
            ListaRichiesteManager listaRichiestaManager = new ListaRichiesteManager(_RCDDbContext);

            var richieste = await listaRichiestaManager.GetRichiestaInstallazioneById(richiestaR);
            Int32 totRichieste = 1;
                //await listaRichiestaManager.GetViewReportRichiesteTot();

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste; //..ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totRichieste, List = richieste } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiestaInstallazioneById finish at: {time}", DateTimeOffset.Now);
            }

            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero richiesta installazione by id" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiestaInstallazioneById " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("getRichiestaLocationById")]
        public async Task<IActionResult> GetRichiestaLocationById([FromBody] RichiestaRequestFull richiestaR)
        {
            ListaRichiesteManager listaRichiestaManager = new ListaRichiesteManager(_RCDDbContext);

            var richieste = await listaRichiestaManager.GetRichiestaLocationById(richiestaR);
            //  var richieste1 = await listaRichiestaManager.GetRichiestaById1(richiestaR);
            Int32 totRichieste = 1;
                //await listaRichiestaManager.GetViewReportRichiesteTot();
           
            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste; //..ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totRichieste, List = richieste } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiestaById finish at: {time}", DateTimeOffset.Now);
            }

            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiestaById " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("getRichiestaUtentiById")]
        public async Task<IActionResult> GetRichiestaUtentiById([FromBody] RichiestaRequestFull richiestaR)
        {
            ListaRichiesteManager listaRichiestaManager = new ListaRichiesteManager(_RCDDbContext);

            var richieste = await listaRichiestaManager.GetRichiestaUtentiById(richiestaR);
          //  var richieste1 = await listaRichiestaManager.GetRichiestaById1(richiestaR);
            //Int32 totRichieste = await listaRichiestaManager.GetViewReportRichiesteTot();
             Int32 totRichieste = 1;

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste; //..ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totRichieste, List = richieste } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiestaById finish at: {time}", DateTimeOffset.Now);
            }

            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiestaById " + ex.Message);
            }
            
            return jsonResult;
        }

        [HttpPost]
        [Route("getRichiestaSopralluogoById")]
        public async Task<IActionResult> GetRichiestaSopralluogoById([FromBody] RichiestaRequestFull richiestaR)
        {
            ListaRichiesteManager listaRichiestaManager = new ListaRichiesteManager(_RCDDbContext);

          
            //  var richieste1 = await listaRichiestaManager.GetRichiestaById1(richiestaR);
            // Int32 totRichieste = await listaRichiestaManager.GetViewReportRichiesteTot();
            Int32 totRichieste = 1;

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                var richieste = await listaRichiestaManager.GetRichiestaSopralluogoById(richiestaR);
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste; //..ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totRichieste, List = richieste } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiestaById finish at: {time}", DateTimeOffset.Now);
            }

            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiestaById " + ex.Message);
            }

            return jsonResult;
        }

        #endregion "GET RICHIESTE"

        #region "AZIONI RICHIESTE - SALVATAGGI"

        [HttpPost]
        [Route("insertNuovaRichiesta")]
        public async Task<IActionResult> InsertRichiesta([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                long idUtente = 928;
                //var identity = User.Identity as ClaimsIdentity;
                //Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                //long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta= DateTime.Now;
                EntityRichiesta newRichiesta = new EntityRichiesta();
                long? idRichiesta = actionFormManager.InsertNewRichiesta(richiesta, idUtente,false);
                newRichiesta.Id = idRichiesta;
                
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = {List = newRichiesta}, Message = "Richiesta " + idRichiesta.ToString() + " aggiunta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddRichiesta finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddRichiesta " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("onConfirmSave")]
        public async Task<IActionResult> OnConfirmSave([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                long idUtente = 928;
                //var identity = User.Identity as ClaimsIdentity;
                //Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                //long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                actionFormManager.OnConfirmSave(richiesta, idUtente,false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "onConfirmSave: Richiesta salvata con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("OnConfirmSave finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "OnConfirmAttesaOkInstallazione: Errore in fase di aggiornamento stato richiesta " + ex.Message })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in OnConfirmAttesaOkInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("onConfirmSaveOkInstallazione")]
        public async Task<IActionResult> OnConfirmSaveOkInstallazione([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                long idUtente = 928;
                //var identity = User.Identity as ClaimsIdentity;
                //Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                //long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                actionFormManager.OnConfirmSaveOkInstallazione(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "OnConfirmSaveOkInstallazione: Richiesta salvata con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("OnConfirmSaveOkInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "OnConfirmSaveOkInstallazione: Errore in fase di aggiornamento stato richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in OnConfirmSaveOkInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("onConfirmInstallazioneAvvenuta")]
        public async Task<IActionResult> OnConfirmInstallazioneAvvenuta([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                long idUtente = 928;
                //var identity = User.Identity as ClaimsIdentity;
                //Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                //long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                actionFormManager.OnConfirmInstallazioneAvvenuta(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "OnConfirmInstallazioneAvvenuta: Richiesta salvata con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("OnConfirmInstallazioneAvvenuta finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "OnConfirmSaveOkInstallazione: Errore in fase di aggiornamento stato richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in OnConfirmSaveOkInstallazione " + ex.Message);
            }

            return jsonResult;
        }
        
        [HttpPost]
        [Route("okSopralluogo")]
        public async Task<IActionResult> OKSopralluogo([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                long idUtente = 928;
                //var identity = User.Identity as ClaimsIdentity;
                //Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                //long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                actionFormManager.OKSopralluogo(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "OKSopralluogo: Aggiornato next stato richiesta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("OKSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "OKSopralluogo: Errore in fase di inserimento richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in OKSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("onConfirmAttesaOkSopralluogo")]
        public async Task<IActionResult> OnConfirmAttesaOkSopralluogo([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                //long idUtente = 928;
                var identity = User.Identity as ClaimsIdentity;
                Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                actionFormManager.OnConfirmAttesaOkSopralluogo(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "OnConfirmAttesaOkSopralluogo: Aggiornato next stato richiesta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("OnConfirmAttesaOkSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "OnConfirmAttesaOkSopralluogo: Errore in fase di aggiornamento stato richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in OnConfirmAttesaOkSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("onConfirmSopralluogoEffettuato")]
        public async Task<IActionResult> OnConfirmSopralluogoEffettuato([FromBody] EntityRichiesta richiesta)
        {
            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                //long idUtente = 928;
                var identity = User.Identity as ClaimsIdentity;
                Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                actionFormManager.SopralluogoEffettuato(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "OnConfirmSopralluogoEffettuato: Aggiornato next stato richiesta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("OnConfirmSopralluogoEffettuato finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "OnConfirmSopralluogoEffettuato: Errore in fase di aggiornamento stato richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in OnConfirmSopralluogoEffettuato " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("OnConfirmKoTecnico")]
        public async Task<IActionResult> OnConfirmKoTecnico([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                //long idUtente = 928;
                var identity = User.Identity as ClaimsIdentity;
                Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                actionFormManager.KoTecnicoDopoSopralluogo(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "KoTecnicoDopoSopralluogo: Aggiornato next stato richiesta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("KoTecnicoDopoSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "KoTecnicoDopoSopralluogo: Errore in fase di aggiornamento stato richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in KoTecnicoDopoSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("OnConfirmOkTecnicoDopoSopralluogo")]
        public async Task<IActionResult> OnConfirmOkTecnicoDopoSopralluogo([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                var identity = User.Identity as ClaimsIdentity;
                Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                long idUtente = Convert.ToInt64(claim.Value);
                //long idUtente = 928;
                richiesta.DataRichiesta = DateTime.Now;
                actionFormManager.OkTecnicoDopoSopralluogo(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "OkTecnicoDopoSopralluogo: Aggiornato next stato richiesta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("OkTecnicoDopoSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "OkTecnicoDopoSopralluogo: Errore in fase di aggiornamento stato richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in KoTecnicoDopoSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("onConfirmAttesaOkInstallazione")]
        public async Task<IActionResult> OnConfirmAttesaOkInstallazione([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                long idUtente = 928;
                //var identity = User.Identity as ClaimsIdentity;
                //Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                //long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                actionFormManager.OnConfirmAttesaOkInstallazione(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "OnConfirmAttesaOkInstallazione: Aggiornato next stato richiesta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("OnConfirmAttesaOkInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "OnConfirmAttesaOkInstallazione: Errore in fase di aggiornamento stato richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in OnConfirmAttesaOkInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("attesaOkInstallazioneDopoGov")]
        public async Task<IActionResult> AttesaOkInstallazioneDopoGov([FromBody] EntityRichiesta richiesta)
        {
            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                //long idUtente = 928;
                var identity = User.Identity as ClaimsIdentity;
                Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                actionFormManager.AttesaOkInstallazioneDopoGov(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AttesaOkInstallazioneDopoGov: Aggiornato next stato richiesta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AttesaOkInstallazioneDopoGov finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "AttesaOkInstallazioneDopoGov: Errore in fase di aggiornamento stato richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AttesaOkInstallazioneDopoGov " + ex.Message);
            }

            return jsonResult;
        }

        //[HttpPost]
        //[Route("attesaOkInstallazione")]
        //public async Task<IActionResult> AttesaOkInstallazione([FromBody] EntityRichiesta richiesta)
        //{

        //    ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
        //    JsonResult jsonResult = new JsonResult(null);
        //    try
        //    {
        //        //utente inserito da scommentare
        //        long idUtente = 928;
        //        richiesta.DataRichiesta = DateTime.Now;
        //        actionFormManager.AttesaOkInstallazione(richiesta, idUtente, false);
        //        jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AttesaOkInstallazione: Aggiornato next stato richiesta con successo!" })
        //        {
        //            StatusCode = 200,
        //        };
        //        _logger.LogInformation("AttesaOkInstallazione finish at: {time}", DateTimeOffset.Now);

        //    }
        //    catch (Exception ex)
        //    {
        //        jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "AttesaOkInstallazione: Errore in fase di aggiornamento stato richiesta" })
        //        {
        //            StatusCode = 500,
        //        };
        //        _logger.LogError("Error in AttesaOkInstallazione " + ex.Message);
        //    }

        //    return jsonResult;
        //}

        [HttpPost]
        [Route("onConfirmOkInstallazione")]
        public async Task<IActionResult> OnConfirmOkInstallazione([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                //long idUtente = 928;
                var identity = User.Identity as ClaimsIdentity;
                Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                actionFormManager.OkInstallazioneFuoriGovernance(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "OkInstallazione: Aggiornato next stato richiesta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("OkInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "OkInstallazione: Errore in fase di aggiornamento stato richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in OkInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("onConfirmKovendite")]
        public async Task<IActionResult> OnConfirmKovendite([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                long idUtente = 928;
                //var identity = User.Identity as ClaimsIdentity;
                //Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                //long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                //actionFormManager.KoClienteFuoriGovernance(richiesta, idUtente, false);
                actionFormManager.KoVendite(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "KoVendite: Aggiornato next stato richiesta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("KoVendite finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "KoVendite: Errore in fase di inserimento richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in KoVendite " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("onConfirmKovenditeDopoSopralluogo")]
        public async Task<IActionResult> OnConfirmKovenditeDopoSopralluogo([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                //long idUtente = 928;
                var identity = User.Identity as ClaimsIdentity;
                Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                //actionFormManager.KoClienteFuoriGovernance(richiesta, idUtente, false);
                actionFormManager.KoVenditeDopoSopralluogo(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "KoVenditeDopoSopralluogo: Aggiornato next stato richiesta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("KoVenditeDopoSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "KoVenditeDopoSopralluogo: Errore in fase di inserimento richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in KoVenditeDopoSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("onConfirmKoCliente")]
        public async Task<IActionResult> OnConfirmKoCliente([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                //long idUtente = 928;
                var identity = User.Identity as ClaimsIdentity;
                Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                actionFormManager.KoClienteDopoOkTecnico(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "KOCliente: Aggiornato next stato richiesta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("KOCliente finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "KOCliente: Errore in fase di inserimento richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in KOCliente " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("onConfirmKoClienteSopralluogo")]
        public async Task<IActionResult> OnConfirmKoClienteSopralluogo([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                //long idUtente = 928;
                var identity = User.Identity as ClaimsIdentity;
                Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                actionFormManager.KoClienteSopralluogo(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "KOClienteSopralluogo: Aggiornato next stato richiesta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("KOClienteSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "KOClienteSopralluogo: Errore in fase di inserimento richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in KOClienteSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("onConfirmKoClienteInstallazione")]
        public async Task<IActionResult> OnConfirmKoClienteInstallazione([FromBody] EntityRichiesta richiesta)
        {

            ActionFormManager actionFormManager = new ActionFormManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                //utente inserito da scommentare
                //long idUtente = 928;
                var identity = User.Identity as ClaimsIdentity;
                Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
                long idUtente = Convert.ToInt64(claim.Value);
                richiesta.DataRichiesta = DateTime.Now;
                actionFormManager.KoClienteInstallazione(richiesta, idUtente, false);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "KoClienteInstallazione: Aggiornato next stato richiesta con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("KoClienteInstallazione finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "KoClienteInstallazione: Errore in fase di inserimento richiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in KoClienteInstallazione " + ex.Message);
            }

            return jsonResult;
        }
        #endregion "AZIONI RICHIESTE - SALVATAGGI"


        //FORSE DA CANCELLARE
        //[HttpPost]
        //[Route("insertNuovaRichiestaRichiedente")]
        //public async Task<IActionResult> InsertRichiestaRichiedente([FromBody] EntityRichiesta richiestaR)
        //{

        //    RichiedenteManager richiedenteManager = new RichiedenteManager(_RCDDbContext);
        //    JsonResult jsonResult = new JsonResult(null);
        //    try
        //    {

        //        richiestaR.DataRichiesta = DateTime.Now;
        //        //DA TOGLIERE
        //        long idUtente = 928;
        //        richiedenteManager.AddRichiestaNuovoRichiedente(richiestaR,idUtente);
        //        jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Richiesta nuovo richiedente aggiunta con successo!" })
        //        {
        //            StatusCode = 200,
        //        };
        //        _logger.LogInformation("InsertNuovaRichiestaRichiedente finish at: {time}", DateTimeOffset.Now);

        //    }
        //    catch (Exception ex)
        //    {
        //        jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento richiesta richiedente" })
        //        {
        //            StatusCode = 500,
        //        };
        //        _logger.LogError("Error in AddRichiesta " + ex.Message);
        //    }

        //    return jsonResult;
        //}

    }
}
