﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Richieste;
using RCDContracts;
using RCDContracts.Data;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers.Richieste
{

    [ApiController]
    [RenewToken]
    [Route("richieste/[controller]")]
    public class DocumentazioneSopralluogoController : _BaseController
    {
        private readonly ILogger<DocumentazioneSopralluogoController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public DocumentazioneSopralluogoController(ILogger<DocumentazioneSopralluogoController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }


        [HttpPost]
        [Route("getDocSopralluogobySopralluogoId")]
        public async Task<IActionResult> GetDocSopralluogobySopralluogoId([FromBody] DocumentazioneSopralluogoRequestFull docSpralluogo)
        {
            DocumentazioneSopralluogoManager docManager = new DocumentazioneSopralluogoManager(_RCDDbContext);

            var docSpralluoggi = await docManager.GetDocumentazioneSopralluogobySopralluogoId(docSpralluogo);
            Int32 ddocSpralluogoTot = await docManager.GetDocumentazioneSopralluogobySopralluogoIdTot(docSpralluogo);


            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = docSpralluoggi.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = ddocSpralluogoTot, List = docSpralluoggi.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetDocSopralluogobySopralluogoId finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetDocSopralluogobySopralluogoId" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetDocSopralluogobySopralluogoId " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("getDocumentoSopralluogoById")]
        public async Task<IActionResult> GetDocumentoSopralluogoById([FromBody] DocumentazioneSopralluogoRequestFull docSpralluogo)
        {
            DocumentazioneSopralluogoManager docManager = new DocumentazioneSopralluogoManager(_RCDDbContext);

            var docSpralluoggi = await docManager.GetDocumentoSopralluogoById(docSpralluogo);
            Int32 ddocSpralluogoTot = await docManager.GetDocumentoSopralluogoByIdTot(docSpralluogo);


            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = docSpralluoggi.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = ddocSpralluogoTot, List = docSpralluoggi.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetDocumentoSopralluogoById finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetDocumentoSopralluogoById" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetDocumentoSopralluogoById " + ex.Message);
            }

            return jsonResult;
        }
    }


}


