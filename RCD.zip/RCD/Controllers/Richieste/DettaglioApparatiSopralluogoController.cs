﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Richieste;
using RCDContracts;
using RCDContracts.Data;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers.Richieste
{
    [ApiController]
    [RenewToken]
    [Route("richieste/[controller]")]
    public class DettaglioApparatiSopralluogoController : _BaseController
    {

        private readonly ILogger<DettaglioApparatiSopralluogoController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        private Int32 counterDiRisposteAsync = 0;

        public DettaglioApparatiSopralluogoController(ILogger<DettaglioApparatiSopralluogoController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        #region APPARATI DETTAGLIO
        [HttpPost]
        [Route("GetApparatiSopralluogoDettaglio")]
        public async Task<IActionResult> GetApparatiSopralluogoDettaglio([FromBody] ApparatiSopralluogoRequestFull apparatoSopralluogo)
        {
            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);

            var apparatiSopralluoghi = await dettaglioApparatoSopralluogoManager.GetApparatiSopralluogo(apparatoSopralluogo);
            Int32 totApparatiSopralluoghi = await dettaglioApparatoSopralluogoManager.GetApparatiSopralluogoTot(apparatoSopralluogo);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = apparatiSopralluoghi.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totApparatiSopralluoghi, List = apparatiSopralluoghi.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetApparatiSopralluogo finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero apparati sopralluoghi" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getApparatiSopralluogo " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("add")]
        public async Task<IActionResult> AddApparatiSopralluogo([FromBody] ApparatiSopralluogoRequest EntitySopralluogoApparati)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.AddApparatiSopralluogo(EntitySopralluogoApparati);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "ApparatiSopralluogo aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddApparatiSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento ApparatiSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddApparatiSopralluogo " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("edit")]
        public async Task<IActionResult> EditApparatiSopralluogo([FromBody] ApparatiSopralluogoRequest EntitySopralluogoApparati)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.UpdateApparatiSopralluogo(EntitySopralluogoApparati);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Accessorio modificato con ApparatiSopralluogo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("EditApparatiSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica ApparatiSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditApparatiSopralluogo " + ex.Message);
            }

            return jsonResult;
        }
        [HttpPost]
        [Route("delete")]
        public async Task<IActionResult> DeleteApparatiSopralluogo([FromBody] ApparatiSopralluogoRequest EntitySopralluogoApparati)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.DeleteApparatiSopralluogo(EntitySopralluogoApparati);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "ApparatiSopralluogo modificato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteApparatiSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione ApparatiSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteApparatiSopralluogo " + ex.Message);
            }

            return jsonResult;
        }
        #endregion APPARATI DETTAGLIO

        #region CROWDCELL DETTAGLIO
        [HttpPost]
        [Route("GetCrowdcellSopralluogoDettaglio")]
        public async Task<IActionResult> GetCrowdcellSopralluogoDettaglio([FromBody] CrowdcellSopralluogoRequestFull crowdcellSopralluogo)
        {
            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);

            var crowdcellSopralluoghi = await dettaglioApparatoSopralluogoManager.GetCrowdcellSopralluogo(crowdcellSopralluogo);
            Int32 totCrowdcellSopralluoghi = await dettaglioApparatoSopralluogoManager.GetCrowdcellSopralluogoTot(crowdcellSopralluogo);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = crowdcellSopralluoghi.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totCrowdcellSopralluoghi, List = crowdcellSopralluoghi.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetCrowdcellSopralluogo finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero crowdcell sopralluoghi" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getCrowdcellSopralluogo " + ex.Message);
            }

            return jsonResult;
        }
        
        [HttpPost]
        [Route("addCrowdcellSopralluogoDettaglio")]
        public async Task<IActionResult> AddCrowdcellSopralluogo([FromBody] CrowdcellSopralluogoRequest crowdcellSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.AddCrowdcellSopralluogo(crowdcellSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AddCrowdcellSopralluogo aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddCrowdcellSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento CrowdcellSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddCrowdcellSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("editCrowdcellSopralluogoDettaglio")]
        public async Task<IActionResult> EditCrowdcellSopralluogo([FromBody] CrowdcellSopralluogoRequest crowdcellSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.UpdateCrowdcellSopralluogo(crowdcellSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Accessorio modificato con CrowdcellSopralluogo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("EditCrowdcellSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica CrowdcellSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditCrowdcellSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteCrowdcellSopralluogoDettaglio")]
        public async Task<IActionResult> DeleteCrowdcellSopralluogo([FromBody] CrowdcellSopralluogoRequest crowdcellSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.DeleteCrowdcellSopralluogo(crowdcellSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "CrowdcellSopralluogo cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteCrowdcellSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione CrowdcellSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteCrowdcellSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        #endregion CROWDCELL DETTAGLIO

        #region FEMTO DETTAGLIO
        [HttpPost]
        [Route("GetFemtoSopralluogoDettaglio")]
        public async Task<IActionResult> GetFemtoSopralluogoDettaglio([FromBody] FemtoSopralluogoRequestFull femtoSopralluogo)
        {
            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);

            var femtoSopralluoghi = await dettaglioApparatoSopralluogoManager.GetFemtoSopralluogo(femtoSopralluogo);
            Int32 totFemtoSopralluoghi = await dettaglioApparatoSopralluogoManager.GetFemtoSopralluogoTot(femtoSopralluogo);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = femtoSopralluoghi.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totFemtoSopralluoghi, List = femtoSopralluoghi.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetFemtoSopralluogo finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero apparati femto" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getFemtoSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addFemtoSopralluogo")]
        public async Task<IActionResult> AddFemtoSopralluogo([FromBody] FemtoSopralluogoRequest femtoSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.AddFemtoSopralluogo(femtoSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AddFemtoSopralluogo aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddFemtoSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento FemtoSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddFemtoSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("editFemtoSopralluogo")]
        public async Task<IActionResult> EditFemtoSopralluogo([FromBody] FemtoSopralluogoRequest femtoSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.UpdateFemtoSopralluogo(femtoSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Accessorio modificato con FemtoSopralluogo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("EditFemtoSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica FemtoSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in EditFemtoSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteFemtoSopralluogo")]
        public async Task<IActionResult> DeleteFemtoSopralluogo([FromBody] FemtoSopralluogoRequest femtoSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.DeleteFemtoSopralluogo(femtoSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "FemtoSopralluogo cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteFemtoSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione FemtoSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteFemtoSopralluogo " + ex.Message);
            }

            return jsonResult;
        }
        #endregion FEMTO DETTAGLIO

        #region MISURE DETTAGLIO
        [HttpPost]
        [Route("GetMisuraSopralluogoDettaglio")]
        public async Task<IActionResult> GetMisuraSopralluogoDettaglio([FromBody] MisuraSopralluogoRequestFull misuraSopralluogo)
        {
            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);

            var misureSopralluoghi = await dettaglioApparatoSopralluogoManager.GetMisureSopralluogo(misuraSopralluogo);
            Int32 totMisuraSopralluoghi = await dettaglioApparatoSopralluogoManager.GetMisureSopralluogoTot(misuraSopralluogo);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = misureSopralluoghi.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totMisuraSopralluoghi, List = misureSopralluoghi.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetMisureSopralluogo finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero apparati femto" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getMisureSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addMisuraSopralluogo")]
        public async Task<IActionResult> AddMisuraSopralluogo([FromBody] MisuraSopralluogoRequest misuraSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.AddMisuraSopralluogo(misuraSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AddMisuraSopralluogo aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddMisuraSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento MisuraSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddMisuraSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("editMisuraSopralluogo")]
        public async Task<IActionResult> UpdateMisuraSopralluogo([FromBody] MisuraSopralluogoRequest misuraSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.UpdateMisuraSopralluogo(misuraSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "Accessorio modificato con MisuraSopralluogo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editMisuraSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica MisuraSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editMisuraSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteMisuraSopralluogo")]
        public async Task<IActionResult> DeleteMisuraSopralluogo([FromBody] MisuraSopralluogoRequest misuraSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.DeleteMisuraSopralluogo(misuraSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "MisuraSopralluogo cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteMisuraSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione MisuraSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteMisuraSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        #endregion MISURE DETTAGLIO

        #region ANTENNE DETTAGLIO
        [HttpPost]
        [Route("GetAntennaSopralluogoDettaglio")]
        public async Task<IActionResult> GetAntennaSopralluogoDettaglio([FromBody] AntennaSopralluogoRequestFull antennaSopralluogo)
        {
            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);

            var antenneSopralluoghi = await dettaglioApparatoSopralluogoManager.GetAntenneSopralluogo(antennaSopralluogo);
            Int32 totAntennaSopralluoghi = await dettaglioApparatoSopralluogoManager.GetAntenneSopralluogoTot(antennaSopralluogo);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = antenneSopralluoghi.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totAntennaSopralluoghi, List = antenneSopralluoghi.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAntenneSopralluogo finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero antenne" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getAntenneSopralluogo " + ex.Message);
            }

            return jsonResult;
        }


        [HttpPost]
        [Route("addAntenneSopralluogo")]
        public async Task<IActionResult> AddAntenneSopralluogo([FromBody] AntennaSopralluogoRequest antennaSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.AddAntenneSopralluogo(antennaSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AddAntenneSopralluogo aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddAntenneSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento AntenneSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddAntenneSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("editAntenneSopralluogo")]
        public async Task<IActionResult> UpdateAntenneSopralluogo([FromBody] AntennaSopralluogoRequest antennaSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.UpdateAntenneSopralluogo(antennaSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AntenneSopralluogo modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editAntenneSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica AntenneSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editAntenneSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteAntenneSopralluogo")]
        public async Task<IActionResult> DeleteAntenneSopralluogo([FromBody] AntennaSopralluogoRequest antennaSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.DeleteAntenneSopralluogo(antennaSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AntenneSopralluogo cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteAntenneSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione AntenneSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteAntenneSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

  
        #endregion ANTENNE DETTAGLIO

        #region ACCESSORIO DETTAGLIO
        [HttpPost]
        [Route("GetAccessorioSopralluogoDettaglio")]
        public async Task<IActionResult> GetAccessorioSopralluogoDettaglio([FromBody] AccessorioSopralluogoRequestFull accessorioSopralluogo)
        {
            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);

            var accessoriSopralluoghi = await dettaglioApparatoSopralluogoManager.GetAccessoriSopralluogo(accessorioSopralluogo);
            Int32 totAccessorioSopralluoghi = await dettaglioApparatoSopralluogoManager.GetAccessoriSopralluogoTot(accessorioSopralluogo);

            JsonResult jsonResult = new JsonResult(null);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = accessoriSopralluoghi.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = totAccessorioSopralluoghi, List = accessoriSopralluoghi.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetAccessoriSopralluogo finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero accessori" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in getAccessoriSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("addAccessoriSopralluogo")]
        public async Task<IActionResult> AddAccessoriSopralluogo([FromBody] AccessorioSopralluogoRequest accessorioSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.AddAccessoriSopralluogo(accessorioSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AddAccessoriSopralluogo aggiunto con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("AddAccessoriSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di inserimento AccessoriSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in AddAccessoriSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("editAccessoriSopralluogo")]
        public async Task<IActionResult> UpdateAccessoriSopralluogo([FromBody] AccessorioSopralluogoRequest accessorioSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.UpdateAccessoriSopralluogo(accessorioSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AccessoriSopralluogo modificato con Successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("editAccessoriSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di modifica AccessoriSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in editAccessoriSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        [HttpPost]
        [Route("deleteAccessoriSopralluogo")]
        public async Task<IActionResult> DeleteAccessoriSopralluogo([FromBody] AccessorioSopralluogoRequest accessorioSopralluogo)
        {

            DettaglioApparatoSopralluogoManager dettaglioApparatoSopralluogoManager = new DettaglioApparatoSopralluogoManager(_RCDDbContext);
            JsonResult jsonResult = new JsonResult(null);
            try
            {
                dettaglioApparatoSopralluogoManager.DeleteAccessoriSopralluogo(accessorioSopralluogo);
                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Message = "AccessoriSopralluogo cancellato con successo!" })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("DeleteAccessoriSopralluogo finish at: {time}", DateTimeOffset.Now);

            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = "Errore in fase di Cancellazione AccessoriSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in DeleteAccessoriSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        #endregion ACCESSORIO DETTAGLIO
    }

}
