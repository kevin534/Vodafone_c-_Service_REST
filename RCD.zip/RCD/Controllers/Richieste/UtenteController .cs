﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Richieste;
using RCDContracts;
using RCDContracts.Data;
using RCD.Code;
using RCDContracts.Request;

namespace RCD.Controllers.Richieste
{

    [ApiController]
    [RenewToken]
    [Route("richieste/[controller]")]
    public class UtenteController : _BaseController
    {
        private readonly ILogger<UtenteController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public UtenteController(ILogger<UtenteController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }

        [HttpPost]
        [Route("getUtentiRiferimentiVendite")]
        public async Task<IActionResult> GetUtentiRiferimentiVendite(UtenteRequestFull utenteFilter)
        {

            UtenteManager utentiManager = new UtenteManager(_RCDDbContext);

            var utenti = await utentiManager.GetUtentiRiferimentiVendite(utenteFilter);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = utenti.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = utenti.ToList().Count, List = utenti.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtentiRiferimentiVendite finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetUtentiRiferimentiVendite" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetUtentiRiferimentiVendite " + ex.Message);
            }

            return jsonResult;
        }
        
        [HttpPost]
        [Route("getUtentiRiferimentiAreaManager")]
        public async Task<IActionResult> GetUtentiRiferimentiAreaManager(UtenteRequestFull utenteFilter)
        {

            UtenteManager utentiManager = new UtenteManager(_RCDDbContext);

            var utenti = await utentiManager.GetUtentiRiferimentiAreaManager(utenteFilter);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = utenti.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = utenti.ToList().Count, List = utenti.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtentiRiferimentiAreaManager finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetUtentiRiferimentiAreaManager" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetUtentiRiferimentiAreaManager " + ex.Message);
            }

            return jsonResult;
        }

        
        [HttpGet]
        [Route("getUtentiRiferimentiDce")]
        public async Task<IActionResult> GetUtentiRiferimentiDce()
        {

            UtenteManager utentiManager = new UtenteManager(_RCDDbContext);

            var utenti = await utentiManager.GetUtentiRiferimentiDce();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = utenti.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = utenti.ToList().Count, List = utenti.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtentiRiferimentiDce finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetUtentiRiferimentiDce" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetUtentiRiferimentiDce " + ex.Message);
            }

            return jsonResult;
        }
      
        [HttpGet]
        [Route("getUtentiSiteManagerNI")]
        public async Task<IActionResult> GetUtentiSiteManagerNI()
        {

            UtenteManager utentiManager = new UtenteManager(_RCDDbContext);

            var utenti = await utentiManager.GetUtentiSiteManagerNI();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = utenti.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = utenti.ToList().Count, List = utenti.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtentiSiteManagerNI finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetUtentiSiteManagerNI" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetUtentiSiteManagerNI " + ex.Message);
            }

            return jsonResult;
        }
 
        [HttpGet]
        [Route("getUtentiProgettistiRAN")]
        public async Task<IActionResult> GetUtentiProgettistiRAN()
        {

            UtenteManager utentiManager = new UtenteManager(_RCDDbContext);

            var utenti = await utentiManager.GetUtentiProgettistiRAN();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = utenti.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = utenti.ToList().Count, List = utenti.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtentiProgettistiRAN finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetUtentiProgettistiRAN" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetUtentiProgettistiRAN " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getUtentiDeliveryManager")]
        public async Task<IActionResult> GetUtentiDeliveryManager()
        {

            UtenteManager utentiManager = new UtenteManager(_RCDDbContext);

            var utenti = await utentiManager.GetUtentiDeliveryManager();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = utenti.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = utenti.ToList().Count, List = utenti.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetUtentiDeliveryManager finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetUtentiDeliveryManager" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetUtentiDeliveryManager " + ex.Message);
            }

            return jsonResult;
        }
    }


}


