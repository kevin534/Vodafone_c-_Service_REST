﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RCD.Code.Richieste;
using RCDContracts;
using RCDContracts.Data;
using RCD.Code;
using RCDContracts.Request;
using System.Security.Claims;

namespace RCD.Controllers.Richieste
{

    [ApiController]
    [RenewToken]
    [Route("richieste/[controller]")]
    public class RichiestaController : _BaseController
    {
        private readonly ILogger<RichiestaController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;

        public RichiestaController(ILogger<RichiestaController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }


        [HttpPost]
        [Route("getRichiestaById")]
        public async Task<IActionResult> GetRichiestaById([FromBody] RichiestaRequestFull richiesta)
        {
            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var richieste = await richiestaManager.GetRichiestaById(richiesta);
            Int32 richiesteTot = await richiestaManager.GetRichiestaTot(richiesta);


            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesteTot, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiestaById By Id finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRichiestaById" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiestaById " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getSistemaRichiesto")]
        public async Task<IActionResult> GetSistemaRichiesto()
        {

            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var richiesta = await richiestaManager.GetSistemaRichiesto();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richiesta.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesta.ToList().Count, List = richiesta.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetSistemaRichiesto finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetSistemaRichiesto" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetSistemaRichiesto " + ex.Message);
            }

            return jsonResult;
        }
        [HttpGet]
        [Route("getServizio")]
        public async Task<IActionResult> GetServizio()
        {

            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var servizio = await richiestaManager.GetServizio();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = servizio.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = servizio.ToList().Count, List = servizio.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetServizio finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetServizio" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetServizio " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getMancanzaSegnale")]
        public async Task<IActionResult> GetMancanzaSegnale()
        {

            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var segnale = await richiestaManager.GetMancanzaSegnale();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = segnale.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = segnale.ToList().Count, List = segnale.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetMancanzaSegnale finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetMancanzaSegnale" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetMancanzaSegnale " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getPrioritaVendite")]
        public async Task<IActionResult> GetPrioritaVendite()
        {

            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var vendite = await richiestaManager.GetPrioritaVendite();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = vendite.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = vendite.ToList().Count, List = vendite.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetPrioritaVendite finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetPrioritaVendite" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetPrioritaVendite " + ex.Message);
            }

            return jsonResult;
        }

        [HttpGet]
        [Route("getMotivoRichiesta")]
        public async Task<IActionResult> GetMotivoRichiesta()
        {

            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var motivoRichiesta = await richiestaManager.GetMotivoRichiesta();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = motivoRichiesta.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = motivoRichiesta.ToList().Count, List = motivoRichiesta.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetMotivoRichiesta finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetMotivoRichiesta" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetMotivoRichiesta " + ex.Message);
            }

            return jsonResult;
        }


        [HttpGet]
        [Route("getTipologiaCantiere")]
        public async Task<IActionResult> GetTipologiaCantiere()
        {

            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var cantiere = await richiestaManager.GetTipologiaCantiere();

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = cantiere.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = cantiere.ToList().Count, List = cantiere.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetTipologiaCantiere finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetTipologiaCantiere" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetTipologiaCantiere " + ex.Message);
            }

            return jsonResult;
        }

        #region RICHIESTA FUORI GOVERNANCE 

        [HttpPost]
        [Route("getRichiesteFuoriGovernance")]
        public async Task<IActionResult> GetRichiesteFuoriGovernance(RichiestaRequestFull richiesta)
        {
            JsonResult jsonResult = new JsonResult(null);
            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            Int64 idUtente = Convert.ToInt64(claim.Value);
            // Int64 idUtente = 25; //1395;//       
            if (idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteFuoriGovernance nel recupero utente loggato");
            }
            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var richieste = await richiestaManager.GetRichiesteFuoriGovernance(richiesta, idUtente);
            Int32 richiesteTot = await richiestaManager.GetRichiesteFuoriGovernanceTot(richiesta, idUtente);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesteTot, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiesteFuoriGovernance finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRichiesteFuoriGovernance" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteFuoriGovernance " + ex.Message);
            }

            return jsonResult;
        }

        #endregion RICHIESTA FUORI GOVERNANCE

        #region RICHIESTA SOPRALUOGO

        [HttpPost]
        [Route("getRichiesteSopralluoghi")]
        public async Task<IActionResult> GetRichiesteSopralluoghi(RichiestaRequestFull richiesta)
        {
            JsonResult jsonResult = new JsonResult(null);

            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            Int64 idUtente = Convert.ToInt64(claim.Value);
            //Int64 idUtente = 25; //1395;//       

            if (idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteSopralluoghi nel recupero utente loggato");
            }
            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var richieste = await richiestaManager.GetRichiesteSopralluoghi(richiesta, idUtente);
            Int32 richiesteTot = await richiestaManager.GetRichiesteSopralluoghiTot(richiesta, idUtente);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesteTot, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiesteSopralluoghi finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRichiesteSopralluoghi" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteSopralluoghi " + ex.Message);
            }

            return jsonResult;
        }

        #endregion RICHIESTA SOPRALUOGO

        #region RICHIESTA BUTTON
        [HttpPost]
        [Route("getButtonSopralluogo")]
        public async Task<IActionResult> GetButtonSopralluogo([FromBody] ContractButton contractButton)
        {

            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            ContractButton button = await richiestaManager.GetButtonSopralluogo(contractButton);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;


                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = 1, List = button } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetButtonSopralluogo finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetButtonSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetButtonSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        #endregion RICHIESTA BUTTON
        #region RICHIESTA SOPRALlUOGO EFFETTUATO
        [HttpPost]
        [Route("getRichiesteSopralluoghiEffettuati")]
        public async Task<IActionResult> GetRichiesteSopralluoghiEffettuati(RichiestaRequestFull richiesta)
        {
            JsonResult jsonResult = new JsonResult(null);

            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            Int64 idUtente = Convert.ToInt64(claim.Value);
            //Int64 idUtente = 25; //1395;//       

            if (idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteSopralluoghi nel recupero utente loggato");
            }
            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var richieste = await richiestaManager.GetRichiesteSopralluoghiEffettuati(richiesta, idUtente);
            Int32 richiesteTot = await richiestaManager.GetRichiesteSopralluoghiEffettuatiTot(richiesta, idUtente);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesteTot, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiesteSopralluoghiEffettuati finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRichiesteSopralluoghiEffettuati" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteSopralluoghiEffettuati " + ex.Message);
            }

            return jsonResult;
        }

        #endregion RICHIESTA SOPRALlUOGO EFFETTUATO

        #region RICHIESTA SOPRALlUOGO OK TECNICO
        [HttpPost]
        [Route("getRichiesteSopralluoghiOkTecnico")]
        public async Task<IActionResult> GetRichiesteSopralluoghiOkTecnico(RichiestaRequestFull richiesta)
        {
            JsonResult jsonResult = new JsonResult(null);

            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            Int64 idUtente = Convert.ToInt64(claim.Value);
            //Int64 idUtente = 25; //1395;//       

            if (idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteSopralluoghi nel recupero utente loggato");
            }
            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var richieste = await richiestaManager.GetRichiesteSopralluoghiOkTecnico(richiesta, idUtente);
            Int32 richiesteTot = await richiestaManager.GetRichiesteSopralluoghiOkTecnicoTot(richiesta, idUtente);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesteTot, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiesteSopralluoghiOkTecnico finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRichiesteSopralluoghiOkTecnico" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteSopralluoghiOkTecnico " + ex.Message);
            }

            return jsonResult;
        }

        #endregion RICHIESTA SOPRALlUOGO OK TECNICO

        #region Attesa OK installazione fuori governance STATO 7 

        [HttpPost]
        [Route("getRichiesteKoGovernanceDopoSopralluogo")]
        public async Task<IActionResult> GetRichiesteKoGovernanceDopoSopralluogo(RichiestaRequestFull richiesta)
        {
            JsonResult jsonResult = new JsonResult(null);
            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            Int64 idUtente = Convert.ToInt64(claim.Value);
            // Int64 idUtente = 25; //1395;//       
            if (idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteKoGovernanceDopoSopralluogo nel recupero utente loggato");
            }
            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var richieste = await richiestaManager.GetRichiesteKoGovernanceDopoSopralluogo(richiesta, idUtente);
            Int32 richiesteTot = await richiestaManager.GetRichiesteKoGovernanceDopoSopralluogoTot(richiesta, idUtente);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesteTot, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiesteKoGovernanceDopoSopralluogo finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRichiesteKoGovernanceDopoSopralluogo" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteKoGovernanceDopoSopralluogo " + ex.Message);
            }

            return jsonResult;
        }

        #endregion Attesa OK installazione fuori governance STATO 7

        #region Attesa OK installazione STATO 8 

        [HttpPost]
        [Route("getRichiesteAttesaOKInstallazione")]
        public async Task<IActionResult> GetRichiesteAttesaOKInstallazione(RichiestaRequestFull richiesta)
        {
            JsonResult jsonResult = new JsonResult(null);
            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            Int64 idUtente = Convert.ToInt64(claim.Value);
            // Int64 idUtente = 25; //1395;//       
            if (idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in  GetRichiesteAttesaOKInstallazione nel recupero utente loggato");
            }
            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var richieste = await richiestaManager.GetRichiesteAttesaOkInstallazione(richiesta, idUtente);
            Int32 richiesteTot = await richiestaManager.GetRichiesteAttesaOkInstallazioneTot(richiesta, idUtente);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesteTot, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiesteAttesaOKInstallazione finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRichiesteAttesaOKInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteAttesaOKInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        #endregion Attesa OK installazione  STATO 8
        
        #region  OK installazione STATO 10

        [HttpPost]
        [Route("getRichiesteOKInstallazione")]
        public async Task<IActionResult> GetRichiesteOKInstallazione(RichiestaRequestFull richiesta)
        {
            JsonResult jsonResult = new JsonResult(null);
            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            Int64 idUtente = Convert.ToInt64(claim.Value);
            // Int64 idUtente = 25; //1395;//       
            if (idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in  GetRichiesteOKInstallazione nel recupero utente loggato");
            }
            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var richieste = await richiestaManager.GetRichiesteOKInstallazione(richiesta, idUtente);
            Int32 richiesteTot = await richiestaManager.GetRichiesteOKInstallazioneTot(richiesta, idUtente);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesteTot, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiesteOKInstallazione finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRichiesteOKInstallazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteAttesaOKInstallazione " + ex.Message);
            }

            return jsonResult;
        }

        #endregion  OK installazione STATO 10

        #region  Stato richieste

        [HttpPost]
        [Route("getStatoRichieste")]
        public async Task<IActionResult> GetStatoRichieste(ViewRichiesteRequestFull richiesta)
        {
            JsonResult jsonResult = new JsonResult(null);
            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            Int64 idUtente = Convert.ToInt64(claim.Value);
            // Int64 idUtente = 25; //1395;//       
            if (idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in  GetStatoRichieste nel recupero utente loggato");
            }
            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var richieste = await richiestaManager.GetStatoRichieste(richiesta, idUtente);
            Int32 richiesteTot = await richiestaManager.GetStatoRichiesteTot(richiesta, idUtente);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesteTot, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetStatoRichieste finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetStatoRichieste" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetStatoRichieste " + ex.Message);
            }

            return jsonResult;
        }

        #endregion  Stato Richieste

        #region  Richieste Inserite

        [HttpPost]
        [Route("getRichiesteInserite")]
        public async Task<IActionResult> GetRichiesteInserite(ViewRichiesteRequestFull richiesta)
        {
            JsonResult jsonResult = new JsonResult(null);
            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            Int64 idUtente = Convert.ToInt64(claim.Value);
            // Int64 idUtente = 25; //1395;//       
            if (idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in  GetRichiesteInserite nel recupero utente loggato");
            }
            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var richieste = await richiestaManager.GetRichiesteInserite(richiesta, idUtente);
            Int32 richiesteTot = await richiestaManager.GetRichiesteInseriteTot(richiesta, idUtente);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesteTot, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiesteInserite finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRichiesteInserite" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteInserite " + ex.Message);
            }

            return jsonResult;
        }

        #endregion  Richieste Inserite

        #region  Richieste in Lavorazione

        [HttpPost]
        [Route("getRichiesteInLavorazione")]
        public async Task<IActionResult> GetRichiesteInLavorazione(ViewRichiesteRequestFull richiesta)
        {
            JsonResult jsonResult = new JsonResult(null);
            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            Int64 idUtente = Convert.ToInt64(claim.Value);
            // Int64 idUtente = 25; //1395;//       
            if (idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in  GetRichiesteInLavorazione nel recupero utente loggato");
            }
            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var richieste = await richiestaManager.GetRichiesteInLavorazione(richiesta, idUtente);
            Int32 richiesteTot = await richiestaManager.GetRichiesteInLavorazioneTot(richiesta, idUtente);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesteTot, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiesteInLavorazione finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRichiesteInLavorazione" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteInLavorazione " + ex.Message);
            }

            return jsonResult;
        }

        #endregion  Richieste In Lavorazione

        #region  Richieste concluse

        [HttpPost]
        [Route("getRichiesteConcluse")]
        public async Task<IActionResult> GetRichiesteConcluse(ViewRichiesteRequestFull richiesta)
        {
            JsonResult jsonResult = new JsonResult(null);
            var identity = User.Identity as ClaimsIdentity;
            Claim claim = identity.Claims.Where(x => x.Type == ClaimTypes.UserData).FirstOrDefault();
            Int64 idUtente = Convert.ToInt64(claim.Value);
            // Int64 idUtente = 25; //1395;//       
            if (idUtente == null)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero utente loggato" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in  GetRichiesteConcluse nel recupero utente loggato");
            }
            RichiestaManager richiestaManager = new RichiestaManager(_RCDDbContext);

            var richieste = await richiestaManager.GetRichiesteConcluse(richiesta, idUtente);
            Int32 richiesteTot = await richiestaManager.GetRichiesteConcluseTot(richiesta, idUtente);

            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = richieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = richiesteTot, List = richieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetRichiesteConcluse finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetRichiesteConcluse" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetRichiesteConcluse " + ex.Message);
            }

            return jsonResult;
        }

        #endregion  Richieste concluse

    }


}


