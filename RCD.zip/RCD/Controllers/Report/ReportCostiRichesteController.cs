﻿using Microsoft.AspNetCore.Mvc;
using RCD.Code.Amministrazione;
using RCD.Code.Recuperi;
using RCD.Code.Report;
using RCD.Controllers;
using RCDContracts;
using RCDContracts.Request;
using RCDEngine.Entities;
namespace RCD.Controllers.Report
{
    [ApiController]
    [Route("report/[controller]")]
    public class ReportCostiRichesteController : _BaseController
    {
        private readonly ILogger<ReportCostiRichesteController> _logger;
        private IConfigurationRoot _configuration;
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly RCDEngine.RCDDbContext? _RCDDbContext;
        public ReportCostiRichesteController(ILogger<ReportCostiRichesteController> logger, IConfiguration configuration, IHttpContextAccessor httpContextAccessor, RCDEngine.RCDDbContext RCDDbContext) : base(logger, configuration, httpContextAccessor, RCDDbContext)
        {
            _logger = logger;
            _configuration = (IConfigurationRoot)configuration;
            _httpContextAccessor = httpContextAccessor;

            _RCDDbContext = RCDDbContext;
        }
        #region View Report Costi Richieste

        [HttpPost]
        [Route("getReportCostiRichiesteCustom")]
        public async Task<IActionResult> GetReportCostiRichiesteCustom(ViewReportCostiRichiesteRequestFull richieste)
        {
            ReportCostiRichiesteManager reportManager = new ReportCostiRichiesteManager(_RCDDbContext);
            var reportRichieste = await reportManager.GetReportCostiRichiesteCustom(richieste);
            Int32 reportRichiesteTot = await reportManager.GetReportCostiRichiesteCustomTot(richieste);

            JsonResult jsonResult = new JsonResult(null);
            try
            {
                jsonResult.StatusCode = 200;
                jsonResult.Value = reportRichieste.ToList(); //dataResponse

                jsonResult = new JsonResult(new BaseResponse { Result = "SUCCESS", Payload = { TotaleElementi = reportRichiesteTot, List = reportRichieste.ToList() } })
                {
                    StatusCode = 200,
                };
                _logger.LogInformation("GetReportCostiRichiesteCustom finish at: {time}", DateTimeOffset.Now);
            }
            catch (Exception ex)
            {
                jsonResult = new JsonResult(new BaseResponse { Result = "ERROR", Message = " Errore nel recupero GetReportCostiRichiesteCustom" })
                {
                    StatusCode = 500,
                };
                _logger.LogError("Error in GetReportCostiRichiesteCustom " + ex.Message);
            }

            return jsonResult;
        }
        #endregion View Report Costi Richieste


    }
}
