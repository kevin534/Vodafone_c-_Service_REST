﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;

namespace RCD.Code.Location
{
    public class DettaglioCostiLocationManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;


        public DettaglioCostiLocationManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractLocationCme>> GetCostiLocationCME(LocationCmeRequestFull location)
        {
            List<EntityLocationCme> locations;

            String sortParam = String.Concat(String.Concat(location.CampoOrdinamento, " "), location.Ordinamento.ToUpper());

            if (location.Pageable)
            {
                locations = await _RCDDbContext.LocationCme.Where(x => x.IdLocation.Equals(location.Filter.IdLocation))
                .OrderBy(sortParam)
                .Skip(location.NumeroElementi * location.Page).Take(location.NumeroElementi)
                .ToListAsync();

            }
            else
            {
                locations = await _RCDDbContext.LocationCme.Where(x => x.IdLocation.Equals(location.Filter.IdLocation))
               .OrderBy(sortParam)
               .ToListAsync();
            }

            List<ContractLocationCme> locationCmeElenco = new List<ContractLocationCme>();
            foreach (EntityLocationCme varLocationCme in locations)
            {
                ContractLocationCme locationCme1 = new ContractLocationCme();
                UtilityManager.MapProp(varLocationCme, locationCme1);
                locationCmeElenco.Add(locationCme1);
            }
            return locationCmeElenco;
        }

        public async Task<Int32> GetCostiLocationCMETot(LocationCmeRequestFull location)
        {

            Int32 count = _RCDDbContext.LocationCme.Where(x => x.IdLocation.Equals(location.Filter.IdLocation))
                .Count();

            return count;

        }

        public void AddCostiLocationCME(LocationCmeRequest location)
        {
            try
            {
                EntityLocationCme locationCmeToAdd = new EntityLocationCme();
                UtilityManager.MapProp(location, locationCmeToAdd);
                var result = _RCDDbContext.Add(locationCmeToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateLocationCME(LocationCmeRequest location)
        {
            try
            {
                EntityLocationCme locationCmeToEdit = new EntityLocationCme();
                UtilityManager.MapProp(location, locationCmeToEdit);
                var result = _RCDDbContext.Update(locationCmeToEdit);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteLocationCME(LocationCmeRequest location)
        {
            try
            {
                EntityLocationCme locationCmeToRemove = new EntityLocationCme();
                UtilityManager.MapProp(location, locationCmeToRemove);
                var result = _RCDDbContext.Remove(locationCmeToRemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }


    }
}
