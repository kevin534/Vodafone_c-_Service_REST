﻿using System.Reflection;
using static RCD.Code.EnumerateManager;

namespace RCD.Code
{
    public class UtilityManager
    {
        public static ENVIRONMENT_TYPE CurrentEnvironment(String url)
        {
            ENVIRONMENT_TYPE environmentType = ENVIRONMENT_TYPE.UNKNOWN;

            if (url.ToLower().Contains("firprod") || url.ToLower().Contains("fondoindennizzorisparmiatori"))
            {
                environmentType = ENVIRONMENT_TYPE.PRODUZIONE;
            }
            else if (url.ToLower().Contains("172.27.144.10"))
            {
                environmentType = ENVIRONMENT_TYPE.PRE_PRODUZIONE;
            }
            else if (url.ToLower().Contains("172.27.144.12"))
            {
                environmentType = ENVIRONMENT_TYPE.PRE_PRODUZIONE;
            }
            else
            {
                environmentType = ENVIRONMENT_TYPE.LOCALHOST;
            }

            return environmentType;
        }

        public static String PrefixEnvironment(ENVIRONMENT_TYPE environmentType)
        {
            String prefixEnvironment = String.Empty;

            switch (environmentType)
            {
                case ENVIRONMENT_TYPE.LOCALHOST:
                    prefixEnvironment = "Local-" + Environment.MachineName;
                    break;

                case ENVIRONMENT_TYPE.PRE_PRODUZIONE:
                    prefixEnvironment = "PreProd";
                    break;

                case ENVIRONMENT_TYPE.PRODUZIONE:
                    prefixEnvironment = "Prod";
                    break;

                default:
                    prefixEnvironment = String.Empty;
                    break;
            }

            return prefixEnvironment;
        }


        public static String GetConnectionStringName(String prefixEnvironment)
        {
            return "ConnectionString-" + prefixEnvironment;
        }
        /// <summary>
        /// map properties
        /// </summary>
        /// <param name="sourceObj"></param>
        /// <param name="targetObj"></param>
        internal static void MapProp(object sourceObj, object targetObj)
        {
            Type T1 = sourceObj.GetType();
            Type T2 = targetObj.GetType();


            PropertyInfo[] sourceProprties = T1.GetProperties(BindingFlags.Instance | BindingFlags.Public);
            PropertyInfo[] targetProprties = T2.GetProperties(BindingFlags.Instance | BindingFlags.Public);

            foreach (var sourceProp in sourceProprties)
            {
                if (sourceProp.PropertyType.Name.StartsWith("Entity"))
                {

                    var targetSottoProp = targetProprties.Where(x => x.Name == sourceProp.Name).First();
                    object osourceVal = sourceProp.GetValue(sourceObj, null);
                    if (osourceVal == null)
                    {

                    }
                    else
                    {
                        Type T3 = targetSottoProp.PropertyType;
                        object otargetVal = Activator.CreateInstance(T3);
                        UtilityManager.MapProp(osourceVal, otargetVal);
                        targetSottoProp.SetValue(targetObj, otargetVal);
                    }
                }
                else if (sourceProp.PropertyType.Name.StartsWith("List"))
                { 
                    
                }
                else
                {
                    object osourceVal = sourceProp.GetValue(sourceObj, null);
                    var targetProp = targetProprties.Where(x => x.Name == sourceProp.Name).First();
                    targetProp.SetValue(targetObj, osourceVal);
                }

            }
        }
        public static String TokenKey { get; } = "rUcs)Ee6£§)_Zn?8rcPWZHR5%597oZPa";

        T GetInstance<T>() where T : new()
        {
            T instance = new T();
            return instance;
        }

    }
}
