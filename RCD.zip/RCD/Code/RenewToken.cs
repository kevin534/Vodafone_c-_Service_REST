﻿using Microsoft.AspNetCore.Mvc.Filters;
using RCDContracts.Data;
using System.Security.Claims;
using System.Text.Json;

namespace RCD.Code
{

    public class RenewToken : ResultFilterAttribute, IFilterMetadata
    {

        //Int32 tokenDuration;
        //public RenewToken(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        //{
        //    String url = httpContextAccessor.HttpContext.Request.Path;
        //    EnumerateManager.ENVIRONMENT_TYPE CurrentEnviroment = UtilityManager.CurrentEnvironment(url == null ? "" : url);
        //    String prefixEnvironment = UtilityManager.PrefixEnvironment(CurrentEnviroment);

        //    this.tokenDuration = Convert.ToInt32(configuration["AppSettings:" + prefixEnvironment + ":TokenDuration"]);
        //}
        public override void OnResultExecuting(ResultExecutingContext context)
        {
            var config = context.HttpContext.RequestServices.GetService<IConfiguration>();
            String url = context.HttpContext.Request.Path;
            EnumerateManager.ENVIRONMENT_TYPE CurrentEnviroment = UtilityManager.CurrentEnvironment(url == null ? "" : url);
            String prefixEnvironment = UtilityManager.PrefixEnvironment(CurrentEnviroment);

            Int32 tokenDuration = Convert.ToInt32(config["AppSettings:" + prefixEnvironment + ":TokenDuration"]);

            String token1 = context.HttpContext.Request.Headers.Where(x => x.Key == "Authorization").FirstOrDefault().Value;
            string authenticationToken = context.HttpContext.Request.Headers["Authorization"];
            if (string.IsNullOrWhiteSpace(authenticationToken))
                return;

            String[] tokens = authenticationToken.Split(' ');
            SecurityManager securityManager = new SecurityManager();
            String decryptedTokenString = securityManager.DecryptTokenKey(tokens[1], UtilityManager.TokenKey);
            TokenData token = JsonSerializer.Deserialize<TokenData>(decryptedTokenString);
            token.DateToken = DateTime.Now.AddMinutes(tokenDuration);
            String serializationTokenString = JsonSerializer.Serialize(token);

            String cryptedTokenString = securityManager.EncryptTokenKey(serializationTokenString, UtilityManager.TokenKey);

            context.HttpContext.Response.Headers.Add("Authorization", "bearer " + cryptedTokenString);
            context.HttpContext.Response.Headers.Add("Access-Control-Expose-Headers", "Authorization");
            context.HttpContext.Response.Headers.Add("Access-Control-Allow-Headers", "Authorization");
            base.OnResultExecuting(context);
        }


    }
}
