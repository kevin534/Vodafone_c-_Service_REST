﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.TargheTecniche
{
    public class TargheTecnicheManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public TargheTecnicheManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public List<EntityElement>  GetTargheTecnicheByIdOffice(Decimal? IdOffice, List<string?> listTT)
        {
            List<EntityElement> elementi = new List<EntityElement>();

            if (listTT != null)
            {               
                    elementi =  _RCDDbContext.Elementi          
                          .Where(x => x.IdOffice == IdOffice && listTT.Contains(x.TargaTecnicaSap))
                        .ToList();
            }
            else
            {
                elementi = _RCDDbContext.Elementi
                          .Where(x => x.IdOffice == IdOffice && x.TargaTecnicaSap != String.Empty)
                        .ToList();
             
            }
          
            return elementi;
        }

        public List<EntityElement> GetTargheTecnicheBySiglaOffice(string? siglaOffice)
        {
            List<EntityElement> Element = new List<EntityElement>();

            var offices =  _RCDDbContext.Office
                 .Where(x => x.OfficeSigla == siglaOffice)
                         .FirstOrDefault();

                if (offices != null)
                {

                Element = _RCDDbContext.Elementi
                          .Where(x => x.IdOffice == offices.IdOffice && x.TargaTecnicaSap != String.Empty)
                        .ToList();
                }

                else
                {

                Element = _RCDDbContext.Elementi
                          .Where(x => x.IdOffice == null)
                        .ToList();

                }
            return Element;
        }

        public List<EntityTargheTechnicheBidone> GetTargheTecnicheBidoneByIdZona(long? idZona)
        {
            List<EntityTargheTechnicheBidone> targheTechniche = new List<EntityTargheTechnicheBidone>();

            targheTechniche = _RCDDbContext.TargheTechnicheBidone
                          .Where(x => x.IdZona == idZona)
                        .ToList();        
            return targheTechniche;
        }

        public List<EntityInstallazioneApparati> GetInstallApparati(long? idInstallazione)
        {
            List<EntityInstallazioneApparati> entityInsApparati = new List<EntityInstallazioneApparati>();

            entityInsApparati = _RCDDbContext.InstallazioneApparati
                                 .Where(a => a.IdInstallazione == idInstallazione)
                                 .Include("Apparati")
                                 .Include("Apparati.TipologiaApparato")
                                 .ToList();
            return entityInsApparati;
        }

    }
}

