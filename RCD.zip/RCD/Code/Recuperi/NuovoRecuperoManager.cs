﻿using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;

namespace RCD.Code.Recuperi
{     public class NuovoRecuperoManager
    {
            private readonly RCDEngine.RCDDbContext _RCDDbContext;
            public NuovoRecuperoManager(RCDEngine.RCDDbContext RCDDbContext)
            {
                _RCDDbContext = RCDDbContext;
            }

        #region INSTALLAZIONE RECUPERO
        public async Task<List<EntityLocation>> GetInstallazioniPerRecuperoCustom(LocationRequestFull location, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(location.CampoOrdinamento, " "),
                              location.Ordinamento.ToUpper());

            List<EntityLocation> locations = new List<EntityLocation>();
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();

            _RCDDbContext.Database.SetCommandTimeout(300);
            if (location.Pageable)
            {

                List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
                if (utente.IdZona != null)
                {
                    region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
                   .Select(x => x.Id)
                   .ToList();

                    locations = await _RCDDbContext.Location
                        .Where(x => x.LocationApparati.Count() > 0 || x.LocationAntenne.Count() > 0 || x.LocationAccessori.Count() > 0)
                        .Where(x => x.IsDismesso == false && region.Contains(x.StsComune.ProvinciaSts.Provincia.RegioneVF.Id)
                        && x.LocationApparati.Count(x => x.Recuperato == false && x.InRecupero == false) > 0)
                        .OrderBy(sortParam)
                        .Include("StsComune")
                        .Include("StsComune.ProvinciaSts")
                        .Include("StsComune.ProvinciaSts.RegioneSts")
                        .Include("StsComune.ProvinciaSts.Provincia")
                        .Include("StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                         .Select(x => x)
                          .Skip(location.NumeroElementi * location.Page).Take(location.NumeroElementi)
                           .ToListAsync();

                }
                else if (listUtenteProvincia.Count() > 0)

                {
                    province = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente.Equals(utente.Id))
                       .Select(x => x.StsProvincia.Id)
                       .ToList();

                    locations = await _RCDDbContext.Location
                      .Where(x => x.LocationApparati.Count() > 0 || x.LocationAntenne.Count() > 0 || x.LocationAccessori.Count() > 0)
                      .Where(x => x.IsDismesso == false && province.Contains(x.StsComune.ProvinciaSts.Id)
                      && x.LocationApparati.Count(x => x.Recuperato == false && x.InRecupero == false) > 0)
                      .OrderBy(sortParam)
                      .Include("StsComune")
                      .Include("StsComune.ProvinciaSts")
                      .Include("StsComune.ProvinciaSts.RegioneSts")
                      .Include("StsComune.ProvinciaSts.Provincia")
                      .Include("StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                       .Select(x => x)
                       .Skip(location.NumeroElementi * location.Page).Take(location.NumeroElementi)
                         .ToListAsync();

                }
                else
                {
                    locations = null;
                }

            }
            else
            {
                List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                  .ToListAsync();
                if (utente.IdZona != null)
                {
                    region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
                   .Select(x => x.Id)
                   .ToList();

                    locations = await _RCDDbContext.Location
                        .Where(x => x.LocationApparati.Count() > 0 || x.LocationAntenne.Count() > 0 || x.LocationAccessori.Count() > 0)
                        .Where(x => x.IsDismesso == false && region.Contains(x.StsComune.ProvinciaSts.Provincia.RegioneVF.Id)
                        && x.LocationApparati.Count(x => x.Recuperato == false && x.InRecupero == false) > 0)
                        .OrderBy(sortParam)
                        .Include("StsComune")
                        .Include("StsComune.ProvinciaSts")
                        .Include("StsComune.ProvinciaSts.RegioneSts")
                        .Include("StsComune.ProvinciaSts.Provincia")
                        .Include("StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                         .Select(x => x)
                           .ToListAsync();

                }
                else if (listUtenteProvincia.Count() > 0)

                {
                    province = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente.Equals(utente.Id))
                       .Select(x => x.StsProvincia.Id)
                       .ToList();

                    locations = await _RCDDbContext.Location
                      .Where(x => x.LocationApparati.Count() > 0 || x.LocationAntenne.Count() > 0 || x.LocationAccessori.Count() > 0)
                      .Where(x => x.IsDismesso == false && province.Contains(x.StsComune.ProvinciaSts.Id)
                      && x.LocationApparati.Count(x => x.Recuperato == false && x.InRecupero == false) > 0)
                      .OrderBy(sortParam)
                      .Include("StsComune")
                      .Include("StsComune.ProvinciaSts")
                      .Include("StsComune.ProvinciaSts.RegioneSts")
                      .Include("StsComune.ProvinciaSts.Provincia")
                      .Include("StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                       .Select(x => x)
                         .ToListAsync();

                }
                else
                {
                    locations = null;
                }
            }

            return locations;
        }

        public async Task<Int32> GetInstallazioniPerRecuperoCustomTot(LocationRequestFull location, Int64 idUtente)
        {

            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(location.CampoOrdinamento, " "),
                              location.Ordinamento.ToUpper());

            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();
            Int32 locations; 

            List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                 .ToListAsync();
            if (utente.IdZona != null)
            {
                region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
               .Select(x => x.Id)
               .ToList();

                locations = _RCDDbContext.Location
                     .Where(x => x.LocationApparati.Count() > 0 || x.LocationAntenne.Count() > 0 || x.LocationAccessori.Count() > 0)
                     .Where(x => x.IsDismesso == false && region.Contains(x.StsComune.ProvinciaSts.Provincia.RegioneVF.Id)
                     && x.LocationApparati.Count(x => x.Recuperato == false && x.InRecupero == false) > 0)
                     .Include("StsComune")
                     .Include("StsComune.ProvinciaSts")
                     .Include("StsComune.ProvinciaSts.RegioneSts")
                     .Include("StsComune.ProvinciaSts.Provincia")
                     .Include("StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                      .Select(x => x)
                       .Count();

            }
            else if (listUtenteProvincia.Count() > 0)

            {
                province = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente.Equals(utente.Id))
                   .Select(x => x.StsProvincia.Id)
                   .ToList();

                locations =  _RCDDbContext.Location
                  .Where(x => x.LocationApparati.Count() > 0 || x.LocationAntenne.Count() > 0 || x.LocationAccessori.Count() > 0)
                  .Where(x => x.IsDismesso == false && province.Contains(x.StsComune.ProvinciaSts.Id)
                  && x.LocationApparati.Count(x => x.Recuperato == false && x.InRecupero == false) > 0)
                  .Include("StsComune")
                  .Include("StsComune.ProvinciaSts")
                  .Include("StsComune.ProvinciaSts.RegioneSts")
                  .Include("StsComune.ProvinciaSts.Provincia")
                  .Include("StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                   .Select(x => x)
                     .Count();

            }
            else
            {
                locations = 0;
            }
            return locations;

        }

        #endregion INSTALLAZIONE RECUPERO


    }
}
