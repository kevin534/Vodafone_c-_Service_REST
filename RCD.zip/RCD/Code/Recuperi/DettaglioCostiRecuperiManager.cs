﻿using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCD.Code.Installazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;
namespace RCD.Code.Recuperi
{
    public class DettaglioCostiRecuperiManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public DettaglioCostiRecuperiManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        #region  RECUPERO CME BY IDRECUPERO

        public async Task<List<ContractRecuperoCME>> GetRecuperoCMEbyRecuperoId(RecuperoCMERequestFull recupero)
        {
            List<EntityRecuperoCME> recuperi;
            String sortParam = String.Concat(String.Concat(recupero.CampoOrdinamento, " "), recupero.Ordinamento.ToUpper());

            if (recupero.Pageable)
            {
                recuperi = await _RCDDbContext.RecuperiCME
                    .WhereIf(!String.IsNullOrEmpty(recupero.Filter.IdRecupero.ToString()), x => x.IdRecupero.Equals(recupero.Filter.IdRecupero))
                    .Skip(recupero.NumeroElementi * recupero.Page).Take(recupero.NumeroElementi)
                    .OrderBy(sortParam)
                    .ToListAsync();
            }
            else
            {
                recuperi = await _RCDDbContext.RecuperiCME
                   .WhereIf(!String.IsNullOrEmpty(recupero.Filter.IdRecupero.ToString()), x => x.IdRecupero.Equals(recupero.Filter.IdRecupero))
                   .OrderBy(sortParam)
                   .ToListAsync();
            }
            List<ContractRecuperoCME> recuperoElenco = new List<ContractRecuperoCME>();
            foreach (EntityRecuperoCME varRecuperi in recuperi)
            {
                ContractRecuperoCME recupero1 = new ContractRecuperoCME();
                UtilityManager.MapProp(varRecuperi, recupero1);
                recuperoElenco.Add(recupero1);
            }
            return recuperoElenco;
        }

        public async Task<Int32> GetRecuperoCMEbyRecuperoIdTot(RecuperoCMERequestFull recupero)
        {
            Int32 count = _RCDDbContext.RecuperiCME
                   .WhereIf(!String.IsNullOrEmpty(recupero.Filter.IdRecupero.ToString()), x => x.IdRecupero.Equals(recupero.Filter.IdRecupero))
                    .Count();
            return count;
        }

        public void AddRecuperoCME(RecuperoCMERequest recupero)
        {
            try
            {
                EntityRecuperoCME recuperoCmeToAdd = new EntityRecuperoCME();
                UtilityManager.MapProp(recupero, recuperoCmeToAdd);
                var result = _RCDDbContext.Add(recuperoCmeToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void UpdateRecuperoCME(RecuperoCMERequest recupero)
        {
            try
            {
                EntityRecuperoCME recuperoCmeToEdit = new EntityRecuperoCME();
                UtilityManager.MapProp(recupero, recuperoCmeToEdit);
                var result = _RCDDbContext.Update(recuperoCmeToEdit);
                _RCDDbContext.SaveChanges();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void DeleteRecuperoCME(RecuperoCMERequest recupero)
        {
            try
            {
                EntityRecuperoCME recuperoCmeToRemove = new EntityRecuperoCME();
                UtilityManager.MapProp(recupero, recuperoCmeToRemove);
                var result = _RCDDbContext.Remove(recuperoCmeToRemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        #endregion RECUPERO CME BY IDRECUPERO
    }

}
