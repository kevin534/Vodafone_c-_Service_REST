﻿using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCD.Code.Installazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;
namespace RCD.Code.Recuperi
{
    public class DettaglioDocumentazioneRecuperiManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public DettaglioDocumentazioneRecuperiManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        #region DOCUMENTAZIONE RECUPERO BY IDRECUPERO

        public async Task<List<ContractDocumentazioneRecupero>> GetDocumentazioneRecuperobyRecuperoId(DocumentazioneRecuperoRequestFull recupero)
        {
            List<EntityDocumentazioneRecupero> recuperi;
            String sortParam = String.Concat(String.Concat(recupero.CampoOrdinamento, " "), recupero.Ordinamento.ToUpper());

            if (recupero.Pageable)
            {
                recuperi = await _RCDDbContext.DocumentazioneRecupero.Where(x => x.Active == true)
                    .WhereIf(!String.IsNullOrEmpty(recupero.Filter.IdRecupero.ToString()), x => x.IdRecupero.Equals(recupero.Filter.IdRecupero))
                    .Skip(recupero.NumeroElementi * recupero.Page).Take(recupero.NumeroElementi)
                    .OrderBy(sortParam)
                    .ToListAsync();
            }
            else
            {
                recuperi = await _RCDDbContext.DocumentazioneRecupero.Where(x => x.Active == true)
                   .WhereIf(!String.IsNullOrEmpty(recupero.Filter.IdRecupero.ToString()), x => x.IdRecupero.Equals(recupero.Filter.IdRecupero))
                   .OrderBy(sortParam)
                   .ToListAsync();
            }
            List<ContractDocumentazioneRecupero> recuperoElenco = new List<ContractDocumentazioneRecupero>();
            foreach (EntityDocumentazioneRecupero varRecuperi in recuperi)
            {
                ContractDocumentazioneRecupero recupero1 = new ContractDocumentazioneRecupero();
                UtilityManager.MapProp(varRecuperi, recupero1);
                recuperoElenco.Add(recupero1);
            }
            return recuperoElenco;
        }

        public async Task<Int32> GetDocumentazioneRecuperobyRecuperoIdTot(DocumentazioneRecuperoRequestFull recupero)
        {
            Int32 count = _RCDDbContext.DocumentazioneRecupero.Where(x => x.Active == true)
                   .WhereIf(!String.IsNullOrEmpty(recupero.Filter.IdRecupero.ToString()), x => x.IdRecupero.Equals(recupero.Filter.IdRecupero))
                    .Count();
            return count;
        }
        public void AddDocumentazioneRecuperobyRecuperoId(DocumentazioneRecuperoRequest recupero)
        {
            try
            {
                EntityDocumentazioneRecupero recuperoToAdd = new EntityDocumentazioneRecupero();
                UtilityManager.MapProp(recupero, recuperoToAdd);
                var result = _RCDDbContext.Add(recuperoToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void UpdateDocumentazioneRecuperobyRecuperoId(DocumentazioneRecuperoRequest recupero)
        {
            try
            {
                EntityDocumentazioneRecupero recuperoToEdit = new EntityDocumentazioneRecupero();
                UtilityManager.MapProp(recupero, recuperoToEdit);
                var result = _RCDDbContext.Update(recuperoToEdit);
                _RCDDbContext.SaveChanges();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void DeleteDocumentazioneRecuperobyRecuperoId(DocumentazioneRecuperoRequest recupero)
        {
            try
            {
                EntityDocumentazioneRecupero recuperoToRemove = new EntityDocumentazioneRecupero();
                UtilityManager.MapProp(recupero, recuperoToRemove);
                var result = _RCDDbContext.Remove(recuperoToRemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion DOCUMENTAZIONE RECUPERO BY IDRECUPERO
    }
}
