﻿using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCD.Code.Installazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;
namespace RCD.Code.Recuperi
{
    public class RecuperiManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;
        


        public RecuperiManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        #region VIEW RECUPERI
        public async Task<List<ContractViewRecuperi>> GetViewRecuperi(ViewRecuperiRequestFull recuperi)
        {
            List<EntityViewRecuperi> recupers;

            if (recuperi.CampoOrdinamento == "recuperoManutenzione")
                recuperi.CampoOrdinamento = "IsManutenzione";

            if (recuperi.CampoOrdinamento == "dittaAssegnata")
                recuperi.CampoOrdinamento = "DittaIncaricata";

            String sortParam = String.Concat(String.Concat(recuperi.CampoOrdinamento, " "), recuperi.Ordinamento.ToUpper());



            if (recuperi.Pageable)
            {
                recupers = await _RCDDbContext.ViewRecuperi.Where(x => x.IsChiuso == false)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdRecupero.ToString()), q => q.IdRecupero.Equals(recuperi.Filter.IdRecupero))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Richiedente), q => q.Richiedente.Contains(recuperi.Filter.Richiedente))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CodiceCliente), q => q.CodiceCliente.Contains(recuperi.Filter.CodiceCliente))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.RagioneSociale), q => q.RagioneSociale.Contains(recuperi.Filter.RagioneSociale))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.PartitaIVA), q => q.PartitaIVA.Contains(recuperi.Filter.PartitaIVA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(recuperi.Filter.NomeInstallazione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudineGradi.ToString()), q => q.LatitudineGradi.Equals(recuperi.Filter.LatitudineGradi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudinePrimi.ToString()), q => q.LatitudinePrimi.Equals(recuperi.Filter.LatitudinePrimi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudineSecondi.ToString()), q => q.LatitudineSecondi.Equals(recuperi.Filter.LatitudineSecondi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudineGradi.ToString()), q => q.LongitudineGradi.Equals(recuperi.Filter.LongitudineGradi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudinePrimi.ToString()), q => q.LongitudinePrimi.Equals(recuperi.Filter.LongitudinePrimi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudineSecondi.ToString()), q => q.LongitudineSecondi.Equals(recuperi.Filter.LongitudineSecondi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Indirizzo), q => q.Indirizzo.Contains(recuperi.Filter.Indirizzo))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Comune), q => q.Comune.Contains(recuperi.Filter.Comune))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Provincia), q => q.Provincia.Contains(recuperi.Filter.Provincia))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Regione), q => q.Regione.Contains(recuperi.Filter.Regione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.RegioneVF), q => q.RegioneVF.Contains(recuperi.Filter.RegioneVF))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Zona), q => q.Zona.Contains(recuperi.Filter.Zona))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Office), q => q.Office.Contains(recuperi.Filter.Office))
                //.Where(x => x.ApparatiInviatiMagazzino == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CostoApparatiRecuperati.ToString()), q => q.CostoApparatiRecuperati.Equals(recuperi.Filter.CostoApparatiRecuperati))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CostoStimatoRecupero.ToString()), q => q.CostoStimatoRecupero.Equals(recuperi.Filter.CostoStimatoRecupero))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataInvioRichiestaDisinstallazioneVersoDitta.ToString()), q => q.DataInvioRichiestaDisinstallazioneVersoDitta.Equals(recuperi.Filter.DataInvioRichiestaDisinstallazioneVersoDitta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRecuperoConsuntivata.ToString()), q => q.DataRecuperoConsuntivata.Equals(recuperi.Filter.DataRecuperoConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRecuperoStimata.ToString()), q => q.DataRecuperoStimata.Equals(recuperi.Filter.DataRecuperoStimata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Equals(recuperi.Filter.DataRichiesta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataChiusuraAttivitaDitta.ToString()), q => q.DataChiusuraAttivitaDitta.Equals(recuperi.Filter.DataChiusuraAttivitaDitta))
                //.Where(x => x.NcLEmessa == true)
                //.Where(x => x.NominaRLInviataDitta == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CognomeRL), q => q.CognomeRL.Contains(recuperi.Filter.CognomeRL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NomeRL), q => q.NomeRL.Contains(recuperi.Filter.NomeRL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroCompactGsm.ToString()), q => q.NumeroCompactGsm.Equals(recuperi.Filter.NumeroCompactGsm))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroCompactUmts.ToString()), q => q.NumeroCompactUmts.Equals(recuperi.Filter.NumeroCompactUmts))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroMiniGsm.ToString()), q => q.NumeroMiniGsm.Equals(recuperi.Filter.NumeroMiniGsm))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroMiniUmts.ToString()), q => q.NumeroMiniUmts.Equals(recuperi.Filter.NumeroMiniUmts))
                // .Where(x => x.RdAEmessa == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroRda), q => q.NumeroRda.Contains(recuperi.Filter.NumeroRda))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(recuperi.Filter.StudioProgettazione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TotaleApparatiDaRecuperare.ToString()), q => q.TotaleApparatiDaRecuperare.Equals(recuperi.Filter.TotaleApparatiDaRecuperare))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TotaleSimDaRecuperare.ToString()), q => q.TotaleSimDaRecuperare.Equals(recuperi.Filter.TotaleSimDaRecuperare))
                //.Where(x => x.Vincolo == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.InseritoDa), q => q.InseritoDa.Contains(recuperi.Filter.InseritoDa))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DittaIncaricata), q => q.DittaIncaricata.Contains(recuperi.Filter.DittaIncaricata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.ProgettistaRan), q => q.ProgettistaRan.Contains(recuperi.Filter.ProgettistaRan))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.ProvenienzaRichiesta), q => q.ProvenienzaRichiesta.Contains(recuperi.Filter.ProvenienzaRichiesta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.SiteManagerNI), q => q.SiteManagerNI.Contains(recuperi.Filter.SiteManagerNI))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroODA), q => q.NumeroODA.Contains(recuperi.Filter.NumeroODA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroNCL), q => q.NumeroNCL.Contains(recuperi.Filter.NumeroNCL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataInvio.ToString()), q => q.DataInvio.Equals(recuperi.Filter.DataInvio))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.PreventivoRDA.ToString()), q => q.PreventivoRDA.Equals(recuperi.Filter.PreventivoRDA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(recuperi.Filter.TipologiaCantiere))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataDismissioneImpianti.ToString()), q => q.DataDismissioneImpianti.Equals(recuperi.Filter.DataDismissioneImpianti))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(recuperi.Filter.IdProvincia))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdRegioneVF.ToString()), q => q.IdRegioneVF.Equals(recuperi.Filter.IdRegioneVF))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CanaleVendita), q => q.CanaleVendita.Contains(recuperi.Filter.CanaleVendita))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(recuperi.Filter.CanaleVenditaDettaglio))
                .WhereIf(recuperi.Filter.IsManutenzione != null ,x => x.IsManutenzione == recuperi.Filter.IsManutenzione)
                .Skip(recuperi.NumeroElementi * recuperi.Page).Take(recuperi.NumeroElementi)
                .OrderBy(sortParam)
                .ToListAsync();




            }
            else
            {



                recupers = await _RCDDbContext.ViewRecuperi.Where(x => x.IsChiuso == false)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdRecupero.ToString()), q => q.IdRecupero.Equals(recuperi.Filter.IdRecupero))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Richiedente), q => q.Richiedente.Contains(recuperi.Filter.Richiedente))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CodiceCliente), q => q.CodiceCliente.Contains(recuperi.Filter.CodiceCliente))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.RagioneSociale), q => q.RagioneSociale.Contains(recuperi.Filter.RagioneSociale))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.PartitaIVA), q => q.PartitaIVA.Contains(recuperi.Filter.PartitaIVA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(recuperi.Filter.NomeInstallazione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudineGradi.ToString()), q => q.LatitudineGradi.Equals(recuperi.Filter.LatitudineGradi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudinePrimi.ToString()), q => q.LatitudinePrimi.Equals(recuperi.Filter.LatitudinePrimi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudineSecondi.ToString()), q => q.LatitudineSecondi.Equals(recuperi.Filter.LatitudineSecondi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudineGradi.ToString()), q => q.LongitudineGradi.Equals(recuperi.Filter.LongitudineGradi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudinePrimi.ToString()), q => q.LongitudinePrimi.Equals(recuperi.Filter.LongitudinePrimi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudineSecondi.ToString()), q => q.LongitudineSecondi.Equals(recuperi.Filter.LongitudineSecondi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Indirizzo), q => q.Indirizzo.Contains(recuperi.Filter.Indirizzo))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Comune), q => q.Comune.Contains(recuperi.Filter.Comune))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Provincia), q => q.Provincia.Contains(recuperi.Filter.Provincia))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Regione), q => q.Regione.Contains(recuperi.Filter.Regione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.RegioneVF), q => q.RegioneVF.Contains(recuperi.Filter.RegioneVF))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Zona), q => q.Zona.Contains(recuperi.Filter.Zona))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Office), q => q.Office.Contains(recuperi.Filter.Office))
                // .Where(x => x.ApparatiInviatiMagazzino == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CostoApparatiRecuperati.ToString()), q => q.CostoApparatiRecuperati.Equals(recuperi.Filter.CostoApparatiRecuperati))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CostoStimatoRecupero.ToString()), q => q.CostoStimatoRecupero.Equals(recuperi.Filter.CostoStimatoRecupero))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataInvioRichiestaDisinstallazioneVersoDitta.ToString()), q => q.DataInvioRichiestaDisinstallazioneVersoDitta.Equals(recuperi.Filter.DataInvioRichiestaDisinstallazioneVersoDitta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRecuperoConsuntivata.ToString()), q => q.DataRecuperoConsuntivata.Equals(recuperi.Filter.DataRecuperoConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRecuperoStimata.ToString()), q => q.DataRecuperoStimata.Equals(recuperi.Filter.DataRecuperoStimata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Equals(recuperi.Filter.DataRichiesta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataChiusuraAttivitaDitta.ToString()), q => q.DataChiusuraAttivitaDitta.Equals(recuperi.Filter.DataChiusuraAttivitaDitta))
                //.Where(x => x.NcLEmessa == true)
                //.Where(x => x.NominaRLInviataDitta == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CognomeRL), q => q.CognomeRL.Contains(recuperi.Filter.CognomeRL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NomeRL), q => q.NomeRL.Contains(recuperi.Filter.NomeRL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroCompactGsm.ToString()), q => q.NumeroCompactGsm.Equals(recuperi.Filter.NumeroCompactGsm))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroCompactUmts.ToString()), q => q.NumeroCompactUmts.Equals(recuperi.Filter.NumeroCompactUmts))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroMiniGsm.ToString()), q => q.NumeroMiniGsm.Equals(recuperi.Filter.NumeroMiniGsm))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroMiniUmts.ToString()), q => q.NumeroMiniUmts.Equals(recuperi.Filter.NumeroMiniUmts))
                // .Where(x => x.RdAEmessa == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroRda), q => q.NumeroRda.Contains(recuperi.Filter.NumeroRda))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(recuperi.Filter.StudioProgettazione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TotaleApparatiDaRecuperare.ToString()), q => q.TotaleApparatiDaRecuperare.Equals(recuperi.Filter.TotaleApparatiDaRecuperare))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TotaleSimDaRecuperare.ToString()), q => q.TotaleSimDaRecuperare.Equals(recuperi.Filter.TotaleSimDaRecuperare))
                // .Where(x => x.Vincolo == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.InseritoDa), q => q.InseritoDa.Contains(recuperi.Filter.InseritoDa))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DittaIncaricata), q => q.DittaIncaricata.Contains(recuperi.Filter.DittaIncaricata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.ProgettistaRan), q => q.ProgettistaRan.Contains(recuperi.Filter.ProgettistaRan))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.ProvenienzaRichiesta), q => q.ProvenienzaRichiesta.Contains(recuperi.Filter.ProvenienzaRichiesta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.SiteManagerNI), q => q.SiteManagerNI.Contains(recuperi.Filter.SiteManagerNI))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroODA), q => q.NumeroODA.Contains(recuperi.Filter.NumeroODA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroNCL), q => q.NumeroNCL.Contains(recuperi.Filter.NumeroNCL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataInvio.ToString()), q => q.DataInvio.Equals(recuperi.Filter.DataInvio))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.PreventivoRDA.ToString()), q => q.PreventivoRDA.Equals(recuperi.Filter.PreventivoRDA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(recuperi.Filter.TipologiaCantiere))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataDismissioneImpianti.ToString()), q => q.DataDismissioneImpianti.Equals(recuperi.Filter.DataDismissioneImpianti))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(recuperi.Filter.IdProvincia))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdRegioneVF.ToString()), q => q.IdRegioneVF.Equals(recuperi.Filter.IdRegioneVF))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CanaleVendita), q => q.CanaleVendita.Contains(recuperi.Filter.CanaleVendita))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(recuperi.Filter.CanaleVenditaDettaglio))
                .WhereIf(recuperi.Filter.IsManutenzione != null, x => x.IsManutenzione == recuperi.Filter.IsManutenzione)
                .OrderBy(sortParam)
                .ToListAsync();



            }



            List<ContractViewRecuperi> recuperoElenco = new List<ContractViewRecuperi>();
            foreach (EntityViewRecuperi varVwRecupero in recupers)
            {
                ContractViewRecuperi vwReportRecupero1 = new ContractViewRecuperi();
                UtilityManager.MapProp(varVwRecupero, vwReportRecupero1);
                recuperoElenco.Add(vwReportRecupero1);
            }
            return recuperoElenco;
        }

        public async Task<Int32> GetViewRecuperiTot(ViewRecuperiRequestFull recuperi)
        {


            Int32 count = _RCDDbContext.ViewRecuperi.Where(x => x.IsChiuso == false)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdRecupero.ToString()), q => q.IdRecupero.Equals(recuperi.Filter.IdRecupero))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Richiedente), q => q.Richiedente.Contains(recuperi.Filter.Richiedente))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CodiceCliente), q => q.CodiceCliente.Contains(recuperi.Filter.CodiceCliente))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.RagioneSociale), q => q.RagioneSociale.Contains(recuperi.Filter.RagioneSociale))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.PartitaIVA), q => q.PartitaIVA.Contains(recuperi.Filter.PartitaIVA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(recuperi.Filter.NomeInstallazione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudineGradi.ToString()), q => q.LatitudineGradi.Equals(recuperi.Filter.LatitudineGradi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudinePrimi.ToString()), q => q.LatitudinePrimi.Equals(recuperi.Filter.LatitudinePrimi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudineSecondi.ToString()), q => q.LatitudineSecondi.Equals(recuperi.Filter.LatitudineSecondi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudineGradi.ToString()), q => q.LongitudineGradi.Equals(recuperi.Filter.LongitudineGradi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudinePrimi.ToString()), q => q.LongitudinePrimi.Equals(recuperi.Filter.LongitudinePrimi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudineSecondi.ToString()), q => q.LongitudineSecondi.Equals(recuperi.Filter.LongitudineSecondi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Indirizzo), q => q.Indirizzo.Contains(recuperi.Filter.Indirizzo))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Comune), q => q.Comune.Contains(recuperi.Filter.Comune))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Provincia), q => q.Provincia.Contains(recuperi.Filter.Provincia))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Regione), q => q.Regione.Contains(recuperi.Filter.Regione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.RegioneVF), q => q.RegioneVF.Contains(recuperi.Filter.RegioneVF))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Zona), q => q.Zona.Contains(recuperi.Filter.Zona))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Office), q => q.Office.Contains(recuperi.Filter.Office))
                // .Where(x => x.ApparatiInviatiMagazzino == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CostoApparatiRecuperati.ToString()), q => q.CostoApparatiRecuperati.Equals(recuperi.Filter.CostoApparatiRecuperati))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CostoStimatoRecupero.ToString()), q => q.CostoStimatoRecupero.Equals(recuperi.Filter.CostoStimatoRecupero))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataInvioRichiestaDisinstallazioneVersoDitta.ToString()), q => q.DataInvioRichiestaDisinstallazioneVersoDitta.Equals(recuperi.Filter.DataInvioRichiestaDisinstallazioneVersoDitta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRecuperoConsuntivata.ToString()), q => q.DataRecuperoConsuntivata.Equals(recuperi.Filter.DataRecuperoConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRecuperoStimata.ToString()), q => q.DataRecuperoStimata.Equals(recuperi.Filter.DataRecuperoStimata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Equals(recuperi.Filter.DataRichiesta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataChiusuraAttivitaDitta.ToString()), q => q.DataChiusuraAttivitaDitta.Equals(recuperi.Filter.DataChiusuraAttivitaDitta))
                //.Where(x => x.NcLEmessa == true)
                //.Where(x => x.NominaRLInviataDitta == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CognomeRL), q => q.CognomeRL.Contains(recuperi.Filter.CognomeRL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NomeRL), q => q.NomeRL.Contains(recuperi.Filter.NomeRL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroCompactGsm.ToString()), q => q.NumeroCompactGsm.Equals(recuperi.Filter.NumeroCompactGsm))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroCompactUmts.ToString()), q => q.NumeroCompactUmts.Equals(recuperi.Filter.NumeroCompactUmts))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroMiniGsm.ToString()), q => q.NumeroMiniGsm.Equals(recuperi.Filter.NumeroMiniGsm))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroMiniUmts.ToString()), q => q.NumeroMiniUmts.Equals(recuperi.Filter.NumeroMiniUmts))
                // .Where(x => x.RdAEmessa == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroRda), q => q.NumeroRda.Contains(recuperi.Filter.NumeroRda))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(recuperi.Filter.StudioProgettazione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TotaleApparatiDaRecuperare.ToString()), q => q.TotaleApparatiDaRecuperare.Equals(recuperi.Filter.TotaleApparatiDaRecuperare))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TotaleSimDaRecuperare.ToString()), q => q.TotaleSimDaRecuperare.Equals(recuperi.Filter.TotaleSimDaRecuperare))
                // .Where(x => x.Vincolo == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.InseritoDa), q => q.InseritoDa.Contains(recuperi.Filter.InseritoDa))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DittaIncaricata), q => q.DittaIncaricata.Contains(recuperi.Filter.DittaIncaricata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.ProgettistaRan), q => q.ProgettistaRan.Contains(recuperi.Filter.ProgettistaRan))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.ProvenienzaRichiesta), q => q.ProvenienzaRichiesta.Contains(recuperi.Filter.ProvenienzaRichiesta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.SiteManagerNI), q => q.SiteManagerNI.Contains(recuperi.Filter.SiteManagerNI))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroODA), q => q.NumeroODA.Contains(recuperi.Filter.NumeroODA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroNCL), q => q.NumeroNCL.Contains(recuperi.Filter.NumeroNCL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataInvio.ToString()), q => q.DataInvio.Equals(recuperi.Filter.DataInvio))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.PreventivoRDA.ToString()), q => q.PreventivoRDA.Equals(recuperi.Filter.PreventivoRDA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(recuperi.Filter.TipologiaCantiere))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataDismissioneImpianti.ToString()), q => q.DataDismissioneImpianti.Equals(recuperi.Filter.DataDismissioneImpianti))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(recuperi.Filter.IdProvincia))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdRegioneVF.ToString()), q => q.IdRegioneVF.Equals(recuperi.Filter.IdRegioneVF))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CanaleVendita), q => q.CanaleVendita.Contains(recuperi.Filter.CanaleVendita))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(recuperi.Filter.CanaleVenditaDettaglio))
                .WhereIf(recuperi.Filter.IsManutenzione != null, x => x.IsManutenzione == recuperi.Filter.IsManutenzione)
                             .Count();

            return count;

        }

        #endregion VIEW RECUPERI

        #region RECUPERI WITH ISCHIUSO

        public async Task<List<ContractViewRecuperi>> GetViewRecuperiWithIsChiusoTrue(ViewRecuperiRequestFull recuperi)
        {
            List<EntityViewRecuperi> recupers;

            if (recuperi.CampoOrdinamento == "recuperoManutenzione")
                recuperi.CampoOrdinamento = "IsManutenzione";

            if (recuperi.CampoOrdinamento == "dittaAssegnata")
                recuperi.CampoOrdinamento = "DittaIncaricata";

            String sortParam = String.Concat(String.Concat(recuperi.CampoOrdinamento, " "), recuperi.Ordinamento.ToUpper());



            if (recuperi.Pageable)
            {
                recupers = await _RCDDbContext.ViewRecuperi.Where(x => x.IsChiuso == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdRecupero.ToString()), q => q.IdRecupero.Equals(recuperi.Filter.IdRecupero))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Richiedente), q => q.Richiedente.Contains(recuperi.Filter.Richiedente))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CodiceCliente), q => q.CodiceCliente.Contains(recuperi.Filter.CodiceCliente))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.RagioneSociale), q => q.RagioneSociale.Contains(recuperi.Filter.RagioneSociale))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.PartitaIVA), q => q.PartitaIVA.Contains(recuperi.Filter.PartitaIVA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(recuperi.Filter.NomeInstallazione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudineGradi.ToString()), q => q.LatitudineGradi.Equals(recuperi.Filter.LatitudineGradi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudinePrimi.ToString()), q => q.LatitudinePrimi.Equals(recuperi.Filter.LatitudinePrimi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudineSecondi.ToString()), q => q.LatitudineSecondi.Equals(recuperi.Filter.LatitudineSecondi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudineGradi.ToString()), q => q.LongitudineGradi.Equals(recuperi.Filter.LongitudineGradi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudinePrimi.ToString()), q => q.LongitudinePrimi.Equals(recuperi.Filter.LongitudinePrimi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudineSecondi.ToString()), q => q.LongitudineSecondi.Equals(recuperi.Filter.LongitudineSecondi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Indirizzo), q => q.Indirizzo.Contains(recuperi.Filter.Indirizzo))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Comune), q => q.Comune.Contains(recuperi.Filter.Comune))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Provincia), q => q.Provincia.Contains(recuperi.Filter.Provincia))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Regione), q => q.Regione.Contains(recuperi.Filter.Regione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.RegioneVF), q => q.RegioneVF.Contains(recuperi.Filter.RegioneVF))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Zona), q => q.Zona.Contains(recuperi.Filter.Zona))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Office), q => q.Office.Contains(recuperi.Filter.Office))
                //.Where(x => x.ApparatiInviatiMagazzino == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CostoApparatiRecuperati.ToString()), q => q.CostoApparatiRecuperati.Equals(recuperi.Filter.CostoApparatiRecuperati))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CostoStimatoRecupero.ToString()), q => q.CostoStimatoRecupero.Equals(recuperi.Filter.CostoStimatoRecupero))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataInvioRichiestaDisinstallazioneVersoDitta.ToString()), q => q.DataInvioRichiestaDisinstallazioneVersoDitta.Equals(recuperi.Filter.DataInvioRichiestaDisinstallazioneVersoDitta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRecuperoConsuntivata.ToString()), q => q.DataRecuperoConsuntivata.Equals(recuperi.Filter.DataRecuperoConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRecuperoStimata.ToString()), q => q.DataRecuperoStimata.Equals(recuperi.Filter.DataRecuperoStimata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Equals(recuperi.Filter.DataRichiesta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataChiusuraAttivitaDitta.ToString()), q => q.DataChiusuraAttivitaDitta.Equals(recuperi.Filter.DataChiusuraAttivitaDitta))
                //.Where(x => x.NcLEmessa == true)
                //.Where(x => x.NominaRLInviataDitta == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CognomeRL), q => q.CognomeRL.Contains(recuperi.Filter.CognomeRL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NomeRL), q => q.NomeRL.Contains(recuperi.Filter.NomeRL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroCompactGsm.ToString()), q => q.NumeroCompactGsm.Equals(recuperi.Filter.NumeroCompactGsm))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroCompactUmts.ToString()), q => q.NumeroCompactUmts.Equals(recuperi.Filter.NumeroCompactUmts))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroMiniGsm.ToString()), q => q.NumeroMiniGsm.Equals(recuperi.Filter.NumeroMiniGsm))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroMiniUmts.ToString()), q => q.NumeroMiniUmts.Equals(recuperi.Filter.NumeroMiniUmts))
                // .Where(x => x.RdAEmessa == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroRda), q => q.NumeroRda.Contains(recuperi.Filter.NumeroRda))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(recuperi.Filter.StudioProgettazione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TotaleApparatiDaRecuperare.ToString()), q => q.TotaleApparatiDaRecuperare.Equals(recuperi.Filter.TotaleApparatiDaRecuperare))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TotaleSimDaRecuperare.ToString()), q => q.TotaleSimDaRecuperare.Equals(recuperi.Filter.TotaleSimDaRecuperare))
                //.Where(x => x.Vincolo == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.InseritoDa), q => q.InseritoDa.Contains(recuperi.Filter.InseritoDa))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DittaIncaricata), q => q.DittaIncaricata.Contains(recuperi.Filter.DittaIncaricata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.ProgettistaRan), q => q.ProgettistaRan.Contains(recuperi.Filter.ProgettistaRan))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.ProvenienzaRichiesta), q => q.ProvenienzaRichiesta.Contains(recuperi.Filter.ProvenienzaRichiesta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.SiteManagerNI), q => q.SiteManagerNI.Contains(recuperi.Filter.SiteManagerNI))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroODA), q => q.NumeroODA.Contains(recuperi.Filter.NumeroODA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroNCL), q => q.NumeroNCL.Contains(recuperi.Filter.NumeroNCL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataInvio.ToString()), q => q.DataInvio.Equals(recuperi.Filter.DataInvio))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.PreventivoRDA.ToString()), q => q.PreventivoRDA.Equals(recuperi.Filter.PreventivoRDA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(recuperi.Filter.TipologiaCantiere))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataDismissioneImpianti.ToString()), q => q.DataDismissioneImpianti.Equals(recuperi.Filter.DataDismissioneImpianti))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(recuperi.Filter.IdProvincia))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdRegioneVF.ToString()), q => q.IdRegioneVF.Equals(recuperi.Filter.IdRegioneVF))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CanaleVendita), q => q.CanaleVendita.Contains(recuperi.Filter.CanaleVendita))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(recuperi.Filter.CanaleVenditaDettaglio))
                .Where(x => x.IsManutenzione == recuperi.Filter.IsManutenzione)
                .Skip(recuperi.NumeroElementi * recuperi.Page).Take(recuperi.NumeroElementi)
                .OrderBy(sortParam)
                .ToListAsync();




            }
            else
            {



                recupers = await _RCDDbContext.ViewRecuperi.Where(x => x.IsChiuso == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdRecupero.ToString()), q => q.IdRecupero.Equals(recuperi.Filter.IdRecupero))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Richiedente), q => q.Richiedente.Contains(recuperi.Filter.Richiedente))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CodiceCliente), q => q.CodiceCliente.Contains(recuperi.Filter.CodiceCliente))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.RagioneSociale), q => q.RagioneSociale.Contains(recuperi.Filter.RagioneSociale))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.PartitaIVA), q => q.PartitaIVA.Contains(recuperi.Filter.PartitaIVA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(recuperi.Filter.NomeInstallazione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudineGradi.ToString()), q => q.LatitudineGradi.Equals(recuperi.Filter.LatitudineGradi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudinePrimi.ToString()), q => q.LatitudinePrimi.Equals(recuperi.Filter.LatitudinePrimi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudineSecondi.ToString()), q => q.LatitudineSecondi.Equals(recuperi.Filter.LatitudineSecondi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudineGradi.ToString()), q => q.LongitudineGradi.Equals(recuperi.Filter.LongitudineGradi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudinePrimi.ToString()), q => q.LongitudinePrimi.Equals(recuperi.Filter.LongitudinePrimi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudineSecondi.ToString()), q => q.LongitudineSecondi.Equals(recuperi.Filter.LongitudineSecondi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Indirizzo), q => q.Indirizzo.Contains(recuperi.Filter.Indirizzo))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Comune), q => q.Comune.Contains(recuperi.Filter.Comune))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Provincia), q => q.Provincia.Contains(recuperi.Filter.Provincia))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Regione), q => q.Regione.Contains(recuperi.Filter.Regione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.RegioneVF), q => q.RegioneVF.Contains(recuperi.Filter.RegioneVF))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Zona), q => q.Zona.Contains(recuperi.Filter.Zona))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Office), q => q.Office.Contains(recuperi.Filter.Office))
                // .Where(x => x.ApparatiInviatiMagazzino == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CostoApparatiRecuperati.ToString()), q => q.CostoApparatiRecuperati.Equals(recuperi.Filter.CostoApparatiRecuperati))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CostoStimatoRecupero.ToString()), q => q.CostoStimatoRecupero.Equals(recuperi.Filter.CostoStimatoRecupero))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataInvioRichiestaDisinstallazioneVersoDitta.ToString()), q => q.DataInvioRichiestaDisinstallazioneVersoDitta.Equals(recuperi.Filter.DataInvioRichiestaDisinstallazioneVersoDitta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRecuperoConsuntivata.ToString()), q => q.DataRecuperoConsuntivata.Equals(recuperi.Filter.DataRecuperoConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRecuperoStimata.ToString()), q => q.DataRecuperoStimata.Equals(recuperi.Filter.DataRecuperoStimata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Equals(recuperi.Filter.DataRichiesta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataChiusuraAttivitaDitta.ToString()), q => q.DataChiusuraAttivitaDitta.Equals(recuperi.Filter.DataChiusuraAttivitaDitta))
                //.Where(x => x.NcLEmessa == true)
                //.Where(x => x.NominaRLInviataDitta == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CognomeRL), q => q.CognomeRL.Contains(recuperi.Filter.CognomeRL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NomeRL), q => q.NomeRL.Contains(recuperi.Filter.NomeRL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroCompactGsm.ToString()), q => q.NumeroCompactGsm.Equals(recuperi.Filter.NumeroCompactGsm))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroCompactUmts.ToString()), q => q.NumeroCompactUmts.Equals(recuperi.Filter.NumeroCompactUmts))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroMiniGsm.ToString()), q => q.NumeroMiniGsm.Equals(recuperi.Filter.NumeroMiniGsm))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroMiniUmts.ToString()), q => q.NumeroMiniUmts.Equals(recuperi.Filter.NumeroMiniUmts))
                // .Where(x => x.RdAEmessa == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroRda), q => q.NumeroRda.Contains(recuperi.Filter.NumeroRda))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(recuperi.Filter.StudioProgettazione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TotaleApparatiDaRecuperare.ToString()), q => q.TotaleApparatiDaRecuperare.Equals(recuperi.Filter.TotaleApparatiDaRecuperare))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TotaleSimDaRecuperare.ToString()), q => q.TotaleSimDaRecuperare.Equals(recuperi.Filter.TotaleSimDaRecuperare))
                // .Where(x => x.Vincolo == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.InseritoDa), q => q.InseritoDa.Contains(recuperi.Filter.InseritoDa))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DittaIncaricata), q => q.DittaIncaricata.Contains(recuperi.Filter.DittaIncaricata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.ProgettistaRan), q => q.ProgettistaRan.Contains(recuperi.Filter.ProgettistaRan))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.ProvenienzaRichiesta), q => q.ProvenienzaRichiesta.Contains(recuperi.Filter.ProvenienzaRichiesta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.SiteManagerNI), q => q.SiteManagerNI.Contains(recuperi.Filter.SiteManagerNI))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroODA), q => q.NumeroODA.Contains(recuperi.Filter.NumeroODA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroNCL), q => q.NumeroNCL.Contains(recuperi.Filter.NumeroNCL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataInvio.ToString()), q => q.DataInvio.Equals(recuperi.Filter.DataInvio))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.PreventivoRDA.ToString()), q => q.PreventivoRDA.Equals(recuperi.Filter.PreventivoRDA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(recuperi.Filter.TipologiaCantiere))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataDismissioneImpianti.ToString()), q => q.DataDismissioneImpianti.Equals(recuperi.Filter.DataDismissioneImpianti))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(recuperi.Filter.IdProvincia))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdRegioneVF.ToString()), q => q.IdRegioneVF.Equals(recuperi.Filter.IdRegioneVF))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CanaleVendita), q => q.CanaleVendita.Contains(recuperi.Filter.CanaleVendita))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(recuperi.Filter.CanaleVenditaDettaglio))
                .Where(x => x.IsManutenzione == recuperi.Filter.IsManutenzione)
                .OrderBy(sortParam)
                .ToListAsync();



            }



            List<ContractViewRecuperi> recuperoElenco = new List<ContractViewRecuperi>();
            foreach (EntityViewRecuperi varVwRecupero in recupers)
            {
                ContractViewRecuperi vwReportRecupero1 = new ContractViewRecuperi();
                UtilityManager.MapProp(varVwRecupero, vwReportRecupero1);
                recuperoElenco.Add(vwReportRecupero1);
            }
            return recuperoElenco;
        }

        public async Task<Int32> GetViewRecuperiWithIsChiusoTrueTot(ViewRecuperiRequestFull recuperi)
        {


            Int32 count = _RCDDbContext.ViewRecuperi.Where(x => x.IsChiuso == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdRecupero.ToString()), q => q.IdRecupero.Equals(recuperi.Filter.IdRecupero))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Richiedente), q => q.Richiedente.Contains(recuperi.Filter.Richiedente))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CodiceCliente), q => q.CodiceCliente.Contains(recuperi.Filter.CodiceCliente))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.RagioneSociale), q => q.RagioneSociale.Contains(recuperi.Filter.RagioneSociale))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.PartitaIVA), q => q.PartitaIVA.Contains(recuperi.Filter.PartitaIVA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(recuperi.Filter.NomeInstallazione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudineGradi.ToString()), q => q.LatitudineGradi.Equals(recuperi.Filter.LatitudineGradi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudinePrimi.ToString()), q => q.LatitudinePrimi.Equals(recuperi.Filter.LatitudinePrimi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LatitudineSecondi.ToString()), q => q.LatitudineSecondi.Equals(recuperi.Filter.LatitudineSecondi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudineGradi.ToString()), q => q.LongitudineGradi.Equals(recuperi.Filter.LongitudineGradi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudinePrimi.ToString()), q => q.LongitudinePrimi.Equals(recuperi.Filter.LongitudinePrimi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.LongitudineSecondi.ToString()), q => q.LongitudineSecondi.Equals(recuperi.Filter.LongitudineSecondi))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Indirizzo), q => q.Indirizzo.Contains(recuperi.Filter.Indirizzo))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Comune), q => q.Comune.Contains(recuperi.Filter.Comune))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Provincia), q => q.Provincia.Contains(recuperi.Filter.Provincia))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Regione), q => q.Regione.Contains(recuperi.Filter.Regione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.RegioneVF), q => q.RegioneVF.Contains(recuperi.Filter.RegioneVF))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Zona), q => q.Zona.Contains(recuperi.Filter.Zona))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Office), q => q.Office.Contains(recuperi.Filter.Office))
                // .Where(x => x.ApparatiInviatiMagazzino == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CostoApparatiRecuperati.ToString()), q => q.CostoApparatiRecuperati.Equals(recuperi.Filter.CostoApparatiRecuperati))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CostoStimatoRecupero.ToString()), q => q.CostoStimatoRecupero.Equals(recuperi.Filter.CostoStimatoRecupero))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataInvioRichiestaDisinstallazioneVersoDitta.ToString()), q => q.DataInvioRichiestaDisinstallazioneVersoDitta.Equals(recuperi.Filter.DataInvioRichiestaDisinstallazioneVersoDitta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRecuperoConsuntivata.ToString()), q => q.DataRecuperoConsuntivata.Equals(recuperi.Filter.DataRecuperoConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRecuperoStimata.ToString()), q => q.DataRecuperoStimata.Equals(recuperi.Filter.DataRecuperoStimata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Equals(recuperi.Filter.DataRichiesta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataChiusuraAttivitaDitta.ToString()), q => q.DataChiusuraAttivitaDitta.Equals(recuperi.Filter.DataChiusuraAttivitaDitta))
                //.Where(x => x.NcLEmessa == true)
                //.Where(x => x.NominaRLInviataDitta == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CognomeRL), q => q.CognomeRL.Contains(recuperi.Filter.CognomeRL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NomeRL), q => q.NomeRL.Contains(recuperi.Filter.NomeRL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroCompactGsm.ToString()), q => q.NumeroCompactGsm.Equals(recuperi.Filter.NumeroCompactGsm))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroCompactUmts.ToString()), q => q.NumeroCompactUmts.Equals(recuperi.Filter.NumeroCompactUmts))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroMiniGsm.ToString()), q => q.NumeroMiniGsm.Equals(recuperi.Filter.NumeroMiniGsm))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroMiniUmts.ToString()), q => q.NumeroMiniUmts.Equals(recuperi.Filter.NumeroMiniUmts))
                // .Where(x => x.RdAEmessa == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroRda), q => q.NumeroRda.Contains(recuperi.Filter.NumeroRda))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(recuperi.Filter.StudioProgettazione))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TotaleApparatiDaRecuperare.ToString()), q => q.TotaleApparatiDaRecuperare.Equals(recuperi.Filter.TotaleApparatiDaRecuperare))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TotaleSimDaRecuperare.ToString()), q => q.TotaleSimDaRecuperare.Equals(recuperi.Filter.TotaleSimDaRecuperare))
                // .Where(x => x.Vincolo == true)
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.InseritoDa), q => q.InseritoDa.Contains(recuperi.Filter.InseritoDa))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DittaIncaricata), q => q.DittaIncaricata.Contains(recuperi.Filter.DittaIncaricata))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.ProgettistaRan), q => q.ProgettistaRan.Contains(recuperi.Filter.ProgettistaRan))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.ProvenienzaRichiesta), q => q.ProvenienzaRichiesta.Contains(recuperi.Filter.ProvenienzaRichiesta))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.SiteManagerNI), q => q.SiteManagerNI.Contains(recuperi.Filter.SiteManagerNI))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroODA), q => q.NumeroODA.Contains(recuperi.Filter.NumeroODA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.NumeroNCL), q => q.NumeroNCL.Contains(recuperi.Filter.NumeroNCL))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataInvio.ToString()), q => q.DataInvio.Equals(recuperi.Filter.DataInvio))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.PreventivoRDA.ToString()), q => q.PreventivoRDA.Equals(recuperi.Filter.PreventivoRDA))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(recuperi.Filter.TipologiaCantiere))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.DataDismissioneImpianti.ToString()), q => q.DataDismissioneImpianti.Equals(recuperi.Filter.DataDismissioneImpianti))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(recuperi.Filter.IdProvincia))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.IdRegioneVF.ToString()), q => q.IdRegioneVF.Equals(recuperi.Filter.IdRegioneVF))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CanaleVendita), q => q.CanaleVendita.Contains(recuperi.Filter.CanaleVendita))
                .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(recuperi.Filter.CanaleVenditaDettaglio))
                .Where(x => x.IsManutenzione == recuperi.Filter.IsManutenzione)
                .Count();
            return count;

        }

        #endregion WITH RECUPERI ISCHIUSO

        #region RECUPERO LOCATION BY ID

        public async Task<List<ContractRecuperi>> getRecuperoLocationById(RecuperiRequestFull recuperi)
        {
            List<EntityRecuperi> recupers;
            String sortParam = String.Concat(String.Concat(recuperi.CampoOrdinamento, " "), recuperi.Ordinamento.ToUpper());

            if (recuperi.Pageable)
            {
                recupers = await _RCDDbContext.Recuperi
                    .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Id.ToString()), q => q.Id.Equals(recuperi.Filter.Id))
                    .Skip(recuperi.NumeroElementi * recuperi.Page).Take(recuperi.NumeroElementi)
                    .OrderBy(sortParam)
                    .Include("Location")
                    .Include("Location.TipologiaStabile")
                    .Include("Location.AccessibilitaTetto")
                    .Include("Location.Richiedente")
                    .Include("Location.Richiedente.TipologiaCliente")
                    .Include("Location.Richiedente.CanaleVenditaDettaglio")
                    .Include("Location.StsComune")
                    .Include("Location.Gestori")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .ToListAsync();
            }
            else
            {
                recupers = await _RCDDbContext.Recuperi
                     .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Id.ToString()), q => q.Id.Equals(recuperi.Filter.Id))
                    .OrderBy(sortParam)
                    .Include("Location")
                    .Include("Location.TipologiaStabile")
                    .Include("Location.AccessibilitaTetto")
                    .Include("Location.Richiedente")
                    .Include("Location.Richiedente.TipologiaCliente")
                    .Include("Location.Richiedente.CanaleVenditaDettaglio")
                    .Include("Location.StsComune")
                    .Include("Location.Gestori")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")                       
                    .ToListAsync();
            }
            List<ContractRecuperi> recuperoElenco = new List<ContractRecuperi>();
            foreach (EntityRecuperi varVwRecupero in recupers)
            {
                ContractRecuperi vwReportRecupero1 = new ContractRecuperi();
                UtilityManager.MapProp(varVwRecupero, vwReportRecupero1);
                recuperoElenco.Add(vwReportRecupero1);
            }
            return recuperoElenco;
        }

        public async Task<Int32> getRecuperoLocationByIdTot(RecuperiRequestFull recuperi)
        {
            Int32 count = _RCDDbContext.Recuperi
                     .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Id.ToString()), q => q.Id.Equals(recuperi.Filter.Id))
                    .Include("Location")
                    .Include("Location.TipologiaStabile")
                    .Include("Location.AccessibilitaTetto")
                    .Include("Location.Richiedente")
                    .Include("Location.Richiedente.TipologiaCliente")
                    .Include("Location.Richiedente.CanaleVenditaDettaglio")
                    .Include("Location.StsComune")
                    .Include("Location.Gestori")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .Count();
            return count;
        }

        #endregion RECUPERO LOCATION BY ID

        #region RECUPERO DETAILS BY ID

        public async Task<List<ContractRecuperi>> getRecuperoDetailsById(RecuperiRequestFull recuperi)
        {
            List<EntityRecuperi> recupers;
            String sortParam = String.Concat(String.Concat(recuperi.CampoOrdinamento, " "), recuperi.Ordinamento.ToUpper());

            if (recuperi.Pageable)
            {
                recupers = await _RCDDbContext.Recuperi
                    .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Id.ToString()), q => q.Id.Equals(recuperi.Filter.Id))
                    .Skip(recuperi.NumeroElementi * recuperi.Page).Take(recuperi.NumeroElementi)
                    .OrderBy(sortParam)
                    .Include("UserInsert")
                    .Include("SiteManagerNI")
                    .Include("ProgettistaRan")
                    .Include("Ditta")
                    .Include("ProvenienzaRichiesta")
                    .Include("TipologiaCantiere")                 
                    .ToListAsync();
            }
            else
            {
                recupers = await _RCDDbContext.Recuperi
                    .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Id.ToString()), q => q.Id.Equals(recuperi.Filter.Id))
                    .OrderBy(sortParam)
                    .Include("UserInsert")
                    .Include("SiteManagerNI")
                    .Include("ProgettistaRan")
                    .Include("Ditta")
                    .Include("ProvenienzaRichiesta")
                    .Include("TipologiaCantiere")
                    .ToListAsync();
            }
            List<ContractRecuperi> recuperoElenco = new List<ContractRecuperi>();
            foreach (EntityRecuperi varVwRecupero in recupers)
            {
                ContractRecuperi vwReportRecupero1 = new ContractRecuperi();
                UtilityManager.MapProp(varVwRecupero, vwReportRecupero1);
                recuperoElenco.Add(vwReportRecupero1);
            }
            return recuperoElenco;
        }

        public async Task<Int32> getRecuperoDetailsByIdTot(RecuperiRequestFull recuperi)
        {
            Int32 count = _RCDDbContext.Recuperi
                     .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Id.ToString()), q => q.Id.Equals(recuperi.Filter.Id))
                    .Include("UserInsert")
                    .Include("SiteManagerNI")
                    .Include("ProgettistaRan")
                    .Include("Ditta")
                    .Include("ProvenienzaRichiesta")
                    .Include("TipologiaCantiere")
                    .Count();
            return count;

        }

        #endregion RECUPERO DETAILS BY ID

        #region RECUPERO CME BY ID
        public async Task<List<ContractRecuperoCME>> getRecuperoCMEById(RecuperoCMERequestFull recuperi)
        {
            List<EntityRecuperoCME> recupers;
            String sortParam = String.Concat(String.Concat(recuperi.CampoOrdinamento, " "), recuperi.Ordinamento.ToUpper());

            if (recuperi.Pageable)
            {
                recupers = await _RCDDbContext.RecuperiCME
                    .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Id.ToString()), q => q.Id.Equals(recuperi.Filter.Id))
                .Skip(recuperi.NumeroElementi * recuperi.Page).Take(recuperi.NumeroElementi)
                .OrderBy(sortParam)
                .Include("Recupero")
                .Include("Listino")

                .ToListAsync();
            }
            else
            {
                recupers = await _RCDDbContext.RecuperiCME
                     .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Id.ToString()), q => q.Id.Equals(recuperi.Filter.Id))
                 .OrderBy(sortParam)
                  .Include("Recupero")
                  .Include("Listino")
                 .ToListAsync();
            }
            List<ContractRecuperoCME> recuperoElenco = new List<ContractRecuperoCME>();
            foreach (EntityRecuperoCME varVwRecupero in recupers)
            {
                ContractRecuperoCME vwReportRecupero1 = new ContractRecuperoCME();
                UtilityManager.MapProp(varVwRecupero, vwReportRecupero1);
                recuperoElenco.Add(vwReportRecupero1);
            }
            return recuperoElenco;
        }
        public async Task<Int32> getRecuperoCMEByIdTot(RecuperoCMERequestFull recuperi)
        {
            Int32 count  = _RCDDbContext.RecuperiCME
                     .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Id.ToString()), q => q.Id.Equals(recuperi.Filter.Id))
                  .Include("Recupero")
                  .Include("Listino")
                .Count();
            return count;

        }

        #endregion RECUPERO CME BY ID

        #region DOCUMENTAZIONE RECUPERO BY ID
        public async Task<List<ContractDocumentazioneRecupero>> getDocumentazioneRecuperoById(DocumentazioneRecuperoRequestFull documentazione)
        {
            List<EntityDocumentazioneRecupero> doc;
            String sortParam = String.Concat(String.Concat(documentazione.CampoOrdinamento, " "), documentazione.Ordinamento.ToUpper());

            if (documentazione.Pageable)
            {
                doc = await _RCDDbContext.DocumentazioneRecupero.Where(q => q.Active == true)
                    .WhereIf(!String.IsNullOrEmpty(documentazione.Filter.Id.ToString()), q => q.Id.Equals(documentazione.Filter.Id))
                .Skip(documentazione.NumeroElementi * documentazione.Page).Take(documentazione.NumeroElementi)
                .OrderBy(sortParam)
                .Include("Recupero")
                .ToListAsync();
            }
            else
            {
                doc = await _RCDDbContext.DocumentazioneRecupero.Where(q => q.Active == true)
                     .WhereIf(!String.IsNullOrEmpty(documentazione.Filter.Id.ToString()), q => q.Id.Equals(documentazione.Filter.Id))
                 .OrderBy(sortParam)
                 .Include("Recupero")
                 .ToListAsync();
            }
            List<ContractDocumentazioneRecupero> docElenco = new List<ContractDocumentazioneRecupero>();
            foreach (EntityDocumentazioneRecupero varDoc in doc)
            {
                ContractDocumentazioneRecupero doc1 = new ContractDocumentazioneRecupero();
                UtilityManager.MapProp(varDoc, doc1);
                docElenco.Add(doc1);
            }
            return docElenco;
        }
        public async Task<Int32> getDocumentazioneRecuperoByIdTot(DocumentazioneRecuperoRequestFull documentazione)
        {
            Int32 count =  _RCDDbContext.DocumentazioneRecupero.Where(q => q.Active == true)
                     .WhereIf(!String.IsNullOrEmpty(documentazione.Filter.Id.ToString()), q => q.Id.Equals(documentazione.Filter.Id))
                 .Include("Recupero")
                .Count();
            return count;

        }

        #endregion DOCUMENTAZIONE RECUPERO BY ID

        #region RECUPERO BY ID

        public async Task<List<ContractRecuperi>> GetRecuperoById(RecuperiRequestFull recuperi)
        {
            List<EntityRecuperi> recupers;
            String sortParam = String.Concat(String.Concat(recuperi.CampoOrdinamento, " "), recuperi.Ordinamento.ToUpper());

            if (recuperi.Pageable)
            {
                recupers = await _RCDDbContext.Recuperi
                    .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Id.ToString()), q => q.Id.Equals(recuperi.Filter.Id))
                    .Skip(recuperi.NumeroElementi * recuperi.Page).Take(recuperi.NumeroElementi)
                    .OrderBy(sortParam)
                    .Include("Location")
                    .Include("UserInsert")
                    .Include("ProgettistaRan")
                    .Include("SiteManagerNI")
                    .Include("Ditta")
                    .Include("ProvenienzaRichiesta")
                    .Include("TipologiaCantiere")
                    .Include("Location.TipologiaStabile")
                    .Include("Location.AccessibilitaTetto")
                    .Include("Location.Gestori")
                    .Include("Location.Richiedente")
                    .Include("Location.Richiedente.TipologiaCliente")
                    .Include("Location.Richiedente.CanaleVenditaDettaglio")
                    .Include("Location.StsComune")
                    .Include("Location.Gestori")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .ToListAsync();
            }
            else
            {
                recupers = await _RCDDbContext.Recuperi
                     .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Id.ToString()), q => q.Id.Equals(recuperi.Filter.Id))
                    .OrderBy(sortParam)
                    .Include("Location")
                    .Include("UserInsert")
                    .Include("ProgettistaRan")
                    .Include("SiteManagerNI")
                    .Include("Ditta")
                    .Include("ProvenienzaRichiesta")
                    .Include("TipologiaCantiere")
                    .Include("Location.TipologiaStabile")
                    .Include("Location.AccessibilitaTetto")
                    .Include("Location.Gestori")
                    .Include("Location.Richiedente")
                    .Include("Location.Richiedente.TipologiaCliente")
                    .Include("Location.Richiedente.CanaleVenditaDettaglio")
                    .Include("Location.StsComune")
                    .Include("Location.Gestori")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .ToListAsync();
            }
            List<ContractRecuperi> recuperoElenco = new List<ContractRecuperi>();
            foreach (EntityRecuperi varVwRecupero in recupers)
            {
                ContractRecuperi vwReportRecupero1 = new ContractRecuperi();
                UtilityManager.MapProp(varVwRecupero, vwReportRecupero1);
                recuperoElenco.Add(vwReportRecupero1);
            }
            return recuperoElenco;
        }

        public async Task<Int32> GetRecuperoByIdTot(RecuperiRequestFull recuperi)
        {
            Int32 count = _RCDDbContext.Recuperi
                     .WhereIf(!String.IsNullOrEmpty(recuperi.Filter.Id.ToString()), q => q.Id.Equals(recuperi.Filter.Id))
                    .Include("Location")
                    .Include("UserInsert")
                    .Include("ProgettistaRan")
                    .Include("SiteManagerNI")
                    .Include("Ditta")
                    .Include("ProvenienzaRichiesta")
                    .Include("TipologiaCantiere")
                    .Include("Location.TipologiaStabile")
                    .Include("Location.AccessibilitaTetto")
                    .Include("Location.Gestori")
                    .Include("Location.Richiedente")
                    .Include("Location.Richiedente.TipologiaCliente")
                    .Include("Location.Richiedente.CanaleVenditaDettaglio")
                    .Include("Location.StsComune")
                    .Include("Location.Gestori")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .Count();

            return count;
        }
        #endregion RECUPERO BY ID

        #region RECUPERI UPDATE e INSERT

        public async void UpdateRecuperiManutenzione(RecuperiRequest recupero)
        {
            try
            {
                //Salvataggio dati di recupero o di manutenzione

                //RECUPERO
                
                    EntityRecuperi recuperoToAdd = new EntityRecuperi();

                    if (recupero.DataRichiesta == null) // ?? || recupero.DataRichiesta.Length < 1)
                        throw new Exception("errore: Immettere la data della richiesta.");

                    bool sendMailDitta = false;
                    EntityRecuperi originalRecupero = _RCDDbContext.Recuperi.AsNoTracking().First(g => g.Id == recupero.Id);


                    if (recupero.Ditta != null && originalRecupero != null)  //verificare originalRecupero
                    {
                        if (!originalRecupero.IdDittaInstallazione.HasValue)
                        {
                            sendMailDitta = true;
                        }
                        else if (originalRecupero.IdDittaInstallazione.Value != recupero.IdDittaInstallazione.Value)
                        {
                            sendMailDitta = true;
                        }

                    }

                    if (recupero.DataRichiesta != null && originalRecupero != null)
                    {
                     
                        if (recupero.IsChiuso is null)
                            recupero.IsChiuso = false;
                        if (recupero.DismettiImpianto is null)
                            recupero.DismettiImpianto = false;
                        if (recupero.OdAEmessa is null)
                            recupero.OdAEmessa = false;
                        if (recupero.RdAEmessa is null)
                            recupero.RdAEmessa = false;
                        if (recupero.NcLEmessa is null)
                            recupero.NcLEmessa = false;
                        if (recupero.NominaRLInviataDitta is null)
                            recupero.NominaRLInviataDitta = false;
                        if (recupero.ApparatiInviatiMagazzino is null)
                            recupero.ApparatiInviatiMagazzino = false;
                        if (recupero.Vincolo is null)
                            recupero.Vincolo = false;

                    }

                    UtilityManager.MapProp(recupero, recuperoToAdd);
                    var result = _RCDDbContext.Update(recuperoToAdd);
                    _RCDDbContext.SaveChanges();

                
                

                //if (sendMailDitta)
                //{
                //     .........  DA FARE
                //}
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void CreaRecuperoManutenzione(RecuperiRequest recupero,long? userId)
        {
            try
            {
                EntityRecuperi recuperoToAdd = new EntityRecuperi();
                UtilityManager.MapProp(recupero, recuperoToAdd);

                //long? idRecupero = recupero.Id;
                //EntityRecuperi recuperoObj = _RCDDbContext.Recuperi.AsNoTracking().First(g => g.Id == idRecupero);
                long? idLocation = recuperoToAdd.IdLocation;

                recuperoToAdd.IdUserInsert = userId;
                recuperoToAdd.Location = _RCDDbContext.Location.First(g => g.Id == idLocation);

                List<EntityLocationApparato> listLocationApparati = _RCDDbContext.LocationApparato
                    .Include("Apparato.Sistema").Include("Apparato.TipologiaApparato")
                    .Where(i => i.IdLocation == recuperoToAdd.IdLocation).ToList();


                recuperoToAdd.Location.LocationApparati = listLocationApparati;

                if (recuperoToAdd.ApparatiInviatiMagazzino is null)
                    recuperoToAdd.ApparatiInviatiMagazzino = false;

                if (recuperoToAdd.NominaRLInviataDitta is null)
                    recuperoToAdd.NominaRLInviataDitta = false;

                if (recuperoToAdd.Vincolo is null)
                    recuperoToAdd.Vincolo = false;

                if (recuperoToAdd.IsChiuso is null)
                    recuperoToAdd.IsChiuso = false;

                if (recuperoToAdd.DismettiImpianto is null)
                    recuperoToAdd.DismettiImpianto = false;

                if (recuperoToAdd.OdAEmessa is null)
                    recuperoToAdd.OdAEmessa = false;

                if (recuperoToAdd.IsManutenzione is null)
                    recuperoToAdd.IsManutenzione = false;

                if (recuperoToAdd.NcLEmessa is null)
                    recuperoToAdd.NcLEmessa = false;

                if (recuperoToAdd.RdAEmessa is null)
                    recuperoToAdd.RdAEmessa = false;

                recuperoToAdd.NumeroApparatiFemto = recuperoToAdd.Location.LocationApparati.Where(sApp => sApp.Apparato.TipologiaApparato.TipologiaApparato.ToLower() == "femto" && sApp.Recuperato == true).Sum(sApp => sApp.Quantita);
                recuperoToAdd.NumeroApparatiDualBand = recuperoToAdd.Location.LocationApparati.Where(sApp => sApp.Apparato.Sistema.Sistema.ToLower() == "gsm/umts" && sApp.Recuperato == true).Sum(sApp => sApp.Quantita);
                recuperoToAdd.NumeroMiniGsm = recuperoToAdd.Location.LocationApparati.Where(sApp => sApp.Apparato.TipologiaApparato.TipologiaApparato.ToLower() == "mini" && sApp.Apparato.Sistema.Sistema.ToLower() == "gsm" && sApp.Recuperato == true).Sum(sApp => sApp.Quantita);
                recuperoToAdd.NumeroCompactGsm = recuperoToAdd.Location.LocationApparati.Where(sApp => sApp.Apparato.TipologiaApparato.TipologiaApparato.ToLower() == "compact" && sApp.Apparato.Sistema.Sistema.ToLower() == "gsm" && sApp.Recuperato == true).Sum(sApp => sApp.Quantita);
                recuperoToAdd.NumeroMiniUmts = recuperoToAdd.Location.LocationApparati.Where(sApp => sApp.Apparato.TipologiaApparato.TipologiaApparato.ToLower() == "mini" && sApp.Apparato.Sistema.Sistema.ToLower() == "umts" && sApp.Recuperato == true).Sum(sApp => sApp.Quantita);
                recuperoToAdd.NumeroCompactUmts = recuperoToAdd.Location.LocationApparati.Where(sApp => sApp.Apparato.TipologiaApparato.TipologiaApparato.ToLower() == "compact" && sApp.Apparato.Sistema.Sistema.ToLower() == "umts" && sApp.Recuperato == true).Sum(sApp => sApp.Quantita);

                var result = _RCDDbContext.Add(recuperoToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion RECUPERI UPDATE e INSERT

        #region CANCELLAZIONE RECUPERI/MANUTENZIONE

        public void DeleteRecuperoManutenzione(RecuperiRequest recupero)
        {
            try
            {
                EntityRecuperi recuperoToDelete = _RCDDbContext.Recuperi
                    .Include("Location").Include("Location.LocationApparati")
                    .FirstOrDefault(item => item.Id == recupero.Id);

                //Settare InRecupero = 0 in LocationApparati
                recuperoToDelete.Location.LocationApparati.ToList().ForEach(la => la.InRecupero = false);

                List<EntityRecuperoCME> recuperiCmeList = _RCDDbContext.RecuperiCME
                                    .Where(i => i.IdRecupero == recupero.Id).ToList();


                ////Cancellazione del CME associato al recupero/manutenzione
                //foreach (RecuperoCme rc in recupero.RecuperiCme)
                //{
                //    recupero.RecuperiCme.Remove(rc);
                //    ctx.RecuperoCmes.Remove(rc);
                //}

              
                // recuperoToDelete.RecuperiCme = recuperiCmeList;
                //Cancellazione del CME associato al recupero/manutenzione
                foreach (EntityRecuperoCME rc in recuperiCmeList)
                {
                    var result = _RCDDbContext.Remove(rc);
                    _RCDDbContext.SaveChanges();
                }

                //Cancellazione della documentazione relativa al recuepro/manutenzione
                int cont = 1;

                var documentazioneRecupero = _RCDDbContext.DocumentazioneRecupero.Where(g => g.IdRecupero == recupero.Id).ToList();
                int totalDoc = documentazioneRecupero.Count;

                if (totalDoc > 0)
                {
                    foreach (EntityDocumentazioneRecupero dr in documentazioneRecupero)
                    {
                        //....DA FARE
                        //string fileName = dr.PortalFilename;
                        //RcdUploadDownloadFileServiceClient deleteService = new RcdUploadDownloadFileServiceClient();
                        //string message = string.Empty;
                        //deleteService.DeleteAsync(fileName, recupero.IdLocation, UploadDownloadFile.TipologiaSezione.Recuperi, recupero.Id, UploadDownloadFile.TipologiaFile.Recupero, message);
                        //if (ee.Result == true)
                        //{
                        //  ...

                        documentazioneRecupero.Remove(dr);
                        _RCDDbContext.SaveChanges();

                        if (cont == totalDoc)
                        {
                            //Elimino il recupero/manutenzione
                            var result = _RCDDbContext.Remove(recuperoToDelete);
                            _RCDDbContext.SaveChanges();

                            //}
                        }

                    }

                }
                else
                {
                    //Elimino il recupero/manutenzione
                    if (recuperoToDelete != null)
                    {
                        var result = _RCDDbContext.Remove(recuperoToDelete);
                        _RCDDbContext.SaveChanges();
                    }


                }


                //if (recuperoToDelete != null)
                //{
                //    var result = _RCDDbContext.Update(recuperoToDelete);
                //    _RCDDbContext.SaveChanges();
                //}
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion CANCELLAZIONE RECUPERI/MANUTENZIONE

        #region GET SELECT PER DETTAGLIO
        public async Task<List<ContractProvenienzaRichiesta>> GetProvenienzaRichiesta()
        {
            List<EntityProvenienzaRichiesta> provenienza;
            provenienza = await _RCDDbContext.ProvenienzaRichiesta
                                 .OrderBy(x => x.Id)
                                 .ToListAsync();
            List<ContractProvenienzaRichiesta> provenienzaElenco = new List<ContractProvenienzaRichiesta>();
            foreach (EntityProvenienzaRichiesta varProvenienza in provenienza)
            {
                ContractProvenienzaRichiesta provenienza1 = new ContractProvenienzaRichiesta();
                UtilityManager.MapProp(varProvenienza, provenienza1);
                provenienzaElenco.Add(provenienza1);
            }
            return provenienzaElenco;
        }
        #endregion

        #region RECUPERI CHIUSURA

        /// <summary>
        /// Chiude il recupero ed inposta l'installazione a rimossa
        /// </summary>
        /// <param name="recupero"></param>
        /// <param name="flagManutenzione"></param>
        /// <exception cref="Exception"></exception>
        public async void OnConfirmChiudiRecupero(EntityRecuperi recuperoInput, long idUtente, Boolean flagManutenzione)
        {
            try
            {
                bool sendMailDitta = false;
                List<long> IdDittaFittizia = new List<long> { 1, 2, 3, 4 };
                //List<ContractRecuperi> recuperiElenco = new List<ContractRecuperi>();

                ////Amministrazione.UtentiManager utentiManager;
                ////EntityUtente utente;
                //Int32 countRichieste = 0;

                //EntityUtente utente = await _RCDDbContext.Utente
                // //.Include("TipologiaUtente")
                // //.Include("AreaVendita")
                // .Where(x => x.Id == idUtente).FirstOrDefaultAsync();

                //EntityUtente utente;
                //UtentiManager utentiManager = new UtentiManager(_RCDDbContext);
                ////utente = await utentiManager.GetUtenteById(idUtente);
                // _RCDDbContext.Utente.GetUtenteById(idUtente);

                //utentiManager = new Amministrazione.UtentiManager(_RCDDbContext);
                //utente = await utentiManager.GetUtenteById(idUtente);
              
                EntityRecuperi recuperoToUpdate = new EntityRecuperi();
                EntityRecuperi originalRecupero = _RCDDbContext.Recuperi.Include("Location")
                    .Include("Ditta")
                    .Include("ProvenienzaRichiesta")
                    .Include("Location.LocationAccessori")
                     .Include("Location.LocationAntenne")
                     .Include("Location.LocationApparati")
                    //.Include("Location.StsComune")
                    //.Include("Location.StsComune.ProvinciaSts")
                    //.Include("Location.StsComune.ProvinciaSts.Provincia")
                    //.Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF")
                    //.Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .AsNoTracking()
                    .First(g => g.Id == recuperoInput.Id);
                   

                UtilityManager.MapProp(originalRecupero, recuperoToUpdate);

                recuperoToUpdate = ValidateForm(recuperoInput, ref recuperoToUpdate);

               // EntityRecuperi originalRecupero = _RCDDbContext.Recuperi.AsNoTracking().First(g => g.Id == recupero.Id);

                if (recuperoToUpdate.Ditta != null && originalRecupero != null)
                {
                    if (!recuperoToUpdate.IdDittaInstallazione.HasValue)
                    {
                        sendMailDitta = true;
                    }
                    else if (recuperoToUpdate.IdDittaInstallazione.HasValue && recuperoToUpdate.IdDittaInstallazione.Value != originalRecupero.IdDittaInstallazione.Value)
                    {
                        sendMailDitta = true;
                    }
                }
                if (originalRecupero.IdDittaInstallazione is not null)
                { 
                if (IdDittaFittizia.Contains((long)originalRecupero.IdDittaInstallazione))
                {
                    recuperoToUpdate.ApparatiInviatiMagazzino = true;
                }}

                
                Boolean isChiuso = ScaricaBudgetRecupero(ref recuperoToUpdate, idUtente);

                if (isChiuso)
                {
                    if ((recuperoToUpdate.Location is not null) && (recuperoToUpdate.Location.Id != null && recuperoToUpdate.Location.Id > 0))
                    {
                        if (recuperoToUpdate.IsManutenzione == true)
                        {
                            List<EntityLocationApparato> locationApparatiList = _RCDDbContext.LocationApparato.Where(x => x.IdLocation.Equals(recuperoToUpdate.Location.Id))
                            .ToList();

                            foreach (EntityLocationApparato l in locationApparatiList)
                            {
                                if (l.InRecupero == true && l.Recuperato == true)
                                    l.Recuperato = l.InRecupero = false;
                            }

                            recuperoToUpdate.Location.LocationApparati = locationApparatiList;
                            ////SALVATAGGIO LOCATION_APPARATI
 
                            List<EntityLocationAccessori> locationAccessoriList = _RCDDbContext.LocationAccessori.Where(x => x.IdLocation.Equals(recuperoToUpdate.Location.Id))
                           .ToList();

                            //foreach (EntityLocationAccessori l in recupero.Location.LocationAccessori)
                            foreach (EntityLocationAccessori l in locationAccessoriList)
                            {
                                if (l.InRecupero == true && l.Recuperato == true)
                                    l.Recuperato = l.InRecupero = false;
                            }
                            recuperoToUpdate.Location.LocationAccessori = locationAccessoriList;
                            ////SALVATAGGIO LOCATION_ACCESSORI

                            List<EntityLocationAntenna> locationAntenneList = _RCDDbContext.LocationAntenna.Where(x => x.IdLocation.Equals(recuperoToUpdate.Location.Id))
                            .ToList();
                            foreach (EntityLocationAntenna l in locationAntenneList)
                            {
                                if (l.InRecupero == true && l.Recuperato == true)
                                    l.Recuperato = l.InRecupero = false;
                            }
                            recuperoToUpdate.Location.LocationAntenne = locationAntenneList;
                            ////SALVATAGGIO LOCATION_ANTENNE

                            // INDAGARE CON FEDERICA
                        }
                        else
                        {
                            //////SALVATAGGIO LOCATION_APPARATI
                            List<EntityLocationApparato> locationApparatiList = 
                                _RCDDbContext.LocationApparato.Where(x => x.IdLocation.Equals(recuperoToUpdate.Location.Id)).ToList();
                            // _RCDDbContext.LocationApparato.Where(lo => lo.Recuperato == true).ToList().ForEach(la => la.InRecupero = false);

                            foreach (EntityLocationApparato l in locationApparatiList)
                            {
                                if (l.Recuperato == true)
                                    l.InRecupero = false;
                            }
                            recuperoToUpdate.Location.LocationApparati = locationApparatiList;


                            //  recuperoToUpdate.Location.LocationApparati.Where(lo => lo.Recuperato == true).ToList().ForEach(la => la.InRecupero = false);
                            // Se tutti gli apparati sono stati recuperati (nessun Recuperato = false) dismetti Location.
                            if (recuperoToUpdate.Location.LocationApparati.Count(lApp => lApp.Recuperato == false) == 0)
                            {
                                recuperoToUpdate.Location.IsDismesso = true;
                                recuperoToUpdate.Location.DismissioneImpianti = true;
                            }

                            // recuperoToUpdate.Location.LocationAccessori.Where(lo => lo.Recuperato == true).ToList().ForEach(la => la.InRecupero = false);
                            //////SALVATAGGIO LOCATION_ACCESSORI
                            List<EntityLocationAccessori> locationAccessoriList = _RCDDbContext.LocationAccessori.Where(x => x.IdLocation.Equals(recuperoToUpdate.Location.Id))
                           .ToList();
                            foreach (EntityLocationAccessori l in locationAccessoriList)
                            {
                                if (l.Recuperato == true)
                                    l.InRecupero = false;
                            }
                            recuperoToUpdate.Location.LocationAccessori = locationAccessoriList;

                            //////SALVATAGGIO LOCATION_ANTENNE
                            ///   recuperoToUpdate.Location.LocationAntenne.Where(lo => lo.Recuperato == true).ToList().ForEach(la => la.InRecupero = false);
                            List<EntityLocationAntenna> locationAntenneList = _RCDDbContext.LocationAntenna.Where(x => x.IdLocation.Equals(recuperoToUpdate.Location.Id))
                           .ToList();
                            foreach (EntityLocationAntenna l in locationAntenneList)
                            {
                                if (l.Recuperato == true)
                                    l.InRecupero = false;
                            }
                            recuperoToUpdate.Location.LocationAntenne = locationAntenneList;
                         

                        }
                        ////SALVATAGGIO LOCATION
                        _RCDDbContext.Update(recuperoToUpdate.Location);
                        _RCDDbContext.SaveChanges();
                    }


                    _RCDDbContext.Update(recuperoToUpdate);
                    _RCDDbContext.SaveChanges();
                }

                //List<EntityRecuperi> listRecuperi = new List<EntityRecuperi>();
                //foreach (EntityRecuperi varRecuperi in listRecuperi)
                //{
                //    ContractRecuperi recuperi1 = new ContractRecuperi();
                //    UtilityManager.MapProp(varRecuperi, recuperi1);
                //    recuperiElenco.Add(recuperi1);
                //}

                
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        private EntityRecuperi ValidateForm(EntityRecuperi recuperoInput, ref EntityRecuperi recuperoUpdate)
        {
            try
            {
                if (recuperoInput.IdDittaInstallazione != null)
                    recuperoUpdate.IdDittaInstallazione = recuperoInput.IdDittaInstallazione;

                if (recuperoInput.StudioProgettazione != null)
                    recuperoUpdate.StudioProgettazione = recuperoInput.StudioProgettazione;

                if (recuperoInput.IdSiteManagerNI != null)
                    recuperoUpdate.IdSiteManagerNI = recuperoInput.IdSiteManagerNI;

                if (recuperoInput.IdProgettistaRan != null)
                    recuperoUpdate.IdProgettistaRan = recuperoInput.IdProgettistaRan;

                if (recuperoInput.ApparatiInviatiMagazzino != null)
                    recuperoUpdate.ApparatiInviatiMagazzino = recuperoInput.ApparatiInviatiMagazzino;

                if (recuperoInput.Vincolo != null)
                    recuperoUpdate.Vincolo = recuperoInput.Vincolo;

                if (recuperoInput.NominaRLInviataDitta != null)
                {
                    recuperoUpdate.NominaRLInviataDitta = recuperoInput.NominaRLInviataDitta;

                    if (recuperoUpdate.NominaRLInviataDitta == true)
                    {
                        if (recuperoInput.CognomeRL is not null)
                            recuperoUpdate.CognomeRL = recuperoInput.CognomeRL;
                        else
                        {
                            if (recuperoUpdate.CognomeRL is null)
                                throw new Exception("Immettere il cognome del responsabile lavori.");
                        }

                        if (recuperoInput.NomeRL is not null)
                            recuperoUpdate.NomeRL = recuperoInput.NomeRL;
                        else
                        {
                            if (recuperoUpdate.NomeRL is null)
                                throw new Exception("Immettere il nome del responsabile lavori.");
                        }
                    }
                }

                if (recuperoInput.IdProvenienzaRichiesta is not null)
                    recuperoUpdate.IdProvenienzaRichiesta = recuperoInput.IdProvenienzaRichiesta;
                else
                {
                    if (recuperoUpdate.IdProvenienzaRichiesta is null)
                        throw new Exception("Selezionare la provenienza della richiesta.");
                }

                if (recuperoInput.IdTipoCantiere is not null)
                    recuperoUpdate.IdTipoCantiere = recuperoInput.IdTipoCantiere;
                else
                {
                    if (recuperoUpdate.IdTipoCantiere is null)
                        throw new Exception("Selezionare la tipologia di cantiere.");
                }

              //VERIFICARE SE METTERE CONTROLLO,SOLO SE CHECK = SI
                //if (recuperoInput.CognomeRL is not null)
                //    recuperoUpdate.CognomeRL = recuperoInput.CognomeRL;
                //else
                //{
                //    if (recuperoUpdate.CognomeRL is null)
                //        throw new Exception("Immettere il cognome del responsabile lavori.");
                //}

                //if (recuperoInput.NomeRL is not null)
                //    recuperoUpdate.NomeRL = recuperoInput.NomeRL;
                //else
                //{
                //    if (recuperoUpdate.NomeRL is null)
                //        throw new Exception("Immettere il nome del responsabile lavori.");
                //}

                if (recuperoInput.NoteDeliveryManager != null)
                    recuperoUpdate.NoteDeliveryManager = recuperoInput.NoteDeliveryManager;

                if (recuperoInput.NoteRanNi != null)
                    recuperoUpdate.NoteRanNi = recuperoInput.NoteRanNi;

                if (recuperoInput.DataRichiesta is not null)
                    recuperoUpdate.DataRichiesta = recuperoInput.DataRichiesta;
                else
                {
                    if (recuperoUpdate.DataRichiesta is null)
                        throw new Exception("Immettere la data della richiesta.");
                }

                if (recuperoInput.DataRecuperoConsuntivata is not null)
                    recuperoUpdate.DataRecuperoConsuntivata = recuperoInput.DataRecuperoConsuntivata;
                else
                {
                    if (recuperoUpdate.DataRecuperoConsuntivata is null)
                        throw new Exception("Immettere la data di recupero consuntivata.");
                }

                if (recuperoInput.DataRecuperoStimata is not null)
                    recuperoUpdate.DataRecuperoStimata = recuperoInput.DataRecuperoStimata;
                else
                {
                    if (recuperoUpdate.DataRecuperoStimata is null)
                        throw new Exception("Immettere la data di recupero stimata.");
                }

                return recuperoUpdate;

            }
            catch(Exception ex)
            {
                throw new Exception("errore: " + ex.Message);
            }
        }

        /// <summary>
        /// Scarica il budget per il completamento del recupero
        /// </summary>
        /// <param name="recupero">recupero da chiudere</param>
        /// <param name="ctx">Contesto</param>
        private Boolean ScaricaBudgetRecupero(ref EntityRecuperi recupero, long userId)
        {
            Boolean isChiuso = false;
            try
            {
                SendMaterialiToMagazzino(ref recupero);
                isChiuso = true;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return isChiuso;
        }

        /// <summary>
        /// Invia i materiali recuperati a magazzino
        /// </summary>
        /// <param name="recupero">Recupero chiuso</param>
        /// <param name="ctx">Contesto</param>
        private void SendMaterialiToMagazzino( ref EntityRecuperi recupero)
        {
            EntityStatoMateriale riuso = _RCDDbContext.StatoMateriale.Where(x => x.Id == 2).AsNoTracking().FirstOrDefault();

            // NON FARE LA PARTE DI MAGAZZINO
            //if (recupero.ApparatiInviatiMagazzino == true)
            //{
            //    //SendMaterialiToMagazziniVirtuali(recupero, riuso);
            //}
            //else
            //{
            //   // SendMaterialeToMagazzinoDitta(recupero, riuso);
            //}
            ControllaDismissioneImpianto(ref recupero);
        }

        /// <summary>
        /// Invia i materiali recuperati al magazzino virtuale
        /// </summary>
        /// <param name="recupero">Recupero chiuso</param>
        /// <param name="riuso">Stato materiale riuso</param>
        /// <param name="ctx">Contesto</param>
        private void SendMaterialiToMagazziniVirtuali(EntityRecuperi recupero, EntityStatoMateriale riuso)
        {
            
            //........
        }

        /// <summary>
        /// Invia i materiali recuperati al magazzino della ditta
        /// </summary>
        /// <param name="recupero">Recupero chiuso</param>
        /// <param name="riuso">Stato materuale riuso</param>
        /// <param name="ctx">Contesto</param>
        private void SendMaterialeToMagazzinoDitta(EntityRecuperi recupero, EntityStatoMateriale riuso)
        {
            //da fare??
        //    long? idDitta = recupero.Ditta.Id;
            //EntityDitta ditta = _RCDDbContext.Ditta.Where(x => x.Id == idDitta).Include("VistaAccessoriMagazzinoDitta").Include("VistaAntenneMagazzinoDitta").Include("VistaApparatiMagazzinoDitta")
            //                 .Include("VistaAccessoriMagazzinoDitta.AccessorioMagazzinoDitta.Accessorio").Include("VistaAccessoriMagazzinoDitta.AccessorioMagazzinoDitta.StatoMateriale")
            //                 .Include("VistaAccessoriMagazzinoDitta.AccessorioMagazzinoDitta.Accessorio.Fornitore").Include("VistaAccessoriMagazzinoDitta.AccessorioMagazzinoDitta.Accessorio.Sistema").Include("VistaAccessoriMagazzinoDitta.AccessorioMagazzinoDitta.Accessorio.TipologiaAccessorio")
            //                 .Include("VistaAntenneMagazzinoDitta.AntennaMagazzinoDitta.Antenna").Include("VistaAntenneMagazzinoDitta.AntennaMagazzinoDitta.StatoMateriale")
            //                 .Include("VistaAntenneMagazzinoDitta.AntennaMagazzinoDitta.Antenna.Fornitore").Include("VistaAntenneMagazzinoDitta.AntennaMagazzinoDitta.Antenna.Sistema").Include("VistaAntenneMagazzinoDitta.AntennaMagazzinoDitta.Antenna.TipologiaAntenna")
            //                 .Include("VistaApparatiMagazzinoDitta.ApparatoMagazzinoDitta.Apparato").Include("VistaApparatiMagazzinoDitta.ApparatoMagazzinoDitta.StatoMateriale")
            //                 .Include("VistaApparatiMagazzinoDitta.ApparatoMagazzinoDitta.Apparato.Fornitore").Include("VistaApparatiMagazzinoDitta.ApparatoMagazzinoDitta.Apparato.Sistema").Include("VistaApparatiMagazzinoDitta.ApparatoMagazzinoDitta.Apparato.TipologiaApparato")
            //      .AsNoTracking().FirstOrDefault();
            //...7

            //EntityDitta magazzinoDitta = _RCDDbContext.Ditta.Where(x => x.Id == idDitta).FirstOrDefault();

            //List<EntityLocationApparato> apparatiToRemove = recupero.Location.LocationApparati.Where(la => la.InRecupero == true).ToList();
            //foreach (EntityLocationApparato la in apparatiToRemove)
            //{
            //    la.Recuperato = true;
            //    //DA FARE ENTITY RECUPERI APPARATI
            //    EntityRecuperiApparati ra = new RecuperoApparati();
            //    ra.AltezzaApparato = la.AltezzaApparato;
            //    ra.Apparato = la.Apparato;
            //    ra.BcchSc = la.BcchSc;
            //    ra.CellaRipetuta = la.CellaRipetuta;
            //    ra.CellaRipetutaLte = la.CellaRipetutaLte;
            //    ra.CheckFrequenze = la.CheckFrequenze;
            //    ra.Codice = la.Codice;
            //    // ASSEGNARE IL CODICE DELL'APPARATO LOCATION
            //    ra.IdApparatoLocation = la.Id;
            //    ra.Frequenze = la.Frequenze;
            //    ra.IdClasse = la.IdClasse;
            //    ra.IdZona = la.IdZona;
            //    ra.MatricolaApparato = la.MatricolaApparato;
            //    ra.NomeApparato = la.NomeApparato;
            //    ra.Note = la.Note;
            //    ra.NumeroSim = la.NumeroSim;
            //    ra.PosizioneApparato = la.PosizioneApparato;
            //    ra.PrezzoTotale = la.PrezzoTotale;
            //    ra.Quantita = la.Quantita;
            //    ra.Raggiungibilita = la.Raggiungibilita;
            //    ra.Recuperato = la.Recuperato;
            //    ra.Refarming = la.Refarming;
            //    ra.Riuso = la.Riuso;
            //    ra.SerialeApparato = la.SerialeApparato;
            //    ra.SerialeSim = la.SerialeSim;
            //    ra.SiglaCodice = la.SiglaCodice;
            //    ra.SiglaProvincia = la.SiglaProvincia;
            //    la.StatoApparato = _RCDDbContext.StatoApparati.Where(stato => stato.Id == 3).FirstOrDefault();        //imposto a disattivo l'apparato da entrambe le parti
            //    ra.StatoApparato = la.StatoApparato;
            //    ra.ApparatoPosizione = la.PosizioneApparato;                //Modificato per nuova gestione 19/06/12
            //    ra.RaggiungibilitaApparato = la.Raggiungibilita;
            //    ra.IdPosizioneInstallazioneApparato = la.IdPosizioneInstallazioneApparato;
            //    ra.DataAttivazioneApparato = la.DataAttivazioneApparato;
            //    ra.ProprietaCliente = la.ProprietaCliente;
            //    recupero.RecuperoApparati.Add(ra);
            //    ApparatoMagazzinoDitta apparatoInStock = magazzinoDitta.ApparatoMagazzinoDitta.Where(am => am.Apparato.Id == la.Apparato.Id && am.StatoMateriale.Id == riuso.Id).FirstOrDefault<ApparatoMagazzinoDitta>();
            //    if (apparatoInStock == null)
            //    {
            //        ApparatoMagazzinoDitta apparatoToSend = new ApparatoMagazzinoDitta();
            //        apparatoToSend.Apparato = la.Apparato;
            //        apparatoToSend.Quantità = la.Quantita;
            //        apparatoToSend.StatoMateriale = riuso;
            //        magazzinoDitta.ApparatoMagazzinoDitta.Add(apparatoToSend);
            //    }
            //    else
            //    {
            //        apparatoInStock.Quantità += la.Quantita;
            //    }
            //}



          //  ControllaDismissioneImpianto(recupero); ;
        }

        /// <summary>
        /// Verifica se con la chiusura del recupero deve essere dismesso anche l'impianto
        /// </summary>
        /// <param name="recupero">Recupero chiuso</param>
        /// <param name="ctx">Contesto</param>
        private void ControllaDismissioneImpianto( ref EntityRecuperi recupero)
        {
            if (recupero.DismettiImpianto == true)
            {
                recupero.Location.IsDismesso = true;
                recupero.Location.DataDismissioneImpianti = DateTime.Today;
            }
            recupero.IsChiuso = true;
            
        }


        #endregion RECUPERI CHIUSURA

    }
}
