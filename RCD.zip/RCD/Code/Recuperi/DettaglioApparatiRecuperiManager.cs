﻿using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCD.Code.Installazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;
namespace RCD.Code.Recuperi
{
    public class DettaglioApparatiRecuperiManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public DettaglioApparatiRecuperiManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        #region APPARATI RECUPERO BY IdLocation

        public async Task<List<ContractLocationApparato>> GetApparatiRecuperoByIdLocation(LocationApparatiRequestFull apparato)
        {
            List<EntityLocationApparato> apparati;
            String sortParam = String.Concat(String.Concat(apparato.CampoOrdinamento, " "), apparato.Ordinamento.ToUpper());

            if (apparato.Pageable)
            {
                apparati = await _RCDDbContext.LocationApparato.Where(x => x.Recuperato == false)
                    .WhereIf(!String.IsNullOrEmpty(apparato.Filter.IdLocation.ToString()), x => x.IdLocation.Equals(apparato.Filter.IdLocation))
                    .Skip(apparato.NumeroElementi * apparato.Page).Take(apparato.NumeroElementi)
                    .OrderBy(sortParam)
                    .Include("Location")
                    .Include("Apparato")
                    .Include("StatoApparato")
                   .Include("PosizioneApparatoEntity")
                    .Include("RaggiungibilitaEntity")
                    .ToListAsync();
            }
            else
            {
                apparati = await _RCDDbContext.LocationApparato.Where(x => x.Recuperato == false)
                    .WhereIf(!String.IsNullOrEmpty(apparato.Filter.IdLocation.ToString()), x => x.IdLocation.Equals(apparato.Filter.IdLocation))
                    .OrderBy(sortParam)
                    .Include("Location")
                    .Include("Apparato")
                    .Include("StatoApparato")
                   .Include("PosizioneApparatoEntity")
                    .Include("RaggiungibilitaEntity")
                    .ToListAsync();
            }
            List<ContractLocationApparato> apparatoElenco = new List<ContractLocationApparato>();
            foreach (EntityLocationApparato varLocation in apparati)
            {
                ContractLocationApparato locationApp1 = new ContractLocationApparato();
                UtilityManager.MapProp(varLocation, locationApp1);
                apparatoElenco.Add(locationApp1);
            }
            return apparatoElenco;
        }

        public async Task<Int32> GetApparatiRecuperoByIdLocationTot(LocationApparatiRequestFull apparato)
        {
            Int32 count = _RCDDbContext.LocationApparato.Where(x => x.Recuperato == false)
                    .WhereIf(!String.IsNullOrEmpty(apparato.Filter.IdLocation.ToString()), x => x.IdLocation.Equals(apparato.Filter.IdLocation))
                    .Include("Location")
                    .Include("Apparato")
                    .Include("StatoApparato")
                   .Include("PosizioneApparatoEntity")
                    .Include("RaggiungibilitaEntity")
                    .Count();
            return count;
        }

        #endregion APPARATI RECUPERO BY IdLocation

        #region FEMTO RECUPERO BY IdLocation

        public async Task<List<ContractLocationFemTo>> GetFemtoRecuperoByIdLocation(LocationFemtoRequestFull apparato)
        {
            List<EntityLocationFemTo> apparati;
            String sortParam = String.Concat(String.Concat(apparato.CampoOrdinamento, " "), apparato.Ordinamento.ToUpper());

            if (apparato.Pageable)
            {
                apparati = await _RCDDbContext.LocationFemTo
                    .WhereIf(!String.IsNullOrEmpty(apparato.Filter.IdLocation.ToString()), x => x.IdLocation.Equals(apparato.Filter.IdLocation))
                    .Skip(apparato.NumeroElementi * apparato.Page).Take(apparato.NumeroElementi)
                    .OrderBy(sortParam)
                    .Include("Location")
                    .Include("TipologiaLan")
                    .Include("Copertura")
                    .ToListAsync();
            }
            else
            {
                apparati = await _RCDDbContext.LocationFemTo
                    .WhereIf(!String.IsNullOrEmpty(apparato.Filter.IdLocation.ToString()), x => x.IdLocation.Equals(apparato.Filter.IdLocation))
                    .OrderBy(sortParam)
                    .Include("Location")
                    .Include("TipologiaLan")
                    .Include("Copertura")
                    .ToListAsync();
            }
            List<ContractLocationFemTo> apparatoElenco = new List<ContractLocationFemTo>();
            foreach (EntityLocationFemTo varLocation in apparati)
            {
                ContractLocationFemTo locationApp1 = new ContractLocationFemTo();
                UtilityManager.MapProp(varLocation, locationApp1);
                apparatoElenco.Add(locationApp1);
            }
            return apparatoElenco;
        }

        public async Task<Int32> GetFemtoRecuperoByIdLocationTot(LocationFemtoRequestFull apparato)
        {
            Int32 count = _RCDDbContext.LocationFemTo
                    .WhereIf(!String.IsNullOrEmpty(apparato.Filter.IdLocation.ToString()), x => x.IdLocation.Equals(apparato.Filter.IdLocation))
                    .Include("Location")
                    .Include("TipologiaLan")
                    .Include("Copertura")
                    .Count();
            return count;
        }

        #endregion FEMTO RECUPERO BY IdLocation

        #region LOCATION ANTENNE RECUPERO BY IdLocation

        public async Task<List<ContractLocationAntenna>> GetAntenneRecuperoByIdLocation(LocationAntenneRequestFull antenne)
        {
            List<EntityLocationAntenna> antenna;
            String sortParam = String.Concat(String.Concat(antenne.CampoOrdinamento, " "), antenne.Ordinamento.ToUpper());

            if (antenne.Pageable)
            {
                antenna = await _RCDDbContext.LocationAntenna.Where(x => x.Recuperato == false)
                    .WhereIf(!String.IsNullOrEmpty(antenne.Filter.IdLocation.ToString()), x => x.IdLocation.Equals(antenne.Filter.IdLocation))
                    .Skip(antenne.NumeroElementi * antenne.Page).Take(antenne.NumeroElementi)
                    .OrderBy(sortParam)
                    .Include("Location")
                    .Include("Antenna")
                    .Include("TipologiaSegnaleAntenna")
                    .Include("AccessibilitaAntenna")
                    .Include("LocalizzazioneAntenna")
                    .Include("InstallazioneAntenna")
                    .ToListAsync();
            }
            else
            {
                antenna = await _RCDDbContext.LocationAntenna.Where(x => x.Recuperato == false)
                    .WhereIf(!String.IsNullOrEmpty(antenne.Filter.IdLocation.ToString()), x => x.IdLocation.Equals(antenne.Filter.IdLocation))
                    .OrderBy(sortParam)
                    .Include("Location")
                    .Include("Antenna")
                    .Include("TipologiaSegnaleAntenna")
                    .Include("AccessibilitaAntenna")
                    .Include("LocalizzazioneAntenna")
                    .Include("InstallazioneAntenna")
                    .ToListAsync();
            }
            List<ContractLocationAntenna> antennaElenco = new List<ContractLocationAntenna>();
            foreach (EntityLocationAntenna varLocation in antenna)
            {
                ContractLocationAntenna locationApp1 = new ContractLocationAntenna();
                UtilityManager.MapProp(varLocation, locationApp1);
                antennaElenco.Add(locationApp1);
            }
            return antennaElenco;
        }

        public async Task<Int32> GetAntenneRecuperoByIdLocationTot(LocationAntenneRequestFull antenne)
        {
            Int32 count = _RCDDbContext.LocationAntenna.Where(x => x.Recuperato == false)
                    .WhereIf(!String.IsNullOrEmpty(antenne.Filter.IdLocation.ToString()), x => x.IdLocation.Equals(antenne.Filter.IdLocation))
                    .Include("Location")
                    .Include("Antenna")
                    .Include("TipologiaSegnaleAntenna")
                    .Include("AccessibilitaAntenna")
                    .Include("LocalizzazioneAntenna")
                    .Include("InstallazioneAntenna")
                    .Count();
            return count;
        }

        #endregion APPARATI RECUPERO BY IdLocation

        #region ACCESSORI  RECUPERO BY IdLocation

        public async Task<List<ContractLocationAccessori>> GetAccessoriRecuperoByIdLocation(LocationAccessorioRequestFull accessorio)
        {
            List<EntityLocationAccessori> accessori;
            String sortParam = String.Concat(String.Concat(accessorio.CampoOrdinamento, " "), accessorio.Ordinamento.ToUpper());

            if (accessorio.Pageable)
            {
                accessori= await _RCDDbContext.LocationAccessori.Where(x => x.Recuperato == false)
                    .WhereIf(!String.IsNullOrEmpty(accessorio.Filter.IdLocation.ToString()), x => x.IdLocation.Equals(accessorio.Filter.IdLocation))
                    .Skip(accessorio.NumeroElementi * accessorio.Page).Take(accessorio.NumeroElementi)
                    .OrderBy(sortParam)
                    .Include("Location")
                    .Include("Accessorio")
                    .ToListAsync();
            }
            else
            {
                accessori = await _RCDDbContext.LocationAccessori.Where(x => x.Recuperato == false)
                    .WhereIf(!String.IsNullOrEmpty(accessorio.Filter.IdLocation.ToString()), x => x.IdLocation.Equals(accessorio.Filter.IdLocation))
                    .OrderBy(sortParam)
                    .Include("Location")
                    .Include("Accessorio")
                    .ToListAsync();
            }
            List<ContractLocationAccessori> accessorioElenco = new List<ContractLocationAccessori>();
            foreach (EntityLocationAccessori  varLocation in accessori)
            {
                ContractLocationAccessori locationApp1 = new ContractLocationAccessori();
                UtilityManager.MapProp(varLocation, locationApp1);
                accessorioElenco.Add(locationApp1);
            }
            return accessorioElenco;
        }

        public async Task<Int32> GetAccessoriRecuperoByIdLocationTot(LocationAccessorioRequestFull accessorio)
        {
            Int32 count = _RCDDbContext.LocationAccessori.Where(x => x.Recuperato == false)
                    .WhereIf(!String.IsNullOrEmpty(accessorio.Filter.IdLocation.ToString()), x => x.IdLocation.Equals(accessorio.Filter.IdLocation))
                    .Include("Location")
                    .Include("Accessorio")
                    .Count();
            return count;
        }

        #endregion ACCESSORI RECUPERO BY IdLocation

        #region CODICE BIDONE RIPETITORE

        public async Task<List<ContractRipetitori>> GetCodiciBidoneByRipetitori()
        {
            List<EntityRipetitori> ripetitore;
            ripetitore = await _RCDDbContext.Ripetitori
                .Where(x => x.IdOffice == (decimal?) - 1 || x.IdOffice == (decimal?) - 2 || x.IdOffice == (decimal?) - 3 || x.IdOffice == (decimal?) - 4)
                .ToListAsync();
            
            List<ContractRipetitori> ripetitoreElenco = new List<ContractRipetitori>();
            foreach (EntityRipetitori varRipetitore in ripetitore)
            {
                ContractRipetitori ripetitor1 = new ContractRipetitori();
                UtilityManager.MapProp(varRipetitore, ripetitor1);
                ripetitoreElenco.Add(ripetitor1);
            }
            return ripetitoreElenco;
        }

        public async Task<Int32> GetCodiciBidoneByRipetitoriTot()
        {
            Int32 count = _RCDDbContext.Ripetitori
                .Where(x => x.IdOffice == (decimal?)-1 || x.IdOffice == (decimal?)-2 || x.IdOffice == (decimal?)-3 || x.IdOffice == (decimal?)-4)
                    .Count();
            return count;
        }
        #endregion CODICE BIDONE RIPETITORE
    }
}
