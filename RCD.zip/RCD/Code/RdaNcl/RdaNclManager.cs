﻿using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;
using System.Linq;

namespace RCD.Code.RdaNcl
{
    public class RdaNclManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;


        public RdaNclManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
        public async Task<List<EntityViewRDA>> GetListaRdAByIdFornitore(ViewRdaRequestFull rda, Int64 idDitta)
        {
            List<EntityViewRDA> rdaDitta = new List<EntityViewRDA>();
            String sortParam = String.Concat(String.Concat(rda.CampoOrdinamento, " "),
                             rda.Ordinamento.ToUpper());
            if (rda.Pageable)
            {
                _RCDDbContext.Database.SetCommandTimeout(300);
                rdaDitta = _RCDDbContext.ViewRDA.Where(x => x.IdFornitore.Equals(idDitta))
                    .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdFornitore.ToString()), x => x.IdFornitore.Equals(rda.Filter.IdFornitore))
                        .WhereIf(!String.IsNullOrEmpty(rda.Filter.StatoRichiesta), x => x.StatoRichiesta.Contains(rda.Filter.StatoRichiesta))
                        .WhereIf(!String.IsNullOrEmpty(rda.Filter.CreatoDa), x => x.CreatoDa.Contains(rda.Filter.CreatoDa))
                        .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataInvio.ToString()), x => x.DataInvio.Equals(rda.Filter.DataInvio))
                        .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataChiusuraLavori.ToString()), x => x.DataChiusuraLavori.Equals(rda.Filter.DataChiusuraLavori))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.CodiceNazionale), x => x.CodiceNazionale.Contains(rda.Filter.CodiceNazionale))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.Office), x => x.Office.Contains(rda.Filter.Office))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.Zona), x => x.Zona.Contains(rda.Filter.Zona))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.CodiceCliente), x => x.CodiceCliente.Contains(rda.Filter.CodiceCliente))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.RagioneSocialeCliente), x => x.RagioneSocialeCliente.Contains(rda.Filter.RagioneSocialeCliente))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.NomeInstallazione), x => x.NomeInstallazione.Contains(rda.Filter.NomeInstallazione))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.Indirizzo), x => x.Indirizzo.Contains(rda.Filter.Indirizzo))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.Comune), x => x.Comune.Contains(rda.Filter.Comune))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.Provincia), x => x.Provincia.Contains(rda.Filter.Provincia))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.Fornitore), x => x.Fornitore.Contains(rda.Filter.Fornitore))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.StatoAmministrativo), x => x.StatoAmministrativo.Contains(rda.Filter.StatoAmministrativo))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.StatoRda), x => x.StatoRda.Contains(rda.Filter.StatoRda))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdRdaCsc), x => x.IdRdaCsc.Contains(rda.Filter.IdRdaCsc))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdOdaCsc), x => x.IdOdaCsc.Contains(rda.Filter.IdOdaCsc))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.TotaleRDA.ToString()), x => x.TotaleRDA.Equals(rda.Filter.TotaleRDA))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdEntry), x => x.IdEntry.Contains(rda.Filter.IdEntry))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataSopralluogoStimata.ToString()), x => x.DataSopralluogoStimata.Equals(rda.Filter.DataSopralluogoStimata))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataSopralluogoConsuntivata.ToString()), x => x.DataSopralluogoConsuntivata.Equals(rda.Filter.DataSopralluogoConsuntivata))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataInstallazioneStimata.ToString()), x => x.DataInstallazioneStimata.Equals(rda.Filter.DataInstallazioneStimata))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataOnAirConsuntivata.ToString()), x => x.DataOnAirConsuntivata.Equals(rda.Filter.DataOnAirConsuntivata))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataRichiesta.ToString()), x => x.DataRichiesta.Equals(rda.Filter.DataRichiesta))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataChiusuraAttivitaDitta.ToString()), x => x.DataChiusuraAttivitaDitta.Equals(rda.Filter.DataChiusuraAttivitaDitta))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.DeliveryManager), x => x.DeliveryManager.Contains(rda.Filter.DeliveryManager))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.RAN), x => x.RAN.Contains(rda.Filter.RAN))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.NI), x => x.NI.Contains(rda.Filter.NI))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdFornitore.ToString()), x => x.IdFornitore.Equals(rda.Filter.IdFornitore))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.TipologiaRichiesta), x => x.TipologiaRichiesta.Contains(rda.Filter.TipologiaRichiesta))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdIntervento.ToString()), x => x.IdIntervento.Equals(rda.Filter.IdIntervento))
                        .OrderBy(sortParam)
                       .Select(x => x)
                       .Skip(rda.NumeroElementi * rda.Page).Take(rda.NumeroElementi)
                       .ToList();
            }
            else
            {
                _RCDDbContext.Database.SetCommandTimeout(300);
                rdaDitta = _RCDDbContext.ViewRDA.Where(x => x.IdFornitore.Equals(idDitta))
                    .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdFornitore.ToString()), x => x.IdFornitore.Equals(rda.Filter.IdFornitore))
                      .WhereIf(!String.IsNullOrEmpty(rda.Filter.StatoRichiesta), x => x.StatoRichiesta.Contains(rda.Filter.StatoRichiesta))
                      .WhereIf(!String.IsNullOrEmpty(rda.Filter.CreatoDa), x => x.CreatoDa.Contains(rda.Filter.CreatoDa))
                      .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataInvio.ToString()), x => x.DataInvio.Equals(rda.Filter.DataInvio))
                      .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataChiusuraLavori.ToString()), x => x.DataChiusuraLavori.Equals(rda.Filter.DataChiusuraLavori))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.CodiceNazionale), x => x.CodiceNazionale.Contains(rda.Filter.CodiceNazionale))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.Office), x => x.Office.Contains(rda.Filter.Office))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.Zona), x => x.Zona.Contains(rda.Filter.Zona))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.CodiceCliente), x => x.CodiceCliente.Contains(rda.Filter.CodiceCliente))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.RagioneSocialeCliente), x => x.RagioneSocialeCliente.Contains(rda.Filter.RagioneSocialeCliente))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.NomeInstallazione), x => x.NomeInstallazione.Contains(rda.Filter.NomeInstallazione))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.Indirizzo), x => x.Indirizzo.Contains(rda.Filter.Indirizzo))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.Comune), x => x.Comune.Contains(rda.Filter.Comune))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.Provincia), x => x.Provincia.Contains(rda.Filter.Provincia))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.Fornitore), x => x.Fornitore.Contains(rda.Filter.Fornitore))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.StatoAmministrativo), x => x.StatoAmministrativo.Contains(rda.Filter.StatoAmministrativo))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.StatoRda), x => x.StatoRda.Contains(rda.Filter.StatoRda))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdRdaCsc), x => x.IdRdaCsc.Contains(rda.Filter.IdRdaCsc))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdOdaCsc), x => x.IdOdaCsc.Contains(rda.Filter.IdOdaCsc))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.TotaleRDA.ToString()), x => x.TotaleRDA.Equals(rda.Filter.TotaleRDA))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdEntry), x => x.IdEntry.Contains(rda.Filter.IdEntry))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataSopralluogoStimata.ToString()), x => x.DataSopralluogoStimata.Equals(rda.Filter.DataSopralluogoStimata))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataSopralluogoConsuntivata.ToString()), x => x.DataSopralluogoConsuntivata.Equals(rda.Filter.DataSopralluogoConsuntivata))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataInstallazioneStimata.ToString()), x => x.DataInstallazioneStimata.Equals(rda.Filter.DataInstallazioneStimata))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataOnAirConsuntivata.ToString()), x => x.DataOnAirConsuntivata.Equals(rda.Filter.DataOnAirConsuntivata))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataRichiesta.ToString()), x => x.DataRichiesta.Equals(rda.Filter.DataRichiesta))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataChiusuraAttivitaDitta.ToString()), x => x.DataChiusuraAttivitaDitta.Equals(rda.Filter.DataChiusuraAttivitaDitta))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.DeliveryManager), x => x.DeliveryManager.Contains(rda.Filter.DeliveryManager))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.RAN), x => x.RAN.Contains(rda.Filter.RAN))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.NI), x => x.NI.Contains(rda.Filter.NI))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdFornitore.ToString()), x => x.IdFornitore.Equals(rda.Filter.IdFornitore))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.TipologiaRichiesta), x => x.TipologiaRichiesta.Contains(rda.Filter.TipologiaRichiesta))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdIntervento.ToString()), x => x.IdIntervento.Equals(rda.Filter.IdIntervento))
                      .OrderBy(sortParam)
                     .Select(x => x)
                     .ToList();


            }

            return rdaDitta;
        }

        public async Task<Int32> GetListaRdAByIdFornitoreTot(ViewRdaRequestFull rda, Int64 idDitta)
        {

            _RCDDbContext.Database.SetCommandTimeout(300);
            Int32 rdaDitta = _RCDDbContext.ViewRDA.Where(x => x.IdFornitore.Equals(idDitta))
                      .WhereIf(!String.IsNullOrEmpty(rda.Filter.StatoRichiesta), x => x.StatoRichiesta.Contains(rda.Filter.StatoRichiesta))
                      .WhereIf(!String.IsNullOrEmpty(rda.Filter.CreatoDa), x => x.CreatoDa.Contains(rda.Filter.CreatoDa))
                       .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdFornitore.ToString()), x => x.IdFornitore.Equals(rda.Filter.IdFornitore))
                      .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataInvio.ToString()), x => x.DataInvio.Equals(rda.Filter.DataInvio))
                      .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataChiusuraLavori.ToString()), x => x.DataChiusuraLavori.Equals(rda.Filter.DataChiusuraLavori))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.CodiceNazionale), x => x.CodiceNazionale.Contains(rda.Filter.CodiceNazionale))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.Office), x => x.Office.Contains(rda.Filter.Office))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.Zona), x => x.Zona.Contains(rda.Filter.Zona))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.CodiceCliente), x => x.CodiceCliente.Contains(rda.Filter.CodiceCliente))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.RagioneSocialeCliente), x => x.RagioneSocialeCliente.Contains(rda.Filter.RagioneSocialeCliente))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.NomeInstallazione), x => x.NomeInstallazione.Contains(rda.Filter.NomeInstallazione))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.Indirizzo), x => x.Indirizzo.Contains(rda.Filter.Indirizzo))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.Comune), x => x.Comune.Contains(rda.Filter.Comune))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.Provincia), x => x.Provincia.Contains(rda.Filter.Provincia))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.Fornitore), x => x.Fornitore.Contains(rda.Filter.Fornitore))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.StatoAmministrativo), x => x.StatoAmministrativo.Contains(rda.Filter.StatoAmministrativo))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.StatoRda), x => x.StatoRda.Contains(rda.Filter.StatoRda))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdRdaCsc), x => x.IdRdaCsc.Contains(rda.Filter.IdRdaCsc))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdOdaCsc), x => x.IdOdaCsc.Contains(rda.Filter.IdOdaCsc))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.TotaleRDA.ToString()), x => x.TotaleRDA.Equals(rda.Filter.TotaleRDA))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdEntry), x => x.IdEntry.Contains(rda.Filter.IdEntry))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataSopralluogoStimata.ToString()), x => x.DataSopralluogoStimata.Equals(rda.Filter.DataSopralluogoStimata))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataSopralluogoConsuntivata.ToString()), x => x.DataSopralluogoConsuntivata.Equals(rda.Filter.DataSopralluogoConsuntivata))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataInstallazioneStimata.ToString()), x => x.DataInstallazioneStimata.Equals(rda.Filter.DataInstallazioneStimata))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataOnAirConsuntivata.ToString()), x => x.DataOnAirConsuntivata.Equals(rda.Filter.DataOnAirConsuntivata))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataRichiesta.ToString()), x => x.DataRichiesta.Equals(rda.Filter.DataRichiesta))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.DataChiusuraAttivitaDitta.ToString()), x => x.DataChiusuraAttivitaDitta.Equals(rda.Filter.DataChiusuraAttivitaDitta))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.DeliveryManager), x => x.DeliveryManager.Contains(rda.Filter.DeliveryManager))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.RAN), x => x.RAN.Contains(rda.Filter.RAN))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.NI), x => x.NI.Contains(rda.Filter.NI))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdFornitore.ToString()), x => x.IdFornitore.Equals(rda.Filter.IdFornitore))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.TipologiaRichiesta), x => x.TipologiaRichiesta.Contains(rda.Filter.TipologiaRichiesta))
                     .WhereIf(!String.IsNullOrEmpty(rda.Filter.IdIntervento.ToString()), x => x.IdIntervento.Equals(rda.Filter.IdIntervento))
                     .Select(x => x)
                     .Count();

            return rdaDitta;


        }
        #region RICHIESTE ATTESA

        public async Task<List<EntityRichiesta>> GetRichiesteAttesaRdA(RichiestaRequestFull richiesta, Int64? idDitta)
        {
            List<EntityRichiesta> richieste = new List<EntityRichiesta>();
            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                             richiesta.Ordinamento.ToUpper());
            List<Int64?> idStatiOkEmissioneRdaSopralluogo = new List<Int64?>();
            List<Int64?> idStatiOkEmissioneRdaInstallazione = new List<Int64?>();

            idStatiOkEmissioneRdaSopralluogo = _RCDDbContext.Stato
                                    .Where(x => x.CanEmitRdASopralluogo == true)
                                    .Select(x => x.Id)
                                    .ToList();
            idStatiOkEmissioneRdaInstallazione = _RCDDbContext.Stato
                                                .Where(x => x.CanEmitRdAInstallazione == true)
                                                .Select(x => x.Id)
                                                .ToList();
            if (richiesta.Pageable)
            {

                _RCDDbContext.Database.SetCommandTimeout(300);
                richieste = await _RCDDbContext.Richieste
                   .Where(x => idStatiOkEmissioneRdaSopralluogo.Contains(x.LastStatusId) && x.Sopralluogo.IdDittaIncaricata.Equals(idDitta) && x.Sopralluogo.RdAEmessa == false && x.Sopralluogo.DataPresaInCaricoDitta != null
                    || idStatiOkEmissioneRdaInstallazione.Contains(x.LastStatusId) && x.Installazione.IdDittaInstallazione.Equals(idDitta)
                     && x.Installazione.RdAEmessa == false)
                     .Include("Richiedente")
                   .Include("Utente")
                   .Include("Location")
                   .Include("Location.StsComune")
                   .Include("Location.StsComune.ProvinciaSts")
                   .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                   .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                   .Include("Sopralluogo")
                   .Include("Installazione")
                   .Include("SiteManagerNI")
                   .Include("ProgettistaRan")
                        .OrderBy(sortParam)
                       .Select(x => x)
                       .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                       .ToListAsync();
            }
            else
            {
                _RCDDbContext.Database.SetCommandTimeout(300);
                richieste =  await _RCDDbContext.Richieste
                    .Where(x => idStatiOkEmissioneRdaSopralluogo.Contains(x.LastStatusId) &&  x.Sopralluogo.IdDittaIncaricata.Equals(idDitta) && x.Sopralluogo.RdAEmessa == false &&  x.Sopralluogo.DataPresaInCaricoDitta != null
                    || idStatiOkEmissioneRdaInstallazione.Contains(x.LastStatusId) && x.Installazione.IdDittaInstallazione.Equals(idDitta)
                     && x.Installazione.RdAEmessa == false)
                     .Include("Richiedente")
                   .Include("Utente")
                   .Include("Location")
                   .Include("Location.StsComune")
                   .Include("Location.StsComune.ProvinciaSts")
                   .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                   .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                   .Include("Sopralluogo")
                   .Include("Installazione")
                   .Include("SiteManagerNI")
                   .Include("ProgettistaRan")
                        .OrderBy(sortParam)
                       .Select(x => x)
                       .ToListAsync();

            }

            return richieste;
        }
        
        public async Task<Int32> GetRichiesteAttesaRdATot(RichiestaRequestFull richiesta, Int64? idDitta)
        {
            List<Int64?> idStatiOkEmissioneRdaSopralluogo = new List<Int64?>();
            List<Int64?> idStatiOkEmissioneRdaInstallazione = new List<Int64?>();

            idStatiOkEmissioneRdaSopralluogo = _RCDDbContext.Stato
                                    .Where(x => x.CanEmitRdASopralluogo == true)
                                    .Select(x => x.Id)
                                    .ToList();
            idStatiOkEmissioneRdaInstallazione = _RCDDbContext.Stato
                                                .Where(x => x.CanEmitRdAInstallazione == true)
                                                .Select(x => x.Id)
                                                .ToList();

            _RCDDbContext.Database.SetCommandTimeout(300);
            Int32 count = _RCDDbContext.Richieste
                .Where(x => idStatiOkEmissioneRdaSopralluogo.Contains(x.LastStatusId) && x.Sopralluogo.IdDittaIncaricata.Equals(idDitta) && x.Sopralluogo.RdAEmessa == false && x.Sopralluogo.DataPresaInCaricoDitta != null
                    || idStatiOkEmissioneRdaInstallazione.Contains(x.LastStatusId) && x.Installazione.IdDittaInstallazione.Equals(idDitta)
                     && x.Installazione.RdAEmessa == false)
                 .Include("Richiedente")
               .Include("Utente")
               .Include("Location")
               .Include("Location.StsComune")
               .Include("Location.StsComune.ProvinciaSts")
               .Include("Location.StsComune.ProvinciaSts.RegioneSts")
               .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
               .Include("Sopralluogo")
               .Include("Installazione")
               .Include("SiteManagerNI")
               .Include("ProgettistaRan")
               .Count();

            return count;
        }
        #endregion RICHIESTE ATTESA

        #region RECUPERI ATTESA RDA
        public async Task<List<EntityRecuperi>> GetRecuperiAttesaRdA(RecuperiRequestFull recupero, Int64? idDitta)
        {
            List<EntityRecuperi> recuperi = new List<EntityRecuperi>();
            String sortParam = String.Concat(String.Concat(recupero.CampoOrdinamento, " "),
                             recupero.Ordinamento.ToUpper());

            if (recupero.Pageable)
            {

                _RCDDbContext.Database.SetCommandTimeout(300);
                recuperi = await _RCDDbContext.Recuperi
                    .Where(x => x.IdDittaInstallazione == idDitta && x.RdAEmessa == false 
                    && x.IsManutenzione == false && x.IsChiuso == false)               
                    .Include("Location")
                .Include("Location.StsComune")
                .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.Richiedente") 
                    .OrderBy(sortParam)
                    .Select(x => x)
                    .Skip(recupero.NumeroElementi * recupero.Page).Take(recupero.NumeroElementi)
                    .ToListAsync();
            }
            else
            {
                _RCDDbContext.Database.SetCommandTimeout(300);
                recuperi = await _RCDDbContext.Recuperi
                .Where(x => x.IdDittaInstallazione == idDitta && x.RdAEmessa == false
                && x.IsManutenzione == false && x.IsChiuso == false)
                .Include("Location")
            .Include("Location.StsComune")
            .Include("Location.StsComune.ProvinciaSts")
                .Include("Location.Richiedente") 
                    .OrderBy(sortParam)
                .Select(x => x)
                .ToListAsync();

            }

            return recuperi;
        }

        public async Task<Int32> GetRecuperiAttesaRdATot(RecuperiRequestFull recupero, Int64? idDitta)
        {
            

            _RCDDbContext.Database.SetCommandTimeout(300);
            Int32 count =  _RCDDbContext.Recuperi
                        .Where(x => x.IdDittaInstallazione == idDitta && x.RdAEmessa == false
                        && x.IsManutenzione == false && x.IsChiuso == false)
                        .Include("Location")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                        .Include("Location.Richiedente")
                       .Count();

            return count;
        }
        #endregion RECUPERI ATTESA RDA

        #region MANUTENZIONE ATTESA RDA
        public async Task<List<EntityRecuperi>> GetManutenzioniAttesaRdA(RecuperiRequestFull recupero, Int64? idDitta)
        {
            List<EntityRecuperi> recuperi = new List<EntityRecuperi>();
            String sortParam = String.Concat(String.Concat(recupero.CampoOrdinamento, " "),
                             recupero.Ordinamento.ToUpper());

            if (recupero.Pageable)
            {

                _RCDDbContext.Database.SetCommandTimeout(300);
                recuperi = await _RCDDbContext.Recuperi
                    .Where(x => x.IdDittaInstallazione == idDitta && x.RdAEmessa == false
                    && x.IsManutenzione == true && x.IsChiuso == false)
                    .Include("Location")
                .Include("Location.StsComune")
                .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.Richiedente")
                    .OrderBy(sortParam)
                    .Select(x => x)
                    .Skip(recupero.NumeroElementi * recupero.Page).Take(recupero.NumeroElementi)
                    .ToListAsync();
            }
            else
            {
                _RCDDbContext.Database.SetCommandTimeout(300);
                recuperi = await _RCDDbContext.Recuperi
                .Where(x => x.IdDittaInstallazione == idDitta && x.RdAEmessa == false
                && x.IsManutenzione == true && x.IsChiuso == false)
                .Include("Location")
            .Include("Location.StsComune")
            .Include("Location.StsComune.ProvinciaSts")
                .Include("Location.Richiedente")
                    .OrderBy(sortParam)
                .Select(x => x)
                .ToListAsync();

            }

            return recuperi;
        }

        public async Task<Int32> GetManutenzioniAttesaRdATot(RecuperiRequestFull recupero, Int64? idDitta)
        {


            _RCDDbContext.Database.SetCommandTimeout(300);
            Int32 count = _RCDDbContext.Recuperi
                .Where(x => x.IdDittaInstallazione == idDitta && x.RdAEmessa == false
                && x.IsManutenzione == true && x.IsChiuso == false)
                .Include("Location")
            .Include("Location.StsComune")
            .Include("Location.StsComune.ProvinciaSts")
                .Include("Location.Richiedente")
                       .Count();

            return count;
        }
        #endregion MANUTENZIONE ATTESA RDA



    }
}
