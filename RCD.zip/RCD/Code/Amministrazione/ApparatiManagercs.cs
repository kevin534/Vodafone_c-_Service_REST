﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class ApparatiManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public ApparatiManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractApparati>> GetApparato(ApparatiRequestFull apparato)
        {

            List<EntityApparati> apparati;

            String sortParam = String.Concat(String.Concat(apparato.CampoOrdinamento, " "), apparato.Ordinamento.ToUpper());

            if (apparato.Pageable)
            {
                apparati = await _RCDDbContext.Apparati.Where(x => x.Abilitato == true)
                            .WhereIf(!String.IsNullOrEmpty(apparato.Filter.Modello), q => q.Modello.Contains(apparato.Filter.Modello))
                            .WhereIf(!String.IsNullOrEmpty(apparato.Filter.RfOutputPowerDlUl), q => q.RfOutputPowerDlUl.Contains(apparato.Filter.RfOutputPowerDlUl))
                            .WhereIf(!String.IsNullOrEmpty(apparato.Filter.NumeroCanali.ToString()), q => q.NumeroCanali.Equals(apparato.Filter.NumeroCanali))
                            .WhereIf(!String.IsNullOrEmpty(apparato.Filter.Modem.ToString()), q => q.Modem.Equals(apparato.Filter.Modem))
                            .WhereIf(!String.IsNullOrEmpty(apparato.Filter.Costo.ToString()), q => q.Costo.Equals(apparato.Filter.Costo))
                           .WhereIf(apparato.Filter.Fornitore != null && !String.IsNullOrEmpty(apparato.Filter.Fornitore.RagioneSociale), q => q.Fornitore.RagioneSociale.Contains(apparato.Filter.Fornitore.RagioneSociale))
                         .WhereIf(apparato.Filter.Sistema != null && !String.IsNullOrEmpty(apparato.Filter.Sistema.Sistema), q => q.Sistema.Sistema.Contains(apparato.Filter.Sistema.Sistema))
                         .WhereIf(apparato.Filter.TipologiaApparato != null && !String.IsNullOrEmpty(apparato.Filter.TipologiaApparato.TipologiaApparato), q => q.TipologiaApparato.TipologiaApparato.Contains(apparato.Filter.TipologiaApparato.TipologiaApparato))
                         .OrderBy(sortParam)
                            .Skip(apparato.NumeroElementi * apparato.Page).Take(apparato.NumeroElementi)
                            .Include("Sistema")
                            .Include("Fornitore")
                            .Include("TipologiaApparato")
                            .ToListAsync();

            }
            else
            {
                apparati = await _RCDDbContext.Apparati.Where(x => x.Abilitato == true)
                            .WhereIf(!String.IsNullOrEmpty(apparato.Filter.Modello), q => q.Modello.Contains(apparato.Filter.Modello))
                            .WhereIf(!String.IsNullOrEmpty(apparato.Filter.RfOutputPowerDlUl), q => q.RfOutputPowerDlUl.Contains(apparato.Filter.RfOutputPowerDlUl))
                            .WhereIf(!String.IsNullOrEmpty(apparato.Filter.NumeroCanali.ToString()), q => q.NumeroCanali.Equals(apparato.Filter.NumeroCanali))
                            .WhereIf(!String.IsNullOrEmpty(apparato.Filter.Modem.ToString()), q => q.Modem.Equals(apparato.Filter.Modem))
                            .WhereIf(!String.IsNullOrEmpty(apparato.Filter.Costo.ToString()), q => q.Costo.Equals(apparato.Filter.Costo))
                            .WhereIf(apparato.Filter.Fornitore != null && !String.IsNullOrEmpty(apparato.Filter.Fornitore.RagioneSociale), q => q.Fornitore.RagioneSociale.Contains(apparato.Filter.Fornitore.RagioneSociale))
                         .WhereIf(apparato.Filter.Sistema != null && !String.IsNullOrEmpty(apparato.Filter.Sistema.Sistema), q => q.Sistema.Sistema.Contains(apparato.Filter.Sistema.Sistema))
                         .WhereIf(apparato.Filter.TipologiaApparato != null && !String.IsNullOrEmpty(apparato.Filter.TipologiaApparato.TipologiaApparato), q => q.TipologiaApparato.TipologiaApparato.Contains(apparato.Filter.TipologiaApparato.TipologiaApparato))
                         .OrderBy(sortParam)
                            .Include("Sistema")
                            .Include("Fornitore")
                            .Include("TipologiaApparato")
                            .ToListAsync();
            }
            

            List<ContractApparati> apparatiElenco = new List<ContractApparati>();
            foreach (EntityApparati varApparato in apparati)
            {
                ContractApparati apparato1 = new ContractApparati();
                UtilityManager.MapProp(varApparato, apparato1);
                apparatiElenco.Add(apparato1);
            }
            return apparatiElenco;
        }
        public async Task<List<ContractCriticitaEMF>> GetCritcitaEMF()
        {
            List<EntityCriticitaEMF> app;

            app = await _RCDDbContext.CriticitaE.OrderBy(x => x.id)
                                .ToListAsync();


            List<ContractCriticitaEMF> getElenco = new List<ContractCriticitaEMF>();
            foreach (EntityCriticitaEMF varCriticita in app)
            {
                ContractCriticitaEMF criticita = new ContractCriticitaEMF();
                UtilityManager.MapProp(varCriticita, criticita);
                getElenco.Add(criticita);
            }
            return getElenco;
        }
        public async Task<List<ContractInstallazioneApparato>> GetInstallazioneApparato()
        {
            List<EntityInstallazioneApparato> app;

            app = await _RCDDbContext.InstallazioneAp.OrderBy(x => x.id)
                                .ToListAsync();


            List<ContractInstallazioneApparato> getElenco = new List<ContractInstallazioneApparato>();
            foreach (EntityInstallazioneApparato varAccAntenna in app)
            {
                ContractInstallazioneApparato ant1 = new ContractInstallazioneApparato();
                UtilityManager.MapProp(varAccAntenna, ant1);
                getElenco.Add(ant1);
            }
            return getElenco;
        }
        public async Task<List<ContractRaggiungibilitaApparato>> GetRaggiungibilitaApparato()
        {
            List<EntityRaggiungibilitaApparato> app;

            app = await _RCDDbContext.RaggiungibilitaAP.OrderBy(x => x.id)
                                .ToListAsync();


            List<ContractRaggiungibilitaApparato> getElenco = new List<ContractRaggiungibilitaApparato>();
            foreach (EntityRaggiungibilitaApparato varRaggAPP in app)
            {
                ContractRaggiungibilitaApparato RAGG1 = new ContractRaggiungibilitaApparato();
                UtilityManager.MapProp(varRaggAPP, RAGG1);
                getElenco.Add(RAGG1);
            }
            return getElenco;
        }
        public async Task<List<ContractPosizioneApparato>> GetPosizioneApparato()
        {
            List<EntityPosizioneApparato> app;

            app = await _RCDDbContext.PosizioneAp.OrderBy(x => x.id)
                                .ToListAsync();


            List<ContractPosizioneApparato> getElenco = new List<ContractPosizioneApparato>();
            foreach (EntityPosizioneApparato varRaggAPP in app)
            {
                ContractPosizioneApparato pos1 = new ContractPosizioneApparato();
                UtilityManager.MapProp(varRaggAPP, pos1);
                getElenco.Add(pos1);
            }
            return getElenco;
        }
        public async Task<Int32> GetApparatoTot(ApparatiRequestFull apparato)
        {
            List<EntityApparati> apparati;


            apparati = await _RCDDbContext.Apparati.Where(x => x.Abilitato == true)
                           .WhereIf(!String.IsNullOrEmpty(apparato.Filter.Modello), q => q.Modello.Contains(apparato.Filter.Modello))
                           .WhereIf(!String.IsNullOrEmpty(apparato.Filter.RfOutputPowerDlUl), q => q.RfOutputPowerDlUl.Contains(apparato.Filter.RfOutputPowerDlUl))
                           .WhereIf(!String.IsNullOrEmpty(apparato.Filter.NumeroCanali.ToString()), q => q.NumeroCanali.Equals(apparato.Filter.NumeroCanali))
                           .WhereIf(!String.IsNullOrEmpty(apparato.Filter.Modem.ToString()), q => q.Modem.Equals(apparato.Filter.Modem))
                           .WhereIf(!String.IsNullOrEmpty(apparato.Filter.Costo.ToString()), q => q.Costo.Equals(apparato.Filter.Costo))
                           .WhereIf(apparato.Filter.Fornitore != null && !String.IsNullOrEmpty(apparato.Filter.Fornitore.RagioneSociale), q => q.Fornitore.RagioneSociale.Contains(apparato.Filter.Fornitore.RagioneSociale))
                         .WhereIf(apparato.Filter.Sistema != null && !String.IsNullOrEmpty(apparato.Filter.Sistema.Sistema), q => q.Sistema.Sistema.Contains(apparato.Filter.Sistema.Sistema))
                         .WhereIf(apparato.Filter.TipologiaApparato != null && !String.IsNullOrEmpty(apparato.Filter.TipologiaApparato.TipologiaApparato), q => q.TipologiaApparato.TipologiaApparato.Contains(apparato.Filter.TipologiaApparato.TipologiaApparato))
                           .ToListAsync();
            return apparati.Count();

        }

        public void AddApparato(ApparatiRequest apparato)
        {
            try
            {
                EntityApparati apparatoToAdd = new EntityApparati();
                UtilityManager.MapProp(apparato, apparatoToAdd);
                var result = _RCDDbContext.Add(apparatoToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateApparato(ApparatiRequest apparato)
        {
            try
            {
                EntityApparati apparatoToAdd = new EntityApparati();
                UtilityManager.MapProp(apparato, apparatoToAdd);
                var result = _RCDDbContext.Update(apparatoToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteApparato(ApparatiRequest apparato)
        {
            try
            {
                EntityApparati entityApparatoToUpdate = _RCDDbContext.Apparati.FirstOrDefault(item => item.Id == apparato.Id);

                if (entityApparatoToUpdate != null)
                {
                    entityApparatoToUpdate.Abilitato = false;
                    var result = _RCDDbContext.Update(entityApparatoToUpdate);
                    _RCDDbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public async Task<List<ContractStatoApparati>> GetStatoApparati()
        {
            List<EntityStatoApparati> apparati;
            apparati = await _RCDDbContext.StatoApparati
                                 .OrderBy(x => x.Id)
                                 .ToListAsync();
            List<ContractStatoApparati> apparatiElenco = new List<ContractStatoApparati>();
            foreach (EntityStatoApparati varapparati in apparati)
            {
                ContractStatoApparati sist1 = new ContractStatoApparati();
                UtilityManager.MapProp(varapparati, sist1);
                apparatiElenco.Add(sist1);
            }
            return apparatiElenco;
        }


    }
}
