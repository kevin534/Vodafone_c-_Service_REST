﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class TipologiaAccessorioManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public TipologiaAccessorioManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
        public async Task<List<ContractTipologiaAccessorio>> GetTipologiaAccessorio(TipologiaAccessarioRequestFull tipologiaAccessorio)
        {
            List<EntityTipologiaAccessorio> tipologiaAccessori;

            String sortParam = String.Concat(String.Concat(tipologiaAccessorio.CampoOrdinamento, " "), tipologiaAccessorio.Ordinamento.ToUpper());

            if (tipologiaAccessorio.Pageable)
            {
                tipologiaAccessori = await _RCDDbContext.TipologiaAccessorio.Where(x => x.Abilitato == true)
                            .WhereIf(!String.IsNullOrEmpty(tipologiaAccessorio.Filter.TipologiaAccessorio), q => q.TipologiaAccessorio.Contains(tipologiaAccessorio.Filter.TipologiaAccessorio))            
                            .OrderBy(sortParam)
                            .Skip(tipologiaAccessorio.NumeroElementi * tipologiaAccessorio.Page).Take(tipologiaAccessorio.NumeroElementi)
                            .ToListAsync();

            }
            else
            {
                tipologiaAccessori = await _RCDDbContext.TipologiaAccessorio.Where(x => x.Abilitato == true)
                              .WhereIf(!String.IsNullOrEmpty(tipologiaAccessorio.Filter.TipologiaAccessorio), q => q.TipologiaAccessorio.Contains(tipologiaAccessorio.Filter.TipologiaAccessorio))
                            .OrderBy(sortParam)
                            .ToListAsync();
            }
           
            List<ContractTipologiaAccessorio> tipologiaAccessorioElenco = new List<ContractTipologiaAccessorio>();
            foreach (EntityTipologiaAccessorio varTipologiaAccessorio in tipologiaAccessori)
            {
                ContractTipologiaAccessorio tipologiaAccessorio1 = new ContractTipologiaAccessorio();
                UtilityManager.MapProp(varTipologiaAccessorio, tipologiaAccessorio1);
                tipologiaAccessorioElenco.Add(tipologiaAccessorio1);
            }
            return tipologiaAccessorioElenco;
        }

        public async Task<Int32> GetTipologiaAccessorioTot(TipologiaAccessarioRequestFull tipologiaAccessorio)
        {
            List<EntityTipologiaAccessorio> tipologiaAccessori;


            tipologiaAccessori = await _RCDDbContext.TipologiaAccessorio.Where(x => x.Abilitato == true)
                               .WhereIf(!String.IsNullOrEmpty(tipologiaAccessorio.Filter.TipologiaAccessorio), q => q.TipologiaAccessorio.Contains(tipologiaAccessorio.Filter.TipologiaAccessorio))
                             .ToListAsync();
            return tipologiaAccessori.Count();

        }

        public void AddTipologiaAccessorio(TipologiaAccessorioRequest tipologiaAccessorio)
        {
            try
            {
                EntityTipologiaAccessorio tipologiaAccessorioToAdd = new EntityTipologiaAccessorio();
                UtilityManager.MapProp(tipologiaAccessorio, tipologiaAccessorioToAdd);
                tipologiaAccessorioToAdd.Abilitato = true;
                var result = _RCDDbContext.Add(tipologiaAccessorioToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateTipologiaAccessorio(TipologiaAccessorioRequest tipologiaAccessorio)
        {
            try
            {
                EntityTipologiaAccessorio tipologiaAccessorioToUpdate = new EntityTipologiaAccessorio();
                UtilityManager.MapProp(tipologiaAccessorio, tipologiaAccessorioToUpdate);
                tipologiaAccessorioToUpdate.Abilitato = true;
                var result = _RCDDbContext.Update(tipologiaAccessorioToUpdate);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void DeleteTipologiaAccessorio(TipologiaAccessorioRequest tipologiaAccessorio)
        {
            try
            {
                EntityTipologiaAccessorio tipologiaAccessorioToDelete = new EntityTipologiaAccessorio();
                // UtilityManager.MapProp(tipologiaApparato, tipologiaApparatoToDelete);
                tipologiaAccessorioToDelete = _RCDDbContext.TipologiaAccessorio.Where(x => x.Id == tipologiaAccessorio.Id).First();
                tipologiaAccessorioToDelete.Abilitato = false;
                var result = _RCDDbContext.Update(tipologiaAccessorioToDelete);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }




    }
}
