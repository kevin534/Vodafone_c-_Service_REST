﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class TipologiaAutorizzazioneManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public TipologiaAutorizzazioneManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
        public async Task<List<ContractTipologiaAutorizzazione>> GetTipologiaAutorizzazione(TipologiaAutorizzazioneRequestFull tipologiaAutorizzazione)
        {
            List<EntityTipologiaAutorizzazione> tipologiaAutorizzazioni;
            String sortParam = String.Concat(String.Concat(tipologiaAutorizzazione.CampoOrdinamento, " "), tipologiaAutorizzazione.Ordinamento.ToUpper());

            if (tipologiaAutorizzazione.Pageable)
            {
                tipologiaAutorizzazioni = await _RCDDbContext.TipologiaAutorizzazione
                            .WhereIf(!String.IsNullOrEmpty(tipologiaAutorizzazione.Filter.TipologiaAutorizzazione), q => q.TipologiaAutorizzazione.Contains(tipologiaAutorizzazione.Filter.TipologiaAutorizzazione))
                            .OrderBy(sortParam)
                            .Skip(tipologiaAutorizzazione.NumeroElementi * tipologiaAutorizzazione.Page).Take(tipologiaAutorizzazione.NumeroElementi)
                            .ToListAsync();

            }
            else
            {
                tipologiaAutorizzazioni = await _RCDDbContext.TipologiaAutorizzazione
                            .WhereIf(!String.IsNullOrEmpty(tipologiaAutorizzazione.Filter.TipologiaAutorizzazione), q => q.TipologiaAutorizzazione.Contains(tipologiaAutorizzazione.Filter.TipologiaAutorizzazione))
                            .OrderBy(sortParam)
                            .ToListAsync();
            }


            List<ContractTipologiaAutorizzazione> tipologiaAutorizzazioneElenco = new List<ContractTipologiaAutorizzazione>();
            foreach (EntityTipologiaAutorizzazione varTipologia in tipologiaAutorizzazioni)
            {
                ContractTipologiaAutorizzazione tipologia1 = new ContractTipologiaAutorizzazione();
                UtilityManager.MapProp(varTipologia, tipologia1);
                tipologiaAutorizzazioneElenco.Add(tipologia1);
            }
            return tipologiaAutorizzazioneElenco;
        }
        public async Task<Int32> GetTipologiaAutorizzazioneTot(TipologiaAutorizzazioneRequestFull tipologiaAutorizzazione)
        {
            List<EntityTipologiaAutorizzazione> tipologiaAutorizzazioni;

            tipologiaAutorizzazioni = await _RCDDbContext.TipologiaAutorizzazione
                           .WhereIf(!String.IsNullOrEmpty(tipologiaAutorizzazione.Filter.TipologiaAutorizzazione), q => q.TipologiaAutorizzazione.Contains(tipologiaAutorizzazione.Filter.TipologiaAutorizzazione))
                           .ToListAsync();

            return tipologiaAutorizzazioni.Count();
        }
    }
}

