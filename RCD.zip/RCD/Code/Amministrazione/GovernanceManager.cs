﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class GovernanceManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public GovernanceManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractGovernance>> GetGovernance(GovernanceRequestFull governance)
        {

            List<EntityGovernance> governances;
 

            String sortParam = String.Concat(String.Concat(governance.CampoOrdinamento, " "), governance.Ordinamento.ToUpper());

            if (governance.Pageable)
            {
                governances = await _RCDDbContext.Governances
                            .WhereIf(!String.IsNullOrEmpty(governance.Filter.NumeroSimVoce.ToString()), q => q.NumeroSimVoce.Equals(governance.Filter.NumeroSimVoce))
                            .WhereIf(!String.IsNullOrEmpty(governance.Filter.NumeroInterniVruc.ToString()), q => q.NumeroInterniVruc.Equals(governance.Filter.NumeroInterniVruc))
                            .WhereIf(!String.IsNullOrEmpty(governance.Filter.FatturatoBimestrale.ToString()), q => q.FatturatoBimestrale.Equals(governance.Filter.FatturatoBimestrale))
                            .WhereIf(!String.IsNullOrEmpty(governance.Filter.CostoSopralluogo.ToString()), q => q.CostoSopralluogo.Equals(governance.Filter.CostoSopralluogo))
                            .WhereIf(governance.Filter.CanaleVenditaDettaglio!= null && !String.IsNullOrEmpty(governance.Filter.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.CanaleVenditaDettaglio.Descrizione.Equals(governance.Filter.CanaleVenditaDettaglio.Descrizione))
                            .WhereIf(governance.Filter.TipologiaAutorizzazione != null && !String.IsNullOrEmpty(governance.Filter.TipologiaAutorizzazione.TipologiaAutorizzazione.ToString()), q => q.TipologiaAutorizzazione.TipologiaAutorizzazione.Equals(governance.Filter.TipologiaAutorizzazione.TipologiaAutorizzazione))
                            .OrderBy(sortParam)
                            .Skip(governance.NumeroElementi * governance.Page).Take(governance.NumeroElementi)
                            .Include("TipologiaAutorizzazione")
                            .Include("CanaleVenditaDettaglio")
                             .Include("CanaleVenditaDettaglio.CanaleVendita")
                            //.Include("CanaleVenditaDettaglio.descrizione")
                            .ToListAsync();

            }
            else
            {
                governances = await _RCDDbContext.Governances
                           .WhereIf(!String.IsNullOrEmpty(governance.Filter.NumeroSimVoce.ToString()), q => q.NumeroSimVoce.Equals(governance.Filter.NumeroSimVoce))
                           .WhereIf(!String.IsNullOrEmpty(governance.Filter.NumeroInterniVruc.ToString()), q => q.NumeroInterniVruc.Equals(governance.Filter.NumeroInterniVruc))
                           .WhereIf(!String.IsNullOrEmpty(governance.Filter.FatturatoBimestrale.ToString()), q => q.FatturatoBimestrale.Equals(governance.Filter.FatturatoBimestrale))
                           .WhereIf(!String.IsNullOrEmpty(governance.Filter.CostoSopralluogo.ToString()), q => q.CostoSopralluogo.Equals(governance.Filter.CostoSopralluogo))
                             .WhereIf(governance.Filter.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(governance.Filter.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.CanaleVenditaDettaglio.Descrizione.Equals(governance.Filter.CanaleVenditaDettaglio.Descrizione))
                           // .WhereIf(!String.IsNullOrEmpty(governance.Filter.CanaleVenditaDettaglio.CanaleVendita.Canale.ToString()), q => q.CanaleVenditaDettaglio.CanaleVendita.Canale.Equals(governance.Filter.CanaleVenditaDettaglio.CanaleVendita.Canale))
                             .OrderBy(sortParam)
                           .Include("TipologiaAutorizzazione")
                           .Include("CanaleVenditaDettaglio")
                           .Include("CanaleVenditaDettaglio.CanaleVendita")
                           //.Include("CanaleVenditaDettaglio.descrizione")
                           .ToListAsync();
            }

            List<ContractGovernance> governanceElenco = new List<ContractGovernance>();

            foreach (EntityGovernance varGovernance in governances)
            {
                ContractGovernance governance1 = new ContractGovernance();
                UtilityManager.MapProp(varGovernance, governance1);
                governanceElenco.Add(governance1);
            }
            return governanceElenco;
        }
        public async Task<Int32> GetGovernanceTot(GovernanceRequestFull governance)
        {
            List<EntityGovernance> governances;


            governances = await _RCDDbContext.Governances
                          .WhereIf(!String.IsNullOrEmpty(governance.Filter.NumeroSimVoce.ToString()), q => q.NumeroSimVoce.Equals(governance.Filter.NumeroSimVoce))
                          .WhereIf(!String.IsNullOrEmpty(governance.Filter.NumeroInterniVruc.ToString()), q => q.NumeroInterniVruc.Equals(governance.Filter.NumeroInterniVruc))
                          .WhereIf(!String.IsNullOrEmpty(governance.Filter.FatturatoBimestrale.ToString()), q => q.FatturatoBimestrale.Equals(governance.Filter.FatturatoBimestrale))
                          .WhereIf(!String.IsNullOrEmpty(governance.Filter.CostoSopralluogo.ToString()), q => q.CostoSopralluogo.Equals(governance.Filter.CostoSopralluogo))
                            .WhereIf(governance.Filter.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(governance.Filter.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.CanaleVenditaDettaglio.Descrizione.Equals(governance.Filter.CanaleVenditaDettaglio.Descrizione))
                           .ToListAsync();
            return governances.Count();

        }


        public void AddGovernance(GovernanceRequest governance)
        {
            try
            {
                EntityGovernance governanceToAdd = new EntityGovernance();
                UtilityManager.MapProp(governance, governanceToAdd);
                var result = _RCDDbContext.Add(governanceToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateGovernance(GovernanceRequest governance)
        {
            try
            {
                EntityGovernance governanceToAdd = new EntityGovernance();
                UtilityManager.MapProp(governance, governanceToAdd);
                var result = _RCDDbContext.Update(governanceToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteGovernance(GovernanceRequest governance)
        {
            try
            {
                EntityGovernance governanceToAdd = new EntityGovernance();
                UtilityManager.MapProp(governance, governanceToAdd);
                var result = _RCDDbContext.Remove(governanceToAdd);
                    _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }


    }
}
