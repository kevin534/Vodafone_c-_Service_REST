﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class CanaleVenditaDettaglioManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public CanaleVenditaDettaglioManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
        public async Task<List<ContractCanaleVenditaDettaglio>> GetCanaleVenditaDettaglio(CanaleVenditaDettaglioRequestFull canaleVenditaDettaglio)
        {
            List<EntityCanaleVenditaDettaglio> canaleVenditaDettagli;
            String sortParam = String.Concat(String.Concat(canaleVenditaDettaglio.CampoOrdinamento, " "), canaleVenditaDettaglio.Ordinamento.ToUpper());

            if (canaleVenditaDettaglio.Pageable)
            {
                canaleVenditaDettagli = await _RCDDbContext.CanaleVenditaDettaglio
                            //.Where(x => x.Abilitato == true && x.HasDistrettoVendite == true)
                            //.WhereIf(!String.IsNullOrEmpty(canaleVenditaDettaglio.Filter.Descrizione), q => q.Descrizione.Contains(canaleVenditaDettaglio.Filter.Descrizione))
                            .OrderBy(sortParam)
                            .Skip(canaleVenditaDettaglio.NumeroElementi * canaleVenditaDettaglio.Page).Take(canaleVenditaDettaglio.NumeroElementi)
                            .Include("CanaleVendita")
                            .ToListAsync();

            }
            else
            {
                canaleVenditaDettagli = await _RCDDbContext.CanaleVenditaDettaglio
                            //.Where(x => x.Abilitato == true && x.HasDistrettoVendite == true)
                            //.WhereIf(!String.IsNullOrEmpty(canaleVenditaDettaglio.Filter.Descrizione), q => q.Descrizione.Contains(canaleVenditaDettaglio.Filter.Descrizione))
                            .OrderBy(sortParam)
                            .Include("CanaleVendita")
                            .ToListAsync();
            }


            List<ContractCanaleVenditaDettaglio> canaleVenditaDettaglioElenco = new List<ContractCanaleVenditaDettaglio>();
            foreach (EntityCanaleVenditaDettaglio varCanale in canaleVenditaDettagli)
            {
                ContractCanaleVenditaDettaglio canale1 = new ContractCanaleVenditaDettaglio();
                UtilityManager.MapProp(varCanale, canale1);
                canaleVenditaDettaglioElenco.Add(canale1);
            }
            return canaleVenditaDettaglioElenco;
        }
        public async Task<Int32> GetCanaleVenditaDettaglioTot(CanaleVenditaDettaglioRequestFull canaleVenditaDettaglio)
        {
            List<EntityCanaleVenditaDettaglio> canaleVenditaDettagli;

            canaleVenditaDettagli = await _RCDDbContext.CanaleVenditaDettaglio
                            // .Where(x => x.Abilitato == true && x.HasDistrettoVendite == true)
                             //.WhereIf(!String.IsNullOrEmpty(canaleVenditaDettaglio.Filter.Descrizione), q => q.Descrizione.Contains(canaleVenditaDettaglio.Filter.Descrizione))
                             .ToListAsync();

            return canaleVenditaDettagli.Count();
        }
    }
}
