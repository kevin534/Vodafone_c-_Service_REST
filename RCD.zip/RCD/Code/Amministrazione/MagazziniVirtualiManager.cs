﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class MagazziniVirtualiManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public MagazziniVirtualiManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractMagazzino>> GetMagazziniVirtuali(MagazzinoVirtualeRequestFull magazzinoVirtuale)
        {            
            List<EntityMagazzino> magazziniVirtuali;
            String sortParam = String.Concat(String.Concat(magazzinoVirtuale.CampoOrdinamento, " "), magazzinoVirtuale.Ordinamento.ToUpper());

            
                if (magazzinoVirtuale.Pageable) 
                {
                    magazziniVirtuali = await _RCDDbContext.Magazzino.Where(x => x.Magazzino.Contains(magazzinoVirtuale.Filter.Magazzino)
                                ).OrderBy(sortParam)
                                .Skip(magazzinoVirtuale.NumeroElementi * magazzinoVirtuale.Page).Take(magazzinoVirtuale.NumeroElementi)
                                .Include("Zona")
                                .ToListAsync();
                }
                else
                {
                    magazziniVirtuali = await _RCDDbContext.Magazzino.Where(x => x.Magazzino.Contains(magazzinoVirtuale.Filter.Magazzino))
                                .OrderBy(sortParam)
                                .Include("Zona")
                                .ToListAsync();
                }
           

            List<ContractMagazzino> magazziniVirtualiElenco = new List<ContractMagazzino>();

            foreach (EntityMagazzino varMagazzinoVirtuale in magazziniVirtuali)
            {
                ContractMagazzino magazzinoVirtuale1 = new ContractMagazzino();
                UtilityManager.MapProp(varMagazzinoVirtuale, magazzinoVirtuale1);
                magazziniVirtualiElenco.Add(magazzinoVirtuale1);
            }

            return magazziniVirtualiElenco;
        }
        public async Task<Int32> GetMagazziniVirtualiTot(MagazzinoVirtualeRequestFull magazzinoVirtuale)
        {
            List<EntityMagazzino> magazziniVirtuali;
         
            magazziniVirtuali = await _RCDDbContext.Magazzino.Where(x => x.Magazzino.Contains(magazzinoVirtuale.Filter.Magazzino))
                          
                        .Include("Zona")
                        .ToListAsync();
            return magazziniVirtuali.Count();
        }

        public void AddMagazzinoVirtuale(MagazzinoVirtualeRequest magazzinoVirtuale)
        {
            try
            {
                EntityMagazzino magazzinoVirtualeToAdd = new EntityMagazzino();
                UtilityManager.MapProp(magazzinoVirtuale, magazzinoVirtualeToAdd);
                var result = _RCDDbContext.Add(magazzinoVirtualeToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void UpdateMagazzinoVirtuale(MagazzinoVirtualeRequest magazzinoVirtuale)
        {
            try
            {
                EntityMagazzino magazzinoVirtualeToAdd = new EntityMagazzino();
                UtilityManager.MapProp(magazzinoVirtuale, magazzinoVirtualeToAdd);
                var result = _RCDDbContext.Update(magazzinoVirtualeToAdd);

                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void DeleteMagazzinoVirtuale(MagazzinoVirtualeRequest magazzinoVirtuale)
        {
            try
            {
                EntityMagazzino magazzinoVirtualeToDelete = new EntityMagazzino();
                UtilityManager.MapProp(magazzinoVirtuale, magazzinoVirtualeToDelete);
                var result = _RCDDbContext.Remove(magazzinoVirtualeToDelete);

                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}