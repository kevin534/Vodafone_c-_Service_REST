﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;


namespace RCD.Code.Amministrazione
{
    public class ListinoManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public ListinoManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
        public async Task<List<ContractListino>> GetListino(ListinoRequestFull listino)
        {
            List<EntityListino> listini;
            String sortParam = String.Concat(String.Concat(listino.CampoOrdinamento, " "), listino.Ordinamento.ToUpper());

            EntityDitta idDitta = _RCDDbContext.Ditta.Where(x => x.Id == listino.IdDitta).FirstOrDefault();
            if(idDitta != null)
            {
                listino.Filter.IdVendor = idDitta.IdVendor;
            }

            if (listino.Pageable)
            {
                listini = await _RCDDbContext.Listino.Where(x => x.Attivo == true && x.FyAttuale == true)
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceMateriale), q => q.CodiceMateriale.Contains(listino.Filter.CodiceMateriale))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceInforecord), q => q.CodiceInforecord.Contains(listino.Filter.CodiceInforecord))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.DescrizioneInforecord), q => q.DescrizioneInforecord.Contains(listino.Filter.DescrizioneInforecord))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PrezzoUnitario.ToString()), q => q.PrezzoUnitario.Equals(listino.Filter.PrezzoUnitario))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.MaterialGroup), q => q.MaterialGroup.Contains(listino.Filter.MaterialGroup))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceFornitore), q => q.CodiceFornitore.Contains(listino.Filter.CodiceFornitore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.MaterialGroupFornitore), q => q.MaterialGroupFornitore.Contains(listino.Filter.MaterialGroupFornitore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceProduttore), q => q.CodiceProduttore.Contains(listino.Filter.CodiceProduttore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceMaterialeFornitore), q => q.CodiceMaterialeFornitore.Contains(listino.Filter.CodiceMaterialeFornitore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PurchaseOrg), q => q.PurchaseOrg.Contains(listino.Filter.PurchaseOrg))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.InforecordCategory), q => q.InforecordCategory.Contains(listino.Filter.InforecordCategory))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.Divisione), q => q.Divisione.Contains(listino.Filter.Divisione))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PurchaseGroup), q => q.PurchaseGroup.Contains(listino.Filter.PurchaseGroup))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaMisPo), q => q.UnitaMisPo.Contains(listino.Filter.UnitaMisPo))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaMisMag), q => q.UnitaMisMag.Contains(listino.Filter.UnitaMisMag))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaPrezzo.ToString()), q => q.UnitaPrezzo.Equals(listino.Filter.UnitaPrezzo))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.QuantitaMinima.ToString()), q => q.QuantitaMinima.Equals(listino.Filter.QuantitaMinima))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.QuantitaStandard.ToString()), q => q.QuantitaStandard.Equals(listino.Filter.QuantitaStandard))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PrezzoStandard.ToString()), q => q.PrezzoStandard.Equals(listino.Filter.PrezzoStandard))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.DataCreazioneInforecord.ToString()), q => q.DataCreazioneInforecord.Equals(listino.Filter.DataCreazioneInforecord))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.DataFineValidita.ToString()), q => q.DataFineValidita.Equals(listino.Filter.DataFineValidita))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.IsCancellato), q => q.IsCancellato.Contains(listino.Filter.IsCancellato))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.Valuta), q => q.Valuta.Contains(listino.Filter.Valuta))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.FiscalYear), q => q.FiscalYear.Contains(listino.Filter.FiscalYear))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.IdVendor.ToString()), q => q.IdVendor == idDitta.IdVendor)
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.IdZona.ToString()), q => q.IdZona == idDitta.IdZona)
                            .OrderBy(sortParam)
                            .Skip(listino.NumeroElementi * listino.Page).Take(listino.NumeroElementi)
                            .Include("Zona")
                            .ToListAsync();


                if (listini.Count() == 0)
                {
                    listini = await _RCDDbContext.Listino.Where(x => x.Attivo == true && x.FyAttuale == true)
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceMateriale), q => q.CodiceMateriale.Contains(listino.Filter.CodiceMateriale))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceInforecord), q => q.CodiceInforecord.Contains(listino.Filter.CodiceInforecord))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.DescrizioneInforecord), q => q.DescrizioneInforecord.Contains(listino.Filter.DescrizioneInforecord))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.PrezzoUnitario.ToString()), q => q.PrezzoUnitario.Equals(listino.Filter.PrezzoUnitario))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.MaterialGroup), q => q.MaterialGroup.Contains(listino.Filter.MaterialGroup))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceFornitore), q => q.CodiceFornitore.Contains(listino.Filter.CodiceFornitore))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.MaterialGroupFornitore), q => q.MaterialGroupFornitore.Contains(listino.Filter.MaterialGroupFornitore))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceProduttore), q => q.CodiceProduttore.Contains(listino.Filter.CodiceProduttore))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceMaterialeFornitore), q => q.CodiceMaterialeFornitore.Contains(listino.Filter.CodiceMaterialeFornitore))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.PurchaseOrg), q => q.PurchaseOrg.Contains(listino.Filter.PurchaseOrg))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.InforecordCategory), q => q.InforecordCategory.Contains(listino.Filter.InforecordCategory))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.Divisione), q => q.Divisione.Contains(listino.Filter.Divisione))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.PurchaseGroup), q => q.PurchaseGroup.Contains(listino.Filter.PurchaseGroup))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaMisPo), q => q.UnitaMisPo.Contains(listino.Filter.UnitaMisPo))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaMisMag), q => q.UnitaMisMag.Contains(listino.Filter.UnitaMisMag))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaPrezzo.ToString()), q => q.UnitaPrezzo.Equals(listino.Filter.UnitaPrezzo))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.QuantitaMinima.ToString()), q => q.QuantitaMinima.Equals(listino.Filter.QuantitaMinima))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.QuantitaStandard.ToString()), q => q.QuantitaStandard.Equals(listino.Filter.QuantitaStandard))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.PrezzoStandard.ToString()), q => q.PrezzoStandard.Equals(listino.Filter.PrezzoStandard))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.DataCreazioneInforecord.ToString()), q => q.DataCreazioneInforecord.Equals(listino.Filter.DataCreazioneInforecord))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.DataFineValidita.ToString()), q => q.DataFineValidita.Equals(listino.Filter.DataFineValidita))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.IsCancellato), q => q.IsCancellato.Contains(listino.Filter.IsCancellato))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.Valuta), q => q.Valuta.Contains(listino.Filter.Valuta))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.FiscalYear), q => q.FiscalYear.Contains(listino.Filter.FiscalYear))
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.IdVendor.ToString()), q => q.IdVendor == idDitta.IdVendor)
                             .WhereIf(!String.IsNullOrEmpty(listino.Filter.IdZona.ToString()), q => q.IdZona == idDitta.IdZona)
                             .OrderBy(sortParam)
                             .Skip(listino.NumeroElementi * listino.Page).Take(listino.NumeroElementi)
                             .ToListAsync();
                }

            }
            else
            {
                listini = await _RCDDbContext.Listino.Where(x => x.Attivo == true && x.FyAttuale == true)
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceMateriale), q => q.CodiceMateriale.Contains(listino.Filter.CodiceMateriale))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceInforecord), q => q.CodiceInforecord.Contains(listino.Filter.CodiceInforecord))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.DescrizioneInforecord), q => q.DescrizioneInforecord.Contains(listino.Filter.DescrizioneInforecord))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PrezzoUnitario.ToString()), q => q.PrezzoUnitario.Equals(listino.Filter.PrezzoUnitario))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.MaterialGroup), q => q.MaterialGroup.Contains(listino.Filter.MaterialGroup))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceFornitore), q => q.CodiceFornitore.Contains(listino.Filter.CodiceFornitore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.MaterialGroupFornitore), q => q.MaterialGroupFornitore.Contains(listino.Filter.MaterialGroupFornitore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceProduttore), q => q.CodiceProduttore.Contains(listino.Filter.CodiceProduttore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceMaterialeFornitore), q => q.CodiceMaterialeFornitore.Contains(listino.Filter.CodiceMaterialeFornitore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PurchaseOrg), q => q.PurchaseOrg.Contains(listino.Filter.PurchaseOrg))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.InforecordCategory), q => q.InforecordCategory.Contains(listino.Filter.InforecordCategory))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.Divisione), q => q.Divisione.Contains(listino.Filter.Divisione))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PurchaseGroup), q => q.PurchaseGroup.Contains(listino.Filter.PurchaseGroup))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaMisPo), q => q.UnitaMisPo.Contains(listino.Filter.UnitaMisPo))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaMisMag), q => q.UnitaMisMag.Contains(listino.Filter.UnitaMisMag))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaPrezzo.ToString()), q => q.UnitaPrezzo.Equals(listino.Filter.UnitaPrezzo))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.QuantitaMinima.ToString()), q => q.QuantitaMinima.Equals(listino.Filter.QuantitaMinima))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.QuantitaStandard.ToString()), q => q.QuantitaStandard.Equals(listino.Filter.QuantitaStandard))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PrezzoStandard.ToString()), q => q.PrezzoStandard.Equals(listino.Filter.PrezzoStandard))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.DataCreazioneInforecord.ToString()), q => q.DataCreazioneInforecord.Equals(listino.Filter.DataCreazioneInforecord))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.DataFineValidita.ToString()), q => q.DataFineValidita.Equals(listino.Filter.DataFineValidita))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.IsCancellato), q => q.IsCancellato.Contains(listino.Filter.IsCancellato))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.Valuta), q => q.Valuta.Contains(listino.Filter.Valuta))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.FiscalYear), q => q.FiscalYear.Contains(listino.Filter.FiscalYear))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.IdVendor.ToString()), q => q.IdVendor == idDitta.IdVendor)
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.IdZona.ToString()), q => q.IdZona == idDitta.IdZona)
                            .OrderBy(sortParam)
                            .Include("Zona")
                            .ToListAsync();
                if (listini.Count() == 0)
                {
                    listini = await _RCDDbContext.Listino.Where(x => x.Attivo == true && x.FyAttuale == true)
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceMateriale), q => q.CodiceMateriale.Contains(listino.Filter.CodiceMateriale))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceInforecord), q => q.CodiceInforecord.Contains(listino.Filter.CodiceInforecord))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.DescrizioneInforecord), q => q.DescrizioneInforecord.Contains(listino.Filter.DescrizioneInforecord))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PrezzoUnitario.ToString()), q => q.PrezzoUnitario.Equals(listino.Filter.PrezzoUnitario))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.MaterialGroup), q => q.MaterialGroup.Contains(listino.Filter.MaterialGroup))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceFornitore), q => q.CodiceFornitore.Contains(listino.Filter.CodiceFornitore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.MaterialGroupFornitore), q => q.MaterialGroupFornitore.Contains(listino.Filter.MaterialGroupFornitore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceProduttore), q => q.CodiceProduttore.Contains(listino.Filter.CodiceProduttore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceMaterialeFornitore), q => q.CodiceMaterialeFornitore.Contains(listino.Filter.CodiceMaterialeFornitore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PurchaseOrg), q => q.PurchaseOrg.Contains(listino.Filter.PurchaseOrg))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.InforecordCategory), q => q.InforecordCategory.Contains(listino.Filter.InforecordCategory))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.Divisione), q => q.Divisione.Contains(listino.Filter.Divisione))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PurchaseGroup), q => q.PurchaseGroup.Contains(listino.Filter.PurchaseGroup))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaMisPo), q => q.UnitaMisPo.Contains(listino.Filter.UnitaMisPo))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaMisMag), q => q.UnitaMisMag.Contains(listino.Filter.UnitaMisMag))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaPrezzo.ToString()), q => q.UnitaPrezzo.Equals(listino.Filter.UnitaPrezzo))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.QuantitaMinima.ToString()), q => q.QuantitaMinima.Equals(listino.Filter.QuantitaMinima))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.QuantitaStandard.ToString()), q => q.QuantitaStandard.Equals(listino.Filter.QuantitaStandard))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PrezzoStandard.ToString()), q => q.PrezzoStandard.Equals(listino.Filter.PrezzoStandard))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.DataCreazioneInforecord.ToString()), q => q.DataCreazioneInforecord.Equals(listino.Filter.DataCreazioneInforecord))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.DataFineValidita.ToString()), q => q.DataFineValidita.Equals(listino.Filter.DataFineValidita))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.IsCancellato), q => q.IsCancellato.Contains(listino.Filter.IsCancellato))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.Valuta), q => q.Valuta.Contains(listino.Filter.Valuta))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.FiscalYear), q => q.FiscalYear.Contains(listino.Filter.FiscalYear))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.IdVendor.ToString()), q => q.IdVendor == idDitta.IdVendor)
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.IdZona.ToString()), q => q.IdZona == idDitta.IdZona)
                            .OrderBy(sortParam)
                            .ToListAsync();
                }
            }

            List<ContractListino> listiniElenco = new List<ContractListino>();
            foreach (EntityListino varListino in listini)
            {
                ContractListino listino1 = new ContractListino();
                UtilityManager.MapProp(varListino, listino1);
                listiniElenco.Add(listino1);
            }
            return listiniElenco;
        }

        public async Task<Int32> GetListinoTot(ListinoRequestFull listino)
        {
            List<EntityListino> listini;
            EntityDitta idDitta = _RCDDbContext.Ditta.Where(x => x.Id == listino.IdDitta).FirstOrDefault();

            listini = await _RCDDbContext.Listino.Where(x => x.Attivo == true && x.FyAttuale == true)
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceMateriale), q => q.CodiceMateriale.Contains(listino.Filter.CodiceMateriale))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceInforecord), q => q.CodiceInforecord.Contains(listino.Filter.CodiceInforecord))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.DescrizioneInforecord), q => q.DescrizioneInforecord.Contains(listino.Filter.DescrizioneInforecord))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PrezzoUnitario.ToString()), q => q.PrezzoUnitario.Equals(listino.Filter.PrezzoUnitario))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.MaterialGroup), q => q.MaterialGroup.Contains(listino.Filter.MaterialGroup))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceFornitore), q => q.CodiceFornitore.Contains(listino.Filter.CodiceFornitore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.MaterialGroupFornitore), q => q.MaterialGroupFornitore.Contains(listino.Filter.MaterialGroupFornitore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceProduttore), q => q.CodiceProduttore.Contains(listino.Filter.CodiceProduttore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.CodiceMaterialeFornitore), q => q.CodiceMaterialeFornitore.Contains(listino.Filter.CodiceMaterialeFornitore))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PurchaseOrg), q => q.PurchaseOrg.Contains(listino.Filter.PurchaseOrg))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.InforecordCategory), q => q.InforecordCategory.Contains(listino.Filter.InforecordCategory))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.Divisione), q => q.Divisione.Contains(listino.Filter.Divisione))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PurchaseGroup), q => q.PurchaseGroup.Contains(listino.Filter.PurchaseGroup))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaMisPo), q => q.UnitaMisPo.Contains(listino.Filter.UnitaMisPo))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaMisMag), q => q.UnitaMisMag.Contains(listino.Filter.UnitaMisMag))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.UnitaPrezzo.ToString()), q => q.UnitaPrezzo.Equals(listino.Filter.UnitaPrezzo))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.QuantitaMinima.ToString()), q => q.QuantitaMinima.Equals(listino.Filter.QuantitaMinima))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.QuantitaStandard.ToString()), q => q.QuantitaStandard.Equals(listino.Filter.QuantitaStandard))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.PrezzoStandard.ToString()), q => q.PrezzoStandard.Equals(listino.Filter.PrezzoStandard))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.DataCreazioneInforecord.ToString()), q => q.DataCreazioneInforecord.Equals(listino.Filter.DataCreazioneInforecord))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.DataFineValidita.ToString()), q => q.DataFineValidita.Equals(listino.Filter.DataFineValidita))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.IsCancellato), q => q.IsCancellato.Contains(listino.Filter.IsCancellato))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.Valuta), q => q.Valuta.Contains(listino.Filter.Valuta))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.FiscalYear), q => q.FiscalYear.Contains(listino.Filter.FiscalYear))
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.IdVendor.ToString()), q => q.IdVendor == idDitta.IdVendor)
                            .WhereIf(!String.IsNullOrEmpty(listino.Filter.IdZona.ToString()), q => q.IdZona == idDitta.IdZona)
                            .ToListAsync();
            return listini.Count();

        }


    }

}
