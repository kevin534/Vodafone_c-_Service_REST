﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class TipologiaApparatoManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public TipologiaApparatoManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        } 
        public async Task<List<ContractTipologiaApparato>> GetTipologiaApparato(TipologiaApparatoRequestFull tipologiaApparato)
        {
            List<EntityTipologiaApparato> tipologiaApparati;
            String sortParam = String.Concat(String.Concat(tipologiaApparato.CampoOrdinamento, " "), tipologiaApparato.Ordinamento.ToUpper());

            if (tipologiaApparato.Pageable)
            {
                tipologiaApparati = await _RCDDbContext.TipologiaApparato.Where(x => x.Abilitato == true)
                            .WhereIf(!String.IsNullOrEmpty(tipologiaApparato.Filter.Sigla), q => q.Sigla.Contains(tipologiaApparato.Filter.Sigla))
                            .WhereIf(!String.IsNullOrEmpty(tipologiaApparato.Filter.TipologiaApparato), q => q.TipologiaApparato.Contains(tipologiaApparato.Filter.TipologiaApparato))
                            .OrderBy(sortParam)
                            .Skip(tipologiaApparato.NumeroElementi * tipologiaApparato.Page).Take(tipologiaApparato.NumeroElementi)
                            .ToListAsync();

            }
            else
            {
                tipologiaApparati = await _RCDDbContext.TipologiaApparato.Where(x => x.Abilitato == true)
                            .WhereIf(!String.IsNullOrEmpty(tipologiaApparato.Filter.Sigla), q => q.Sigla.Contains(tipologiaApparato.Filter.Sigla))
                            .WhereIf(!String.IsNullOrEmpty(tipologiaApparato.Filter.TipologiaApparato), q => q.TipologiaApparato.Contains(tipologiaApparato.Filter.TipologiaApparato))
                            .OrderBy(sortParam)
                            .ToListAsync();
            }
           
            List<ContractTipologiaApparato> tipologiaApparatiElenco = new List<ContractTipologiaApparato>();
            foreach (EntityTipologiaApparato varTipologiaApparato in tipologiaApparati)
            {
                ContractTipologiaApparato tipologiaApparato1 = new ContractTipologiaApparato();
                UtilityManager.MapProp(varTipologiaApparato, tipologiaApparato1);
                tipologiaApparatiElenco.Add(tipologiaApparato1);
            }
            return tipologiaApparatiElenco;
        }
        public async Task<Int32> GetTipologiaApparatoTot(TipologiaApparatoRequestFull tipologiaApparato)
        {
            List<EntityTipologiaApparato> tipologiaApparati;


            tipologiaApparati = await _RCDDbContext.TipologiaApparato.Where(x => x.Abilitato == true)
                             .WhereIf(!String.IsNullOrEmpty(tipologiaApparato.Filter.Sigla), q => q.Sigla.Contains(tipologiaApparato.Filter.Sigla))
                             .WhereIf(!String.IsNullOrEmpty(tipologiaApparato.Filter.TipologiaApparato), q => q.TipologiaApparato.Contains(tipologiaApparato.Filter.TipologiaApparato))
                             .ToListAsync();
            return tipologiaApparati.Count();

        }

        public void AddTipologiaApparato(TipologiaApparatoRequest tipologiaApparato)
        {
            try
            {
                EntityTipologiaApparato tipologiaApparatoToAdd = new EntityTipologiaApparato();
                UtilityManager.MapProp(tipologiaApparato, tipologiaApparatoToAdd);
                var result = _RCDDbContext.Add(tipologiaApparatoToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateTipologiaApparato(TipologiaApparatoRequest tipologiaApparato)
        {
            try
            {
                EntityTipologiaApparato tipologiaApparatoToUpdate = new EntityTipologiaApparato();
                UtilityManager.MapProp(tipologiaApparato, tipologiaApparatoToUpdate);
                var result = _RCDDbContext.Update(tipologiaApparatoToUpdate);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void DeleteTipologiaApparato(TipologiaApparatoRequest tipologiaApparato)
        {
            try
            {
                EntityTipologiaApparato tipologiaApparatoToDelete = new EntityTipologiaApparato();
                // UtilityManager.MapProp(tipologiaApparato, tipologiaApparatoToDelete);
                tipologiaApparatoToDelete = _RCDDbContext.TipologiaApparato.Where(x => x.Id == tipologiaApparato.Id).First();
                tipologiaApparatoToDelete.Abilitato = false; 
                var result = _RCDDbContext.Update(tipologiaApparatoToDelete);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }




    }
}
