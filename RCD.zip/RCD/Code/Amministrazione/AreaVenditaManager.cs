﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Request;
using RCDEngine.Entities;
using RCDContracts.Data;
using System;

namespace RCD.Code.Amministrazione
{
    public class AreaVenditaManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public AreaVenditaManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
        public async Task<List<ContractAreaVendite>> GetAreeVendita()
        {
            List<EntityAreaVendite> areeVendita;
            areeVendita = await _RCDDbContext.AreaVendita.Where(x => x.Abilitato == true)
                                 .Include("CanaleVenditaDettaglio")
                                 .Include("CanaleVenditaDettaglio.CanaleVendita")
                                 .OrderBy(x => x.CanaleVenditaDettaglio.CanaleVendita.Canale).ThenBy(x => x.CanaleVenditaDettaglio.Descrizione)
                                 .ToListAsync();
            List<ContractAreaVendite> areaElenco = new List<ContractAreaVendite>();
            foreach (EntityAreaVendite varArea in areeVendita)
            {
                ContractAreaVendite areaVendite = new ContractAreaVendite();
                UtilityManager.MapProp(varArea, areaVendite);
                areaElenco.Add(areaVendite);
            }
            return areaElenco;
        }
        public async Task<List<ContractStsProvincia>> GetProvince()
        {
            List<EntityStsProvincia> stsProvince;
            stsProvince = await _RCDDbContext.StsProvincia.Where(x => x.Abilitato == true)
                                 .Include("RegioneSts")
                                .Include("Provincia")
                        .Include("Provincia.RegioneVF")
                        .Include("Provincia.RegioneVF.Zona")
                        .ToListAsync();
            List<ContractStsProvincia> provinciaElenco = new List<ContractStsProvincia>();
            foreach (EntityStsProvincia varProvincia in stsProvince)
            {
                ContractStsProvincia stsProvincia = new ContractStsProvincia();
                UtilityManager.MapProp(varProvincia, stsProvincia);
                provinciaElenco.Add(stsProvincia);
            }
            return provinciaElenco;
        }
        public async Task<List<ContractStsProvincia>> GetProvinceUtente(UtenteRequest utente)
        {
            List<EntityStsProvincia> stsProvince = await _RCDDbContext.StsProvincia.Where(x => x.Abilitato == true)
                                                    .Include("RegioneSts")
                                                    .Include("Provincia")
                                                    .Include("Provincia.RegioneVF")
                                                    .Include("Provincia.RegioneVF.Zona")
                                                    .ToListAsync();
            List<EntityUtentiProvince> stsProvinceUtente = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                    .ToListAsync();

            List<ContractStsProvincia> provinciaElenco = new List<ContractStsProvincia>();
            foreach (EntityStsProvincia varProvincia in stsProvince)
            {
                ContractStsProvincia stsProvincia = new ContractStsProvincia();
                UtilityManager.MapProp(varProvincia, stsProvincia);
                stsProvincia.IsProvinciaUtente = stsProvinceUtente.Where(x => x.IdProvincia == varProvincia.Id).Count() > 0;
                provinciaElenco.Add(stsProvincia);
            }
            return provinciaElenco;
        }
        public async Task<List<ContractCanaleVendita>> GetCanaleVendita()
        {
            List<EntityCanaleVendita> canale;

            canale = await _RCDDbContext.CanaleVendita.Where(x => x.Abilitato == true)
                                .OrderBy(x => x.Id)
                                .ToListAsync();


            List<ContractCanaleVendita> getElenco = new List<ContractCanaleVendita>();
            foreach (EntityCanaleVendita varCanale in canale)
            {
                ContractCanaleVendita canale1 = new ContractCanaleVendita();
                UtilityManager.MapProp(varCanale, canale1);
                getElenco.Add(canale1);
            }
            return getElenco;
        }
        public async Task<List<ContractCanaleVenditaDettaglio>> GetCanaleVenditaDettaglioByIdCanaleV(CanaleVenditaDettaglioRequestFull canale)
        {
            List<EntityCanaleVenditaDettaglio> canali;

            String sortParam = String.Concat(String.Concat(canale.CampoOrdinamento, " "), canale.Ordinamento.ToUpper());

            if (canale.Pageable)
            {
                canali = await _RCDDbContext.CanaleVenditaDettaglio.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(canale.Filter.IdCanaleVendita.ToString()), q => q.IdCanaleVendita == canale.Filter.IdCanaleVendita)
                         .OrderBy(sortParam)
                        .Skip(canale.NumeroElementi * canale.Page).Take(canale.NumeroElementi)
                        .Include("CanaleVendita")
                        .ToListAsync();

            }
            else
            {
                canali = await _RCDDbContext.CanaleVenditaDettaglio.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(canale.Filter.IdCanaleVendita.ToString()), q => q.IdCanaleVendita == canale.Filter.IdCanaleVendita)
                         .OrderBy(sortParam)
                        .Include("CanaleVendita")
                        .ToListAsync();
            }

            List<ContractCanaleVenditaDettaglio> canaleElenco = new List<ContractCanaleVenditaDettaglio>();
            foreach (EntityCanaleVenditaDettaglio varCanale in canali)
            {
                ContractCanaleVenditaDettaglio canale1 = new ContractCanaleVenditaDettaglio();
                UtilityManager.MapProp(varCanale, canale1);
                canaleElenco.Add(canale1);
            }
            return canaleElenco;
        }
        public async Task<List<ContractDistretto>> GetDistrettoByIdCanaleV(DistrettoRequestFull distretto)
        {
            List<EntityDistretto> distretti;

            String sortParam = String.Concat(String.Concat(distretto.CampoOrdinamento, " "), distretto.Ordinamento.ToUpper());

            if (distretto.Pageable)
            {
                distretti = await _RCDDbContext.Distretto
                        .WhereIf(!String.IsNullOrEmpty(distretto.Filter.IdCanaleVenditeDettaglio.ToString()), q => q.IdCanaleVenditeDettaglio == distretto.Filter.IdCanaleVenditeDettaglio)
                         .OrderBy(sortParam)
                        .Skip(distretto.NumeroElementi * distretto.Page).Take(distretto.NumeroElementi)
                        .Include("CanaleVenditaDettaglio")
                        .ToListAsync();

            }
            else
            {
                distretti = await _RCDDbContext.Distretto
                        .WhereIf(!String.IsNullOrEmpty(distretto.Filter.IdCanaleVenditeDettaglio.ToString()), q => q.IdCanaleVenditeDettaglio == distretto.Filter.IdCanaleVenditeDettaglio)
                         .OrderBy(sortParam)
                        .Include("CanaleVenditaDettaglio")
                        .ToListAsync();
            }

            List<ContractDistretto> distrettiElenco = new List<ContractDistretto>();
            foreach (EntityDistretto varCanale in distretti)
            {
                ContractDistretto distretto1 = new ContractDistretto();
                UtilityManager.MapProp(varCanale, distretto1);
                distrettiElenco.Add(distretto1);
            }
            return distrettiElenco;
        }

        public async Task<List<ContractArea>> GetAreaByIdCanaleV(AreaRequestFull area)
        {
            List<EntityArea> arei;

            String sortParam = String.Concat(String.Concat(area.CampoOrdinamento, " "), area.Ordinamento.ToUpper());

            if (area.Pageable)
            {
                arei = await _RCDDbContext.Area.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(area.Filter.IdCanaleVenditaDettaglio.ToString()), q => q.IdCanaleVenditaDettaglio == area.Filter.IdCanaleVenditaDettaglio)
                         .OrderBy(sortParam)
                        .Skip(area.NumeroElementi * area.Page).Take(area.NumeroElementi)
                        .Include("CanaleVenditaDettaglio")
                        .ToListAsync();

            }
            else
            {
                arei = await _RCDDbContext.Area.Where(x => x.Abilitato == true)
                       .WhereIf(!String.IsNullOrEmpty(area.Filter.IdCanaleVenditaDettaglio.ToString()), q => q.IdCanaleVenditaDettaglio == area.Filter.IdCanaleVenditaDettaglio)
                        .OrderBy(sortParam)
                       .Include("CanaleVenditaDettaglio")
                       .ToListAsync();
            }

            List<ContractArea> areaElenco = new List<ContractArea>();
            foreach (EntityArea varArea in arei)
            {
                ContractArea area1 = new ContractArea();
                UtilityManager.MapProp(varArea, area1);
                areaElenco.Add(area1);
            }
            return areaElenco;
        } 

        public async Task<List<ContractAreaVendite>> GetAreaVenditeByIdCanaleV(AreaVenditaRequestFull area)
        {
            List<EntityAreaVendite> arei;

            String sortParam = String.Concat(String.Concat(area.CampoOrdinamento, " "), area.Ordinamento.ToUpper());

            if (area.Pageable)
            {
                arei = await _RCDDbContext.AreaVendita.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(area.Filter.IdCanaleVenditeDettaglio.ToString()), q => q.IdCanaleVenditeDettaglio == area.Filter.IdCanaleVenditeDettaglio)
                        .OrderBy(sortParam)
                        .Skip(area.NumeroElementi * area.Page).Take(area.NumeroElementi)
                        .Include("CanaleVenditaDettaglio")                      
                        .ToListAsync();

            }
            else
            {
                arei = await _RCDDbContext.AreaVendita.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(area.Filter.IdCanaleVenditeDettaglio.ToString()), q => q.IdCanaleVenditeDettaglio == area.Filter.IdCanaleVenditeDettaglio)
                         .WhereIf(area.Filter.CanaleVenditaDettaglio!= null && area.Filter.CanaleVenditaDettaglio.CanaleVendita != null && !String.IsNullOrEmpty(area.Filter.CanaleVenditaDettaglio.CanaleVendita.Id.ToString()), q => q.IdCanaleVenditeDettaglio == area.Filter.IdCanaleVenditeDettaglio)
                        .OrderBy(sortParam)
                        .Include("CanaleVenditaDettaglio")
                        .ToListAsync();
            }

            List<ContractAreaVendite> areaElenco = new List<ContractAreaVendite>();
            foreach (EntityAreaVendite varArea in arei)
            {
                ContractAreaVendite area1 = new ContractAreaVendite();
                UtilityManager.MapProp(varArea, area1);
                areaElenco.Add(area1);
            }
            return areaElenco;
        }
        public async Task<List<ContractTipologiaCliente>> GetTipologiaCliente()
        {
            List<EntityTipologiaCliente> canale;

            canale = await _RCDDbContext.TipologiaClient
                                .OrderBy(x => x.Id)
                                .ToListAsync();


            List<ContractTipologiaCliente> getElenco = new List<ContractTipologiaCliente>();
            foreach (EntityTipologiaCliente varClient in canale)
            {
                ContractTipologiaCliente Tip1 = new ContractTipologiaCliente();
                UtilityManager.MapProp(varClient, Tip1);
                getElenco.Add(Tip1);
            }
            return getElenco;
        }

        public async Task<List<ContractStsRegione>> GetStsRegione()
        {
            List<EntityStsRegione> regione;

            regione = await _RCDDbContext.StsRegione.Where(x=> x.Abilitato == true)
                                .OrderBy(x => x.Id)
                                .ToListAsync();


            List<ContractStsRegione> getElenco = new List<ContractStsRegione>();
            foreach (EntityStsRegione varRegione in regione)
            {
                ContractStsRegione reg1 = new ContractStsRegione();
                UtilityManager.MapProp(varRegione, reg1);
                getElenco.Add(reg1);
            }
            return getElenco;
        }

        public async Task<List<ContractStsProvincia>> GetStsProvinciaByIdRegioneSts(StsProvinciaRequestFull provincia)
        {
            List<EntityStsProvincia> provincie;

            String sortParam = String.Concat(String.Concat(provincia.CampoOrdinamento, " "), provincia.Ordinamento.ToUpper());

            if (provincia.Pageable)
            {           

                provincie = await _RCDDbContext.StsProvincia.Where(x => x.IdRegioneSts.Equals(provincia.Filter.RegioneSts.Id))         
                         .OrderBy(sortParam)
                        .Skip(provincia.NumeroElementi * provincia.Page).Take(provincia.NumeroElementi)
                        .Include("RegioneSts")
                        .ToListAsync();
            }
            else
            {
                provincie = await _RCDDbContext.StsProvincia.Where(x => x.IdRegioneSts.Equals(provincia.Filter.RegioneSts.Id))
                        .OrderBy(sortParam)
                       .Include("RegioneSts")
                       .ToListAsync();
            }

            List<ContractStsProvincia> provinciaElenco = new List<ContractStsProvincia>();
            foreach (EntityStsProvincia varArea in provincie)
            {
                ContractStsProvincia prov1 = new ContractStsProvincia();
                UtilityManager.MapProp(varArea, prov1);
                provinciaElenco.Add(prov1);
            }
            return provinciaElenco;
        }

        public async Task<List<ContractStsComune>> GetStsCommuneByIdProvinciaSts(StsComuneRequestFull comune)
        {
            List<EntityStsComune> comuni;

            String sortParam = String.Concat(String.Concat(comune.CampoOrdinamento, " "), comune.Ordinamento.ToUpper());

            if (comune.Pageable)

            {
                comuni = await _RCDDbContext.StsComune.Where(x => x.IdProvinciaSts.Equals(comune.Filter.ProvinciaSts.Id))
                         .OrderBy(sortParam)
                        .Skip(comune.NumeroElementi * comune.Page).Take(comune.NumeroElementi)
                        .Include("ProvinciaSts")
                        .ToListAsync();

            }
            else
            {
                comuni = await _RCDDbContext.StsComune.Where(x => x.IdProvinciaSts.Equals(comune.Filter.ProvinciaSts.Id))
                          .OrderBy(sortParam)
                         .Include("ProvinciaSts")
                         .ToListAsync();
            }

            List<ContractStsComune> comuneElenco = new List<ContractStsComune>();
            foreach (EntityStsComune varArea in comuni)
            {
                ContractStsComune com1 = new ContractStsComune();
                UtilityManager.MapProp(varArea, com1);
                comuneElenco.Add(com1);
            }
            return comuneElenco;
        }

        public async Task<List<ContractOffice>> GetOfficeByIdComune(OfficeRequestFull office)
        {
            List<EntityOffice> offici;

            String sortParam = String.Concat(String.Concat(office.CampoOrdinamento, " "), office.Ordinamento.ToUpper());

            if (office.Pageable)
            {

                offici = await _RCDDbContext.Office.Where(x => x.IdComune.Equals(office.Filter.StsComune.Id))
                         .OrderBy(sortParam)
                        .Skip(office.NumeroElementi * office.Page).Take(office.NumeroElementi)
                        .Include("StsComune")
                        .ToListAsync();
            }
            else
            {
                offici = await _RCDDbContext.Office.Where(x => x.IdComune.Equals(office.Filter.StsComune.Id))
                         .OrderBy(sortParam)
                        .Include("StsComune")
                        .ToListAsync();
            }
        

            List<ContractOffice> officiElenco = new List<ContractOffice>();
            foreach (EntityOffice varOffici in offici)
            {
                ContractOffice office1 = new ContractOffice();
                UtilityManager.MapProp(varOffici, office1);
                officiElenco.Add(office1);
            }
            return officiElenco;
        }
    }
}
