﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Request;
using RCDEngine.Entities;
using RCDContracts.Data;

namespace RCD.Code.Amministrazione
{
    public class AreaVenditaUtenteManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public AreaVenditaUtenteManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractAreaVenditaUtente>> GetAreeVenditaUtente(AreaVenditaUtenteRequestFull areaVenditaUtente)
        {
            List<EntityAreaVenditeUtente> areeVenditaUtente;
            String campoOrdinamento = "";
            switch (areaVenditaUtente.CampoOrdinamento)
            {
                case "direzione":
                    campoOrdinamento = "CanaleVendita.Canale";
                    break;
                case "divisione":
                    campoOrdinamento = "CanaleVenditaDettaglio.Descrizione";
                    break;
                case "areaVendite":
                    campoOrdinamento = "AreaVendite.Descrizione";
                    break;
                case "areaManager":
                    campoOrdinamento = "Utente.FullName";
                    break;
                default:
                    campoOrdinamento = areaVenditaUtente.CampoOrdinamento;
                    break;
            }
            String sortParam = String.Concat(String.Concat(campoOrdinamento, " "), areaVenditaUtente.Ordinamento.ToUpper());
            if (areaVenditaUtente.Pageable)
            {
                areeVenditaUtente = await _RCDDbContext.AreaVenditaUtente
                                .WhereIf(areaVenditaUtente.Filter.AreaVendite != null && !String.IsNullOrEmpty(areaVenditaUtente.Filter.AreaVendite.Descrizione), q => q.AreaVendite.Descrizione.Contains(areaVenditaUtente.Filter.AreaVendite.Descrizione))
                                .WhereIf(areaVenditaUtente.Filter.CanaleVendita != null && !String.IsNullOrEmpty(areaVenditaUtente.Filter.CanaleVendita.Canale), q => q.CanaleVendita.Canale.Contains(areaVenditaUtente.Filter.CanaleVendita.Canale))
                                .WhereIf(areaVenditaUtente.Filter.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(areaVenditaUtente.Filter.CanaleVenditaDettaglio.Descrizione), q => q.CanaleVenditaDettaglio.Descrizione.Contains(areaVenditaUtente.Filter.CanaleVenditaDettaglio.Descrizione))
                                .WhereIf(areaVenditaUtente.Filter.Utente != null && !String.IsNullOrEmpty(areaVenditaUtente.Filter.Utente.FullName), q => q.Utente.FullName.Contains(areaVenditaUtente.Filter.Utente.FullName))
                                .Include("AreaVendite")
                                .Include("CanaleVenditaDettaglio")
                                .Include("CanaleVendita")
                                .Include("Utente")
                                .OrderBy(sortParam)
                                .Skip(areaVenditaUtente.NumeroElementi * areaVenditaUtente.Page).Take(areaVenditaUtente.NumeroElementi)
                                .ToListAsync();
            }
            else
            {
                areeVenditaUtente = await _RCDDbContext.AreaVenditaUtente
                                .WhereIf(areaVenditaUtente.Filter.AreaVendite != null && !String.IsNullOrEmpty(areaVenditaUtente.Filter.AreaVendite.Descrizione), q => q.AreaVendite.Descrizione.Contains(areaVenditaUtente.Filter.AreaVendite.Descrizione))
                                .WhereIf(areaVenditaUtente.Filter.CanaleVendita != null && !String.IsNullOrEmpty(areaVenditaUtente.Filter.CanaleVendita.Canale), q => q.CanaleVendita.Canale.Contains(areaVenditaUtente.Filter.CanaleVendita.Canale))
                                .WhereIf(areaVenditaUtente.Filter.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(areaVenditaUtente.Filter.CanaleVenditaDettaglio.Descrizione), q => q.CanaleVenditaDettaglio.Descrizione.Contains(areaVenditaUtente.Filter.CanaleVenditaDettaglio.Descrizione))
                                .WhereIf(areaVenditaUtente.Filter.Utente != null && !String.IsNullOrEmpty(areaVenditaUtente.Filter.Utente.FullName), q => q.Utente.FullName.Contains(areaVenditaUtente.Filter.Utente.FullName))
                                .Include("AreaVendite")
                                .Include("CanaleVenditaDettaglio")
                                .Include("CanaleVendita")
                                .Include("Utente")
                                .OrderBy(sortParam)
                                .ToListAsync();
            }
            List<ContractAreaVenditaUtente> areaElenco = new List<ContractAreaVenditaUtente>();
            foreach (EntityAreaVenditeUtente varArea in areeVenditaUtente)
            {
                ContractAreaVenditaUtente areaVenditeUtente = new ContractAreaVenditaUtente();
                UtilityManager.MapProp(varArea, areaVenditeUtente);
                areaElenco.Add(areaVenditeUtente);
            }
            return areaElenco;
        }
        public async Task<Int32> GetAreeVenditaUtenteTot(AreaVenditaUtenteRequestFull areaVenditaUtente)
        {
           Int32 count = _RCDDbContext.AreaVenditaUtente
                                .WhereIf(areaVenditaUtente.Filter.AreaVendite != null && !String.IsNullOrEmpty(areaVenditaUtente.Filter.AreaVendite.Descrizione), q => q.AreaVendite.Descrizione.Contains(areaVenditaUtente.Filter.AreaVendite.Descrizione))
                                .WhereIf(areaVenditaUtente.Filter.CanaleVendita != null && !String.IsNullOrEmpty(areaVenditaUtente.Filter.CanaleVendita.Canale), q => q.CanaleVendita.Canale.Contains(areaVenditaUtente.Filter.CanaleVendita.Canale))
                                .WhereIf(areaVenditaUtente.Filter.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(areaVenditaUtente.Filter.CanaleVenditaDettaglio.Descrizione), q => q.CanaleVenditaDettaglio.Descrizione.Contains(areaVenditaUtente.Filter.CanaleVenditaDettaglio.Descrizione))
                                .WhereIf(areaVenditaUtente.Filter.Utente != null && !String.IsNullOrEmpty(areaVenditaUtente.Filter.Utente.FullName), q => q.Utente.FullName.Contains(areaVenditaUtente.Filter.Utente.FullName))
                                .Include("AreaVendite")
                                .Include("CanaleVenditaDettaglio")
                                .Include("CanaleVendita")
                                .Include("Utente")                               
                                .Count();
           
            return count;
        }
        public async Task<List<ContractAreaVenditaUtente>> GetUtentiAreaVendita(AreaVenditaUtenteRequest areaVenditaUtente)
        {
            List<EntityAreaVenditeUtente> areeVenditaUtente;
            areeVenditaUtente = await _RCDDbContext.AreaVenditaUtente
                                .Include("AreaVendite")
                                .Include("CanaleVenditaDettaglio")
                                .Include("CanaleVendita")
                                .Include("Utente")
                                .Where(x => x.AreaVendite.Abilitato == true && x.Id == areaVenditaUtente.Id)
                                .OrderBy(x => x.CanaleVendita.Canale).ThenBy(x => x.CanaleVenditaDettaglio.Descrizione)
                                .ToListAsync();

            List<ContractAreaVenditaUtente> areaElenco = new List<ContractAreaVenditaUtente>();
            foreach (EntityAreaVenditeUtente varArea in areeVenditaUtente)
            {
                ContractAreaVenditaUtente areaVenditeUtente = new ContractAreaVenditaUtente();
                UtilityManager.MapProp(varArea, areaVenditeUtente);

                List<EntityUtente> listUtenti = await _RCDDbContext.Utente
                    .Where(x =>
                    //x.IdCanaleVendita == areaVenditaUtente.IdDirezione
                    //&& x.IdCanaleVenditaDettaglio == areaVenditaUtente.IdDivisione
                    //&&
                    x.IdAreaVendita == varArea.IdAreaVendita &&
                    x.Abilitato == true && x.TipologiaUtente.TipologiaUtente == "AM")
                    .OrderBy(x => x.Nome).ThenBy(x => x.Cognome)
                    .ToListAsync();

                List<ContractUtente> listUtentiAreaVendita = new List<ContractUtente>();
                foreach (EntityUtente varUtente in listUtenti)
                {
                    ContractUtente contractUtente = new ContractUtente();
                    UtilityManager.MapProp(varUtente, contractUtente);
                    listUtentiAreaVendita.Add(contractUtente);
                }
                areaVenditeUtente.ListUtentiAreaVendita = listUtentiAreaVendita;

                areaElenco.Add(areaVenditeUtente);
            }

            return areaElenco;
        }



        public void AddAreaVenditaUtente(AreaVenditaUtenteRequest areaVenditaUtente)
        {
            try
            {
                EntityAreaVenditeUtente areaVenditaUtenteToAdd = new EntityAreaVenditeUtente();
                UtilityManager.MapProp(areaVenditaUtente, areaVenditaUtenteToAdd);
                var result = _RCDDbContext.Add(areaVenditaUtenteToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void UpdateAreaVenditaUtente(AreaVenditaUtenteRequest areaVenditaUtente)
        {
            try
            {
                EntityAreaVenditeUtente areaVenditaUtenteToEdit = new EntityAreaVenditeUtente();
                UtilityManager.MapProp(areaVenditaUtente, areaVenditaUtenteToEdit);
                var result = _RCDDbContext.Update(areaVenditaUtenteToEdit);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void DeleteAreaVenditaUtente(AreaVenditaUtenteRequest areaVenditaUtente)
        {
            try
            {
                EntityAreaVenditeUtente areaVenditaUtenteToRemove = _RCDDbContext.AreaVenditaUtente.Where(x => x.Id == areaVenditaUtente.Id).FirstOrDefault();
                var result = _RCDDbContext.Remove(areaVenditaUtenteToRemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
    }
}
