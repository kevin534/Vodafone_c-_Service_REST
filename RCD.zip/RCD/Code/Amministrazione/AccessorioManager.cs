﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;


namespace RCD.Code.Amministrazione
{
    public class AccessorioManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public AccessorioManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
        public async Task<List<ContractAccessorio>> GetAccessori(AccessorioRequestFull accessorio)
        {
            List<EntityAccessorio> accessori;

            String sortParam = String.Concat(String.Concat(accessorio.CampoOrdinamento, " "), accessorio.Ordinamento.ToUpper());

            if (accessorio.Pageable)
            {
                accessori = await _RCDDbContext.Accessorio.Where(x => x.Abilitato == true)
                            .WhereIf(!String.IsNullOrEmpty(accessorio.Filter.Modello), q => q.Modello.Contains(accessorio.Filter.Modello))                           
                            .WhereIf(!String.IsNullOrEmpty(accessorio.Filter.Costo.ToString()), q => q.Costo.Equals(accessorio.Filter.Costo))
                             .WhereIf(accessorio.Filter.Fornitore != null && !String.IsNullOrEmpty(accessorio.Filter.Fornitore.RagioneSociale), q => q.Fornitore.RagioneSociale.Contains(accessorio.Filter.Fornitore.RagioneSociale))
                         .WhereIf(accessorio.Filter.Sistema != null && !String.IsNullOrEmpty(accessorio.Filter.Sistema.Sistema), q => q.Sistema.Sistema.Contains(accessorio.Filter.Sistema.Sistema))
                         .WhereIf(accessorio.Filter.TipologiaAccessorio != null && !String.IsNullOrEmpty(accessorio.Filter.TipologiaAccessorio.TipologiaAccessorio), q => q.TipologiaAccessorio.TipologiaAccessorio.Contains(accessorio.Filter.TipologiaAccessorio.TipologiaAccessorio))
                            .OrderBy(sortParam)
                            .Skip(accessorio.NumeroElementi * accessorio.Page).Take(accessorio.NumeroElementi)
                            .Include("TipologiaAccessorio")
                            .Include("Sistema")
                            .Include("Fornitore")
                            .ToListAsync();

            }
            else
            {
                accessori = await _RCDDbContext.Accessorio.Where(x => x.Abilitato == true)
                            .WhereIf(!String.IsNullOrEmpty(accessorio.Filter.Modello), q => q.Modello.Contains(accessorio.Filter.Modello))
                            .WhereIf(!String.IsNullOrEmpty(accessorio.Filter.Costo.ToString()), q => q.Costo.Equals(accessorio.Filter.Costo))
                            .WhereIf(accessorio.Filter.Fornitore != null && !String.IsNullOrEmpty(accessorio.Filter.Fornitore.RagioneSociale), q => q.Fornitore.RagioneSociale.Contains(accessorio.Filter.Fornitore.RagioneSociale))
                         .WhereIf(accessorio.Filter.Sistema != null && !String.IsNullOrEmpty(accessorio.Filter.Sistema.Sistema), q => q.Sistema.Sistema.Contains(accessorio.Filter.Sistema.Sistema))
                         .WhereIf(accessorio.Filter.TipologiaAccessorio != null && !String.IsNullOrEmpty(accessorio.Filter.TipologiaAccessorio.TipologiaAccessorio), q => q.TipologiaAccessorio.TipologiaAccessorio.Contains(accessorio.Filter.TipologiaAccessorio.TipologiaAccessorio))
                            .OrderBy(sortParam)
                            .Include("TipologiaAccessorio")
                            .Include("Sistema")
                            .Include("Fornitore")
                            .ToListAsync();
            }


            List<ContractAccessorio> accessoriElenco = new List<ContractAccessorio>();
            foreach (EntityAccessorio varAccessorio in accessori)
            {
                ContractAccessorio accessorio1 = new ContractAccessorio();
                UtilityManager.MapProp(varAccessorio, accessorio1);
                accessoriElenco.Add(accessorio1);
            }
            return accessoriElenco;
        }
        public async Task<Int32> GetAccessoriTot(AccessorioRequestFull accessorio)
        {
            List<EntityAccessorio> accessori;


            accessori = await _RCDDbContext.Accessorio.Where(x => x.Abilitato == true)
                             .WhereIf(!String.IsNullOrEmpty(accessorio.Filter.Modello), q => q.Modello.Contains(accessorio.Filter.Modello))
                             .WhereIf(!String.IsNullOrEmpty(accessorio.Filter.Costo.ToString()), q => q.Costo.Equals(accessorio.Filter.Costo))
                              .WhereIf(accessorio.Filter.Fornitore != null && !String.IsNullOrEmpty(accessorio.Filter.Fornitore.RagioneSociale), q => q.Fornitore.RagioneSociale.Contains(accessorio.Filter.Fornitore.RagioneSociale))
                         .WhereIf(accessorio.Filter.Sistema != null && !String.IsNullOrEmpty(accessorio.Filter.Sistema.Sistema), q => q.Sistema.Sistema.Contains(accessorio.Filter.Sistema.Sistema))
                         .WhereIf(accessorio.Filter.TipologiaAccessorio != null && !String.IsNullOrEmpty(accessorio.Filter.TipologiaAccessorio.TipologiaAccessorio), q => q.TipologiaAccessorio.TipologiaAccessorio.Contains(accessorio.Filter.TipologiaAccessorio.TipologiaAccessorio))             
                             .ToListAsync();
            return accessori.Count();

        }


        public void AddAccessorio(AccessorioRequest accessorio)
        {
            try
            {
                EntityAccessorio accessorioToAdd = new EntityAccessorio();
                UtilityManager.MapProp(accessorio, accessorioToAdd);
                accessorioToAdd.Abilitato = true;
                var result = _RCDDbContext.Add(accessorioToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateAccessorio(AccessorioRequest accessorio)
        {
            try
            {
                EntityAccessorio accessorioToEdit = new EntityAccessorio();
                UtilityManager.MapProp(accessorio, accessorioToEdit);
                accessorioToEdit.Abilitato = true;
                var result = _RCDDbContext.Update(accessorioToEdit);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteAccessorio(AccessorioRequest accessorio)
        {
            try
            {
                EntityAccessorio accessorioToRemove = _RCDDbContext.Accessorio.Where(x => x.Id == accessorio.Id).FirstOrDefault();

                accessorioToRemove.Abilitato = false;
                var result = _RCDDbContext.Update(accessorioToRemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
    }

}
