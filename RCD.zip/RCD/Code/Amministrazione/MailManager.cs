﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class MailManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public MailManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractMail>> GetMail(MailRequestFull mail)
        {

            List<EntityMail> mails;


            String sortParam = String.Concat(String.Concat(mail.CampoOrdinamento, " "), mail.Ordinamento.ToUpper());

            if (mail.Pageable)
            {
                mails = await _RCDDbContext.Mail
                            .WhereIf(!String.IsNullOrEmpty(mail.Filter.Mail), q => q.Mail.Contains(mail.Filter.Mail))
                            .OrderBy(sortParam)
                            .Skip(mail.NumeroElementi * mail.Page).Take(mail.NumeroElementi)
                            .ToListAsync();

            }
            else
            {
                mails = await _RCDDbContext.Mail
                             .WhereIf(!String.IsNullOrEmpty(mail.Filter.Mail), q => q.Mail.Contains(mail.Filter.Mail))
                             .OrderBy(sortParam)
                             .ToListAsync();
            }

            List<ContractMail> mailElenco = new List<ContractMail>();

            foreach (EntityMail varMail in mails)
            {
                ContractMail mail1 = new ContractMail();
                UtilityManager.MapProp(varMail, mail1);
                mailElenco.Add(mail1);
            }
            return mailElenco;
        }
        public async Task<Int32> GetMailTot(MailRequestFull mail)
        {
            List<EntityMail> mails;


            mails = await _RCDDbContext.Mail
                              .WhereIf(!String.IsNullOrEmpty(mail.Filter.Mail), q => q.Mail.Contains(mail.Filter.Mail))
                              .ToListAsync();
            return mails.Count();

        }


        public void AddMail(MailRequest mail)
        {
            try
            {
                EntityMail mailToAdd = new EntityMail();
                UtilityManager.MapProp(mail, mailToAdd);
                var result = _RCDDbContext.Add(mailToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateMail(MailRequest mail)
        {
            try
            {
                EntityMail mailToAdd = new EntityMail();
                UtilityManager.MapProp(mail, mailToAdd);
                var result = _RCDDbContext.Update(mailToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteMail(MailRequest mail)
        {
            try
            {
                EntityMail mailToAdd = new EntityMail();
                UtilityManager.MapProp(mail, mailToAdd);
                var result = _RCDDbContext.Remove(mailToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }


    }
}
