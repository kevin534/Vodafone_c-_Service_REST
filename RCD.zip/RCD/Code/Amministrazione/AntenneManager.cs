﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class AntenneManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public AntenneManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractAntenna>> GetAntenne(AntennaRequestFull antenna)
        {
            List<EntityAntenna> antenne;
            
            String sortParam = String.Concat(String.Concat(antenna.CampoOrdinamento, " "), antenna.Ordinamento.ToUpper());

            if (antenna.Pageable)
            {
                antenne = await _RCDDbContext.Antenna.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Modello), q => q.Modello.Contains(antenna.Filter.Modello))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Guadagno), q => q.Guadagno.Contains(antenna.Filter.Guadagno))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Lobo3dbOrizzontale), q => q.Lobo3dbOrizzontale.Contains(antenna.Filter.Lobo3dbOrizzontale))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Lobo3dbVerticale), q => q.Lobo3dbVerticale.Contains(antenna.Filter.Lobo3dbVerticale))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Dimensioni), q => q.Dimensioni.Contains(antenna.Filter.Dimensioni))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Costo.ToString()), q => q.Costo == antenna.Filter.Costo)
                         .WhereIf(antenna.Filter.Fornitore != null && !String.IsNullOrEmpty(antenna.Filter.Fornitore.RagioneSociale), q => q.Fornitore.RagioneSociale.Contains(antenna.Filter.Fornitore.RagioneSociale))
                         .WhereIf(antenna.Filter.Sistema != null && !String.IsNullOrEmpty(antenna.Filter.Sistema.Sistema), q => q.Sistema.Sistema.Contains(antenna.Filter.Sistema.Sistema))
                         .WhereIf(antenna.Filter.TipologiaAntenna != null && !String.IsNullOrEmpty(antenna.Filter.TipologiaAntenna.TipologiaAntenna), q => q.TipologiaAntenna.TipologiaAntenna.Contains(antenna.Filter.TipologiaAntenna.TipologiaAntenna))
                         .OrderBy(sortParam)
                        .Skip(antenna.NumeroElementi * antenna.Page).Take(antenna.NumeroElementi)
                        .Include("Sistema")
                        .Include("Fornitore")
                        .Include("TipologiaAntenna")
                        .ToListAsync();

            }
            else
            {
                antenne = await _RCDDbContext.Antenna.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Modello), q => q.Modello.Contains(antenna.Filter.Modello))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Guadagno), q => q.Guadagno.Contains(antenna.Filter.Guadagno))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Lobo3dbOrizzontale), q => q.Lobo3dbOrizzontale.Contains(antenna.Filter.Lobo3dbOrizzontale))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Lobo3dbVerticale), q => q.Lobo3dbVerticale.Contains(antenna.Filter.Lobo3dbVerticale))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Dimensioni), q => q.Dimensioni.Contains(antenna.Filter.Dimensioni))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Costo.ToString()), q => q.Costo == antenna.Filter.Costo)
                        .WhereIf(antenna.Filter.Fornitore != null && !String.IsNullOrEmpty(antenna.Filter.Fornitore.RagioneSociale), q => q.Fornitore.RagioneSociale.Contains(antenna.Filter.Fornitore.RagioneSociale))
                         .WhereIf(antenna.Filter.Sistema != null && !String.IsNullOrEmpty(antenna.Filter.Sistema.Sistema), q => q.Sistema.Sistema.Contains(antenna.Filter.Sistema.Sistema))
                         .WhereIf(antenna.Filter.TipologiaAntenna != null && !String.IsNullOrEmpty(antenna.Filter.TipologiaAntenna.TipologiaAntenna), q => q.TipologiaAntenna.TipologiaAntenna.Contains(antenna.Filter.TipologiaAntenna.TipologiaAntenna))
                         .OrderBy(sortParam)
                        .Include("Sistema")
                        .Include("Fornitore")
                        .Include("TipologiaAntenna")
                        .ToListAsync();
            }

            List<ContractAntenna> antenneElenco = new List<ContractAntenna>();
            foreach (EntityAntenna varAntenna in antenne)
            {
                ContractAntenna antenna1 = new ContractAntenna();
                UtilityManager.MapProp(varAntenna, antenna1);
                antenneElenco.Add(antenna1);
            }
            return antenneElenco;
        }
        public async Task<List<ContractAccessibilitaAntenna>> GetAccessibilitaAntenne()
        {
            List<EntityAccessibilitaAntenna> antenna;

            antenna = await _RCDDbContext.AccessAntenna.OrderBy(x => x.id)
                                .ToListAsync();


            List<ContractAccessibilitaAntenna> getElenco = new List<ContractAccessibilitaAntenna>();
            foreach (EntityAccessibilitaAntenna varAccAntenna in antenna)
            {
                ContractAccessibilitaAntenna ant1 = new ContractAccessibilitaAntenna();
                UtilityManager.MapProp(varAccAntenna, ant1);
                getElenco.Add(ant1);
            }
            return getElenco;
        }
        public async Task<Int32> GetAntenneTot(AntennaRequestFull antenna)
        {
            List<EntityAntenna> antenne;


            antenne = await _RCDDbContext.Antenna.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Modello), q => q.Modello.Contains(antenna.Filter.Modello))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Guadagno), q => q.Guadagno.Contains(antenna.Filter.Guadagno))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Lobo3dbOrizzontale), q => q.Lobo3dbOrizzontale.Contains(antenna.Filter.Lobo3dbOrizzontale))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Lobo3dbVerticale), q => q.Lobo3dbVerticale.Contains(antenna.Filter.Lobo3dbVerticale))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Dimensioni), q => q.Dimensioni.Contains(antenna.Filter.Dimensioni))
                        .WhereIf(!String.IsNullOrEmpty(antenna.Filter.Costo.ToString()), q => q.Costo == antenna.Filter.Costo)
                        .WhereIf(antenna.Filter.Fornitore != null && !String.IsNullOrEmpty(antenna.Filter.Fornitore.RagioneSociale), q => q.Fornitore.RagioneSociale.Contains(antenna.Filter.Fornitore.RagioneSociale))
                         .WhereIf(antenna.Filter.Sistema != null && !String.IsNullOrEmpty(antenna.Filter.Sistema.Sistema), q => q.Sistema.Sistema.Contains(antenna.Filter.Sistema.Sistema))
                         .WhereIf(antenna.Filter.TipologiaAntenna != null && !String.IsNullOrEmpty(antenna.Filter.TipologiaAntenna.TipologiaAntenna), q => q.TipologiaAntenna.TipologiaAntenna.Contains(antenna.Filter.TipologiaAntenna.TipologiaAntenna))

                        .ToListAsync();

            return antenne.Count();

        }
        public void AddAntenna(AntennaRequest antenna)
        {
            try
            {
                EntityAntenna antennaToAdd = new EntityAntenna();
                UtilityManager.MapProp(antenna, antennaToAdd);
                antennaToAdd.Abilitato = true;
                var result = _RCDDbContext.Add(antennaToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateAntenna(AntennaRequest antenna)
        {
            try
            {
                EntityAntenna antennaToAdd = new EntityAntenna();
                UtilityManager.MapProp(antenna, antennaToAdd);
                var result = _RCDDbContext.Update(antennaToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteAntenna(AntennaRequest antenna)
        {
            try
            {
                EntityAntenna entityAntennaToUpdate = _RCDDbContext.Antenna.FirstOrDefault(item => item.Id == antenna.Id);

                if (entityAntennaToUpdate != null)
                {
                    entityAntennaToUpdate.Abilitato = false;
                    var result = _RCDDbContext.Update(entityAntennaToUpdate);
                    _RCDDbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public async Task<List<ContractFrequenzaLTE>> GetFrequenzaLTE()
        {
            List<EntityFrequenzaLTE> frequenzaLTEs;

            frequenzaLTEs = await _RCDDbContext.FrequenzaLTE
                                .OrderBy(x => x.id)
                                .ToListAsync();


            List<ContractFrequenzaLTE> getElenco = new List<ContractFrequenzaLTE>();
            foreach (EntityFrequenzaLTE varFreq in frequenzaLTEs)
            {
                ContractFrequenzaLTE freq1 = new ContractFrequenzaLTE();
                UtilityManager.MapProp(varFreq, freq1);
                getElenco.Add(freq1);
            }
            return getElenco;
        }
        public async Task<List<ContractLocalizzazioneAntenna>> GetLocalizzazioneAntenna()
        {
            List<EntityLocalizzazioneAntenna> localizzazione;

            localizzazione = await _RCDDbContext.LocalizzazioneAntenna1
                                .OrderBy(x => x.Id)
                                .ToListAsync();


            List<ContractLocalizzazioneAntenna> getElenco = new List<ContractLocalizzazioneAntenna>();
            foreach (EntityLocalizzazioneAntenna varloc in localizzazione)
            {
                ContractLocalizzazioneAntenna loc1 = new ContractLocalizzazioneAntenna();
                UtilityManager.MapProp(varloc, loc1);
                getElenco.Add(loc1);
            }
            return getElenco;
        }

        public async Task<List<ContractTTInstallazioneAntenna>> GetTTInstallazioneAntenna()
        {
            List<EntityTTInstallazioneAntenna> installazione;

            installazione = await _RCDDbContext.TTInstallazioneAntenna
                                .OrderBy(x => x.Id)
                                .ToListAsync();


            List<ContractTTInstallazioneAntenna> getElenco = new List<ContractTTInstallazioneAntenna>();
            foreach (EntityTTInstallazioneAntenna varloc in installazione)
            {
                ContractTTInstallazioneAntenna inst1 = new ContractTTInstallazioneAntenna();
                UtilityManager.MapProp(varloc, inst1);
                getElenco.Add(inst1);
            }
            return getElenco;
        }
        public async Task<List<ContractTipologiaCopertura>> GetTipologiaCopertura()
        {
            List<EntityTipologiaCopertura> copertura;

            copertura = await _RCDDbContext.TipologiaCopertura
                                .OrderBy(x => x.Id)
                                .ToListAsync();


            List<ContractTipologiaCopertura> getElenco = new List<ContractTipologiaCopertura>();
            foreach (EntityTipologiaCopertura varCop in copertura)
            {
                ContractTipologiaCopertura tipCop = new ContractTipologiaCopertura();
                UtilityManager.MapProp(varCop, tipCop);
                getElenco.Add(tipCop);
            }
            return getElenco;
        }

        public async Task<List<ContractTipologiaLan>> GetTipologiaLan()
        {
            List<EntityTipologiaLan> tipoLan;

            tipoLan = await _RCDDbContext.TipologiaLan
                                .OrderBy(x => x.Id)
                                .ToListAsync();


            List<ContractTipologiaLan> getElenco = new List<ContractTipologiaLan>();
            foreach (EntityTipologiaLan varTipLan in tipoLan)
            {
                ContractTipologiaLan tipLan = new ContractTipologiaLan();
                UtilityManager.MapProp(varTipLan, tipLan);
                getElenco.Add(tipLan);
            }
            return getElenco;
        }

        public async Task<List<ContractTipologiaSegnaleAntenna>> GetTipologiaSegnaleAntenna()
        {
            List<EntityTipologiaSegnaleAntenna> tipoSegnale;

            tipoSegnale = await _RCDDbContext.TipologiaSegnaleAntenna
                                .OrderBy(x => x.Id)
                                .ToListAsync();


            List<ContractTipologiaSegnaleAntenna> getElenco = new List<ContractTipologiaSegnaleAntenna>();
            foreach (EntityTipologiaSegnaleAntenna varTipSegnale in tipoSegnale)
            {
                ContractTipologiaSegnaleAntenna tipSeg = new ContractTipologiaSegnaleAntenna();
                UtilityManager.MapProp(varTipSegnale, tipSeg);
                getElenco.Add(tipSeg);
            }
            return getElenco;
        }

        public async Task<List<ContractSistemaMisure>> GetSistemaMisure()
        {
            List<EntitySistemaMisure> sistemaMisure;

            sistemaMisure = await _RCDDbContext.SistemaMisure
                                .OrderBy(x => x.Id)
                                .ToListAsync();


            List<ContractSistemaMisure> getElenco = new List<ContractSistemaMisure>();
            foreach (EntitySistemaMisure varMisure in sistemaMisure)
            {
                ContractSistemaMisure tipMesure = new ContractSistemaMisure();
                UtilityManager.MapProp(varMisure, tipMesure);
                getElenco.Add(tipMesure);
            }
            return getElenco;
        }

        public async Task<List<ContractTipologiaMisura>> GetTipologiaMisura()
        {
            List<EntityTipologiaMisura> tipologiaMisure;

            tipologiaMisure = await _RCDDbContext.TipologiaMisura
                                .OrderBy(x => x.Id)
                                .ToListAsync();


            List<ContractTipologiaMisura> getElenco = new List<ContractTipologiaMisura>();
            foreach (EntityTipologiaMisura varMisure in tipologiaMisure)
            {
                ContractTipologiaMisura tipMesure = new ContractTipologiaMisura();
                UtilityManager.MapProp(varMisure, tipMesure);
                getElenco.Add(tipMesure);
            }
            return getElenco;
        }

    }
}
