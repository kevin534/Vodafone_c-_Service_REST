﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;


namespace RCD.Code.Amministrazione
{
    public class FornitoriManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public FornitoriManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractFornitore>> GetFornitori(FornitoreRequestFull fornitore)
        {
            List<EntityFornitore> fornitori;
            String sortParam = String.Concat(String.Concat(fornitore.CampoOrdinamento, " "), fornitore.Ordinamento.ToUpper());

            if (fornitore.Pageable)
            {
                fornitori = await _RCDDbContext.Fornitore.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(fornitore.Filter.RagioneSociale), q => q.RagioneSociale.Contains(fornitore.Filter.RagioneSociale))
                        .OrderBy(sortParam)
                        .Skip(fornitore.NumeroElementi * fornitore.Page).Take(fornitore.NumeroElementi).ToListAsync();

            }
            else
            {
                fornitori = await _RCDDbContext.Fornitore.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(fornitore.Filter.RagioneSociale), q => q.RagioneSociale.Contains(fornitore.Filter.RagioneSociale))
                        .OrderBy(sortParam).ToListAsync();

            }
            

            List<ContractFornitore> fornitoriElenco = new List<ContractFornitore>();
            foreach (EntityFornitore varFornitore in fornitori)
            {
                ContractFornitore fornitore1 = new ContractFornitore();
                UtilityManager.MapProp(varFornitore, fornitore1);
                fornitoriElenco.Add(fornitore1);
            }
            return fornitoriElenco;
        }
        public async Task<Int32> GetFornitoriTot(FornitoreRequestFull fornitore)
        {
            List<EntityFornitore> fornitori;
            fornitori = await _RCDDbContext.Fornitore.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(fornitore.Filter.RagioneSociale), q => q.RagioneSociale.Contains(fornitore.Filter.RagioneSociale))
                        .ToListAsync();

            return fornitori.Count();

        }
        public void AddFornitore(FornitoreRequest fornitore)
        {
            try
            {
                EntityFornitore fornitoreToAdd = new EntityFornitore();
                UtilityManager.MapProp(fornitore, fornitoreToAdd);
                fornitoreToAdd.Abilitato = true;
                var result = _RCDDbContext.Add(fornitoreToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateFornitore(FornitoreRequest fornitore)
        {
            try
            {
                EntityFornitore fornitoreToAdd = new EntityFornitore();
                UtilityManager.MapProp(fornitore, fornitoreToAdd);
                fornitoreToAdd.Abilitato = true;
                var result = _RCDDbContext.Update(fornitoreToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteFornitore(FornitoreRequest fornitore)
        {
            try
            {
                EntityFornitore entityFornitoreToUpdate = _RCDDbContext.Fornitore.FirstOrDefault(item => item.Id == fornitore.Id);

                if (entityFornitoreToUpdate != null)
                {
                    entityFornitoreToUpdate.Abilitato = false;
                    var result = _RCDDbContext.Update(entityFornitoreToUpdate);
                    _RCDDbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
    }
}
