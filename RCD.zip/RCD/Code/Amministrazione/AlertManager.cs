﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class AlertManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public AlertManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractEventoZona>> GetEventiZonaById(AlertRequestFull eventiZonaR)
        {
            List<EntityEventoZona> eventiZona;
            String sortParam = String.Concat(String.Concat(eventiZonaR.CampoOrdinamento, " "), eventiZonaR.Ordinamento.ToUpper());
            bool conditionZone = eventiZonaR.Filter.Zona is not null;
            bool conditionEvento = eventiZonaR.Filter.Evento is not null;
            bool conditionStato = false;

            if (conditionEvento != false)
                conditionStato = eventiZonaR.Filter.Evento.Stato is not null; 

            if (eventiZonaR.Pageable)
            {
                eventiZona = await _RCDDbContext.EventoZona.Where(x => x.IdZona.Equals(eventiZonaR.Filter.IdZona))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.IdEvento.ToString()), q => q.IdEvento.Equals(eventiZonaR.Filter.IdEvento))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.Soglia.ToString()), q => q.Soglia.Equals(eventiZonaR.Filter.Soglia))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.DayBetweenMails.ToString()), q => q.DayBetweenMails.Equals(eventiZonaR.Filter.DayBetweenMails))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.MaxMailsToSend.ToString()), q => q.MaxMailsToSend.Equals(eventiZonaR.Filter.MaxMailsToSend))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.HasReminder.ToString()), q => q.HasReminder.Equals(eventiZonaR.Filter.HasReminder))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendDM.ToString()), q => q.SendDM.Equals(eventiZonaR.Filter.SendDM))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendDitta.ToString()), q => q.SendDitta.Equals(eventiZonaR.Filter.SendDitta))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendVenditore.ToString()), q => q.SendVenditore.Equals(eventiZonaR.Filter.SendVenditore))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendCI.ToString()), q => q.SendCI.Equals(eventiZonaR.Filter.SendCI))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendNI.ToString()), q => q.SendNI.Equals(eventiZonaR.Filter.SendNI))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendNSO.ToString()), q => q.SendNSO.Equals(eventiZonaR.Filter.SendNSO))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendRAN.ToString()), q => q.SendRAN.Equals(eventiZonaR.Filter.SendRAN))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendTS.ToString()), q => q.SendTS.Equals(eventiZonaR.Filter.SendTS))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendRiferimentoAM.ToString()), q => q.SendRiferimentoAM.Equals(eventiZonaR.Filter.SendRiferimentoAM))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendRiferimentoDCE.ToString()), q => q.SendRiferimentoDCE.Equals(eventiZonaR.Filter.SendRiferimentoDCE))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendRiferimentoKAM.ToString()), q => q.SendRiferimentoKAM.Equals(eventiZonaR.Filter.SendRiferimentoKAM))
                            .WhereIf((conditionZone.Equals(true) && !String.IsNullOrEmpty(eventiZonaR.Filter.Zona.Zona)), q => q.Zona.Zona.Contains(eventiZonaR.Filter.Zona.Zona))
                            .WhereIf((conditionEvento.Equals(true) && !String.IsNullOrEmpty(eventiZonaR.Filter.Evento.DescrizioneEvento)), q => q.Evento.DescrizioneEvento.Contains(eventiZonaR.Filter.Evento.DescrizioneEvento))
                            .WhereIf((conditionEvento.Equals(true) && conditionStato.Equals(true) && !String.IsNullOrEmpty(eventiZonaR.Filter.Evento.Stato.Stato)), q => q.Evento.Stato.Stato.Contains(eventiZonaR.Filter.Evento.Stato.Stato))
                            .OrderBy(sortParam)
                            .Skip(eventiZonaR.NumeroElementi * eventiZonaR.Page).Take(eventiZonaR.NumeroElementi)
                            .Include("Zona").Include("Evento").Include("Evento.Stato").ToListAsync();

            }
            else
            {
                eventiZona = await _RCDDbContext.EventoZona.Where(x => x.IdZona == (eventiZonaR.Filter.IdZona))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.IdEvento.ToString()), q => q.IdEvento.Equals(eventiZonaR.Filter.IdEvento))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.Soglia.ToString()), q => q.Soglia.Equals(eventiZonaR.Filter.Soglia))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.DayBetweenMails.ToString()), q => q.DayBetweenMails.Equals(eventiZonaR.Filter.DayBetweenMails))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.MaxMailsToSend.ToString()), q => q.MaxMailsToSend.Equals(eventiZonaR.Filter.MaxMailsToSend))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.HasReminder.ToString()), q => q.HasReminder.Equals(eventiZonaR.Filter.HasReminder))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendDM.ToString()), q => q.SendDM.Equals(eventiZonaR.Filter.SendDM))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendDitta.ToString()), q => q.SendDitta.Equals(eventiZonaR.Filter.SendDitta))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendVenditore.ToString()), q => q.SendVenditore.Equals(eventiZonaR.Filter.SendVenditore))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendCI.ToString()), q => q.SendCI.Equals(eventiZonaR.Filter.SendCI))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendNI.ToString()), q => q.SendNI.Equals(eventiZonaR.Filter.SendNI))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendNSO.ToString()), q => q.SendNSO.Equals(eventiZonaR.Filter.SendNSO))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendRAN.ToString()), q => q.SendRAN.Equals(eventiZonaR.Filter.SendRAN))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendTS.ToString()), q => q.SendTS.Equals(eventiZonaR.Filter.SendTS))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendRiferimentoAM.ToString()), q => q.SendRiferimentoAM.Equals(eventiZonaR.Filter.SendRiferimentoAM))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendRiferimentoDCE.ToString()), q => q.SendRiferimentoDCE.Equals(eventiZonaR.Filter.SendRiferimentoDCE))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendRiferimentoKAM.ToString()), q => q.SendRiferimentoKAM.Equals(eventiZonaR.Filter.SendRiferimentoKAM))
                            .WhereIf((conditionZone.Equals(true) && !String.IsNullOrEmpty(eventiZonaR.Filter.Zona.Zona)), q => q.Zona.Zona.Contains(eventiZonaR.Filter.Zona.Zona))
                            .WhereIf((conditionEvento.Equals(true) && !String.IsNullOrEmpty(eventiZonaR.Filter.Evento.DescrizioneEvento)), q => q.Evento.DescrizioneEvento.Contains(eventiZonaR.Filter.Evento.DescrizioneEvento))
                            .WhereIf((conditionEvento.Equals(true) && conditionStato.Equals(true) && !String.IsNullOrEmpty(eventiZonaR.Filter.Evento.Stato.Stato)), q => q.Evento.Stato.Stato.Contains(eventiZonaR.Filter.Evento.Stato.Stato))
                            .OrderBy(sortParam).Include("Zona")
                            .Include("Evento").Include("Evento.Stato").ToListAsync();
            }


            List<ContractEventoZona> eventiZoneElenco = new List<ContractEventoZona>();
            foreach (EntityEventoZona varEventoZona in eventiZona)
            {
                ContractEventoZona eventiZona1 = new ContractEventoZona();
                UtilityManager.MapProp(varEventoZona, eventiZona1);
                eventiZoneElenco.Add(eventiZona1);
            }

            return eventiZoneElenco;   
        }


        public async Task<Int32> GetEventiZoneTot(AlertRequestFull eventiZonaR)
        {
            List<EntityEventoZona> eventiZona;
            bool conditionZone = eventiZonaR.Filter.Zona is not null;
            bool conditionEvento = eventiZonaR.Filter.Evento is not null;
            bool conditionStato = false;

            if (conditionEvento != false)
                conditionStato = eventiZonaR.Filter.Evento.Stato is not null;

            eventiZona = await _RCDDbContext.EventoZona.Where(x => x.IdZona.Equals(eventiZonaR.Filter.IdZona))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.IdEvento.ToString()), q => q.IdEvento.Equals(eventiZonaR.Filter.IdEvento))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.Soglia.ToString()), q => q.Soglia.Equals(eventiZonaR.Filter.Soglia))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.DayBetweenMails.ToString()), q => q.DayBetweenMails.Equals(eventiZonaR.Filter.DayBetweenMails))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.MaxMailsToSend.ToString()), q => q.MaxMailsToSend.Equals(eventiZonaR.Filter.MaxMailsToSend))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.HasReminder.ToString()), q => q.HasReminder.Equals(eventiZonaR.Filter.HasReminder))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendDM.ToString()), q => q.SendDM.Equals(eventiZonaR.Filter.SendDM))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendDitta.ToString()), q => q.SendDitta.Equals(eventiZonaR.Filter.SendDitta))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendVenditore.ToString()), q => q.SendVenditore.Equals(eventiZonaR.Filter.SendVenditore))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendCI.ToString()), q => q.SendCI.Equals(eventiZonaR.Filter.SendCI))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendNI.ToString()), q => q.SendNI.Equals(eventiZonaR.Filter.SendNI))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendNSO.ToString()), q => q.SendNSO.Equals(eventiZonaR.Filter.SendNSO))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendRAN.ToString()), q => q.SendRAN.Equals(eventiZonaR.Filter.SendRAN))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendTS.ToString()), q => q.SendTS.Equals(eventiZonaR.Filter.SendTS))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendRiferimentoAM.ToString()), q => q.SendRiferimentoAM.Equals(eventiZonaR.Filter.SendRiferimentoAM))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendRiferimentoDCE.ToString()), q => q.SendRiferimentoDCE.Equals(eventiZonaR.Filter.SendRiferimentoDCE))
                            .WhereIf(!String.IsNullOrEmpty(eventiZonaR.Filter.SendRiferimentoKAM.ToString()), q => q.SendRiferimentoKAM.Equals(eventiZonaR.Filter.SendRiferimentoKAM))
                            .WhereIf((conditionZone.Equals(true) && !String.IsNullOrEmpty(eventiZonaR.Filter.Zona.Zona)), q => q.Zona.Zona.Contains(eventiZonaR.Filter.Zona.Zona))
                            .WhereIf((conditionEvento.Equals(true) && !String.IsNullOrEmpty(eventiZonaR.Filter.Evento.DescrizioneEvento)), q => q.Evento.DescrizioneEvento.Contains(eventiZonaR.Filter.Evento.DescrizioneEvento))
                            .WhereIf((conditionEvento.Equals(true) && conditionStato.Equals(true) && !String.IsNullOrEmpty(eventiZonaR.Filter.Evento.Stato.Stato)), q => q.Evento.Stato.Stato.Contains(eventiZonaR.Filter.Evento.Stato.Stato))
                .ToListAsync();
       
            return eventiZona.Count();
        }

        public async Task<List<ContractEventi>> GetEventi(AlertRequestFull eventiR)
        {
            List<EntityEventi> eventi;
            String sortParam = String.Concat(String.Concat(eventiR.CampoOrdinamento, " "), eventiR.Ordinamento.ToUpper());

            if (eventiR.Pageable)
            {
                eventi = await _RCDDbContext.Evento.OrderBy(sortParam)
                       .Skip(eventiR.NumeroElementi * eventiR.Page).Take(eventiR.NumeroElementi)
                       .Include("Stato").ToListAsync();
                       //.WhereIf(!String.IsNullOrEmpty(eventiR.FilterEvento.DescrizioneEvento), q => q.DescrizioneEvento.Contains(eventiR.FilterEvento.DescrizioneEvento))
                       //.WhereIf(!String.IsNullOrEmpty(eventiR.FilterEvento.HasSoglia.ToString()), q => q.HasSoglia.Equals(eventiR.FilterEvento.HasSoglia))
                       //.OrderBy(sortParam)
                       //.Skip(eventiR.NumeroElementi * eventiR.Page).Take(eventiR.NumeroElementi)
                       //.ToListAsync();

            }
            else
            {
                eventi = await _RCDDbContext.Evento.OrderBy(sortParam).Include("Stato").ToListAsync();
                       //.WhereIf(!String.IsNullOrEmpty(eventiR.FilterEvento.DescrizioneEvento), q => q.DescrizioneEvento.Contains(eventiR.FilterEvento.DescrizioneEvento))
                       //.WhereIf(!String.IsNullOrEmpty(eventiR.FilterEvento.HasSoglia.ToString()), q => q.HasSoglia.Equals(eventiR.FilterEvento.HasSoglia))
                       
            }


            List<ContractEventi> eventiElenco = new List<ContractEventi>();
            foreach (EntityEventi varEvento in eventi)
            {
                ContractEventi eventi1 = new ContractEventi();
                UtilityManager.MapProp(varEvento, eventi1);
                eventiElenco.Add(eventi1);
            }

            return eventiElenco;
        }

        public async Task<Int32> GetEventiTot(AlertRequestFull eventiR)
        {
            List<EntityEventi> eventi;

            eventi = await _RCDDbContext.Evento.ToListAsync();
                  

            return eventi.Count();
        }

        public void UpdateAlert(AlertRequestEventoZona eventoZona)
        {
            try
            {
                EntityEventoZona eventoZonaToUpdate = new EntityEventoZona();
                UtilityManager.MapProp(eventoZona, eventoZonaToUpdate);
                var result = _RCDDbContext.Update(eventoZonaToUpdate);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void AddAlert(AlertRequestEventoZona eventoZona)
        {
            try
            {
                EntityEventoZona eventoZonaToAdd = new EntityEventoZona();
                UtilityManager.MapProp(eventoZona, eventoZonaToAdd);
                var result = _RCDDbContext.Add(eventoZonaToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void DeleteAlert(AlertRequestEventoZona eventoZona)
        {
            try
            {
                EntityEventoZona eventoZonaToRemove = new EntityEventoZona();
                UtilityManager.MapProp(eventoZona, eventoZonaToRemove);
                var result = _RCDDbContext.Remove(eventoZonaToRemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
    }

}
