﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class BloccoZoneManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public BloccoZoneManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

       
        public void UpdateBloccoZone(ZonaRequest zona)
        {
            try
            {
                EntityZona zonaUpdate = new EntityZona();
                UtilityManager.MapProp(zona, zonaUpdate);
                var result = _RCDDbContext.Update(zonaUpdate);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

    }
}
