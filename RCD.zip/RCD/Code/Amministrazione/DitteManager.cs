﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;
using System.Text;

namespace RCD.Code.Amministrazione
{
    public class DitteManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public DitteManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractDitta>> GetDitte(DittaRequestFull ditta)
        {
            List<EntityDitta> ditte;
            String sortParam = String.Concat(String.Concat(ditta.CampoOrdinamento, " "), ditta.Ordinamento.ToUpper());

            List<long> idFittizia = new List<long>() { 1, 2, 3, 4 };
            bool conditionZone = ditta.Filter.Zona is not null;
            if (ditta.Pageable)
            {
                

                ditte = await _RCDDbContext.Ditta.Where(x => x.Abilitato == true && !idFittizia.Contains((long)x.Id))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.RagioneSociale), q => q.RagioneSociale.Contains(ditta.Filter.RagioneSociale))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.PartitaIVA), q => q.PartitaIVA.Contains(ditta.Filter.PartitaIVA))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.CognomeRiferimento), q => q.CognomeRiferimento.Contains(ditta.Filter.CognomeRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.NomeRiferimento), q => q.NomeRiferimento.Contains(ditta.Filter.NomeRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(ditta.Filter.TelefonoRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.MailRiferimento), q => q.MailRiferimento.Contains(ditta.Filter.MailRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.SecureKey), q => q.SecureKey.Contains(ditta.Filter.SecureKey))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.IdVendor.ToString()), q => q.IdVendor.Equals(ditta.Filter.IdVendor))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.CodiceFornitore), q => q.CodiceFornitore.Contains(ditta.Filter.CodiceFornitore))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.IdVendorPurchaseOrg.ToString()), q => q.IdVendorPurchaseOrg.Equals(ditta.Filter.IdVendorPurchaseOrg))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.PurchaseOrg), q => q.PurchaseOrg.Contains(ditta.Filter.PurchaseOrg))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.IdZona.ToString()), q => q.IdZona.Equals(ditta.Filter.IdZona))
                    .WhereIf((conditionZone.Equals(true) && !String.IsNullOrEmpty(ditta.Filter.Zona.Zona)), q => q.Zona.Zona.Contains(ditta.Filter.Zona.Zona))
                    .OrderBy(sortParam).Skip(ditta.NumeroElementi * ditta.Page).Take(ditta.NumeroElementi)
                    .Include("Zona")
                    .ToListAsync();
            }
            else
            {
                ditte = await _RCDDbContext.Ditta.Where(x => x.Abilitato == true && !idFittizia.Contains((long)x.Id))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.RagioneSociale), q => q.RagioneSociale.Contains(ditta.Filter.RagioneSociale))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.PartitaIVA), q => q.PartitaIVA.Contains(ditta.Filter.PartitaIVA))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.CognomeRiferimento), q => q.CognomeRiferimento.Contains(ditta.Filter.CognomeRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.NomeRiferimento), q => q.NomeRiferimento.Contains(ditta.Filter.NomeRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(ditta.Filter.TelefonoRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.MailRiferimento), q => q.MailRiferimento.Contains(ditta.Filter.MailRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.SecureKey), q => q.SecureKey.Contains(ditta.Filter.SecureKey))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.IdVendor.ToString()), q => q.IdVendor.Equals(ditta.Filter.IdVendor))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.CodiceFornitore), q => q.CodiceFornitore.Contains(ditta.Filter.CodiceFornitore))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.IdVendorPurchaseOrg.ToString()), q => q.IdVendorPurchaseOrg.Equals(ditta.Filter.IdVendorPurchaseOrg))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.PurchaseOrg), q => q.PurchaseOrg.Contains(ditta.Filter.PurchaseOrg))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.IdZona.ToString()), q => q.IdZona.Equals(ditta.Filter.IdZona))
                   .WhereIf((conditionZone.Equals(true) && !String.IsNullOrEmpty(ditta.Filter.Zona.Zona)), q => q.Zona.Zona.Contains(ditta.Filter.Zona.Zona))
                    .OrderBy(sortParam)
                    .Include("Zona")
                    .ToListAsync();

            }
           
            List<ContractDitta> ditteElenco = new List<ContractDitta>();
            foreach (EntityDitta varDitta in ditte)
            {
                ContractDitta ditta1 = new ContractDitta();
                UtilityManager.MapProp(varDitta, ditta1);
                ditteElenco.Add(ditta1);
            }
            return ditteElenco;
        }

        public async Task<Int32> GetDitteTot(DittaRequestFull ditta)
        {
            List<EntityDitta> ditte;
            List<long> idFittizia = new List<long>() { 1, 2, 3, 4 };
            bool conditionZone = ditta.Filter.Zona is not null;
            ditte = await _RCDDbContext.Ditta.Where(x => x.Abilitato == true && !idFittizia.Contains((long)x.Id))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.RagioneSociale), q => q.RagioneSociale.Contains(ditta.Filter.RagioneSociale))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.PartitaIVA), q => q.PartitaIVA.Contains(ditta.Filter.PartitaIVA))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.CognomeRiferimento), q => q.CognomeRiferimento.Contains(ditta.Filter.CognomeRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.NomeRiferimento), q => q.NomeRiferimento.Contains(ditta.Filter.NomeRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(ditta.Filter.TelefonoRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.MailRiferimento), q => q.MailRiferimento.Contains(ditta.Filter.MailRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.SecureKey), q => q.SecureKey.Contains(ditta.Filter.SecureKey))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.IdVendor.ToString()), q => q.IdVendor.Equals(ditta.Filter.IdVendor))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.CodiceFornitore), q => q.CodiceFornitore.Contains(ditta.Filter.CodiceFornitore))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.IdVendorPurchaseOrg.ToString()), q => q.IdVendorPurchaseOrg.Equals(ditta.Filter.IdVendorPurchaseOrg))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.PurchaseOrg), q => q.PurchaseOrg.Contains(ditta.Filter.PurchaseOrg))
                    .WhereIf(!String.IsNullOrEmpty(ditta.Filter.IdZona.ToString()), q => q.IdZona.Equals(ditta.Filter.IdZona))
                    .WhereIf((conditionZone.Equals(true) && !String.IsNullOrEmpty(ditta.Filter.Zona.Zona)), q => q.Zona.Zona.Contains(ditta.Filter.Zona.Zona))
                    .ToListAsync();

            return ditte.Count();

        }


        public async Task<List<ContractAnagraficaFornitori>> GetAnagraficaFornitoriSts(AnagraficaFornitoriRequestFull anagraficaFornitore, List<long?> idDitteCode)
        {
            List<EntityAnagraficaFornitori> anagraficaFornitoriSts;
            String sortParam = String.Concat(String.Concat(anagraficaFornitore.CampoOrdinamento, " "), anagraficaFornitore.Ordinamento.ToUpper());

            if (anagraficaFornitore.Pageable)
            {
        
                anagraficaFornitoriSts = await _RCDDbContext.AnagraficaFornitore
                .Where(q => !idDitteCode.Contains(q.IdVendor))
                .WhereIf(!String.IsNullOrEmpty(anagraficaFornitore.Filter.DescrizioneFornitore), q => q.DescrizioneFornitore.Contains(anagraficaFornitore.Filter.DescrizioneFornitore))
                .WhereIf(!String.IsNullOrEmpty(anagraficaFornitore.Filter.PartitaIva), q => q.PartitaIva.Contains(anagraficaFornitore.Filter.PartitaIva))
                .WhereIf(!String.IsNullOrEmpty(anagraficaFornitore.Filter.CodiceFornitore), q => q.CodiceFornitore.Contains(anagraficaFornitore.Filter.CodiceFornitore))
                .OrderBy(sortParam).Skip(anagraficaFornitore.NumeroElementi * anagraficaFornitore.Page).Take(anagraficaFornitore.NumeroElementi)
                // .Include("Zona")
                .ToListAsync();

            }
            else
            {
                anagraficaFornitoriSts = await _RCDDbContext.AnagraficaFornitore
                .WhereIf(!String.IsNullOrEmpty(anagraficaFornitore.Filter.DescrizioneFornitore), q => q.DescrizioneFornitore.Contains(anagraficaFornitore.Filter.DescrizioneFornitore))
                .WhereIf(!String.IsNullOrEmpty(anagraficaFornitore.Filter.PartitaIva), q => q.PartitaIva.Contains(anagraficaFornitore.Filter.PartitaIva))
                .WhereIf(!String.IsNullOrEmpty(anagraficaFornitore.Filter.CodiceFornitore), q => q.CodiceFornitore.Contains(anagraficaFornitore.Filter.CodiceFornitore))
                .OrderBy(sortParam).Skip(anagraficaFornitore.NumeroElementi * anagraficaFornitore.Page).Take(anagraficaFornitore.NumeroElementi)
               .Where(q => !idDitteCode.Contains(q.IdVendor))
               .OrderBy(sortParam)
              //  .Include("Zona")
               .ToListAsync();
            }

            List<ContractAnagraficaFornitori> anagraficaFornitoreElenco = new List<ContractAnagraficaFornitori>();
            foreach (EntityAnagraficaFornitori varAnagraficaFornitore in anagraficaFornitoriSts)
            {
                ContractAnagraficaFornitori anagraficaFornitore1 = new ContractAnagraficaFornitori();
                UtilityManager.MapProp(varAnagraficaFornitore, anagraficaFornitore1);
                anagraficaFornitoreElenco.Add(anagraficaFornitore1);
            }
            return anagraficaFornitoreElenco;
        }

        public async Task<Int32> GetAnagraficaFornitoriStsTot(AnagraficaFornitoriRequestFull anagraficaFornitore, List<long?> idDitteCode)
        {
            List<EntityAnagraficaFornitori> anagraficaFornitoriSts;
           // bool conditionAnagraficaFornitore = anagraficaFornitore.Filter.AnagraficaFornitore is not null;

            anagraficaFornitoriSts = await _RCDDbContext.AnagraficaFornitore
             .WhereIf(!String.IsNullOrEmpty(anagraficaFornitore.Filter.DescrizioneFornitore), q => q.DescrizioneFornitore.Contains(anagraficaFornitore.Filter.DescrizioneFornitore))
                .WhereIf(!String.IsNullOrEmpty(anagraficaFornitore.Filter.PartitaIva), q => q.PartitaIva.Contains(anagraficaFornitore.Filter.PartitaIva))
                .WhereIf(!String.IsNullOrEmpty(anagraficaFornitore.Filter.CodiceFornitore), q => q.CodiceFornitore.Contains(anagraficaFornitore.Filter.CodiceFornitore))
            .Where(q => !idDitteCode.Contains(q.IdVendor))
            .ToListAsync();

            return anagraficaFornitoriSts.Count();

        }

        private string CreaSecureKey(EntityDitta ditta)
        {
            try
            {
                StringBuilder builder = new StringBuilder();
                Random random = new Random(unchecked((int)DateTime.Now.Ticks));
                char ch;
                for (int i = 0; i < 25; i++)
                {
                    ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
                    builder.Append(ch);
                }
                string generateSecureKey = builder.ToString();
                return generateSecureKey;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void AddDitta(DittaRequest ditta)
        {
            try
            {
                EntityDitta dittaToAdd = new EntityDitta();

                if (string.IsNullOrWhiteSpace(ditta.SecureKey))
                    ditta.SecureKey = CreaSecureKey(dittaToAdd);

                UtilityManager.MapProp(ditta, dittaToAdd);

                if (string.IsNullOrEmpty(ditta.Password))
                    dittaToAdd.Password = "--"; //evito errore nel caso sia null

                dittaToAdd.Abilitato = true;
                dittaToAdd.IsDefaultPasswordChanged = false;
                dittaToAdd.IsAccountTemporaryLocked = false;

                var result = _RCDDbContext.Add(dittaToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }


        public EntityDitta GetDittaById(DittaRequestFull dittaR)
        {
            var dittaOld = _RCDDbContext.Ditta.Where(x => x.Id.Equals(dittaR.Filter.Id)).FirstOrDefault();
      

            EntityDitta dittaToAdd = new EntityDitta();

            if (dittaR.Filter.SecureKey is null)
                dittaToAdd.SecureKey = dittaOld.SecureKey;
            if (dittaR.Filter.IdVendor is null)
                dittaToAdd.IdVendor = dittaOld.IdVendor;
            if (dittaR.Filter.CodiceFornitore is null)
                dittaToAdd.CodiceFornitore = dittaOld.CodiceFornitore;
            if (dittaR.Filter.PurchaseOrg is null)
                dittaToAdd.PurchaseOrg = dittaOld.PurchaseOrg;
            if (dittaR.Filter.IdZona is null)
                dittaToAdd.IdZona = dittaOld.IdZona;
            if (dittaR.Filter.Password is null)
                dittaToAdd.Password = dittaOld.Password;
            if (dittaR.Filter.IsDefaultPasswordChanged is null)
                dittaToAdd.IsDefaultPasswordChanged = dittaOld.IsDefaultPasswordChanged;
            if (dittaR.Filter.IsAccountTemporaryLocked is null)
                dittaToAdd.IsAccountTemporaryLocked = dittaOld.IsAccountTemporaryLocked;
            if (dittaR.Filter.LockedDate is null)
                dittaToAdd.LockedDate = dittaOld.LockedDate;
            if (dittaR.Filter.Is2FAEnabled is null)
                dittaToAdd.Is2FAEnabled = dittaOld.Is2FAEnabled;
            if (dittaR.Filter.SecretKey is null)
                dittaToAdd.SecretKey = dittaOld.SecretKey;

            //strField = a.PurchaseOrg;
            //    _RCDDbContext.Entry(dittaOld).State = Microsoft.EntityFrameworkCore.EntityState.Detached;

            return dittaToAdd;
        }


        public void UpdateDitta(DittaRequest dittaR)
        {
            try
            {
                EntityDitta dittaToAdd = new EntityDitta(); 
                UtilityManager.MapProp(dittaR, dittaToAdd);

                var dittaOld = _RCDDbContext.Ditta.Where(x => x.Id.Equals(dittaR.Id)).FirstOrDefault();

                if (string.IsNullOrEmpty(dittaR.SecureKey))
                    dittaToAdd.SecureKey = dittaOld.SecureKey;
                if (dittaR.IdVendor is null)
                    dittaToAdd.IdVendor = dittaOld.IdVendor;
                if (string.IsNullOrEmpty(dittaR.CodiceFornitore))
                    dittaToAdd.CodiceFornitore = dittaOld.CodiceFornitore;
                if (string.IsNullOrEmpty(dittaR.PurchaseOrg))
                    dittaToAdd.PurchaseOrg = dittaOld.PurchaseOrg;
                if (dittaR.IdVendorPurchaseOrg is null)
                    dittaToAdd.IdVendorPurchaseOrg = dittaOld.IdVendorPurchaseOrg;
                if (dittaR.IdZona is null)
                    dittaToAdd.IdZona = dittaOld.IdZona;
                if (string.IsNullOrEmpty(dittaR.Password))
                    dittaToAdd.Password = dittaOld.Password;
                if (dittaR.IsDefaultPasswordChanged is null)
                    dittaToAdd.IsDefaultPasswordChanged = dittaOld.IsDefaultPasswordChanged;
                if (dittaR.IsAccountTemporaryLocked is null)
                    dittaToAdd.IsAccountTemporaryLocked = dittaOld.IsAccountTemporaryLocked;
                if (dittaR.LockedDate is null)
                    dittaToAdd.LockedDate = dittaOld.LockedDate;
                if (dittaR.Is2FAEnabled is null)
                    dittaToAdd.Is2FAEnabled = dittaOld.Is2FAEnabled;
                if (string.IsNullOrEmpty(dittaR.SecretKey))
                    dittaToAdd.SecretKey = dittaOld.SecretKey;
                if (dittaR.Abilitato is null)
                    dittaToAdd.Abilitato = dittaOld.Abilitato;

                _RCDDbContext.Entry(dittaOld).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
         
                var result = _RCDDbContext.Update(dittaToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteDitta(DittaRequest ditta)
        {
            try
            {
                EntityDitta entityDittaToUpdate = _RCDDbContext.Ditta.FirstOrDefault(item => item.Id == ditta.Id);

                if (entityDittaToUpdate != null)
                {
                    entityDittaToUpdate.Abilitato = false;
                    var result = _RCDDbContext.Update(entityDittaToUpdate);
                    _RCDDbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }


    }
}
