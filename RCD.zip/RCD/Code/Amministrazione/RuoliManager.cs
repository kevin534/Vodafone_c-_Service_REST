﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class RuoliManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public RuoliManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractRuolo>> GetRuoli(RuoloRequestFull ruolo)
        {
            List<EntityRuolo> ruoli;
            String sortParam = String.Concat(String.Concat(ruolo.CampoOrdinamento, " "), ruolo.Ordinamento.ToUpper());

            if (ruolo.Pageable)
            {
                ruoli = await _RCDDbContext.Ruolo.Where(x => x.DescrizioneRuolo.Contains(ruolo.Filter.DescrizioneRuolo))
                             .WhereIf(!String.IsNullOrEmpty(ruolo.Filter.NoteRuolo), q => q.NoteRuolo.Contains(ruolo.Filter.NoteRuolo))
                             .OrderBy(sortParam)
                             .Skip(ruolo.NumeroElementi * ruolo.Page).Take(ruolo.NumeroElementi).ToListAsync();
            }
            else
            {
                ruoli = await _RCDDbContext.Ruolo
                    .Where(x => x.DescrizioneRuolo.Contains(ruolo.Filter.DescrizioneRuolo))
                    .WhereIf(!String.IsNullOrEmpty(ruolo.Filter.NoteRuolo), q => q.NoteRuolo.Contains(ruolo.Filter.NoteRuolo))
                    .OrderBy(sortParam)
                    .ToListAsync();
            }


            List<ContractRuolo> ruoliElenco = new List<ContractRuolo>();

            foreach (EntityRuolo varRuolo in ruoli)
            {
                ContractRuolo ruolo1 = new ContractRuolo();
                UtilityManager.MapProp(varRuolo, ruolo1);
                ruoliElenco.Add(ruolo1);
            }
            return ruoliElenco;
        }

        public async Task<Int32> GetRuoliTot(RuoloRequestFull ruolo)
        {
            List<EntityRuolo> ruoli;

            ruoli = await _RCDDbContext.Ruolo.Where(x => x.DescrizioneRuolo.Contains(ruolo.Filter.DescrizioneRuolo)).ToListAsync();


            return ruoli.Count();
        }
        public void AddRuolo(RuoloRequest ruolo)
        {
            try
            {
                EntityRuolo ruoloToAdd = new EntityRuolo();
                UtilityManager.MapProp(ruolo, ruoloToAdd);
                var result = _RCDDbContext.Add(ruoloToAdd);
                _RCDDbContext.SaveChanges();
                Int64 id = (Int64)(ruoloToAdd.Id);
                foreach (var contractRuoloPrivilegio in ruolo.listRuoloPrivilegio)
                {

                    EntityRuoloPrivilegio ruoloPrivilegio = new EntityRuoloPrivilegio();
                    ruoloPrivilegio.IdPrivilegio = contractRuoloPrivilegio.IdPrivilegio;
                    ruoloPrivilegio.IdRuolo = id;
                    var result1 = _RCDDbContext.Add(ruoloPrivilegio);

                }

                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void UpdateRuolo(RuoloRequest ruolo)
        {
            try
            {
                EntityRuolo ruoloToAdd = new EntityRuolo();
                UtilityManager.MapProp(ruolo, ruoloToAdd);
                var result = _RCDDbContext.Update(ruoloToAdd);
                foreach (var contractRuoloPrivilegio in ruolo.listRuoloPrivilegio)
                {
                    if (_RCDDbContext.RuoloPrivilegio.Count(x => x.IdRuolo == ruolo.Id && x.IdPrivilegio == contractRuoloPrivilegio.IdPrivilegio) == 0)
                    {
                        EntityRuoloPrivilegio ruoloPrivilegio = new EntityRuoloPrivilegio();
                        ruoloPrivilegio.IdPrivilegio = contractRuoloPrivilegio.IdPrivilegio;
                        ruoloPrivilegio.IdRuolo = ruoloToAdd.Id;
                        var result1 = _RCDDbContext.Add(ruoloPrivilegio);
                    }
                }
                foreach (var entityRuoloPrivilegio in _RCDDbContext.RuoloPrivilegio.Where(x => x.IdRuolo == ruoloToAdd.Id).ToList())
                {
                    if (ruolo.listRuoloPrivilegio.Count(x =>  x.IdPrivilegio == entityRuoloPrivilegio.IdPrivilegio) == 0)
                    {
                       
                        var result1 = _RCDDbContext.RuoloPrivilegio.Remove(entityRuoloPrivilegio);
                    }
                }
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void DeleteRuolo(RuoloRequest ruolo)
        {
            try
            {
                EntityRuolo ruoloToAdd = new EntityRuolo();
                UtilityManager.MapProp(ruolo, ruoloToAdd);
                var result = _RCDDbContext.Remove(ruoloToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public async Task<List<ContractPrivilegio>> GetPrivilegi()
        {
            List<EntityPrivilegio> privilegi;
            privilegi = await _RCDDbContext.Privilegio.Where(x => x.Abilitato == true)
                                .ToListAsync();
            List<ContractPrivilegio> privilegioElenco = new List<ContractPrivilegio>();
            foreach (EntityPrivilegio varPrivilegio in privilegi)
            {
                ContractPrivilegio privilegio = new ContractPrivilegio();
                UtilityManager.MapProp(varPrivilegio, privilegio);
                privilegioElenco.Add(privilegio);
            }
            return privilegioElenco;
        }
        public async Task<List<ContractPrivilegioGruppo>> GetPrivilegiByRuolo(RuoloRequest ruolo)
        {
            List<EntityPrivilegio> privilegi = await _RCDDbContext.Privilegio.Where(x => x.Abilitato == true).OrderBy(x => x.Gruppo).ThenBy(x => x.Posizione)
                                                    .ToListAsync();
            List<EntityRuoloPrivilegio> privilegiRuolo = await _RCDDbContext.RuoloPrivilegio.Where(x => x.IdRuolo == ruolo.Id)
                                                    .ToListAsync();

            List<ContractPrivilegioGruppo> privilegiElenco = new List<ContractPrivilegioGruppo>();
            ContractPrivilegioGruppo privilegioGruppo = new ContractPrivilegioGruppo();
            foreach (EntityPrivilegio varPrivilegio in privilegi)
            {
                if (!privilegiElenco.Exists(x => x.PrivilegioPadre == varPrivilegio.Gruppo))
                {

                    privilegioGruppo = new ContractPrivilegioGruppo();
                    privilegioGruppo.PrivilegioPadre = varPrivilegio.Gruppo;
                    privilegiElenco.Add(privilegioGruppo);
                }

                ContractPrivilegio privilegio = new ContractPrivilegio();
                UtilityManager.MapProp(varPrivilegio, privilegio);
                privilegio.IsSelected = privilegiRuolo.Where(x => x.IdPrivilegio == varPrivilegio.Id).Count() > 0;
                privilegioGruppo.ElencoPrivilegio.Add(privilegio);
            }

            return privilegiElenco;
        }
    }
}
