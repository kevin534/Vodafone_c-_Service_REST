﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Request;
using RCDEngine.Entities;
using RCDContracts.Data;
using System.Security.Claims;

namespace RCD.Code.Amministrazione
{
    public class UtentiManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;
        private System.Security.Claims.ClaimsPrincipal principal;

        public UtentiManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
        public async Task<List<ContractUtente>> GetUtenti(UtenteRequestFull utente)
        {
            List<EntityUtente> utenti;
            String sortParam = String.Concat(String.Concat(utente.CampoOrdinamento, " "), utente.Ordinamento.ToUpper());

            if (utente.Pageable)
            {
                utenti = await _RCDDbContext.Utente.Where(x => x.Abilitato == true)
                            .WhereIf(!String.IsNullOrEmpty(utente.Filter.Username), q => q.Username.Contains(utente.Filter.Username))
                            .WhereIf(!String.IsNullOrEmpty(utente.Filter.Cognome), q => q.Cognome.Contains(utente.Filter.Cognome))
                            .WhereIf(!String.IsNullOrEmpty(utente.Filter.Nome), q => q.Nome.Contains(utente.Filter.Nome))
                            .WhereIf(!String.IsNullOrEmpty(utente.Filter.Telefono), q => q.Telefono.Contains(utente.Filter.Telefono))
                            .WhereIf(!String.IsNullOrEmpty(utente.Filter.Mail), q => q.Mail.Contains(utente.Filter.Mail))
                            .WhereIf(utente.Filter.AreaVendita != null && !String.IsNullOrEmpty(utente.Filter.AreaVendita.Descrizione), q => q.AreaVendita.Descrizione.Contains(utente.Filter.AreaVendita.Descrizione))
                            .WhereIf(utente.Filter.Ruolo != null && !String.IsNullOrEmpty(utente.Filter.Ruolo.DescrizioneRuolo), q => q.Ruolo.DescrizioneRuolo.Contains(utente.Filter.Ruolo.DescrizioneRuolo))
                            .WhereIf(utente.Filter.Zona != null && !String.IsNullOrEmpty(utente.Filter.Zona.Zona), q => q.Zona.Zona.Contains(utente.Filter.Zona.Zona))
                            .WhereIf(!String.IsNullOrEmpty(utente.Filter.IdRuolo.ToString()), q => q.IdRuolo == utente.Filter.IdRuolo)
                            .OrderBy(sortParam)
                            .Skip(utente.NumeroElementi * utente.Page).Take(utente.NumeroElementi).Include("Zona")
                            .Include("CanaleVendita")
                            .Include("CanaleVenditaDettaglio")
                            .Include("AreaVendita")
                            .Include("Ruolo")
                            .Include("TipologiaUtente")
                            .Include("ListUtenteProvincia.StsProvincia")
                            .ToListAsync();

            }
            else
            {
                utenti = await _RCDDbContext.Utente.Where(x => x.Abilitato == true)
                            .WhereIf(!String.IsNullOrEmpty(utente.Filter.Username), q => q.Username.Contains(utente.Filter.Username))
                            .WhereIf(!String.IsNullOrEmpty(utente.Filter.Cognome), q => q.Cognome.Contains(utente.Filter.Cognome))
                            .WhereIf(!String.IsNullOrEmpty(utente.Filter.Nome), q => q.Nome.Contains(utente.Filter.Nome))
                            .WhereIf(!String.IsNullOrEmpty(utente.Filter.IdRuolo.ToString()), q => q.IdRuolo == utente.Filter.IdRuolo)
                            .WhereIf(utente.Filter.AreaVendita != null && !String.IsNullOrEmpty(utente.Filter.AreaVendita.Descrizione), q => q.AreaVendita.Descrizione.Contains(utente.Filter.AreaVendita.Descrizione))
                            .WhereIf(utente.Filter.Ruolo != null && !String.IsNullOrEmpty(utente.Filter.Ruolo.DescrizioneRuolo), q => q.Ruolo.DescrizioneRuolo.Contains(utente.Filter.Ruolo.DescrizioneRuolo))
                            .WhereIf(utente.Filter.Zona != null && !String.IsNullOrEmpty(utente.Filter.Zona.Zona), q => q.Zona.Zona.Contains(utente.Filter.Zona.Zona))
                            .OrderBy(sortParam)
                            .Include("Zona")
                            .Include("CanaleVendita")
                            .Include("CanaleVenditaDettaglio")
                            .Include("AreaVendita")
                            .Include("Ruolo")
                            .Include("TipologiaUtente")
                            .Include("ListUtenteProvincia.StsProvincia")
                            .ToListAsync();
            }

            List<ContractUtente> utentiElenco = new List<ContractUtente>();
            foreach (EntityUtente varUtente in utenti)
            {
                ContractUtente utente1 = new ContractUtente();
                UtilityManager.MapProp(varUtente, utente1);
                if(varUtente.ListUtenteProvincia != null)
                {
                    List<ContractUtentiProvincie> listProvince = new List<ContractUtentiProvincie>();
                    foreach(EntityUtentiProvince  uP in varUtente.ListUtenteProvincia)
                    {
                        ContractUtentiProvincie uProvincia = new ContractUtentiProvincie();
                        UtilityManager.MapProp(uP, uProvincia);
                        listProvince.Add(uProvincia);
                    }
                    utente1.ListProvinceUtente = listProvince;
                }
                utentiElenco.Add(utente1);
            }
            return utentiElenco;
        }
        public async Task<Int32> GetUtentiTot(UtenteRequestFull utente)
        {
            //string returnAddress = principal.Claims.FirstOrDefault(
            // c => c.Type == ClaimTypes.UserData)?.Value;
            List<EntityUtente> utenti;


            utenti = await _RCDDbContext.Utente.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(utente.Filter.Username), q => q.Username.Contains(utente.Filter.Username))
                        .WhereIf(!String.IsNullOrEmpty(utente.Filter.Cognome), q => q.Cognome.Contains(utente.Filter.Cognome))
                        .WhereIf(!String.IsNullOrEmpty(utente.Filter.Nome), q => q.Nome.Contains(utente.Filter.Nome))
                        .WhereIf(!String.IsNullOrEmpty(utente.Filter.IdRuolo.ToString()), q => q.IdRuolo == utente.Filter.IdRuolo)
                        .WhereIf(utente.Filter.AreaVendita != null && !String.IsNullOrEmpty(utente.Filter.AreaVendita.Descrizione), q => q.AreaVendita.Descrizione.Contains(utente.Filter.AreaVendita.Descrizione))
                        .WhereIf(utente.Filter.Ruolo != null && !String.IsNullOrEmpty(utente.Filter.Ruolo.DescrizioneRuolo), q => q.Ruolo.DescrizioneRuolo.Contains(utente.Filter.Ruolo.DescrizioneRuolo))
                        .WhereIf(utente.Filter.Zona != null && !String.IsNullOrEmpty(utente.Filter.Zona.Zona), q => q.Zona.Zona.Contains(utente.Filter.Zona.Zona))
                        .ToListAsync();
            return utenti.Count();

        }

        public async Task<EntityUtente> GetUtenteById(long idUtente)
        {
            EntityUtente utente = await _RCDDbContext.Utente
                 .Include("TipologiaUtente")
                 .Include("AreaVendita")
                 .Where(x => x.Id == idUtente).FirstOrDefaultAsync();
            return utente;
        }

        public async Task<EntityUtente> GetUtenteByUtente(UtenteRequest utente)
        {
            EntityUtente resUtente = await _RCDDbContext.Utente.Where(x => x.Username == utente.Username).FirstOrDefaultAsync();
            return resUtente;
        }

        public void AddUtente(UtenteRequest utente)
        {
            try
            {
                EntityUtente utenteToAdd = new EntityUtente();
                UtilityManager.MapProp(utente, utenteToAdd);
                var result = _RCDDbContext.Add(utenteToAdd);
                _RCDDbContext.SaveChanges();
                Int64 id = (Int64)(utenteToAdd.Id);
                if (utente.ListProvinceUtente != null)
                {
                    foreach (var contractUtenteProvince in utente.ListProvinceUtente)
                    {
                        EntityUtentiProvince utenteProvince = new EntityUtentiProvince();
                        utenteProvince.IdProvincia = contractUtenteProvince.IdProvincia;
                        utenteProvince.IdUtente = id;
                        var result1 = _RCDDbContext.Add(utenteProvince);
                    }
                }


                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateUtente(UtenteRequest utente)
        {
            try
            {
                EntityUtente utenteToEdit = new EntityUtente();
                UtilityManager.MapProp(utente, utenteToEdit);
                var result = _RCDDbContext.Update(utenteToEdit);
                if (utente.ListProvinceUtente != null)
                {
                    foreach (var contractUtenteProvince in utente.ListProvinceUtente)
                    {
                        if (_RCDDbContext.UtentiProvince.Count(x => x.IdUtente == utente.Id && x.IdProvincia == contractUtenteProvince.IdProvincia) == 0)
                        {
                            EntityUtentiProvince utenteProvince = new EntityUtentiProvince();
                            utenteProvince.IdProvincia = contractUtenteProvince.IdProvincia;
                            utenteProvince.IdUtente = utente.Id;
                            var result1 = _RCDDbContext.Add(utenteProvince);
                        }
                    }
                    foreach (var entityUtenteProvince in _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id).ToList())
                    {
                        if (utente.ListProvinceUtente.Count(x => x.IdProvincia == entityUtenteProvince.IdProvincia) == 0)
                        {

                            var result1 = _RCDDbContext.UtentiProvince.Remove(entityUtenteProvince);
                        }
                    }
                }
                else
                {
                    foreach (var entityUtenteProvince in _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id).ToList())
                    {
                        var result1 = _RCDDbContext.UtentiProvince.Remove(entityUtenteProvince);
                    }
                }

                _RCDDbContext.SaveChanges();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteUtente(UtenteRequest utente)
        {
            try
            {
                EntityUtente utenteToRemove = _RCDDbContext.Utente.Where(x => x.Id == utente.Id).FirstOrDefault();

                utenteToRemove.Abilitato = false;
                var result = _RCDDbContext.Update(utenteToRemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public async Task<List<ContractTipologiaUtente>> GetTipologia()
        {
            List<EntityTipologiaUtente> tipologia;

            tipologia = await _RCDDbContext.TipologiaUtente.OrderBy(x => x.TipologiaUtente)
                                .ToListAsync();


            List<ContractTipologiaUtente> tipologieElenco = new List<ContractTipologiaUtente>();
            foreach (EntityTipologiaUtente varTipologia in tipologia)
            {
                ContractTipologiaUtente tipologia1 = new ContractTipologiaUtente();
                UtilityManager.MapProp(varTipologia, tipologia1);
                tipologieElenco.Add(tipologia1);
            }
            return tipologieElenco;
        }


    }



}
