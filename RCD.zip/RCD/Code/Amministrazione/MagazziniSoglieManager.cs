﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class MagazziniSoglieManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public MagazziniSoglieManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        #region "MAGAZZINO SOGLIA"
        public async Task<List<EntityMagazzino>> GetMagazzinoSoglieById(MagazzinoSogliaRequestFull magazzinoSoglie)
        {

            List<EntityMagazzino> magazzini;

            String sortParam = String.Concat(String.Concat(magazzinoSoglie.CampoOrdinamento, " "), magazzinoSoglie.Ordinamento.ToUpper());

            if (magazzinoSoglie.Pageable)
            {
                magazzini = await _RCDDbContext.Magazzino.Where(x => x.Id.Equals(magazzinoSoglie.Filter.Id)
                            ).OrderBy(sortParam)
                            .Skip(magazzinoSoglie.NumeroElementi * magazzinoSoglie.Page).Take(magazzinoSoglie.NumeroElementi)
                            .Include("Zona").ToListAsync();
            }
            else
            {

                magazzini = await _RCDDbContext.Magazzino.Where(x => x.Id.Equals(magazzinoSoglie.Filter.Id)
                            ).Include("Zona").OrderBy(sortParam)
                            .ToListAsync();   //.Include("TipologiaApparatoSoglia.TipologiaApparato")
            }

            List<EntityMagazzino> elMagazziniElenco = new List<EntityMagazzino>();
            foreach (EntityMagazzino varMagazzino in magazzini)
            {
                varMagazzino.listTipologiaApparatoSoglia = _RCDDbContext.TipologiaApparatoSoglia.Where(x => x.IdMagazzino.Equals(varMagazzino.Id)).ToList(); 
                for (int i=0; i < varMagazzino.listTipologiaApparatoSoglia.Count; i++)
                {
                    varMagazzino.listTipologiaApparatoSoglia[i].TipologiaApparato = _RCDDbContext.TipologiaApparato.Where(x => x.Id.Equals(varMagazzino.listTipologiaApparatoSoglia[i].IdTipologiaApparato)).FirstOrDefault();
                }

                varMagazzino.listTipologiaAntennaSoglia = _RCDDbContext.TipologiaAntennaSoglia.Where(x => x.IdMagazzino.Equals(varMagazzino.Id)).ToList(); 
                for (int i = 0; i < varMagazzino.listTipologiaAntennaSoglia.Count; i++)
                {
                    varMagazzino.listTipologiaAntennaSoglia[i].TipologiaAntenna = _RCDDbContext.TipologiaAntenna.Where(x => x.Id.Equals(varMagazzino.listTipologiaAntennaSoglia[i].IdTipologiaAntenna)).FirstOrDefault();
                }

                varMagazzino.listTipologiaAccessorioSoglia = _RCDDbContext.TipologiaAccessorioSoglia.Where(x => x.IdMagazzino.Equals(varMagazzino.Id)).ToList(); 
                for (int i = 0; i < varMagazzino.listTipologiaAccessorioSoglia.Count; i++)
                {
                    varMagazzino.listTipologiaAccessorioSoglia[i].TipologiaAccessorio = _RCDDbContext.TipologiaAccessorio.Where(x => x.Id.Equals(varMagazzino.listTipologiaAccessorioSoglia[i].IdTipologiaAccessorio)).FirstOrDefault();
                }

                elMagazziniElenco.Add(varMagazzino);
       
                //      //ContractMagazzino magazzino1 = new ContractMagazzino();
                //      //UtilityManager.MapProp(varMagazzino, magazzino1);
                //      //magazziniElenco.Add(magazzino1);
            }

            return elMagazziniElenco; //magazziniElenco


        }
    
        public async Task<Int32> GetMagazzinoSoglieTot(MagazzinoSogliaRequestFull magazzinoSoglie)
        {
            List<EntityMagazzino> magazzini;
            magazzini = await _RCDDbContext.Magazzino.Where(x => x.Id.Equals(magazzinoSoglie.Filter.Id)
                             ).ToListAsync();

            return magazzini.Count();
        }

        #endregion

        #region "TIPOLOGIA APPARATO SOGLIA"
        public void UpdateTipologiaApparatoSoglia(TipologiaApparatoSogliaRequest tipologiaApparatoSoglia)
        {
            try
            {
                EntityTipologiaApparatoSoglia tipologiaApparatoSogliaToUpdate = new EntityTipologiaApparatoSoglia();
                UtilityManager.MapProp(tipologiaApparatoSoglia, tipologiaApparatoSogliaToUpdate);
                var result = _RCDDbContext.Update(tipologiaApparatoSogliaToUpdate);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void AddTipologiaApparatoSoglia(TipologiaApparatoSogliaRequest tipologiaApparatoSoglia)
        {
            try
            {
                EntityTipologiaApparatoSoglia tipologiaApparatoSogliaToAdd = new EntityTipologiaApparatoSoglia();
                UtilityManager.MapProp(tipologiaApparatoSoglia, tipologiaApparatoSogliaToAdd);
                var result = _RCDDbContext.Add(tipologiaApparatoSogliaToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void DeleteTipologiaApparatoSoglia(TipologiaApparatoSogliaRequest tipologiaApparatoSoglia)
        {
            try
            {
                EntityTipologiaApparatoSoglia tipologiaApparatoSogliaToRemove = new EntityTipologiaApparatoSoglia();
                UtilityManager.MapProp(tipologiaApparatoSoglia, tipologiaApparatoSogliaToRemove);
                var result = _RCDDbContext.Remove(tipologiaApparatoSogliaToRemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        #endregion

        #region "TIPOLOGIA ANTENNA SOGLIA"
        public void UpdateTipologiaAntennaSoglia(TipologiaAntennaSogliaRequest tipologiaAntennaSoglia)
        {
            try
            {
                EntityTipologiaAntennaSoglia tipologiaAntennaSogliaToUpdate = new EntityTipologiaAntennaSoglia();
                UtilityManager.MapProp(tipologiaAntennaSoglia, tipologiaAntennaSogliaToUpdate);
                var result = _RCDDbContext.Update(tipologiaAntennaSogliaToUpdate);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void AddTipologiaAntennaSoglia(TipologiaAntennaSogliaRequest tipologiaAntennaSoglia)
        {
            try
            {
                EntityTipologiaAntennaSoglia tipologiaAntennaSogliaToAdd = new EntityTipologiaAntennaSoglia();
                UtilityManager.MapProp(tipologiaAntennaSoglia, tipologiaAntennaSogliaToAdd);
                var result = _RCDDbContext.Add(tipologiaAntennaSogliaToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void DeleteTipologiaAntennaSoglia(TipologiaAntennaSogliaRequest tipologiaAntennaSoglia)
        {
            try
            {
                EntityTipologiaAntennaSoglia tipologiaAntennaSogliaToRemove = new EntityTipologiaAntennaSoglia();
                UtilityManager.MapProp(tipologiaAntennaSoglia, tipologiaAntennaSogliaToRemove);
                var result = _RCDDbContext.Remove(tipologiaAntennaSogliaToRemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        #endregion

        #region "TIPOLOGIA ACCESSORIO SOGLIA"
        public void UpdateTipologiaAccessorioSoglia(TipologiaAccessorioSogliaRequest tipologiaAccessorioSoglia)
        {
            try
            {
                EntityTipologiaAccessorioSoglia tipologiaAccessorioSogliaToUpdate = new EntityTipologiaAccessorioSoglia();
                UtilityManager.MapProp(tipologiaAccessorioSoglia, tipologiaAccessorioSogliaToUpdate);
                var result = _RCDDbContext.Update(tipologiaAccessorioSogliaToUpdate);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void AddTipologiaAccessorioSoglia(TipologiaAccessorioSogliaRequest tipologiaAccessorioSoglia)
        {
            try
            {
                EntityTipologiaAccessorioSoglia tipologiaAccessorioSogliaToAdd = new EntityTipologiaAccessorioSoglia();
                UtilityManager.MapProp(tipologiaAccessorioSoglia, tipologiaAccessorioSogliaToAdd);
                var result = _RCDDbContext.Add(tipologiaAccessorioSogliaToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void DeleteTipologiaAccessorioSoglia(TipologiaAccessorioSogliaRequest tipologiaAccessorioSoglia)
        {
            try
            {
                EntityTipologiaAccessorioSoglia tipologiaAccessorioSogliaToRemove = new EntityTipologiaAccessorioSoglia();
                UtilityManager.MapProp(tipologiaAccessorioSoglia, tipologiaAccessorioSogliaToRemove);
                var result = _RCDDbContext.Remove(tipologiaAccessorioSogliaToRemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        #endregion
    }
}
