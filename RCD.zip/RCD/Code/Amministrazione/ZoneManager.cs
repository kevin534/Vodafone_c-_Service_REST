﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class ZoneManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public ZoneManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
        public async Task<List<ContractZona>> GetZone(ZonaRequestFull zona)
        {
            List<EntityZona> zone;
            String sortParam = String.Concat(String.Concat(zona.CampoOrdinamento, " "), zona.Ordinamento.ToUpper());

            if (zona.Pageable)
            {
                zone = await _RCDDbContext.Zona.OrderBy(sortParam)
                            .Skip(zona.NumeroElementi * zona.Page ).Take(zona.NumeroElementi).ToListAsync();
            }
            else
            {
                zone = await _RCDDbContext.Zona.OrderBy(sortParam).ToListAsync();
            }


            List<ContractZona> zoneElenco = new List<ContractZona>();
            foreach (EntityZona varZona in zone)
            {
                ContractZona zona1 = new ContractZona();
                UtilityManager.MapProp(varZona, zona1);
                zoneElenco.Add(zona1);
            }
            return zoneElenco;
        }
        public async Task<Int32> GetZoneTot(ZonaRequestFull zona)
        {
            List<EntityZona> zone;

            zone = await _RCDDbContext.Zona.ToListAsync();

            return zone.Count();
        }
    }
}
