﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class VisualizzazioneInstallazioneManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public VisualizzazioneInstallazioneManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
        public async Task<List<EntityUtente>> GetUtenteId(UtenteRequestFull utente)
        {

            List<EntityUtente> utenti;

            String sortParam = String.Concat(String.Concat(utente.CampoOrdinamento, " "), utente.Ordinamento.ToUpper());

            if (utente.Pageable)
            {
                
                utenti = await _RCDDbContext.Utente.Where(x => x.Id.Equals(utente.Filter.Id)
                            )                   
                     .OrderBy(sortParam)
                            .Skip(utente.NumeroElementi * utente.Page).Take(utente.NumeroElementi)
                           .Include("Zona")
                           .Include("TipologiaUtente")
                           .Include("AreaVendita")
                           .Include("AreaVendita.CanaleVenditaDettaglio")
                            .Include("AreaVendita.CanaleVenditaDettaglio.CanaleVendita")
                            //.Include("Zona.RegioniVF")
                            .ToListAsync();
            }
            else
            {

                utenti = await _RCDDbContext.Utente.Where(x => x.Id.Equals(utente.Filter.Id)
                              )                      
                    .OrderBy(sortParam)
                              .Include("Zona")
                               .Include("TipologiaUtente")
                               .Include("AreaVendita")
                               .Include("AreaVendita.CanaleVenditaDettaglio")
                               .Include("AreaVendita.CanaleVenditaDettaglio.CanaleVendita")
                              //.Include("Zona.RegioniVF")
                              .ToListAsync();
            }

            return utenti;


        }

        public async Task<Int32> GetUtenteTot(UtenteRequestFull utente)
        {
            String sortParam = String.Concat(String.Concat(utente.CampoOrdinamento, " "), utente.Ordinamento.ToUpper());
            List<EntityUtente> utenti;
            utenti = await _RCDDbContext.Utente.Where(x => x.Id.Equals(utente.Filter.Id) )             
                .OrderBy(sortParam)
                              .Include("Zona")
                               .Include("TipologiaUtente")
                               .Include("AreaVendita")
                               .Include("AreaVendita.CanaleVenditaDettaglio")
                               .Include("AreaVendita.CanaleVenditaDettaglio.CanaleVendita")
                              //.Include("Zona.RegioniVF")
                              .ToListAsync();

            return utenti.Count();
        }
        public async Task<List<EntityUtentiProvince>> GetIdProvinciaByIdUtente(UtenteProvinciaRequestFull utenteP)
        {

            List<EntityUtentiProvince> utenti;

            String sortParam = String.Concat(String.Concat(utenteP.CampoOrdinamento, " "), utenteP.Ordinamento.ToUpper());


            if (utenteP.Pageable)
            {

                utenti = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente.Equals(utenteP.Filter.Utente.Id)
                            )          
                            .OrderBy(sortParam)
                            .Skip(utenteP.NumeroElementi * utenteP.Page).Take(utenteP.NumeroElementi)
                           .Include("Utente")
                           .Include("StsProvincia")
                            .ToListAsync();
            }
            else
            {
                utenti = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente.Equals(utenteP.Filter.Utente.Id)
                           )
                          .OrderBy(sortParam)
                          .Include("Utente")
                          .Include("StsProvincia")
                           .ToListAsync();
            }
                      
            return utenti;


        }

        // getRichiestaById


    }

}