﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class TipologiaAntenneManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public TipologiaAntenneManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractTipologiaAntenna>> GetTipologiaAntenne(TipologiaAntennaRequestFull tipologiaAntennaR)
        {
            List<EntityTipologiaAntenna> listTipologiaAntenne;
            String sortParam = String.Concat(String.Concat(tipologiaAntennaR.CampoOrdinamento, " "), tipologiaAntennaR.Ordinamento.ToUpper());

            if (tipologiaAntennaR.Pageable)
            {
                listTipologiaAntenne = await _RCDDbContext.TipologiaAntenna.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(tipologiaAntennaR.Filter.TipologiaAntenna), q => q.TipologiaAntenna.Contains(tipologiaAntennaR.Filter.TipologiaAntenna))
                        .OrderBy(sortParam)
                        .Skip(tipologiaAntennaR.NumeroElementi * tipologiaAntennaR.Page)
                        .Take(tipologiaAntennaR.NumeroElementi)
                        .ToListAsync();
            }
            else
            {
                listTipologiaAntenne = await _RCDDbContext.TipologiaAntenna.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(tipologiaAntennaR.Filter.TipologiaAntenna), q => q.TipologiaAntenna.Contains(tipologiaAntennaR.Filter.TipologiaAntenna))
                        .OrderBy(sortParam)
                        .ToListAsync();

            }
           
            List<RCDContracts.Data.ContractTipologiaAntenna> tipologiaAntenneElenco = new List<RCDContracts.Data.ContractTipologiaAntenna>();
            foreach (EntityTipologiaAntenna varTipologiaAntenna in listTipologiaAntenne)
            {
                RCDContracts.Data.ContractTipologiaAntenna tipologiaAntenna1 = new RCDContracts.Data.ContractTipologiaAntenna();
                UtilityManager.MapProp(varTipologiaAntenna, tipologiaAntenna1);
                tipologiaAntenneElenco.Add(tipologiaAntenna1);
            }
            return tipologiaAntenneElenco;
        }
        public async Task<Int32> GetTipologiaAntenneTot(TipologiaAntennaRequestFull tipologiaAntennaR)
        {
            List<EntityTipologiaAntenna> listTipologiaAntenne;
            listTipologiaAntenne = await _RCDDbContext.TipologiaAntenna.Where(x => x.Abilitato == true)
                        .WhereIf(!String.IsNullOrEmpty(tipologiaAntennaR.Filter.TipologiaAntenna), q => q.TipologiaAntenna.Contains(tipologiaAntennaR.Filter.TipologiaAntenna))
                        .ToListAsync();

            return listTipologiaAntenne.Count();

        }
        public void AddTipologiaAntenna(TipologiaAntennaRequest tipologiaAntennaR)
        {
            try
            {
                EntityTipologiaAntenna tipologiaAntennaToAdd = new EntityTipologiaAntenna();
                UtilityManager.MapProp(tipologiaAntennaR, tipologiaAntennaToAdd);
                var result = _RCDDbContext.Add(tipologiaAntennaToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void UpdateTipologiaAntenna(TipologiaAntennaRequest tipologiaAntennaR)
        {
            try
            {
                EntityTipologiaAntenna tipologiaAntennaToAdd = new EntityTipologiaAntenna();
                UtilityManager.MapProp(tipologiaAntennaR, tipologiaAntennaToAdd);
                var result = _RCDDbContext.Update(tipologiaAntennaToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void DeleteTipologiaAntenna(TipologiaAntennaRequest tipologiaAntennaR)
        {
            try
            {
                EntityTipologiaAntenna entityTipologiaAntennaToUpdate = _RCDDbContext.TipologiaAntenna.FirstOrDefault(item => item.Id == tipologiaAntennaR.Id);

                if (entityTipologiaAntennaToUpdate != null)
                {
                    entityTipologiaAntennaToUpdate.Abilitato = false;
                    var result = _RCDDbContext.Update(entityTipologiaAntennaToUpdate);
                    _RCDDbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }

    
}
