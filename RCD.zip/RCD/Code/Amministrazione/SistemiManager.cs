﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Amministrazione
{
    public class SistemiManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public SistemiManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractSistema>> GetSistemi(SistemaRequestFull sistema)
        {
            List<EntitySistema> sistemi;
            String sortParam = String.Concat(String.Concat(sistema.CampoOrdinamento, " "), sistema.Ordinamento.ToUpper());

            if (sistema.Pageable)
            {
                sistemi = await _RCDDbContext.Sistema
                    .WhereIf(!String.IsNullOrEmpty(sistema.Filter.Sistema), q => q.Sistema.Contains(sistema.Filter.Sistema))
                    .OrderBy(sortParam)
                    .Skip(sistema.NumeroElementi * sistema.Page).Take(sistema.NumeroElementi)
                    .ToListAsync();

            }
            else
            {
                sistemi = await _RCDDbContext.Sistema
                    .WhereIf(!String.IsNullOrEmpty(sistema.Filter.Sistema), q => q.Sistema.Contains(sistema.Filter.Sistema))
                    .OrderBy(sortParam)
                    .ToListAsync();

            }
           
            List<ContractSistema> sistemiElenco = new List<ContractSistema>();
            foreach (EntitySistema varSistema in sistemi)
            {
                ContractSistema sistema1 = new ContractSistema();
                UtilityManager.MapProp(varSistema, sistema1);
                sistemiElenco.Add(sistema1);
            }
            return sistemiElenco;
        }

        public async Task<Int32> GetSistemiTot(SistemaRequestFull sistema)
        {
            List<EntitySistema> sistemi;
            sistemi = await _RCDDbContext.Sistema
                    .WhereIf(!String.IsNullOrEmpty(sistema.Filter.Sistema), q => q.Sistema.Contains(sistema.Filter.Sistema))
                    .ToListAsync();

            return sistemi.Count();

        }
    }
}
