﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;
using System.Text;


namespace RCD.Code.Amministrazione
{
    public class PianificazioniManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public PianificazioniManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }




        public async Task<List<ContractPianificazione>> GetPianificazioni(PianificazioneRequestFull pianificazione, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            List<EntityPianificazione> pianificazioni;
            String sortParam = String.Concat(String.Concat(pianificazione.CampoOrdinamento, " "),
                               pianificazione.Ordinamento.ToUpper());

            List<Int64?> province = _RCDDbContext.UtentiProvince.WhereIf(utente != null && utente.IdZona == null, q => q.IdUtente == utente.Id).Select(q => q.Id).ToList();
            List<Int64?> stati = _RCDDbContext.Stato.Where(x => x.Id >= 3 && x.IsKoState == false && x.IsFinalState == false).Select(x => x.Id).ToList();
            List<Int64?> statiFuoriGovernance = _RCDDbContext.Stato.Where(x => x.Id >= 2 && x.IsAutomaticChange == true).Select(x => x.Id).ToList();
            stati = stati.Union(statiFuoriGovernance).ToList();

            if (pianificazione.Pageable)
            {
                pianificazioni = await _RCDDbContext.Pianificazione
                            .Where(q => stati.Contains(q.IdUltimoStato))
                            .WhereIf(utente != null && utente.IdZona != null, q => q.IdZona == utente.IdZona)
                            .WhereIf(utente != null && utente.IdZona == null, q => province.Contains(q.IdProvincia))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Id.ToString()), q => q.Id == pianificazione.Filter.Id)
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RagioneSociale), q => q.RagioneSociale.Contains(pianificazione.Filter.RagioneSociale))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PartitaIVA), q => q.PartitaIVA.Contains(pianificazione.Filter.PartitaIVA))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CodiceCliente), q => q.CodiceCliente.Contains(pianificazione.Filter.CodiceCliente))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Richiedente), q => q.Richiedente.Contains(pianificazione.Filter.Richiedente))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(pianificazione.Filter.NomeInstallazione))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Indirizzo), q => q.Indirizzo.Contains(pianificazione.Filter.Indirizzo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Comune), q => q.Comune.Contains(pianificazione.Filter.Comune))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Provincia), q => q.Provincia.Contains(pianificazione.Filter.Provincia))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaCopertura), q => q.TipologiaCopertura.Contains(pianificazione.Filter.TipologiaCopertura))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.SistemaRichiesto), q => q.SistemaRichiesto.Contains(pianificazione.Filter.SistemaRichiesto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.ServizioRichiesto), q => q.ServizioRichiesto.Contains(pianificazione.Filter.ServizioRichiesto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(pianificazione.Filter.PrevistaVruVruc))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MancanzaSegnaleEsterno), q => q.MancanzaSegnaleEsterno.Contains(pianificazione.Filter.MancanzaSegnaleEsterno))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MancanzaSegnaleInterno), q => q.MancanzaSegnaleInterno.Contains(pianificazione.Filter.MancanzaSegnaleInterno))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.StabileDiProprietà.ToString()), q => q.StabileDiProprietà.Equals(pianificazione.Filter.StabileDiProprietà))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaStabile), q => q.TipologiaStabile.Contains(pianificazione.Filter.TipologiaStabile))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MetriQuadriDaCoprire.ToString()), q => q.MetriQuadriDaCoprire.Equals(pianificazione.Filter.MetriQuadriDaCoprire))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PianiDaCoprire.ToString()), q => q.PianiDaCoprire.Equals(pianificazione.Filter.PianiDaCoprire))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.AccessibilitaTetto), q => q.AccessibilitaTetto.Contains(pianificazione.Filter.AccessibilitaTetto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DisponibilitàOspitareRepeater.ToString()), q => q.DisponibilitàOspitareRepeater.Equals(pianificazione.Filter.DisponibilitàOspitareRepeater))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(pianificazione.Filter.CoperturaIndoorAltriGestori))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.InseritoDa), q => q.InseritoDa.Contains(pianificazione.Filter.InseritoDa))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataRichiesta.ToString()), q => q.DataRichiesta>= pianificazione.Filter.DataRichiesta.GetValueOrDefault().Date && q.DataRichiesta < pianificazione.Filter.DataRichiesta.GetValueOrDefault().Date.AddDays(1))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CanaleVendita), q => q.CanaleVendita.Contains(pianificazione.Filter.CanaleVendita))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(pianificazione.Filter.CanaleVenditaDettaglio))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.AreaVendite), q => q.AreaVendite.Contains(pianificazione.Filter.AreaVendite))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(pianificazione.Filter.DistrettoVendite))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MotivoRichiesta), q => q.MotivoRichiesta.Contains(pianificazione.Filter.MotivoRichiesta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(pianificazione.Filter.RiferimentoVendite))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(pianificazione.Filter.RiferimentoAM))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(pianificazione.Filter.RiferimentoDce))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.ProgettistaRan), q => q.ProgettistaRan.Contains(pianificazione.Filter.ProgettistaRan))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.SiteManagerNI), q => q.SiteManagerNI.Contains(pianificazione.Filter.SiteManagerNI))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaCliente), q => q.TipologiaCliente.Contains(pianificazione.Filter.TipologiaCliente))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(pianificazione.Filter.PrioritaVendite))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(pianificazione.Filter.FatturatoMedioBimestrale))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(pianificazione.Filter.NumeroSIM))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(pianificazione.Filter.NumeroInterniVRUC))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.UltimoStato), q => q.UltimoStato.Contains(pianificazione.Filter.UltimoStato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(pianificazione.Filter.IdUltimoStato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(pianificazione.Filter.IdProvincia))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Zona), q => q.Zona.Contains(pianificazione.Filter.Zona))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataInstallazioneStimata.ToString()), q => q.DataInstallazioneStimata.Equals(pianificazione.Filter.DataInstallazioneStimata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataInvioStima.ToString()), q => q.DataInvioStima.Equals(pianificazione.Filter.DataInvioStima))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataRichiestaSopralluogo.ToString()), q => q.DataRichiestaSopralluogo.Equals(pianificazione.Filter.DataRichiestaSopralluogo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(pianificazione.Filter.DataSopralluogoConsuntivata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(pianificazione.Filter.DataSopralluogoStimata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(pianificazione.Filter.DataInvioIncaricoVersoDitta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(pianificazione.Filter.DataOnAirConsuntivata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(pianificazione.Filter.DataOnAirStimata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataPermessoPresentato.ToString()), q => q.DataPermessoPresentato.Equals(pianificazione.Filter.DataPermessoPresentato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(pianificazione.Filter.DittaInstallatrice))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.IdZona.ToString()), q => q.IdZona.Equals(pianificazione.Filter.IdZona))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CodiceInstallazione), q => q.CodiceInstallazione.Contains(pianificazione.Filter.CodiceInstallazione))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(pianificazione.Filter.StudioProgettazione))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoAccessoriApparatiStimato.ToString()), q => q.CostoAccessoriApparatiStimato.Equals(pianificazione.Filter.CostoAccessoriApparatiStimato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.StimaIntervento.ToString()), q => q.StimaIntervento.Equals(pianificazione.Filter.StimaIntervento))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroCompactGsmRichiesti.ToString()), q => q.NumeroCompactGsmRichiesti.Equals(pianificazione.Filter.NumeroCompactGsmRichiesti))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroCompactUmtsRichiesti.ToString()), q => q.NumeroCompactUmtsRichiesti.Equals(pianificazione.Filter.NumeroCompactUmtsRichiesti))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroMiniUmtsRichiesti.ToString()), q => q.NumeroMiniUmtsRichiesti.Equals(pianificazione.Filter.NumeroMiniUmtsRichiesti))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroApparatiFemto.ToString()), q => q.NumeroApparatiFemto.Equals(pianificazione.Filter.NumeroApparatiFemto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroApparatiDualBand.ToString()), q => q.NumeroApparatiDualBand.Equals(pianificazione.Filter.NumeroApparatiDualBand))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MicrocelleMacrosito.ToString()), q => q.MicrocelleMacrosito.Equals(pianificazione.Filter.MicrocelleMacrosito))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.AutorizzazioneCliente.ToString()), q => q.AutorizzazioneCliente.Equals(pianificazione.Filter.AutorizzazioneCliente))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Preventivo.ToString()), q => q.Preventivo.Equals(pianificazione.Filter.Preventivo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(pianificazione.Filter.VincoliAreaPresenti))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(pianificazione.Filter.TipologiaCantiere))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.SimNecessarie.ToString()), q => q.SimNecessarie.Equals(pianificazione.Filter.SimNecessarie))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RarfStsAperta.ToString()), q => q.RarfStsAperta.Equals(pianificazione.Filter.RarfStsAperta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CtaConsegnatoVo.ToString()), q => q.CtaConsegnatoVo.Equals(pianificazione.Filter.CtaConsegnatoVo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NominaRLInviataAllaDitta.ToString()), q => q.NominaRLInviataAllaDitta.Equals(pianificazione.Filter.NominaRLInviataAllaDitta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CognomeRL), q => q.CognomeRL.Contains(pianificazione.Filter.CognomeRL))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NomeRL), q => q.NomeRL.Contains(pianificazione.Filter.NomeRL))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RdAEmessa.ToString()), q => q.RdAEmessa.Equals(pianificazione.Filter.RdAEmessa))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroRdA), q => q.NumeroRdA.Contains(pianificazione.Filter.NumeroRdA))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NcLEmessa.ToString()), q => q.NcLEmessa.Equals(pianificazione.Filter.NcLEmessa))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoApparatiAccessoriConsuntivato.ToString()), q => q.CostoApparatiAccessoriConsuntivato.Equals(pianificazione.Filter.CostoApparatiAccessoriConsuntivato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroCompactGsmInstallati.ToString()), q => q.NumeroCompactGsmInstallati.Equals(pianificazione.Filter.NumeroCompactGsmInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroCompactUmtsInstallati.ToString()), q => q.NumeroCompactUmtsInstallati.Equals(pianificazione.Filter.NumeroCompactUmtsInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroMiniGsmInstallati.ToString()), q => q.NumeroMiniGsmInstallati.Equals(pianificazione.Filter.NumeroMiniGsmInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroMiniUmtsInstallati.ToString()), q => q.NumeroMiniUmtsInstallati.Equals(pianificazione.Filter.NumeroMiniUmtsInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroApparatiFemtoInstallati.ToString()), q => q.NumeroApparatiFemtoInstallati.Equals(pianificazione.Filter.NumeroApparatiFemtoInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroApparatiDualBandInstallati.ToString()), q => q.NumeroApparatiDualBandInstallati.Equals(pianificazione.Filter.NumeroApparatiDualBandInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(pianificazione.Filter.TotaleApparatiNuovi))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(pianificazione.Filter.TotaleApparatiRiuso))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaCosto), q => q.TipologiaCosto.Contains(pianificazione.Filter.TipologiaCosto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DeltaStimatoConsuntivato.ToString()), q => q.DeltaStimatoConsuntivato.Equals(pianificazione.Filter.DeltaStimatoConsuntivato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoTotaleConsuntivato.ToString()), q => q.CostoTotaleConsuntivato.Equals(pianificazione.Filter.CostoTotaleConsuntivato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RegioneVF), q => q.RegioneVF.Contains(pianificazione.Filter.RegioneVF))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(pianificazione.Filter.CodiceNazionale))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Regione), q => q.Regione.Contains(pianificazione.Filter.Regione))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataIncaricoInstallazioneDitta.ToString()), q => q.DataIncaricoInstallazioneDitta.Equals(pianificazione.Filter.DataIncaricoInstallazioneDitta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(pianificazione.Filter.AgenziaRiferimento))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroNCL), q => q.NumeroNCL.Contains(pianificazione.Filter.NumeroNCL))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroODA), q => q.NumeroODA.Contains(pianificazione.Filter.NumeroODA))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.IdEntry), q => q.IdEntry.Contains(pianificazione.Filter.IdEntry))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoTotalePreventivo.ToString()), q => q.CostoTotalePreventivo.Equals(pianificazione.Filter.CostoTotalePreventivo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoTotaleApparatiPreventivo.ToString()), q => q.CostoTotaleApparatiPreventivo.Equals(pianificazione.Filter.CostoTotaleApparatiPreventivo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoTotaleApapratiConsuntivo.ToString()), q => q.CostoTotaleApapratiConsuntivo.Equals(pianificazione.Filter.CostoTotaleApapratiConsuntivo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(pianificazione.Filter.PermessoNecessario))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(pianificazione.Filter.TelefonoRiferimento))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.InsertDate.ToString()), q => q.InsertDate >= pianificazione.Filter.InsertDate && q.InsertDate < pianificazione.Filter.InsertDate.GetValueOrDefault().AddDays(1))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MiniLTE.ToString()), q => q.MiniLTE.Equals(pianificazione.Filter.MiniLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CompactLTE.ToString()), q => q.CompactLTE.Equals(pianificazione.Filter.CompactLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FemtoLTE.ToString()), q => q.FemtoLTE.Equals(pianificazione.Filter.FemtoLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FemtoGSM.ToString()), q => q.FemtoGSM.Equals(pianificazione.Filter.FemtoGSM))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FemtoUMTS.ToString()), q => q.FemtoUMTS.Equals(pianificazione.Filter.FemtoUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FemtoUMTSLTE.ToString()), q => q.FemtoUMTSLTE.Equals(pianificazione.Filter.FemtoUMTSLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiGSM.ToString()), q => q.MaxiGSM.Equals(pianificazione.Filter.MaxiGSM))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiUMTS.ToString()), q => q.MaxiUMTS.Equals(pianificazione.Filter.MaxiUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiLTE.ToString()), q => q.MaxiLTE.Equals(pianificazione.Filter.MaxiLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiUMTSLTE.ToString()), q => q.MaxiUMTSLTE.Equals(pianificazione.Filter.MaxiUMTSLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiGsmUmts.ToString()), q => q.MaxiGsmUmts.Equals(pianificazione.Filter.MaxiGsmUmts))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CompactGSMUMTS.ToString()), q => q.CompactGSMUMTS.Equals(pianificazione.Filter.CompactGSMUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CompactLTEUMTS.ToString()), q => q.CompactLTEUMTS.Equals(pianificazione.Filter.CompactLTEUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Mini.ToString()), q => q.Mini.Equals(pianificazione.Filter.Mini))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MiniGSMUMTS.ToString()), q => q.MiniGSMUMTS.Equals(pianificazione.Filter.MiniGSMUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MiniUMTSLTE.ToString()), q => q.MiniUMTSLTE.Equals(pianificazione.Filter.MiniUMTSLTE))
                            .OrderBy(sortParam)
                            .Skip(pianificazione.NumeroElementi * pianificazione.Page).Take(pianificazione.NumeroElementi)
                            .ToListAsync();
            }
            else
            {
                pianificazioni = await _RCDDbContext.Pianificazione
                            .Where(q => stati.Contains(q.IdUltimoStato))
                            .WhereIf(utente != null && utente.IdZona != null, q => q.IdZona == utente.IdZona)
                            .WhereIf(utente != null && utente.IdZona == null, q => province.Contains(q.IdProvincia))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Id.ToString()), q => q.Id == pianificazione.Filter.Id)
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RagioneSociale), q => q.RagioneSociale.Contains(pianificazione.Filter.RagioneSociale))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PartitaIVA), q => q.PartitaIVA.Contains(pianificazione.Filter.PartitaIVA))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CodiceCliente), q => q.CodiceCliente.Contains(pianificazione.Filter.CodiceCliente))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Richiedente), q => q.Richiedente.Contains(pianificazione.Filter.Richiedente))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(pianificazione.Filter.NomeInstallazione))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Indirizzo), q => q.Indirizzo.Contains(pianificazione.Filter.Indirizzo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Comune), q => q.Comune.Contains(pianificazione.Filter.Comune))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Provincia), q => q.Provincia.Contains(pianificazione.Filter.Provincia))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaCopertura), q => q.TipologiaCopertura.Contains(pianificazione.Filter.TipologiaCopertura))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.SistemaRichiesto), q => q.SistemaRichiesto.Contains(pianificazione.Filter.SistemaRichiesto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.ServizioRichiesto), q => q.ServizioRichiesto.Contains(pianificazione.Filter.ServizioRichiesto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(pianificazione.Filter.PrevistaVruVruc))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MancanzaSegnaleEsterno), q => q.MancanzaSegnaleEsterno.Contains(pianificazione.Filter.MancanzaSegnaleEsterno))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MancanzaSegnaleInterno), q => q.MancanzaSegnaleInterno.Contains(pianificazione.Filter.MancanzaSegnaleInterno))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.StabileDiProprietà.ToString()), q => q.StabileDiProprietà.Equals(pianificazione.Filter.StabileDiProprietà))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaStabile), q => q.TipologiaStabile.Contains(pianificazione.Filter.TipologiaStabile))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MetriQuadriDaCoprire.ToString()), q => q.MetriQuadriDaCoprire.Equals(pianificazione.Filter.MetriQuadriDaCoprire))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PianiDaCoprire.ToString()), q => q.PianiDaCoprire.Equals(pianificazione.Filter.PianiDaCoprire))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.AccessibilitaTetto), q => q.AccessibilitaTetto.Contains(pianificazione.Filter.AccessibilitaTetto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DisponibilitàOspitareRepeater.ToString()), q => q.DisponibilitàOspitareRepeater.Equals(pianificazione.Filter.DisponibilitàOspitareRepeater))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(pianificazione.Filter.CoperturaIndoorAltriGestori))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.InseritoDa), q => q.InseritoDa.Contains(pianificazione.Filter.InseritoDa))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataRichiesta.ToString()), q => q.DataRichiesta >= pianificazione.Filter.DataRichiesta.GetValueOrDefault().Date && q.DataRichiesta < pianificazione.Filter.DataRichiesta.GetValueOrDefault().Date.AddDays(1))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CanaleVendita), q => q.CanaleVendita.Contains(pianificazione.Filter.CanaleVendita))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(pianificazione.Filter.CanaleVenditaDettaglio))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.AreaVendite), q => q.AreaVendite.Contains(pianificazione.Filter.AreaVendite))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(pianificazione.Filter.DistrettoVendite))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MotivoRichiesta), q => q.MotivoRichiesta.Contains(pianificazione.Filter.MotivoRichiesta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(pianificazione.Filter.RiferimentoVendite))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(pianificazione.Filter.RiferimentoAM))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(pianificazione.Filter.RiferimentoDce))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.ProgettistaRan), q => q.ProgettistaRan.Contains(pianificazione.Filter.ProgettistaRan))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.SiteManagerNI), q => q.SiteManagerNI.Contains(pianificazione.Filter.SiteManagerNI))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaCliente), q => q.TipologiaCliente.Contains(pianificazione.Filter.TipologiaCliente))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(pianificazione.Filter.PrioritaVendite))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(pianificazione.Filter.FatturatoMedioBimestrale))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(pianificazione.Filter.NumeroSIM))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(pianificazione.Filter.NumeroInterniVRUC))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.UltimoStato), q => q.UltimoStato.Contains(pianificazione.Filter.UltimoStato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(pianificazione.Filter.IdUltimoStato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(pianificazione.Filter.IdProvincia))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Zona), q => q.Zona.Contains(pianificazione.Filter.Zona))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataInstallazioneStimata.ToString()), q => q.DataInstallazioneStimata.Equals(pianificazione.Filter.DataInstallazioneStimata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataInvioStima.ToString()), q => q.DataInvioStima.Equals(pianificazione.Filter.DataInvioStima))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataRichiestaSopralluogo.ToString()), q => q.DataRichiestaSopralluogo.Equals(pianificazione.Filter.DataRichiestaSopralluogo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(pianificazione.Filter.DataSopralluogoConsuntivata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(pianificazione.Filter.DataSopralluogoStimata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(pianificazione.Filter.DataInvioIncaricoVersoDitta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(pianificazione.Filter.DataOnAirConsuntivata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(pianificazione.Filter.DataOnAirStimata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataPermessoPresentato.ToString()), q => q.DataPermessoPresentato.Equals(pianificazione.Filter.DataPermessoPresentato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(pianificazione.Filter.DittaInstallatrice))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.IdZona.ToString()), q => q.IdZona.Equals(pianificazione.Filter.IdZona))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CodiceInstallazione), q => q.CodiceInstallazione.Contains(pianificazione.Filter.CodiceInstallazione))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(pianificazione.Filter.StudioProgettazione))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoAccessoriApparatiStimato.ToString()), q => q.CostoAccessoriApparatiStimato.Equals(pianificazione.Filter.CostoAccessoriApparatiStimato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.StimaIntervento.ToString()), q => q.StimaIntervento.Equals(pianificazione.Filter.StimaIntervento))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroCompactGsmRichiesti.ToString()), q => q.NumeroCompactGsmRichiesti.Equals(pianificazione.Filter.NumeroCompactGsmRichiesti))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroCompactUmtsRichiesti.ToString()), q => q.NumeroCompactUmtsRichiesti.Equals(pianificazione.Filter.NumeroCompactUmtsRichiesti))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroMiniUmtsRichiesti.ToString()), q => q.NumeroMiniUmtsRichiesti.Equals(pianificazione.Filter.NumeroMiniUmtsRichiesti))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroApparatiFemto.ToString()), q => q.NumeroApparatiFemto.Equals(pianificazione.Filter.NumeroApparatiFemto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroApparatiDualBand.ToString()), q => q.NumeroApparatiDualBand.Equals(pianificazione.Filter.NumeroApparatiDualBand))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MicrocelleMacrosito.ToString()), q => q.MicrocelleMacrosito.Equals(pianificazione.Filter.MicrocelleMacrosito))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.AutorizzazioneCliente.ToString()), q => q.AutorizzazioneCliente.Equals(pianificazione.Filter.AutorizzazioneCliente))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Preventivo.ToString()), q => q.Preventivo.Equals(pianificazione.Filter.Preventivo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(pianificazione.Filter.VincoliAreaPresenti))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(pianificazione.Filter.TipologiaCantiere))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.SimNecessarie.ToString()), q => q.SimNecessarie.Equals(pianificazione.Filter.SimNecessarie))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RarfStsAperta.ToString()), q => q.RarfStsAperta.Equals(pianificazione.Filter.RarfStsAperta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CtaConsegnatoVo.ToString()), q => q.CtaConsegnatoVo.Equals(pianificazione.Filter.CtaConsegnatoVo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NominaRLInviataAllaDitta.ToString()), q => q.NominaRLInviataAllaDitta.Equals(pianificazione.Filter.NominaRLInviataAllaDitta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CognomeRL), q => q.CognomeRL.Contains(pianificazione.Filter.CognomeRL))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NomeRL), q => q.NomeRL.Contains(pianificazione.Filter.NomeRL))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RdAEmessa.ToString()), q => q.RdAEmessa.Equals(pianificazione.Filter.RdAEmessa))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroRdA), q => q.NumeroRdA.Contains(pianificazione.Filter.NumeroRdA))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NcLEmessa.ToString()), q => q.NcLEmessa.Equals(pianificazione.Filter.NcLEmessa))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoApparatiAccessoriConsuntivato.ToString()), q => q.CostoApparatiAccessoriConsuntivato.Equals(pianificazione.Filter.CostoApparatiAccessoriConsuntivato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroCompactGsmInstallati.ToString()), q => q.NumeroCompactGsmInstallati.Equals(pianificazione.Filter.NumeroCompactGsmInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroCompactUmtsInstallati.ToString()), q => q.NumeroCompactUmtsInstallati.Equals(pianificazione.Filter.NumeroCompactUmtsInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroMiniGsmInstallati.ToString()), q => q.NumeroMiniGsmInstallati.Equals(pianificazione.Filter.NumeroMiniGsmInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroMiniUmtsInstallati.ToString()), q => q.NumeroMiniUmtsInstallati.Equals(pianificazione.Filter.NumeroMiniUmtsInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroApparatiFemtoInstallati.ToString()), q => q.NumeroApparatiFemtoInstallati.Equals(pianificazione.Filter.NumeroApparatiFemtoInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroApparatiDualBandInstallati.ToString()), q => q.NumeroApparatiDualBandInstallati.Equals(pianificazione.Filter.NumeroApparatiDualBandInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(pianificazione.Filter.TotaleApparatiNuovi))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(pianificazione.Filter.TotaleApparatiRiuso))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaCosto), q => q.TipologiaCosto.Contains(pianificazione.Filter.TipologiaCosto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DeltaStimatoConsuntivato.ToString()), q => q.DeltaStimatoConsuntivato.Equals(pianificazione.Filter.DeltaStimatoConsuntivato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoTotaleConsuntivato.ToString()), q => q.CostoTotaleConsuntivato.Equals(pianificazione.Filter.CostoTotaleConsuntivato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RegioneVF), q => q.RegioneVF.Contains(pianificazione.Filter.RegioneVF))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(pianificazione.Filter.CodiceNazionale))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Regione), q => q.Regione.Contains(pianificazione.Filter.Regione))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataIncaricoInstallazioneDitta.ToString()), q => q.DataIncaricoInstallazioneDitta.Equals(pianificazione.Filter.DataIncaricoInstallazioneDitta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(pianificazione.Filter.AgenziaRiferimento))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroNCL), q => q.NumeroNCL.Contains(pianificazione.Filter.NumeroNCL))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroODA), q => q.NumeroODA.Contains(pianificazione.Filter.NumeroODA))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.IdEntry), q => q.IdEntry.Contains(pianificazione.Filter.IdEntry))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoTotalePreventivo.ToString()), q => q.CostoTotalePreventivo.Equals(pianificazione.Filter.CostoTotalePreventivo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoTotaleApparatiPreventivo.ToString()), q => q.CostoTotaleApparatiPreventivo.Equals(pianificazione.Filter.CostoTotaleApparatiPreventivo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoTotaleApapratiConsuntivo.ToString()), q => q.CostoTotaleApapratiConsuntivo.Equals(pianificazione.Filter.CostoTotaleApapratiConsuntivo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(pianificazione.Filter.PermessoNecessario))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(pianificazione.Filter.TelefonoRiferimento))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.InsertDate.ToString()), q => q.InsertDate >= pianificazione.Filter.InsertDate && q.InsertDate < pianificazione.Filter.InsertDate.GetValueOrDefault().AddDays(1))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MiniLTE.ToString()), q => q.MiniLTE.Equals(pianificazione.Filter.MiniLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CompactLTE.ToString()), q => q.CompactLTE.Equals(pianificazione.Filter.CompactLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FemtoLTE.ToString()), q => q.FemtoLTE.Equals(pianificazione.Filter.FemtoLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FemtoGSM.ToString()), q => q.FemtoGSM.Equals(pianificazione.Filter.FemtoGSM))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FemtoUMTS.ToString()), q => q.FemtoUMTS.Equals(pianificazione.Filter.FemtoUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FemtoUMTSLTE.ToString()), q => q.FemtoUMTSLTE.Equals(pianificazione.Filter.FemtoUMTSLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiGSM.ToString()), q => q.MaxiGSM.Equals(pianificazione.Filter.MaxiGSM))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiUMTS.ToString()), q => q.MaxiUMTS.Equals(pianificazione.Filter.MaxiUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiLTE.ToString()), q => q.MaxiLTE.Equals(pianificazione.Filter.MaxiLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiUMTSLTE.ToString()), q => q.MaxiUMTSLTE.Equals(pianificazione.Filter.MaxiUMTSLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiGsmUmts.ToString()), q => q.MaxiGsmUmts.Equals(pianificazione.Filter.MaxiGsmUmts))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CompactGSMUMTS.ToString()), q => q.CompactGSMUMTS.Equals(pianificazione.Filter.CompactGSMUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CompactLTEUMTS.ToString()), q => q.CompactLTEUMTS.Equals(pianificazione.Filter.CompactLTEUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Mini.ToString()), q => q.Mini.Equals(pianificazione.Filter.Mini))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MiniGSMUMTS.ToString()), q => q.MiniGSMUMTS.Equals(pianificazione.Filter.MiniGSMUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MiniUMTSLTE.ToString()), q => q.MiniUMTSLTE.Equals(pianificazione.Filter.MiniUMTSLTE))
                            .OrderBy(sortParam)                         
                            .ToListAsync();
            }

            List<ContractPianificazione> pianificazioniElenco = new List<ContractPianificazione>();
            foreach (EntityPianificazione varPianificazione in pianificazioni)
            {
                ContractPianificazione pianificazione1 = new ContractPianificazione();
                UtilityManager.MapProp(varPianificazione, pianificazione1);
                pianificazioniElenco.Add(pianificazione1);
            }
            return pianificazioniElenco;
        }

        public async Task<Int32> GetPianificazioniTot(PianificazioneRequestFull pianificazione, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);
            List<Int64?> province = _RCDDbContext.UtentiProvince.WhereIf(utente != null && utente.IdZona == null, q => q.IdUtente == utente.Id).Select(q => q.Id).ToList();
            List<Int64?> stati = _RCDDbContext.Stato.Where(x => x.Id >= 3 && x.IsKoState == false && x.IsFinalState == false).Select(x => x.Id).ToList();
            List<Int64?> statiFuoriGovernance = _RCDDbContext.Stato.Where(x => x.Id >= 2 && x.IsAutomaticChange == true).Select(x => x.Id).ToList();
            stati = stati.Union(statiFuoriGovernance).ToList();

            List<EntityPianificazione> pianificazioni;

           Int32 pianificazioniCount =  _RCDDbContext.Pianificazione
                            .Where(q => stati.Contains(q.IdUltimoStato))
                            .WhereIf(utente != null && utente.IdZona != null, q => q.IdZona == utente.IdZona)
                            .WhereIf(utente != null && utente.IdZona == null, q => province.Contains(q.IdProvincia))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Id.ToString()), q => q.Id == pianificazione.Filter.Id)
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RagioneSociale), q => q.RagioneSociale.Contains(pianificazione.Filter.RagioneSociale))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PartitaIVA), q => q.PartitaIVA.Contains(pianificazione.Filter.PartitaIVA))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CodiceCliente), q => q.CodiceCliente.Contains(pianificazione.Filter.CodiceCliente))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Richiedente), q => q.Richiedente.Contains(pianificazione.Filter.Richiedente))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(pianificazione.Filter.NomeInstallazione))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Indirizzo), q => q.Indirizzo.Contains(pianificazione.Filter.Indirizzo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Comune), q => q.Comune.Contains(pianificazione.Filter.Comune))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Provincia), q => q.Provincia.Contains(pianificazione.Filter.Provincia))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaCopertura), q => q.TipologiaCopertura.Contains(pianificazione.Filter.TipologiaCopertura))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.SistemaRichiesto), q => q.SistemaRichiesto.Contains(pianificazione.Filter.SistemaRichiesto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.ServizioRichiesto), q => q.ServizioRichiesto.Contains(pianificazione.Filter.ServizioRichiesto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(pianificazione.Filter.PrevistaVruVruc))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MancanzaSegnaleEsterno), q => q.MancanzaSegnaleEsterno.Contains(pianificazione.Filter.MancanzaSegnaleEsterno))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MancanzaSegnaleInterno), q => q.MancanzaSegnaleInterno.Contains(pianificazione.Filter.MancanzaSegnaleInterno))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.StabileDiProprietà.ToString()), q => q.StabileDiProprietà.Equals(pianificazione.Filter.StabileDiProprietà))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaStabile), q => q.TipologiaStabile.Contains(pianificazione.Filter.TipologiaStabile))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MetriQuadriDaCoprire.ToString()), q => q.MetriQuadriDaCoprire.Equals(pianificazione.Filter.MetriQuadriDaCoprire))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PianiDaCoprire.ToString()), q => q.PianiDaCoprire.Equals(pianificazione.Filter.PianiDaCoprire))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.AccessibilitaTetto), q => q.AccessibilitaTetto.Contains(pianificazione.Filter.AccessibilitaTetto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DisponibilitàOspitareRepeater.ToString()), q => q.DisponibilitàOspitareRepeater.Equals(pianificazione.Filter.DisponibilitàOspitareRepeater))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(pianificazione.Filter.CoperturaIndoorAltriGestori))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.InseritoDa), q => q.InseritoDa.Contains(pianificazione.Filter.InseritoDa))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataRichiesta.ToString()), q => q.DataRichiesta >= pianificazione.Filter.DataRichiesta.GetValueOrDefault().Date && q.DataRichiesta < pianificazione.Filter.DataRichiesta.GetValueOrDefault().Date.AddDays(1))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CanaleVendita), q => q.CanaleVendita.Contains(pianificazione.Filter.CanaleVendita))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(pianificazione.Filter.CanaleVenditaDettaglio))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.AreaVendite), q => q.AreaVendite.Contains(pianificazione.Filter.AreaVendite))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(pianificazione.Filter.DistrettoVendite))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MotivoRichiesta), q => q.MotivoRichiesta.Contains(pianificazione.Filter.MotivoRichiesta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(pianificazione.Filter.RiferimentoVendite))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(pianificazione.Filter.RiferimentoAM))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(pianificazione.Filter.RiferimentoDce))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.ProgettistaRan), q => q.ProgettistaRan.Contains(pianificazione.Filter.ProgettistaRan))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.SiteManagerNI), q => q.SiteManagerNI.Contains(pianificazione.Filter.SiteManagerNI))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaCliente), q => q.TipologiaCliente.Contains(pianificazione.Filter.TipologiaCliente))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(pianificazione.Filter.PrioritaVendite))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(pianificazione.Filter.FatturatoMedioBimestrale))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(pianificazione.Filter.NumeroSIM))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(pianificazione.Filter.NumeroInterniVRUC))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.UltimoStato), q => q.UltimoStato.Contains(pianificazione.Filter.UltimoStato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(pianificazione.Filter.IdUltimoStato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(pianificazione.Filter.IdProvincia))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Zona), q => q.Zona.Contains(pianificazione.Filter.Zona))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataInstallazioneStimata.ToString()), q => q.DataInstallazioneStimata.Equals(pianificazione.Filter.DataInstallazioneStimata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataInvioStima.ToString()), q => q.DataInvioStima.Equals(pianificazione.Filter.DataInvioStima))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataRichiestaSopralluogo.ToString()), q => q.DataRichiestaSopralluogo.Equals(pianificazione.Filter.DataRichiestaSopralluogo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(pianificazione.Filter.DataSopralluogoConsuntivata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(pianificazione.Filter.DataSopralluogoStimata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(pianificazione.Filter.DataInvioIncaricoVersoDitta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(pianificazione.Filter.DataOnAirConsuntivata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(pianificazione.Filter.DataOnAirStimata))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataPermessoPresentato.ToString()), q => q.DataPermessoPresentato.Equals(pianificazione.Filter.DataPermessoPresentato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(pianificazione.Filter.DittaInstallatrice))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.IdZona.ToString()), q => q.IdZona.Equals(pianificazione.Filter.IdZona))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CodiceInstallazione), q => q.CodiceInstallazione.Contains(pianificazione.Filter.CodiceInstallazione))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(pianificazione.Filter.StudioProgettazione))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoAccessoriApparatiStimato.ToString()), q => q.CostoAccessoriApparatiStimato.Equals(pianificazione.Filter.CostoAccessoriApparatiStimato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.StimaIntervento.ToString()), q => q.StimaIntervento.Equals(pianificazione.Filter.StimaIntervento))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroCompactGsmRichiesti.ToString()), q => q.NumeroCompactGsmRichiesti.Equals(pianificazione.Filter.NumeroCompactGsmRichiesti))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroCompactUmtsRichiesti.ToString()), q => q.NumeroCompactUmtsRichiesti.Equals(pianificazione.Filter.NumeroCompactUmtsRichiesti))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroMiniUmtsRichiesti.ToString()), q => q.NumeroMiniUmtsRichiesti.Equals(pianificazione.Filter.NumeroMiniUmtsRichiesti))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroApparatiFemto.ToString()), q => q.NumeroApparatiFemto.Equals(pianificazione.Filter.NumeroApparatiFemto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroApparatiDualBand.ToString()), q => q.NumeroApparatiDualBand.Equals(pianificazione.Filter.NumeroApparatiDualBand))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MicrocelleMacrosito.ToString()), q => q.MicrocelleMacrosito.Equals(pianificazione.Filter.MicrocelleMacrosito))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.AutorizzazioneCliente.ToString()), q => q.AutorizzazioneCliente.Equals(pianificazione.Filter.AutorizzazioneCliente))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Preventivo.ToString()), q => q.Preventivo.Equals(pianificazione.Filter.Preventivo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(pianificazione.Filter.VincoliAreaPresenti))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(pianificazione.Filter.TipologiaCantiere))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.SimNecessarie.ToString()), q => q.SimNecessarie.Equals(pianificazione.Filter.SimNecessarie))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RarfStsAperta.ToString()), q => q.RarfStsAperta.Equals(pianificazione.Filter.RarfStsAperta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CtaConsegnatoVo.ToString()), q => q.CtaConsegnatoVo.Equals(pianificazione.Filter.CtaConsegnatoVo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NominaRLInviataAllaDitta.ToString()), q => q.NominaRLInviataAllaDitta.Equals(pianificazione.Filter.NominaRLInviataAllaDitta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CognomeRL), q => q.CognomeRL.Contains(pianificazione.Filter.CognomeRL))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NomeRL), q => q.NomeRL.Contains(pianificazione.Filter.NomeRL))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RdAEmessa.ToString()), q => q.RdAEmessa.Equals(pianificazione.Filter.RdAEmessa))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroRdA), q => q.NumeroRdA.Contains(pianificazione.Filter.NumeroRdA))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NcLEmessa.ToString()), q => q.NcLEmessa.Equals(pianificazione.Filter.NcLEmessa))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoApparatiAccessoriConsuntivato.ToString()), q => q.CostoApparatiAccessoriConsuntivato.Equals(pianificazione.Filter.CostoApparatiAccessoriConsuntivato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroCompactGsmInstallati.ToString()), q => q.NumeroCompactGsmInstallati.Equals(pianificazione.Filter.NumeroCompactGsmInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroCompactUmtsInstallati.ToString()), q => q.NumeroCompactUmtsInstallati.Equals(pianificazione.Filter.NumeroCompactUmtsInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroMiniGsmInstallati.ToString()), q => q.NumeroMiniGsmInstallati.Equals(pianificazione.Filter.NumeroMiniGsmInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroMiniUmtsInstallati.ToString()), q => q.NumeroMiniUmtsInstallati.Equals(pianificazione.Filter.NumeroMiniUmtsInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroApparatiFemtoInstallati.ToString()), q => q.NumeroApparatiFemtoInstallati.Equals(pianificazione.Filter.NumeroApparatiFemtoInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroApparatiDualBandInstallati.ToString()), q => q.NumeroApparatiDualBandInstallati.Equals(pianificazione.Filter.NumeroApparatiDualBandInstallati))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(pianificazione.Filter.TotaleApparatiNuovi))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(pianificazione.Filter.TotaleApparatiRiuso))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TipologiaCosto), q => q.TipologiaCosto.Contains(pianificazione.Filter.TipologiaCosto))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DeltaStimatoConsuntivato.ToString()), q => q.DeltaStimatoConsuntivato.Equals(pianificazione.Filter.DeltaStimatoConsuntivato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoTotaleConsuntivato.ToString()), q => q.CostoTotaleConsuntivato.Equals(pianificazione.Filter.CostoTotaleConsuntivato))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.RegioneVF), q => q.RegioneVF.Contains(pianificazione.Filter.RegioneVF))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(pianificazione.Filter.CodiceNazionale))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Regione), q => q.Regione.Contains(pianificazione.Filter.Regione))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.DataIncaricoInstallazioneDitta.ToString()), q => q.DataIncaricoInstallazioneDitta.Equals(pianificazione.Filter.DataIncaricoInstallazioneDitta))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(pianificazione.Filter.AgenziaRiferimento))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroNCL), q => q.NumeroNCL.Contains(pianificazione.Filter.NumeroNCL))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.NumeroODA), q => q.NumeroODA.Contains(pianificazione.Filter.NumeroODA))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.IdEntry), q => q.IdEntry.Contains(pianificazione.Filter.IdEntry))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoTotalePreventivo.ToString()), q => q.CostoTotalePreventivo.Equals(pianificazione.Filter.CostoTotalePreventivo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoTotaleApparatiPreventivo.ToString()), q => q.CostoTotaleApparatiPreventivo.Equals(pianificazione.Filter.CostoTotaleApparatiPreventivo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CostoTotaleApapratiConsuntivo.ToString()), q => q.CostoTotaleApapratiConsuntivo.Equals(pianificazione.Filter.CostoTotaleApapratiConsuntivo))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(pianificazione.Filter.PermessoNecessario))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(pianificazione.Filter.TelefonoRiferimento))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.InsertDate.ToString()), q => q.InsertDate>=pianificazione.Filter.InsertDate && q.InsertDate < pianificazione.Filter.InsertDate.GetValueOrDefault().AddDays(1))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MiniLTE.ToString()), q => q.MiniLTE.Equals(pianificazione.Filter.MiniLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CompactLTE.ToString()), q => q.CompactLTE.Equals(pianificazione.Filter.CompactLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FemtoLTE.ToString()), q => q.FemtoLTE.Equals(pianificazione.Filter.FemtoLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FemtoGSM.ToString()), q => q.FemtoGSM.Equals(pianificazione.Filter.FemtoGSM))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FemtoUMTS.ToString()), q => q.FemtoUMTS.Equals(pianificazione.Filter.FemtoUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.FemtoUMTSLTE.ToString()), q => q.FemtoUMTSLTE.Equals(pianificazione.Filter.FemtoUMTSLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiGSM.ToString()), q => q.MaxiGSM.Equals(pianificazione.Filter.MaxiGSM))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiUMTS.ToString()), q => q.MaxiUMTS.Equals(pianificazione.Filter.MaxiUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiLTE.ToString()), q => q.MaxiLTE.Equals(pianificazione.Filter.MaxiLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiUMTSLTE.ToString()), q => q.MaxiUMTSLTE.Equals(pianificazione.Filter.MaxiUMTSLTE))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MaxiGsmUmts.ToString()), q => q.MaxiGsmUmts.Equals(pianificazione.Filter.MaxiGsmUmts))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CompactGSMUMTS.ToString()), q => q.CompactGSMUMTS.Equals(pianificazione.Filter.CompactGSMUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.CompactLTEUMTS.ToString()), q => q.CompactLTEUMTS.Equals(pianificazione.Filter.CompactLTEUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.Mini.ToString()), q => q.Mini.Equals(pianificazione.Filter.Mini))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MiniGSMUMTS.ToString()), q => q.MiniGSMUMTS.Equals(pianificazione.Filter.MiniGSMUMTS))
                            .WhereIf(!String.IsNullOrEmpty(pianificazione.Filter.MiniUMTSLTE.ToString()), q => q.MiniUMTSLTE.Equals(pianificazione.Filter.MiniUMTSLTE))
                            .Count();

            return pianificazioniCount;
        }

        public void OnConfirmSave(EntityRichiesta richiesta, long userId)
        {
            try
            {
                UpdatePianificazione(richiesta, userId);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        private void UpdatePianificazione(EntityRichiesta richiesta, long userID)
        {
            try
            {
                EntityRichiesta richiestaToUpdate = new EntityRichiesta();
                EntityRichiesta richiestaOld = richiestaOld = _RCDDbContext.Richieste.Where(x => x.Id == richiesta.Id)
                    //.Include("Location")
                    //.Include("Sopralluogo")
                    //.Include("Installazione")
                    .AsNoTracking()
                    .FirstOrDefault();

                UtilityManager.MapProp(richiestaOld, richiestaToUpdate);

                if ((richiesta.IdSiteManagerNI != null) || (richiesta.IdProgettistaRan is not null))
                {
                    if (richiesta.IdSiteManagerNI != null)
                        richiestaToUpdate.IdSiteManagerNI = richiesta.IdSiteManagerNI;
                    if (richiesta.IdProgettistaRan != null)
                        richiestaToUpdate.IdProgettistaRan = richiesta.IdProgettistaRan;

                    _RCDDbContext.Update(richiestaToUpdate);
                    _RCDDbContext.SaveChanges();
                    _RCDDbContext.Entry(richiestaToUpdate).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                }


                if (richiesta.Location is not null)
                {
                    EntityLocation locationToUpdate = _RCDDbContext.Location.Where(x => x.Id == richiesta.Location.Id)
                    .AsNoTracking()
                    .FirstOrDefault();

                    richiestaToUpdate.Location = locationToUpdate;

                    //UPDATE LOCATION
                    richiestaToUpdate = SetRichiesteLocation(richiesta, richiestaToUpdate);
                    var locationUpdate = richiestaToUpdate.Location;
                    if (locationUpdate is not null)
                    {
                        _RCDDbContext.Update(locationUpdate);
                        _RCDDbContext.SaveChanges();

                        _RCDDbContext.Entry(locationUpdate).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    }
                }

                    if (richiesta.Installazione is not null)
                {
                    EntityInstallazione installazioneToUpdate = _RCDDbContext.Installazione.Where(x => x.Id == richiesta.Installazione.Id)
                   .AsNoTracking().FirstOrDefault();

                    richiestaToUpdate.Installazione = installazioneToUpdate;

                    //UPDATE INSTALLAZIONI
                    richiestaToUpdate = SetRichiesteInstallazione(richiesta, richiestaToUpdate);
                    var installazioneUpdate = richiestaToUpdate.Installazione;
                    if (installazioneUpdate is not null)
                    {
                        _RCDDbContext.Update(installazioneUpdate);
                        _RCDDbContext.SaveChanges();

                        _RCDDbContext.Entry(installazioneUpdate).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    }
                }

                if (richiesta.Sopralluogo is not null)
                {
                    EntitySopralluogo sopralluogoToUpdate = _RCDDbContext.Sopralluogo.Where(x => x.Id == richiesta.Sopralluogo.Id)
                   .AsNoTracking().FirstOrDefault();

                    richiestaToUpdate.Sopralluogo = sopralluogoToUpdate;
                    //UPDATE SOPRALLUOGO
                    richiestaToUpdate = SetRichiesteSopralluogo(richiesta, richiestaToUpdate);
                    var sopralluogoUpdate = richiestaToUpdate.Sopralluogo;
                    if (sopralluogoUpdate is not null)
                    {
                        _RCDDbContext.Update(sopralluogoUpdate);
                        _RCDDbContext.SaveChanges();

                        _RCDDbContext.Entry(sopralluogoUpdate).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    }


                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private EntityRichiesta SetRichiesteInstallazione(EntityRichiesta richiestaInput, EntityRichiesta updateRichiesta)
        {
            if (richiestaInput.Installazione is not null)
            {
                if (richiestaInput.Installazione.IdDittaInstallazione != null)
                    updateRichiesta.Installazione.IdDittaInstallazione = richiestaInput.Installazione.IdDittaInstallazione;
                if (richiestaInput.Installazione.SimNecessarie != null)
                    updateRichiesta.Installazione.SimNecessarie = richiestaInput.Installazione.SimNecessarie;
                if (richiestaInput.Installazione.CtaConsegnatoVo != null)
                    updateRichiesta.Installazione.CtaConsegnatoVo = richiestaInput.Installazione.CtaConsegnatoVo;
                if (richiestaInput.Installazione.RarfStsAperta != null)
                    updateRichiesta.Installazione.RarfStsAperta = richiestaInput.Installazione.RarfStsAperta;
                if (richiestaInput.Installazione.RdAEmessa != null)
                    updateRichiesta.Installazione.RdAEmessa = richiestaInput.Installazione.RdAEmessa;
                if (richiestaInput.Installazione.NumeroRdA != null)
                    updateRichiesta.Installazione.NumeroRdA = richiestaInput.Installazione.NumeroRdA;
                if (richiestaInput.Installazione.NcLEmessa != null)
                    updateRichiesta.Installazione.NcLEmessa = richiestaInput.Installazione.NcLEmessa;
                if (richiestaInput.Installazione.NumeroNCL != null)
                    updateRichiesta.Installazione.NumeroNCL = richiestaInput.Installazione.NumeroNCL;

                 //LAVORI DITTA TERMINATI

                if (richiestaInput.Installazione.DataPermessoPresentato != null)
                    updateRichiesta.Installazione.DataPermessoPresentato = richiestaInput.Installazione.DataPermessoPresentato;
                if (richiestaInput.Installazione.DataOnAirStimata != null)
                    updateRichiesta.Installazione.DataOnAirStimata = richiestaInput.Installazione.DataOnAirStimata;
                if (richiestaInput.Installazione.DataOnAirConsuntivata != null)
                    updateRichiesta.Installazione.DataOnAirConsuntivata = richiestaInput.Installazione.DataOnAirConsuntivata;
                if (richiestaInput.Installazione.IdStatoConsegnaLetteraEmf != null)
                    updateRichiesta.Installazione.IdStatoConsegnaLetteraEmf = richiestaInput.Installazione.IdStatoConsegnaLetteraEmf;
                if (richiestaInput.Installazione.IdStatoConsegnaLetteraComodatoUso != null)
                    updateRichiesta.Installazione.IdStatoConsegnaLetteraComodatoUso = richiestaInput.Installazione.IdStatoConsegnaLetteraComodatoUso;
                if (richiestaInput.Installazione.DescrizioneInstallazione != null)
                    updateRichiesta.Installazione.DescrizioneInstallazione = richiestaInput.Installazione.DescrizioneInstallazione;
                if (richiestaInput.Installazione.NoteInstallazione != null)
                    updateRichiesta.Installazione.NoteInstallazione = richiestaInput.Installazione.NoteInstallazione;
                if (richiestaInput.Installazione.IdTipoCosto != null)
                    updateRichiesta.Installazione.IdTipoCosto = richiestaInput.Installazione.IdTipoCosto;

                
                if (richiestaInput.Installazione.NominaRLInviataAllaDitta != null)
                {
                    updateRichiesta.Installazione.NominaRLInviataAllaDitta = richiestaInput.Installazione.NominaRLInviataAllaDitta;

                    if (updateRichiesta.Installazione.NominaRLInviataAllaDitta == true)
                    {
                        if (richiestaInput.Installazione.CognomeRL is not null)
                            updateRichiesta.Installazione.CognomeRL = richiestaInput.Installazione.CognomeRL;
                        else
                        {
                            if (updateRichiesta.Installazione.CognomeRL is null)
                                throw new Exception("Immettere il cognome del responsabile lavori.");
                        }

                        if (richiestaInput.Installazione.NomeRL is not null)
                            updateRichiesta.Installazione.NomeRL = richiestaInput.Installazione.NomeRL;
                        else
                        {
                            if (updateRichiesta.Installazione.NomeRL is null)
                                throw new Exception("Immettere il nome del responsabile lavori.");
                        }
                    }
                }

               
            }
            return updateRichiesta;
        }

        private EntityRichiesta SetRichiesteSopralluogo(EntityRichiesta richiestaInput, EntityRichiesta updateRichiesta)
        {

            if (richiestaInput.Sopralluogo is not null)
            {
                if (richiestaInput.Sopralluogo.DataSopralluogoStimata != null)
                    updateRichiesta.Sopralluogo.DataSopralluogoStimata = richiestaInput.Sopralluogo.DataSopralluogoStimata;
                if (richiestaInput.Sopralluogo.DataSopralluogoConsuntivata != null)
                    updateRichiesta.Sopralluogo.DataSopralluogoConsuntivata = richiestaInput.Sopralluogo.DataSopralluogoConsuntivata;
                if (richiestaInput.Sopralluogo.DataInstallazioneStimata != null)
                    updateRichiesta.Sopralluogo.DataInstallazioneStimata = richiestaInput.Sopralluogo.DataInstallazioneStimata;

                if (richiestaInput.Sopralluogo.DataInvioStima != null)
                    updateRichiesta.Sopralluogo.DataInvioStima = richiestaInput.Sopralluogo.DataInvioStima;

                if (richiestaInput.Sopralluogo.DataPresentazionePermesso != null)
                    updateRichiesta.Sopralluogo.DataPresentazionePermesso = richiestaInput.Sopralluogo.DataPresentazionePermesso;
                if (richiestaInput.Sopralluogo.StudioProgettazione != null)
                    updateRichiesta.Sopralluogo.StudioProgettazione = richiestaInput.Sopralluogo.StudioProgettazione;
                if (richiestaInput.Sopralluogo.NoteRANVO != null)
                    updateRichiesta.Sopralluogo.NoteRANVO = richiestaInput.Sopralluogo.NoteRANVO;
                //if (richiestaInput.Sopralluogo.DeliveryManager != null)
                //    updateRichiesta.Sopralluogo.DeliveryManager = richiestaInput.Sopralluogo.DeliveryManager;
                if (richiestaInput.Sopralluogo.IdDeliveryManager != null)
                    updateRichiesta.Sopralluogo.IdDeliveryManager = richiestaInput.Sopralluogo.IdDeliveryManager;

                if (richiestaInput.Sopralluogo.IdDittaIncaricata != null)
                    updateRichiesta.Sopralluogo.IdDittaIncaricata = richiestaInput.Sopralluogo.IdDittaIncaricata;

                if (richiestaInput.Sopralluogo.NumeroProtocolloRichiesta != null)
                    updateRichiesta.Sopralluogo.NumeroProtocolloRichiesta = richiestaInput.Sopralluogo.NumeroProtocolloRichiesta;
                if (richiestaInput.Sopralluogo.NumeroSimNecessarie != null)
                    updateRichiesta.Sopralluogo.NumeroSimNecessarie = richiestaInput.Sopralluogo.NumeroSimNecessarie;
                if (richiestaInput.Sopralluogo.StimaOttenimentoPermesso != null)
                    updateRichiesta.Sopralluogo.StimaOttenimentoPermesso = richiestaInput.Sopralluogo.StimaOttenimentoPermesso;
                if (richiestaInput.Sopralluogo.IdTipoCantiere != null)
                    updateRichiesta.Sopralluogo.IdTipoCantiere = richiestaInput.Sopralluogo.IdTipoCantiere;
                if (richiestaInput.Sopralluogo.AutorizzazioneCliente != null)
                    updateRichiesta.Sopralluogo.AutorizzazioneCliente = richiestaInput.Sopralluogo.AutorizzazioneCliente;
                if (richiestaInput.Sopralluogo.Preventivo != null)
                    updateRichiesta.Sopralluogo.Preventivo = richiestaInput.Sopralluogo.Preventivo;
                if (richiestaInput.Sopralluogo.PermessoNecessario != null)
                    updateRichiesta.Sopralluogo.PermessoNecessario = richiestaInput.Sopralluogo.PermessoNecessario;
                if (richiestaInput.Sopralluogo.VincoliAreaPresenti != null)
                    updateRichiesta.Sopralluogo.VincoliAreaPresenti = richiestaInput.Sopralluogo.VincoliAreaPresenti;
                if (richiestaInput.Sopralluogo.NecessitaRelazione != null)
                    updateRichiesta.Sopralluogo.NecessitaRelazione = richiestaInput.Sopralluogo.NecessitaRelazione;
                if (richiestaInput.Sopralluogo.TipologiaVincolo != null)
                    updateRichiesta.Sopralluogo.TipologiaVincolo = richiestaInput.Sopralluogo.TipologiaVincolo;
                if (richiestaInput.Sopralluogo.DescrizioneSopralluogo != null)
                    updateRichiesta.Sopralluogo.DescrizioneSopralluogo = richiestaInput.Sopralluogo.DescrizioneSopralluogo;


            }
            return updateRichiesta;
        }

        private EntityRichiesta SetRichiesteLocation(EntityRichiesta richiestaInput, EntityRichiesta updateRichiesta)
        {

            if (richiestaInput.Location is not null)
            {

                if (richiestaInput.Location.IdComune is not null)
                {
                    updateRichiesta.Location.IdComune = richiestaInput.Location.IdComune;
                }
                else
                {
                    throw new Exception("Attenzione: Comune mancante");
                }

                if (!string.IsNullOrEmpty(richiestaInput.Location.NomeInstallazione))
                    updateRichiesta.Location.NomeInstallazione = richiestaInput.Location.NomeInstallazione;
                if (richiestaInput.Location.LatitudineGradi is not null)
                    updateRichiesta.Location.LatitudineGradi = richiestaInput.Location.LatitudineGradi;
                if (richiestaInput.Location.LatitudinePrimi is not null)
                    updateRichiesta.Location.LatitudinePrimi = richiestaInput.Location.LatitudinePrimi;
                if (richiestaInput.Location.LatitudineSecondi is not null)
                    updateRichiesta.Location.LatitudineSecondi = richiestaInput.Location.LatitudineSecondi;
                if (richiestaInput.Location.LatitudineUTM is not null)
                    updateRichiesta.Location.LatitudineUTM = richiestaInput.Location.LatitudineUTM;
                if (richiestaInput.Location.LongitudineGradi is not null)
                    updateRichiesta.Location.LongitudineGradi = richiestaInput.Location.LongitudineGradi;
                if (richiestaInput.Location.LongitudinePrimi is not null)
                    updateRichiesta.Location.LongitudinePrimi = richiestaInput.Location.LongitudinePrimi;
                if (richiestaInput.Location.LongitudineSecondi is not null)
                    updateRichiesta.Location.LongitudineSecondi = richiestaInput.Location.LongitudineSecondi;
                if (richiestaInput.Location.LongitudineUTM is not null)
                    updateRichiesta.Location.LongitudineUTM = richiestaInput.Location.LongitudineUTM;
                if (richiestaInput.Location.SLM is not null)
                    updateRichiesta.Location.SLM = richiestaInput.Location.SLM;
                if (richiestaInput.Location.Indirizzo is not null)
                    updateRichiesta.Location.Indirizzo = richiestaInput.Location.Indirizzo;
                if (richiestaInput.Location.CAP is not null)
                    updateRichiesta.Location.CAP = richiestaInput.Location.CAP;
                if (richiestaInput.Location.FullNameReferenteLocale is not null)
                    updateRichiesta.Location.FullNameReferenteLocale = richiestaInput.Location.FullNameReferenteLocale;
                if (richiestaInput.Location.EmailReferenteLocale is not null)
                    updateRichiesta.Location.EmailReferenteLocale = richiestaInput.Location.EmailReferenteLocale;
                if (richiestaInput.Location.TelefonoReferenteLocale is not null)
                    updateRichiesta.Location.TelefonoReferenteLocale = richiestaInput.Location.TelefonoReferenteLocale;

            }
            return updateRichiesta;
        }

}
}