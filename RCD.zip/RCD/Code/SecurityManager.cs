﻿using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace RCD.Code
{
	internal class SecurityManager
	{
		//private static String _dataPassword = "TCwZYuCHUHCNtHBLJzM5HiLH54Qhh8Wd";//"KA9i(#47oq£(m-HaY9pe%!£qgrhmYaQgfdcu?(veGm3a!£-yA46H§Bko9(S_sr#*N)ch3K*)zsqAeAmVMc#vMkhSn=6vRyF6e2Ln7njLTb%m-NL6§MLa?RaYzhBf4S%g";
		//private static String _dataPassword2 = "Q9ruA6FDkdCnvv8hYqHoDNw98cXmMGxuvyBU9nNp5YZ3Et9RqSzMGVQphQFkW3CSuLAp6QDHUDGsqGDDDeUAXaustfKXHkMMNbSCDQ7P2aGt4MB6RZjxBgVQ9xbRMw9rAz5H7Anj36xW7Z9dJxwpp8KaMHXyi49mZ8PCqNrWDyWwEm4awTkPcmSQ5HhZkCiqAkRQKQuYrurvWfMGt7dT9FZkbpv63EVWiubv8dcyQ2SVYB7aSfxphEyQt9SXxofmy8EHuQy2z4GxscrvTx8iaojYxERfFm8zRMYZAzL5XwwUHqD7d4xdPVJa5FEUAQtaEcEaU4GFj5LETHJyyTs9Mw2nAsgvj5ocL647TnnDgcNRveVoRCfcyiTfV6Tb2m9t7TiZwVNmNQQrrBMFhXxxfeyRvcRpRvHXMdzF7MoxsvWmNAdzj8GujMG8zTJBGJ8Q45DB2onXoBLmC9hVCWKCrJqL25cuehjZMWZPrz6Nvs6gYGfRiH3FThYnmCUFDV3G"; //"h2ZtvS?gnVN4nfY&z_awMGqHCGG(4sih2q/Asw6LJp?*hdH2N5qzj*g?a!VmbRJw?GEhy%!YBYj2rW2#D7qN(5KGtDR6s$3LPx^rfzLqBQfNPmrK9y$Znq?%&yqK%*TX8ZsYvHhNX%V5grN_zCMaexf=Y/6£9LpuN5x£Q=A_DN3NrbMMxR*22pSL£ZxerJ^j(XhRw)wYzQYw5^MxPx3(-E4SsWvJrA#-CwFkd4ZPgat!3m*)ieY&4J$t§!?RQLev&N^mYta)NSjisyi4?ycm5kvP3LQjysWvk7_5iARB£CRUEg*Y3zzfCLFP6oJX=ae&%AEPWZtmbLG79tvgTfye8K2vzR-m)TfZKpck=SD-PwKiiFsbx/-YrG§jH=E§2$pi(fNnEmm72_oQXJ53N#7R4NVFwh#c_5Pgtc9ipKYc(R-hhnuNdA$-)qR&24YsVjVozx/LfDfs7dBcA$koVqe9xS(D)-w(j)qBDNsBRV_()H6§§w4k#4£cR=%9np//p?(G";
		//public static String DataPassword { get { return _dataPassword; } }
		//public static String DataPassword2 { get { return _dataPassword2; } }


		private readonly Encoding _utf8Encoding = Encoding.UTF8;


		public String EncryptAndEncode(String plainSourceStringToEncrypt, String passPhrase)
		{
			if (String.IsNullOrEmpty(plainSourceStringToEncrypt))
				return String.Empty;

			return HttpUtility.HtmlEncode(Encrypt(plainSourceStringToEncrypt, passPhrase));
		}
		public String DecryptAndDecode(String stringToDecrypt, String passPhrase)
		{
			if (String.IsNullOrEmpty(stringToDecrypt))
				return String.Empty;

			stringToDecrypt = stringToDecrypt.Replace(" ", "+");
			return HttpUtility.HtmlDecode(Decrypt(stringToDecrypt, passPhrase));
		}


		public String EncryptTokenKey(String plainSourceStringToEncrypt, String passPhrase)
		{
			return SplitAndMix(EncryptAndEncode(plainSourceStringToEncrypt, passPhrase));
		}
		public String DecryptTokenKey(String stringToDecrypt, String passPhrase)
		{
			return DecryptAndDecode(DeSplitAndDeMix(stringToDecrypt), passPhrase);
		}



		/// <summary>
		/// Encrpyts the sourceString, returns this result as an Aes encrpyted, BASE64 encoded string
		/// </summary>
		/// <param name="plainSourceStringToEncrypt">a plain, Framework string (ASCII, null terminated)</param>
		/// <param name="passPhrase">The pass phrase.</param>
		/// <returns>
		/// returns an Aes encrypted, BASE64 encoded string
		/// </returns>
		public String Encrypt(String plainSourceStringToEncrypt, String passPhrase)
		{
			if (String.IsNullOrEmpty(plainSourceStringToEncrypt))
				return String.Empty;


			////////UnicodeEncoding unicodeEncoding = new UnicodeEncoding();
			////////byte[] dataToEncrypt = unicodeEncoding.GetBytes(plainSourceStringToEncrypt); ;
			////////byte[] encryptedData;
			////////byte[] decryptedData;

			////////var csp = new RSACryptoServiceProvider(2048);

			//////////how to get the private key
			////////var privKey = csp.ExportParameters(true);

			//////////and the public key ...
			////////var pubKey = csp.ExportParameters(false);


			//////////we need some buffer
			////////var sw = new System.IO.StringWriter();
			//////////we need a serializer
			////////var xs = new System.Xml.Serialization.XmlSerializer(typeof(RSAParameters));
			//////////serialize the key into the stream
			////////xs.Serialize(sw, pubKey);
			//////////get the string from the stream
			////////string pubKeyString = sw.ToString();




			////////return "";


			using (AesCryptoServiceProvider acsp = GetProvider(Encoding.Default.GetBytes(passPhrase)))
			{
				//byte[] sourceBytes = Encoding.ASCII.GetBytes(plainSourceStringToEncrypt);
				byte[] sourceBytes = Encoding.UTF8.GetBytes(plainSourceStringToEncrypt);
				ICryptoTransform ictE = acsp.CreateEncryptor();

				//Set up stream to contain the encryption
				MemoryStream msS = new MemoryStream();

				//Perform the encrpytion, storing output into the stream
				CryptoStream csS = new CryptoStream(msS, ictE, CryptoStreamMode.Write);
				csS.Write(sourceBytes, 0, sourceBytes.Length);
				csS.FlushFinalBlock();

				//sourceBytes are now encrypted as an array of secure bytes
				byte[] encryptedBytes = msS.ToArray(); //.ToArray() is important, don't mess with the buffer

				//return the encrypted bytes as a BASE64 encoded string
				return Convert.ToBase64String(encryptedBytes);
			}
		}
		/// <summary>
		/// Decrypts a BASE64 encoded string of encrypted data, returns a plain string
		/// </summary>
		/// <param name="stringToDecrypt">an Aes encrypted AND base64 encoded string</param>
		/// <param name="passphrase">The passphrase.</param>
		/// <returns>returns a plain string</returns>
		public String Decrypt(String stringToDecrypt, String passphrase)
		{
			if (String.IsNullOrEmpty(stringToDecrypt))
				return String.Empty;

			try
			{
				//Set up the encryption objects
				using (AesCryptoServiceProvider acsp = GetProvider(Encoding.Default.GetBytes(passphrase)))
				{
					byte[] RawBytes = Convert.FromBase64String(stringToDecrypt);
					ICryptoTransform ictD = acsp.CreateDecryptor();

					//RawBytes now contains original byte array, still in Encrypted state

					//Decrypt into stream
					MemoryStream msD = new MemoryStream(RawBytes, 0, RawBytes.Length);
					CryptoStream csD = new CryptoStream(msD, ictD, CryptoStreamMode.Read);
					//csD now contains original byte array, fully decrypted

					//return the content of msD as a regular string
					return (new StreamReader(csD)).ReadToEnd();
				}
			}
			catch (Exception ex)
			{

				return stringToDecrypt;
			}
		}


		#region " PRIVATE METHOS "

		private String SplitAndMix(String value)
		{
			String dummy = value;

			//SPLITTO E MISCHIO LA STRINGA CRYPTATA
			Int32 lunghezzaStringa = dummy.Length;
			Int32 lunghezzaMassima = Convert.ToInt32(Math.Floor(Convert.ToDecimal(lunghezzaStringa) / 10) * 10);
			Int32 lunghezzaResto = lunghezzaStringa - lunghezzaMassima;
			Int32 lunghezzaMeta = lunghezzaMassima / 2;

			String dummy1 = dummy.Substring(0, lunghezzaMeta);
			String dummy2 = dummy.Substring(lunghezzaMeta, lunghezzaMeta);
			String dummy3 = dummy.Substring(lunghezzaMeta * 2);

			dummy = dummy2 + dummy1 + dummy3;

			return dummy;
		}
		private String DeSplitAndDeMix(String value)
		{
			String dummy = value;

			//SPLITTO E MISCHIO LA STRINGA CRYPTATA
			Int32 lunghezzaStringa = dummy.Length;
			Int32 lunghezzaMassima = Convert.ToInt32(Math.Floor(Convert.ToDecimal(lunghezzaStringa) / 10) * 10);
			Int32 lunghezzaResto = lunghezzaStringa - lunghezzaMassima;
			Int32 lunghezzaMeta = lunghezzaMassima / 2;

			String dummy1 = dummy.Substring(0, lunghezzaMeta);
			String dummy2 = dummy.Substring(lunghezzaMeta, lunghezzaMeta);
			String dummy3 = dummy.Substring(lunghezzaMeta * 2);

			dummy = dummy2 + dummy1 + dummy3;

			return dummy;
		}




		private byte[] RSAEncrypt(byte[] dataToEncrypt, RSAParameters rsaKeyInfo, bool doOAEPPadding)
		{
			try
			{
				byte[] encryptedData;
				//Create a new instance of RSACryptoServiceProvider.
				using (RSACryptoServiceProvider RSA = new RSACryptoServiceProvider())
				{
					//Import the RSA Key information. This only needs
					//toinclude the public key information.
					RSA.ImportParameters(rsaKeyInfo);

					//Encrypt the passed byte array and specify OAEP padding.  
					//OAEP padding is only available on Microsoft Windows XP or
					//later.  
					encryptedData = RSA.Encrypt(dataToEncrypt, doOAEPPadding);
				}
				return encryptedData;
			}
			//Catch and display a CryptographicException  
			//to the console.
			catch (CryptographicException e)
			{
				return null;
			}

		}

		private byte[] RSADecrypt(byte[] dataToDecrypt, RSAParameters rsaKeyInfo, bool doOAEPPadding)
		{
			try
			{
				byte[] decryptedData;
				//Create a new instance of RSACryptoServiceProvider.
				using (RSACryptoServiceProvider RSA = new RSACryptoServiceProvider())
				{
					//Import the RSA Key information. This needs
					//to include the private key information.
					RSA.ImportParameters(rsaKeyInfo);

					//Decrypt the passed byte array and specify OAEP padding.  
					//OAEP padding is only available on Microsoft Windows XP or
					//later.  
					decryptedData = RSA.Decrypt(dataToDecrypt, doOAEPPadding);
				}
				return decryptedData;
			}
			//Catch and display a CryptographicException  
			//to the console.
			catch (CryptographicException e)
			{
				return null;
			}

		}





		private AesCryptoServiceProvider GetProvider(byte[] key)
		{
			AesCryptoServiceProvider result = new AesCryptoServiceProvider();
			result.BlockSize = 128;
			result.KeySize = 256;
			result.Mode = CipherMode.CBC;
			result.Padding = PaddingMode.PKCS7;

			result.GenerateIV();
			result.IV = new byte[] { 11, 250, 45, 2, 13, 32, 98, 8, 1, 0, 124, 12, 65, 99, 23, 22 };

			byte[] RealKey = GetKey(key, result);
			result.Key = RealKey;
			// result.IV = RealKey;
			return result;
		}

		private byte[] GetKey(byte[] suggestedKey, SymmetricAlgorithm p)
		{
			byte[] kRaw = suggestedKey;
			List<byte> kList = new List<byte>();

			for (int i = 0; i < p.LegalKeySizes[0].MinSize; i += 8)
			{
				kList.Add(kRaw[(i / 8) % kRaw.Length]);
			}
			byte[] k = kList.ToArray();
			return k;
		}

		#endregion
	}
}

