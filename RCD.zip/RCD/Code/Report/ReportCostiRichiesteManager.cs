﻿using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCD.Code.Installazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;
namespace RCD.Code.Report
{
    public class ReportCostiRichiesteManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public ReportCostiRichiesteManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        #region View Report Costi Richiesta
        public async Task<List<ContractViewReportCostiRichieste>> GetReportCostiRichiesteCustom(ViewReportCostiRichiesteRequestFull richieste)
        {
            List<EntityViewReportCostiRichieste> richiesta;
            List<Int64?> stati = new List<Int64?>();

            String sortParam = String.Concat(String.Concat(richieste.CampoOrdinamento, " "), richieste.Ordinamento.ToUpper());

            if (richieste.Pageable)
            {
                stati = _RCDDbContext.Stato
                                   .Where(x => x.IsKoState == false && x.IsFinalState == true)
                                   .Select(x => x.Id)
                                  .ToList();
                _RCDDbContext.Database.SetCommandTimeout(300);
                richiesta = await _RCDDbContext.ViewReportCostiRichieste
                       .Where(x => stati.Contains(x.IdUltimoStato.Value))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.ProgettistaRan), q => q.ProgettistaRan.Contains(richieste.Filter.ProgettistaRan))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.SiteManagerNi), q => q.SiteManagerNi.Contains(richieste.Filter.SiteManagerNi))
                        .WhereIf(!String.IsNullOrEmpty(richieste.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(richieste.Filter.RiferimentoDce))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.RiferimentoAm), q => q.RiferimentoAm.Contains(richieste.Filter.RiferimentoAm))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(richieste.Filter.RiferimentoVendite))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.RagioneSociale), q => q.RagioneSociale.Contains(richieste.Filter.RagioneSociale))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.PartitaIva), q => q.PartitaIva.Contains(richieste.Filter.PartitaIva))
                          .WhereIf(!String.IsNullOrEmpty(richieste.Filter.InseritoDa), q => q.InseritoDa.Contains(richieste.Filter.InseritoDa))
                          .WhereIf(!String.IsNullOrEmpty(richieste.Filter.CodiceCliente.ToString()), x => x.CodiceCliente.Equals(richieste.Filter.CodiceCliente))
                            .WhereIf(!String.IsNullOrEmpty(richieste.Filter.Richiedente), q => q.Richiedente.Contains(richieste.Filter.Richiedente))
                               .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DataSopralluogoConsuntivata.ToString()), x => x.DataSopralluogoConsuntivata.Equals(richieste.Filter.DataSopralluogoConsuntivata))
                                 .WhereIf(!String.IsNullOrEmpty(richieste.Filter.SpesaStimata.ToString()), x => x.SpesaStimata.Equals(richieste.Filter.SpesaStimata))
                                  .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DataInstallazione.ToString()), x => x.DataInstallazione.Equals(richieste.Filter.DataInstallazione))
                                   .WhereIf(!String.IsNullOrEmpty(richieste.Filter.CostoConsuntivato.ToString()), x => x.CostoConsuntivato.Equals(richieste.Filter.CostoConsuntivato))
                                    .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DeltaCostoStimatoConsuntivato.ToString()), x => x.DeltaCostoStimatoConsuntivato.Equals(richieste.Filter.DeltaCostoStimatoConsuntivato))
                                    .WhereIf(!String.IsNullOrEmpty(richieste.Filter.LastStatus), q => q.LastStatus.Contains(richieste.Filter.LastStatus))
                            .WhereIf(!String.IsNullOrEmpty(richieste.Filter.CodiceInstallazione), q => q.CodiceInstallazione.Contains(richieste.Filter.CodiceInstallazione))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DittaSopralluogo), q => q.DittaSopralluogo.Contains(richieste.Filter.DittaSopralluogo))
                        .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DittaInstallazione), q => q.DittaInstallazione.Contains(richieste.Filter.DittaInstallazione))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(richieste.Filter.CanaleVenditaDettaglio))
                          .WhereIf(!String.IsNullOrEmpty(richieste.Filter.Zona), q => q.Zona.Contains(richieste.Filter.Zona))
                           .WhereIf(!String.IsNullOrEmpty(richieste.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(richieste.Filter.NomeInstallazione))
                          .WhereIf(!String.IsNullOrEmpty(richieste.Filter.FatturatoMedioBimestrale.ToString()), x => x.FatturatoMedioBimestrale.Equals(richieste.Filter.FatturatoMedioBimestrale))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.NumeroSim.ToString()), x => x.NumeroSim.Equals(richieste.Filter.NumeroSim))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.NumeroInterniVruc.ToString()), x => x.NumeroInterniVruc.Equals(richieste.Filter.NumeroInterniVruc))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.IdUltimoStato.ToString()), x => x.IdUltimoStato.Equals(richieste.Filter.IdUltimoStato))
                        .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DataRichiesta.ToString()), x => x.DataRichiesta.Equals(richieste.Filter.DataRichiesta))
                       .Skip(richieste.NumeroElementi * richieste.Page).Take(richieste.NumeroElementi)
                       .OrderBy(sortParam)
                       .ToListAsync();
            }
            else
            {
                stati = _RCDDbContext.Stato
                                   .Where(x => x.IsKoState == false && x.IsFinalState == true)
                                   .Select(x => x.Id)
                                  .ToList();
                _RCDDbContext.Database.SetCommandTimeout(300);
                richiesta = await _RCDDbContext.ViewReportCostiRichieste
                      .Where(x => stati.Contains(x.IdUltimoStato.Value))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.ProgettistaRan), q => q.ProgettistaRan.Contains(richieste.Filter.ProgettistaRan))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.SiteManagerNi), q => q.SiteManagerNi.Contains(richieste.Filter.SiteManagerNi))
                        .WhereIf(!String.IsNullOrEmpty(richieste.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(richieste.Filter.RiferimentoDce))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.RiferimentoAm), q => q.RiferimentoAm.Contains(richieste.Filter.RiferimentoAm))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(richieste.Filter.RiferimentoVendite))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.RagioneSociale), q => q.RagioneSociale.Contains(richieste.Filter.RagioneSociale))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.PartitaIva), q => q.PartitaIva.Contains(richieste.Filter.PartitaIva))
                          .WhereIf(!String.IsNullOrEmpty(richieste.Filter.InseritoDa), q => q.InseritoDa.Contains(richieste.Filter.InseritoDa))
                          .WhereIf(!String.IsNullOrEmpty(richieste.Filter.CodiceCliente.ToString()), x => x.CodiceCliente.Equals(richieste.Filter.CodiceCliente))
                            .WhereIf(!String.IsNullOrEmpty(richieste.Filter.Richiedente), q => q.Richiedente.Contains(richieste.Filter.Richiedente))
                               .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DataSopralluogoConsuntivata.ToString()), x => x.DataSopralluogoConsuntivata.Equals(richieste.Filter.DataSopralluogoConsuntivata))
                                 .WhereIf(!String.IsNullOrEmpty(richieste.Filter.SpesaStimata.ToString()), x => x.SpesaStimata.Equals(richieste.Filter.SpesaStimata))
                                  .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DataInstallazione.ToString()), x => x.DataInstallazione.Equals(richieste.Filter.DataInstallazione))
                                   .WhereIf(!String.IsNullOrEmpty(richieste.Filter.CostoConsuntivato.ToString()), x => x.CostoConsuntivato.Equals(richieste.Filter.CostoConsuntivato))
                                    .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DeltaCostoStimatoConsuntivato.ToString()), x => x.DeltaCostoStimatoConsuntivato.Equals(richieste.Filter.DeltaCostoStimatoConsuntivato))
                                    .WhereIf(!String.IsNullOrEmpty(richieste.Filter.LastStatus), q => q.LastStatus.Contains(richieste.Filter.LastStatus))
                            .WhereIf(!String.IsNullOrEmpty(richieste.Filter.CodiceInstallazione), q => q.CodiceInstallazione.Contains(richieste.Filter.CodiceInstallazione))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DittaSopralluogo), q => q.DittaSopralluogo.Contains(richieste.Filter.DittaSopralluogo))
                        .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DittaInstallazione), q => q.DittaInstallazione.Contains(richieste.Filter.DittaInstallazione))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(richieste.Filter.CanaleVenditaDettaglio))
                          .WhereIf(!String.IsNullOrEmpty(richieste.Filter.Zona), q => q.Zona.Contains(richieste.Filter.Zona))
                           .WhereIf(!String.IsNullOrEmpty(richieste.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(richieste.Filter.NomeInstallazione))
                          .WhereIf(!String.IsNullOrEmpty(richieste.Filter.FatturatoMedioBimestrale.ToString()), x => x.FatturatoMedioBimestrale.Equals(richieste.Filter.FatturatoMedioBimestrale))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.NumeroSim.ToString()), x => x.NumeroSim.Equals(richieste.Filter.NumeroSim))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.NumeroInterniVruc.ToString()), x => x.NumeroInterniVruc.Equals(richieste.Filter.NumeroInterniVruc))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.IdUltimoStato.ToString()), x => x.IdUltimoStato.Equals(richieste.Filter.IdUltimoStato))
                        .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DataRichiesta.ToString()), x => x.DataRichiesta.Equals(richieste.Filter.DataRichiesta))
                       .Skip(richieste.NumeroElementi * richieste.Page).Take(richieste.NumeroElementi)
                       .OrderBy(sortParam)
                       .ToListAsync();

            }
            List<ContractViewReportCostiRichieste> richiestaElenco = new List<ContractViewReportCostiRichieste>();
            foreach (EntityViewReportCostiRichieste varRichiesta in richiesta)
            {
                ContractViewReportCostiRichieste report = new ContractViewReportCostiRichieste();
                UtilityManager.MapProp(varRichiesta, report);
                richiestaElenco.Add(report);
            }
            return richiestaElenco;
        }

        public async Task<Int32> GetReportCostiRichiesteCustomTot(ViewReportCostiRichiesteRequestFull richieste)
        {
            List<Int64?> stati = new List<Int64?>();
            stati = _RCDDbContext.Stato
                                  .Where(x => x.IsKoState == false && x.IsFinalState == true)
                                  .Select(x => x.Id)
                                 .ToList();
            _RCDDbContext.Database.SetCommandTimeout(300);
            Int32 count = _RCDDbContext.ViewReportCostiRichieste
                       .Where(x => stati.Contains(x.IdUltimoStato.Value))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.ProgettistaRan), q => q.ProgettistaRan.Contains(richieste.Filter.ProgettistaRan))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.SiteManagerNi), q => q.SiteManagerNi.Contains(richieste.Filter.SiteManagerNi))
                        .WhereIf(!String.IsNullOrEmpty(richieste.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(richieste.Filter.RiferimentoDce))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.RiferimentoAm), q => q.RiferimentoAm.Contains(richieste.Filter.RiferimentoAm))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(richieste.Filter.RiferimentoVendite))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.RagioneSociale), q => q.RagioneSociale.Contains(richieste.Filter.RagioneSociale))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.PartitaIva), q => q.PartitaIva.Contains(richieste.Filter.PartitaIva))
                          .WhereIf(!String.IsNullOrEmpty(richieste.Filter.InseritoDa), q => q.InseritoDa.Contains(richieste.Filter.InseritoDa))
                          .WhereIf(!String.IsNullOrEmpty(richieste.Filter.CodiceCliente.ToString()), x => x.CodiceCliente.Equals(richieste.Filter.CodiceCliente))
                            .WhereIf(!String.IsNullOrEmpty(richieste.Filter.Richiedente), q => q.Richiedente.Contains(richieste.Filter.Richiedente))
                               .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DataSopralluogoConsuntivata.ToString()), x => x.DataSopralluogoConsuntivata.Equals(richieste.Filter.DataSopralluogoConsuntivata))
                                 .WhereIf(!String.IsNullOrEmpty(richieste.Filter.SpesaStimata.ToString()), x => x.SpesaStimata.Equals(richieste.Filter.SpesaStimata))
                                  .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DataInstallazione.ToString()), x => x.DataInstallazione.Equals(richieste.Filter.DataInstallazione))
                                   .WhereIf(!String.IsNullOrEmpty(richieste.Filter.CostoConsuntivato.ToString()), x => x.CostoConsuntivato.Equals(richieste.Filter.CostoConsuntivato))
                                    .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DeltaCostoStimatoConsuntivato.ToString()), x => x.DeltaCostoStimatoConsuntivato.Equals(richieste.Filter.DeltaCostoStimatoConsuntivato))
                                    .WhereIf(!String.IsNullOrEmpty(richieste.Filter.LastStatus), q => q.LastStatus.Contains(richieste.Filter.LastStatus))
                            .WhereIf(!String.IsNullOrEmpty(richieste.Filter.CodiceInstallazione), q => q.CodiceInstallazione.Contains(richieste.Filter.CodiceInstallazione))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DittaSopralluogo), q => q.DittaSopralluogo.Contains(richieste.Filter.DittaSopralluogo))
                        .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DittaInstallazione), q => q.DittaInstallazione.Contains(richieste.Filter.DittaInstallazione))
                         .WhereIf(!String.IsNullOrEmpty(richieste.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(richieste.Filter.CanaleVenditaDettaglio))
                          .WhereIf(!String.IsNullOrEmpty(richieste.Filter.Zona), q => q.Zona.Contains(richieste.Filter.Zona))
                           .WhereIf(!String.IsNullOrEmpty(richieste.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(richieste.Filter.NomeInstallazione))
                          .WhereIf(!String.IsNullOrEmpty(richieste.Filter.FatturatoMedioBimestrale.ToString()), x => x.FatturatoMedioBimestrale.Equals(richieste.Filter.FatturatoMedioBimestrale))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.NumeroSim.ToString()), x => x.NumeroSim.Equals(richieste.Filter.NumeroSim))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.NumeroInterniVruc.ToString()), x => x.NumeroInterniVruc.Equals(richieste.Filter.NumeroInterniVruc))
                       .WhereIf(!String.IsNullOrEmpty(richieste.Filter.IdUltimoStato.ToString()), x => x.IdUltimoStato.Equals(richieste.Filter.IdUltimoStato))
                        .WhereIf(!String.IsNullOrEmpty(richieste.Filter.DataRichiesta.ToString()), x => x.DataRichiesta.Equals(richieste.Filter.DataRichiesta))
                       .Count();
            return count;
        }

        #endregion View Report Costi Richiesta


    }
}
