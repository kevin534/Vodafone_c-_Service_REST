﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Richieste
{
    public class UtenteManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public UtenteManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractUtente>> GetUtentiRiferimentiVendite(UtenteRequestFull utenteFilter)
        {
            List<EntityUtente> utente;
            utente = await _RCDDbContext.Utente.Where(x => x.Abilitato == true)
                    .Where(x => x.TipologiaUtente.TipologiaUtente == "DPM" || x.TipologiaUtente.TipologiaUtente == "KAM")
                    .WhereIf(!String.IsNullOrEmpty(utenteFilter.Filter.IdAreaVendita.ToString()), q => q.IdAreaVendita.Equals(utenteFilter.Filter.IdAreaVendita))
                    .WhereIf(!String.IsNullOrEmpty(utenteFilter.Filter.IdCanaleVendita.ToString()), q => q.IdCanaleVendita.Equals(utenteFilter.Filter.IdCanaleVendita))
                    .WhereIf(!String.IsNullOrEmpty(utenteFilter.Filter.IdCanaleVenditaDettaglio.ToString()), q => q.IdCanaleVenditaDettaglio.Equals(utenteFilter.Filter.IdCanaleVenditaDettaglio))

                    .OrderBy(x => x.Id)
                    .Include("AreaVendita")
                    .Include("TipologiaUtente")
                    // .Include("ListUtenteProvincia.StsProvincia")
                    .ToListAsync();
            List<ContractUtente> utenteElenco = new List<ContractUtente>();
            foreach (EntityUtente varUtente in utente)
            {
                ContractUtente utente1 = new ContractUtente();
                UtilityManager.MapProp(varUtente, utente1);
                utenteElenco.Add(utente1);
            }
            return utenteElenco;
        }
        
        public async Task<List<ContractUtente>> GetUtentiRiferimentiAreaManager(UtenteRequestFull utenteFilter)
        {
            List<EntityUtente> utente;
            utente = await _RCDDbContext.Utente.Where(x => x.Abilitato == true)
                    .Where(x => x.TipologiaUtente.TipologiaUtente == "AM")
                    .WhereIf(!String.IsNullOrEmpty(utenteFilter.Filter.IdAreaVendita.ToString()), q => q.IdAreaVendita.Equals(utenteFilter.Filter.IdAreaVendita))
                    .WhereIf(!String.IsNullOrEmpty(utenteFilter.Filter.IdCanaleVendita.ToString()), q => q.IdCanaleVendita.Equals(utenteFilter.Filter.IdCanaleVendita))
                    .WhereIf(!String.IsNullOrEmpty(utenteFilter.Filter.IdCanaleVenditaDettaglio.ToString()), q => q.IdCanaleVenditaDettaglio.Equals(utenteFilter.Filter.IdCanaleVenditaDettaglio))
                    .OrderBy(x => x.Id)
                    .Include("AreaVendita")
                    .Include("Zona")
                    .Include("TipologiaUtente")
                    .ToListAsync();
            List<ContractUtente> utenteElenco = new List<ContractUtente>();
            foreach (EntityUtente varUtente in utente)
            {
                ContractUtente utente1 = new ContractUtente();
                UtilityManager.MapProp(varUtente, utente1);
                utenteElenco.Add(utente1);
            }
            return utenteElenco;
        }
        
        public async Task<List<ContractUtente>> GetUtentiRiferimentiDce()
        {
            List<EntityUtente> utente;
            utente = await _RCDDbContext.Utente.Where(x => x.Abilitato == true)
                    .Where(x => x.TipologiaUtente.TipologiaUtente == "DCE")
                    .OrderBy(x => x.Id)
                    .Include("Zona")
                    .Include("TipologiaUtente")
                    .ToListAsync();
            List<ContractUtente> utenteElenco = new List<ContractUtente>();
            foreach (EntityUtente varUtente in utente)
            {
                ContractUtente utente1 = new ContractUtente();
                UtilityManager.MapProp(varUtente, utente1);
                utenteElenco.Add(utente1);
            }
            return utenteElenco;
        }

     public async Task<List<ContractUtente>> GetUtentiSiteManagerNI()
        {
            List<EntityUtente> utente;
            utente = await _RCDDbContext.Utente.Where(x => x.Abilitato == true)
                .Where(x => x.TipologiaUtente.TipologiaUtente == "NI")
                                 .OrderBy(x => x.Id)
                                  .Include("Zona")
                                   .Include("TipologiaUtente")
                                 .ToListAsync();
            List<ContractUtente> utenteElenco = new List<ContractUtente>();
            foreach (EntityUtente varUtente in utente)
            {
                ContractUtente utente1 = new ContractUtente();
                UtilityManager.MapProp(varUtente, utente1);
                utenteElenco.Add(utente1);
            }
            return utenteElenco;
        }

        public async Task<List<ContractUtente>> GetUtentiProgettistiRAN()
        {
            List<EntityUtente> utente;
            utente = await _RCDDbContext.Utente.Where(x => x.Abilitato == true)
                .Where(x => x.TipologiaUtente.TipologiaUtente == "RAN")
                                 .OrderBy(x => x.Id)
                                  .Include("Zona")
                                   .Include("TipologiaUtente")
                                 .ToListAsync();
            List<ContractUtente> utenteElenco = new List<ContractUtente>();
            foreach (EntityUtente varUtente in utente)
            {
                ContractUtente utente1 = new ContractUtente();
                UtilityManager.MapProp(varUtente, utente1);
                utenteElenco.Add(utente1);
            }
            return utenteElenco;
        }

        
    public async Task<List<ContractUtente>> GetUtentiDeliveryManager()
        {
            List<EntityUtente> utente;
            utente = await _RCDDbContext.Utente.Where(x => x.Abilitato == true)
                .Where(x => x.TipologiaUtente.TipologiaUtente == "DM")
                                 .OrderBy(x => x.Id)
                                  .Include("Zona")
                                  /* .Include("CanaleVendita")
                            .Include("CanaleVenditaDettaglio")
                            .Include("AreaVendita")
                            .Include("Ruolo")
                            .Include("TipologiaUtente")
                            .Include("ListUtenteProvincia.StsProvincia")*/
                                 .ToListAsync();
            List<ContractUtente> utenteElenco = new List<ContractUtente>();
            foreach (EntityUtente varUtente in utente)
            {
                ContractUtente utente1 = new ContractUtente();
                UtilityManager.MapProp(varUtente, utente1);
                utenteElenco.Add(utente1);
            }
            return utenteElenco;
        }
    }

}