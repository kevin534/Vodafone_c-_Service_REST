﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Richieste
{
    public class RichiedenteManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public RichiedenteManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }


        //DA CANCELLARE
        public void AddRichiestaNuovoRichiedente(EntityRichiesta richiedenteR, long userId)
        {
            try
            {
                //Salvataggio tabella T_RICHIESTA - T_RICHIEDENTE - T_LOCATION
                EntityRichiesta richiestaRichiedenteToAdd = new EntityRichiesta();
                UtilityManager.MapProp(richiedenteR, richiestaRichiedenteToAdd);
                var result = _RCDDbContext.Add(richiedenteR);

                _RCDDbContext.SaveChanges();
                long? idRichiedente = richiedenteR.Richiedente.Id;
                long? idLocation = richiedenteR.Location.Id;

                var locationRichiesta = _RCDDbContext.Location.First(g => g.Id == idLocation);
                locationRichiesta.IdRichiedente = idRichiedente;
                _RCDDbContext.SaveChanges();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        //DA CANCELLARE
        public void UpdateRichiedente(RichiedenteRequest richiedente)
        {
            try
            {
                EntityFornitore richiedenteToAdd = new EntityFornitore();
                UtilityManager.MapProp(richiedente, richiedenteToAdd);
                var result = _RCDDbContext.Update(richiedenteToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

    }
}
