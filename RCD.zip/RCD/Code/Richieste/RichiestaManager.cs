﻿using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;


namespace RCD.Code.Richieste
{
    public class RichiestaManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public RichiestaManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
        public async Task<List<EntityRichiesta>> GetRichiestaById(RichiestaRequestFull richiesta)
        {

            List<EntityRichiesta> richieste;

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "), richiesta.Ordinamento.ToUpper());

            if (richiesta.Pageable)
            {

                richieste = await _RCDDbContext.Richieste.Where(x => x.Id.Equals(richiesta.Filter.Id)
                            )
                     .OrderBy(sortParam)
                            .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                            .Include("Location")
                            .Include("Location.Gestori")
                            .Include("Installazione.Ditta")
                .Include("Installazione.TipologiaCosto")
                    .Include("Location.TipologiaStabile")
                    .Include("Location.AccessibilitaTetto")
                           .Include("Utente")
                           .Include("Sopralluogo")
                    .Include("Richiedente")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.Area")
                    .Include("Richiedente.AreaVendite")
                    .Include("Richiedente.Distretto")
                    .Include("Richiedente.TipologiaCliente")
                    .Include("MotivoRichiesta")
                    .Include("RiferimentoVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("RiferimentoDce")
                    .Include("PrioritaVendite")
                    .Include("TipologiaCopertura")
                    .Include("SistemaRichiesto")
                    .Include("Servizio")
                    .Include("MancanzaSegnaleEsterno")
                    .Include("MancanzaSegnaleInterno")
                    .Include("ProgettistaRan")
                    .Include("SiteManagerNI")
                            .ToListAsync();
            }
            else
            {

                richieste = await _RCDDbContext.Richieste.Where(x => x.Id.Equals(richiesta.Filter.Id)
                              )
                    .OrderBy(sortParam)
                    .Include("Location")
                    .Include("Location.Gestori")
                    .Include("Installazione.Ditta")
                .Include("Installazione.TipologiaCosto")
                    .Include("Location.TipologiaStabile")
                    .Include("Location.AccessibilitaTetto")
                               .Include("Utente")
                               .Include("Sopralluogo")
                    .Include("Richiedente")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.Area")
                    .Include("Richiedente.AreaVendite")
                    .Include("Richiedente.Distretto")
                    .Include("Richiedente.TipologiaCliente")
                    .Include("MotivoRichiesta")
                    .Include("RiferimentoVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("RiferimentoDce")
                    .Include("PrioritaVendite")
                    .Include("TipologiaCopertura")
                    .Include("SistemaRichiesto")
                    .Include("Servizio")
                    .Include("MancanzaSegnaleEsterno")
                    .Include("MancanzaSegnaleInterno")
                    .Include("ProgettistaRan")
                    .Include("SiteManagerNI")
                              .ToListAsync();
            }

            return richieste;


        }

        public async Task<Int32> GetRichiestaTot(RichiestaRequestFull richiesta)
        {
            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "), richiesta.Ordinamento.ToUpper());
            List<EntityRichiesta> richieste;
            richieste = await _RCDDbContext.Richieste.Where(x => x.Id.Equals(richiesta.Filter.Id))
                .OrderBy(sortParam)
                .Include("Location")
                .Include("Location.Gestori")
                .Include("Installazione.Ditta")
                .Include("Installazione.TipologiaCosto")
                    .Include("Location.TipologiaStabile")
                    .Include("Location.AccessibilitaTetto")
                               .Include("Utente")
                    .Include("Richiedente")
                    .Include("Sopralluogo")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.Area")
                    .Include("Richiedente.AreaVendite")
                    .Include("Richiedente.Distretto")
                    .Include("Richiedente.TipologiaCliente")
                    .Include("MotivoRichiesta")
                    .Include("RiferimentoVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("RiferimentoDce")
                    .Include("PrioritaVendite")
                    .Include("TipologiaCopertura")
                    .Include("SistemaRichiesto")
                    .Include("Servizio")
                    .Include("MancanzaSegnaleEsterno")
                    .Include("MancanzaSegnaleInterno")
                    .Include("ProgettistaRan")
                    .Include("SiteManagerNI")
                              .ToListAsync();

            return richieste.Count();
        }

        public async Task<List<ContractSistemaRichiesto>> GetSistemaRichiesto()
        {
            List<EntitySistemaRichiesto> sistema;
            sistema = await _RCDDbContext.SistemaRichiesto
                                 .OrderBy(x => x.Id)
                                 .ToListAsync();
            List<ContractSistemaRichiesto> sistemaElenco = new List<ContractSistemaRichiesto>();
            foreach (EntitySistemaRichiesto varSistema in sistema)
            {
                ContractSistemaRichiesto sist1 = new ContractSistemaRichiesto();
                UtilityManager.MapProp(varSistema, sist1);
                sistemaElenco.Add(sist1);
            }
            return sistemaElenco;
        }

        public async Task<List<ContractServizio>> GetServizio()
        {
            List<EntityServizio> servizio;
            servizio = await _RCDDbContext.Servizio
                                 .OrderBy(x => x.Id)
                                 .ToListAsync();
            List<ContractServizio> servizioElenco = new List<ContractServizio>();
            foreach (EntityServizio varServizio in servizio)
            {
                ContractServizio servizio1 = new ContractServizio();
                UtilityManager.MapProp(varServizio, servizio1);
                servizioElenco.Add(servizio1);
            }
            return servizioElenco;
        }

        public async Task<List<ContractMancanzaSegnale>> GetMancanzaSegnale()
        {
            List<EntityMancanzaSegnale> segnale;
            segnale = await _RCDDbContext.MancanzaSegnale
                                 .OrderBy(x => x.Id)
                                 .ToListAsync();
            List<ContractMancanzaSegnale> segnaleElenco = new List<ContractMancanzaSegnale>();
            foreach (EntityMancanzaSegnale varSegnale in segnale)
            {
                ContractMancanzaSegnale segnale1 = new ContractMancanzaSegnale();
                UtilityManager.MapProp(varSegnale, segnale1);
                segnaleElenco.Add(segnale1);
            }
            return segnaleElenco;
        }

        public async Task<List<ContractPrioritaVendite>> GetPrioritaVendite()
        {
            List<EntityPrioritaVendite> vendite;
            vendite = await _RCDDbContext.PrioritaVendite
                                 .OrderBy(x => x.Id)
                                 .ToListAsync();
            List<ContractPrioritaVendite> venditeElenco = new List<ContractPrioritaVendite>();
            foreach (EntityPrioritaVendite varVendite in vendite)
            {
                ContractPrioritaVendite vendite1 = new ContractPrioritaVendite();
                UtilityManager.MapProp(varVendite, vendite1);
                venditeElenco.Add(vendite1);
            }
            return venditeElenco;
        }
        public async Task<List<ContractMotivoRichiesta>> GetMotivoRichiesta()
        {
            List<EntityMotivoRichiesta> motivoRichiesta;
            motivoRichiesta = await _RCDDbContext.MotivoRichiesta
                                 .OrderBy(x => x.Id)
                                 .ToListAsync();
            List<ContractMotivoRichiesta> motivoRichiestaElenco = new List<ContractMotivoRichiesta>();
            foreach (EntityMotivoRichiesta varmotivoRichiesta in motivoRichiesta)
            {
                ContractMotivoRichiesta motivo1 = new ContractMotivoRichiesta();
                UtilityManager.MapProp(varmotivoRichiesta, motivo1);
                motivoRichiestaElenco.Add(motivo1);
            }
            return motivoRichiestaElenco;
        }
        public async Task<List<ContractTipologiaCantiere>> GetTipologiaCantiere()
        {
            List<EntityTipologiaCantiere> cantiere;
            cantiere = await _RCDDbContext.TipologiaCantiere
                                 .OrderBy(x => x.Id)
                                 .ToListAsync();
            List<ContractTipologiaCantiere> cantiereElenco = new List<ContractTipologiaCantiere>();
            foreach (EntityTipologiaCantiere varCantiere in cantiere)
            {
                ContractTipologiaCantiere cantiere1 = new ContractTipologiaCantiere();
                UtilityManager.MapProp(varCantiere, cantiere1);
                cantiereElenco.Add(cantiere1);
            }
            return cantiereElenco;
        }
        #region RICHIESTA FUORI GOVERNANCE  
        public async Task<List<EntityRichiesta>> GetRichiesteFuoriGovernance(RichiestaRequestFull richiesta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                              richiesta.Ordinamento.ToUpper());

            List<EntityRichiesta> richieste = new List<EntityRichiesta>();


            if (richiesta.Pageable)
            {

                if ((bool)utente.TipologiaUtente.IsVendita)
                {
                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 2)
                    .WhereIf(utente.AreaVendita != null, x => x.Richiedente.AreaVendite.Id.Equals(utente.AreaVendita.Id))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))

                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .OrderBy(sortParam)
                .Include("Richiedente")
                .Include("Utente")
                .Include("Location")
                .Include("Richiedente.TipologiaCliente")
                .Include("Location.StsComune")
                .Include("Location.StsComune.ProvinciaSts")
                .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                .Include("Richiedente.CanaleVendita")
                .Include("Richiedente.CanaleVenditaDettaglio")
                .Include("Richiedente.AreaVendite")
                .Include("RiferimentoAreaManager")
                .Include("Sopralluogo")
                .Include("Sopralluogo.Ditta")
                .Include("SistemaRichiesto")
                .Include("RiferimentoVendite")
                .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                .ToListAsync();
                }
                else
                {

                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 2)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))

                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .OrderBy(sortParam)
                    .Include("Richiedente")
                    .Include("Utente")
                    .Include("Location")
                    .Include("Richiedente.TipologiaCliente")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.AreaVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("Sopralluogo")
                    .Include("Sopralluogo.Ditta")
                    .Include("SistemaRichiesto")
                    .Include("RiferimentoVendite")
                    .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                    .ToListAsync();
                }

            }
            else
            {
                if ((bool)utente.TipologiaUtente.IsVendita)
                {

                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 2)
                     .WhereIf(utente.AreaVendita != null, x => x.Richiedente.AreaVendite.Id.Equals(utente.AreaVendita.Id))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .OrderBy(sortParam)
                    .Include("Richiedente")
                    .Include("Utente")
                    .Include("Location")
                    .Include("Richiedente.TipologiaCliente")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.AreaVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("Sopralluogo")
                    .Include("Sopralluogo.Ditta")
                    .Include("SistemaRichiesto")
                    .Include("RiferimentoVendite")
                    .ToListAsync();
                }
                else
                {

                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 2)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                                        .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .OrderBy(sortParam)
                    .Include("Richiedente")
                    .Include("Utente")
                    .Include("Location")
                    .Include("Richiedente.TipologiaCliente")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.AreaVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("Sopralluogo")
                    .Include("Sopralluogo.Ditta")
                    .Include("SistemaRichiesto")
                    .Include("RiferimentoVendite")
                    .ToListAsync();
                }
            }

            return richieste;
        }
        public async Task<Int32> GetRichiesteFuoriGovernanceTot(RichiestaRequestFull richiesta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                              richiesta.Ordinamento.ToUpper());

            List<EntityRichiesta> richieste = new List<EntityRichiesta>();

            if ((bool)utente.TipologiaUtente.IsVendita)
            {

                richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 2)
                .WhereIf(utente.AreaVendita != null, x => x.Richiedente.AreaVendite.Id.Equals(utente.AreaVendita.Id))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))

                .OrderBy(sortParam)
                .Include("Richiedente")
                .Include("Utente")
                .Include("Location")
                .Include("Richiedente.TipologiaCliente")
                .Include("Location.StsComune")
                .Include("Location.StsComune.ProvinciaSts")
                .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                .Include("Richiedente.CanaleVendita")
                .Include("Richiedente.CanaleVenditaDettaglio")
                .Include("Richiedente.AreaVendite")
                .Include("RiferimentoAreaManager")
                .Include("Sopralluogo")
                .Include("Sopralluogo.Ditta")
                .Include("SistemaRichiesto")
                .Include("RiferimentoVendite")
                .ToListAsync();
            }
            else
            {

                richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 2)
                    .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                    .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))

                    .OrderBy(sortParam)
                 .Include("Richiedente")
                .Include("Utente")
                .Include("Location")
                .Include("Richiedente.TipologiaCliente")
                .Include("Location.StsComune")
                .Include("Location.StsComune.ProvinciaSts")
                .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                .Include("Richiedente.CanaleVendita")
                .Include("Richiedente.CanaleVenditaDettaglio")
                .Include("Richiedente.AreaVendite")
                .Include("RiferimentoAreaManager")
                .Include("Sopralluogo")
                .Include("Sopralluogo.Ditta")
                .Include("SistemaRichiesto")
                .Include("RiferimentoVendite")
                .ToListAsync();
            }

            return richieste.Count();
        }

        #endregion RICHIESTA FUORI GOVERNANCE

        #region RICHIESTA SOPRALUOGO 
        public async Task<List<EntityRichiesta>> GetRichiesteSopralluoghi(RichiestaRequestFull richiesta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                              richiesta.Ordinamento.ToUpper());

            List<EntityRichiesta> richieste = new List<EntityRichiesta>();
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();

            if (richiesta.Pageable)
            {


                List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
                if (utente.IdZona != null)
                {
                    region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
                   .Select(x => x.Id)
                   .ToList();

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 3 && region.Contains(x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .Include("Richiedente")
                   .Include("Utente")
                   .Include("Location")
                   .Include("Richiedente.TipologiaCliente")
                   .Include("Location.StsComune")
                   .Include("Location.StsComune.ProvinciaSts")
                   .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                   .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                   .Include("Richiedente.CanaleVendita")
                   .Include("Richiedente.CanaleVenditaDettaglio")
                   .Include("Richiedente.AreaVendite")
                   .Include("RiferimentoAreaManager")
                   .Include("RiferimentoVendite")
                   .Include("SistemaRichiesto")
                   .Include("RiferimentoVendite")
                   .Include("Sopralluogo")
                   .Include("Sopralluogo.Ditta")
                   .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                   .OrderBy(sortParam)
                   .Select(x => x)
                   .ToListAsync();

                }
                else if (listUtenteProvincia.Count() > 0)

                {
                
                    province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();

                    var richieste2 = from r in _RCDDbContext.Richieste
                                     join v in _RCDDbContext.ViewRichiestaStatoProvincia on r.Id equals v.IdRichiesta
                                     where 3 == v.IdStatoRichiesta && province.Contains(v.IdProvinciaSts.Value)
                                     select r;

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = richieste2
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .Include("Richiedente")
                    .Include("Utente")
                    .Include("Richiedente.TipologiaCliente")
                    .Include("Location")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.AreaVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("Sopralluogo")
                    .Include("Sopralluogo.Ditta")
                    .Include("SistemaRichiesto")
                    .Include("RiferimentoVendite")
                    .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                    .OrderBy(sortParam)
                    .ToList();
                }
                else
                {
                    richieste = null;
                }

            }
            else
            {
                //ListaRichiesteManager richiesteManager = new ListaRichiesteManager(_RCDDbContext);
                //var listUtenteProvincia = richiesteManager.GetUtentiProvinceByUtente(utente);

                List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
                if (utente.IdZona != null)
                {
                    region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
                   .Select(x => x.Id)
                   .ToList();

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 3 && region.Contains(x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                   .Include("Richiedente")
                   .Include("Utente")
                   .Include("Location")
                   .Include("Richiedente.TipologiaCliente")
                   .Include("Location.StsComune")
                   .Include("Location.StsComune.ProvinciaSts")
                   .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                   .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                   .Include("Richiedente.CanaleVendita")
                   .Include("Richiedente.CanaleVenditaDettaglio")
                   .Include("Richiedente.AreaVendite")
                   .Include("RiferimentoAreaManager")
                   .Include("SistemaRichiesto")
                   .Include("RiferimentoVendite")
                   .Include("Sopralluogo")
                   .Include("Sopralluogo.Ditta")
                    .OrderBy(sortParam)
                   .Select(x => x)
                   .ToListAsync();

                }
                else if (listUtenteProvincia.Count() > 0)

                {
                 
                    _RCDDbContext.Database.SetCommandTimeout(300);
                    province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();
                   

                    var richieste2 = from r in _RCDDbContext.Richieste
                                     join v in _RCDDbContext.ViewRichiestaStatoProvincia on r.Id equals v.IdRichiesta
                                     where 3 == v.IdStatoRichiesta && province.Contains(v.IdProvinciaSts.Value)
                                     select r;

                   
                    richieste = richieste2
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .Include("Richiedente")
                    .Include("Utente")
                    .Include("Location")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.AreaVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("Sopralluogo")
                    .Include("Sopralluogo.Ditta")
                    .Include("SistemaRichiesto")
                    .Include("RiferimentoVendite")
                    .OrderBy(sortParam)
                    .ToList();



                }
                else
                {
                    richieste = null;
                }

            }

            return richieste;
        }

        public async Task<Int32> GetRichiesteSopralluoghiTot(RichiestaRequestFull richiesta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                              richiesta.Ordinamento.ToUpper());

            List<EntityRichiesta> richieste = new List<EntityRichiesta>();
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();

            //ListaRichiesteManager richiesteManager = new ListaRichiesteManager(_RCDDbContext);
            //var listUtenteProvincia = richiesteManager.GetUtentiProvinceByUtente(utente);

            List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
            if (utente.IdZona != null)
            {
                region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
               .Select(x => x.Id)
               .ToList();

                _RCDDbContext.Database.SetCommandTimeout(300);
                richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 3 && region.Contains(x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))
                    .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                    .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

               .OrderBy(sortParam)
               .Include("Richiedente")
               .Include("Utente")
               .Include("Location")
               .Include("Richiedente.TipologiaCliente")
               .Include("Location.StsComune")
               .Include("Location.StsComune.ProvinciaSts")
               .Include("Location.StsComune.ProvinciaSts.RegioneSts")
               .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
               .Include("Richiedente.CanaleVendita")
               .Include("Richiedente.CanaleVenditaDettaglio")
               .Include("Richiedente.AreaVendite")
               .Include("RiferimentoAreaManager")
               .Include("SistemaRichiesto")
               .Include("RiferimentoVendite")
               .Include("Sopralluogo")
               .Include("Sopralluogo.Ditta")
               .Select(x => x)
               .ToListAsync();

            }
            else if (listUtenteProvincia.Count() > 0)

            {
                _RCDDbContext.Database.SetCommandTimeout(300);
                province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();


                var richieste2 = from r in _RCDDbContext.Richieste
                                 join v in _RCDDbContext.ViewRichiestaStatoProvincia on r.Id equals v.IdRichiesta
                                 where 3 == v.IdStatoRichiesta && province.Contains(v.IdProvinciaSts.Value)
                                 select r;


                richieste = richieste2
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                        richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                        richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                    !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                    q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                .Include("Richiedente")
                .Include("Utente")
                .Include("Location")
                .Include("Location.StsComune")
                .Include("Location.StsComune.ProvinciaSts")
                .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                .Include("Richiedente.CanaleVendita")
                .Include("Richiedente.CanaleVenditaDettaglio")
                .Include("Richiedente.AreaVendite")
                .Include("RiferimentoAreaManager")
                .Include("Sopralluogo")
                .Include("Sopralluogo.Ditta")
                .Include("SistemaRichiesto")
                .Include("RiferimentoVendite")
                .OrderBy(sortParam)
                .ToList();
            }
            else
            {
                richieste = null;
            }
            return richieste.Count();
        }
        #endregion RICHIESTA SOPRALUOGO

        #region RICHIESTA BUTTON
        public async Task<ContractButton> GetButtonSopralluogo(ContractButton button)

        {
            EntityRichiesta richiesta = await _RCDDbContext.Richieste.Where(x => x.Id == button.IdRichiesta)
                                    .Include("Sopralluogo")
                                    .Include("Sopralluogo.SopralluogoApparati")
                                    .FirstOrDefaultAsync();
            List<long> IdDittaFittizia = new List<long> { 1, 2, 3, 4 };

            if (richiesta.Sopralluogo != null && richiesta.Sopralluogo.IdDittaIncaricata != null)
            {

                button.BtnInviaMail = true;
                button.BtnDettaglioCosti = false;
                button.BtnDettaglioApparati = true;
                button.BtnDocumentazione = true;
                button.CtpDatiSopralluogo = true;
                button.TxtCostoStimato = true;
                button.DpDataInvioStima = true;
            }
            else
            {

                button.BtnInviaMail = false;
                button.BtnDettaglioCosti = false;
                button.BtnDettaglioApparati = false;
                button.BtnDocumentazione = false;
                button.CtpDatiSopralluogo = false;     //4 5 2012
                button.TxtCostoStimato = false;
                button.DpDataInvioStima = false;
            }
            //DataPresaInCarico è stata inserita per permettere da Code
            //il cambio della ditta fin quando la ditta non decide di prenderla in carico
            if (richiesta.Sopralluogo != null)
            {
                if (richiesta.Sopralluogo.DataPresaInCaricoDitta != null)
                {
                    button.CmbDitta = false;
                }
                //Verifica la presenza di apparati e quindi è possibile compilare il Dettaglio costi
                //e anche che la ditta non sia quella fittizia
                if (richiesta.Sopralluogo.SopralluogoApparati.Count > 0 && !IdDittaFittizia.Contains((long)richiesta.Sopralluogo.IdDittaIncaricata) && richiesta.Sopralluogo.DataPresaInCaricoDitta != null)
                {

                    button.BtnDettaglioCosti = true;

                }
            }

            return button;
        }

        #endregion  RICHIESTA BUTTON


        #region RICHIESTA SOPRALUOGO 
        public async Task<List<EntityRichiesta>> GetRichiesteSopralluoghiEffettuati(RichiestaRequestFull richiesta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                              richiesta.Ordinamento.ToUpper());

            List<EntityRichiesta> richieste = new List<EntityRichiesta>();
           
            List<Int64?> province = new List<Int64?>();

            if (richiesta.Pageable)
            {


                List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
                if (utente.IdZona != null)
                {
                    

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 4 && x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id== utente.IdZona)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento!= null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .OrderBy(sortParam)
                   .Include("Richiedente")
                   .Include("Utente")
                   .Include("Location")
                   .Include("Richiedente.TipologiaCliente")
                   .Include("Location.StsComune")
                   .Include("Location.StsComune.ProvinciaSts")
                   .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                   .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                   .Include("Richiedente.CanaleVendita")
                   .Include("Richiedente.CanaleVenditaDettaglio")
                   .Include("Richiedente.AreaVendite")
                   .Include("RiferimentoAreaManager")
                   .Include("RiferimentoVendite")
                   .Include("SistemaRichiesto")
                   .Include("RiferimentoVendite")
                   .Include("Sopralluogo")
                   .Include("Sopralluogo.Ditta")
                   .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                   .Select(x => x)
                   .ToListAsync();

                }
                else if (listUtenteProvincia.Count() > 0)

                {

                    province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();

                    var richieste2 = from r in _RCDDbContext.Richieste                                
                                     where 4 == r.LastStatusId && province.Contains(r.Location.StsComune.ProvinciaSts.Id)
                                     select r;

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = richieste2
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))                        .Include("Richiedente")
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .OrderBy(sortParam)
                    .Include("Richiedente")
                   .Include("Utente")
                   .Include("Location")
                   .Include("Richiedente.TipologiaCliente")
                   .Include("Location.StsComune")
                   .Include("Location.StsComune.ProvinciaSts")
                   .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                   .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                   .Include("Richiedente.CanaleVendita")
                   .Include("Richiedente.CanaleVenditaDettaglio")
                   .Include("Richiedente.AreaVendite")
                   .Include("RiferimentoAreaManager")
                   .Include("SistemaRichiesto")
                   .Include("RiferimentoVendite")
                   .Include("Sopralluogo")
                   .Include("Sopralluogo.Ditta").Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi).ToList();
                }
                else
                {
                    richieste = null;
                }

            }
            else
            {
                //ListaRichiesteManager richiesteManager = new ListaRichiesteManager(_RCDDbContext);
                //var listUtenteProvincia = richiesteManager.GetUtentiProvinceByUtente(utente);

                List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
                if (utente.IdZona != null)
                {
                    
   
                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 4 && x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id == utente.IdZona)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                   .OrderBy(sortParam)
                   .Include("Richiedente")
                   .Include("Utente")
                   .Include("Location")
                   .Include("Richiedente.TipologiaCliente")
                   .Include("Location.StsComune")
                   .Include("Location.StsComune.ProvinciaSts")
                   .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                   .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                   .Include("Richiedente.CanaleVendita")
                   .Include("Richiedente.CanaleVenditaDettaglio")
                   .Include("Richiedente.AreaVendite")
                   .Include("RiferimentoAreaManager")
                   .Include("SistemaRichiesto")
                   .Include("RiferimentoVendite")
                   .Include("Sopralluogo")
                   .Include("Sopralluogo.Ditta")
                   .Select(x => x)
                   .ToListAsync();

                }
                else if (listUtenteProvincia.Count() > 0)

                {

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();


                    var richieste2 = from r in _RCDDbContext.Richieste
                                     where 4 == r.LastStatusId && province.Contains(r.Location.StsComune.ProvinciaSts.Id)
                                     select r;


                    richieste = richieste2
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .Include("Richiedente")
                                    .Include("Utente")
                                    .Include("Location")
                                    .Include("Location.StsComune")
                                    .Include("Location.StsComune.ProvinciaSts")
                                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                                    .Include("Richiedente.CanaleVendita")
                                    .Include("Richiedente.CanaleVenditaDettaglio")
                                    .Include("Richiedente.AreaVendite")
                                    .Include("RiferimentoAreaManager")
                                    .Include("Sopralluogo")
                                    .Include("Sopralluogo.Ditta")
                                    .Include("SistemaRichiesto")
                                    .Include("RiferimentoVendite")
                                    .OrderBy(sortParam).ToList();



                }
                else
                {
                    richieste = null;
                }

            }

            return richieste;
        }

        public async Task<Int32> GetRichiesteSopralluoghiEffettuatiTot(RichiestaRequestFull richiesta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                              richiesta.Ordinamento.ToUpper());

            List<EntityRichiesta> richieste = new List<EntityRichiesta>();
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();

            //ListaRichiesteManager richiesteManager = new ListaRichiesteManager(_RCDDbContext);
            //var listUtenteProvincia = richiesteManager.GetUtentiProvinceByUtente(utente);

            List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
            if (utente.IdZona != null)
            {
               
                _RCDDbContext.Database.SetCommandTimeout(300);
                richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 4 && x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id == utente.IdZona)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

               .OrderBy(sortParam)
               .Include("Richiedente")
               .Include("Utente")
               .Include("Location")
               .Include("Richiedente.TipologiaCliente")
               .Include("Location.StsComune")
               .Include("Location.StsComune.ProvinciaSts")
               .Include("Location.StsComune.ProvinciaSts.RegioneSts")
               .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
               .Include("Richiedente.CanaleVendita")
               .Include("Richiedente.CanaleVenditaDettaglio")
               .Include("Richiedente.AreaVendite")
               .Include("RiferimentoAreaManager")
               .Include("SistemaRichiesto")
               .Include("RiferimentoVendite")
               .Include("Sopralluogo")
               .Include("Sopralluogo.Ditta")
               .Select(x => x)
               .ToListAsync();

            }
            else if (listUtenteProvincia.Count() > 0)

            {
                _RCDDbContext.Database.SetCommandTimeout(300);
                province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();


                var richieste2 = from r in _RCDDbContext.Richieste
                                 where 4 == r.LastStatusId && province.Contains(r.Location.StsComune.ProvinciaSts.Id)
                                 select r;


                richieste = richieste2
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .Include("Richiedente")
                                .Include("Utente")
                                .Include("Location")
                                .Include("Location.StsComune")
                                .Include("Location.StsComune.ProvinciaSts")
                                .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                                .Include("Richiedente.CanaleVendita")
                                .Include("Richiedente.CanaleVenditaDettaglio")
                                .Include("Richiedente.AreaVendite")
                                .Include("RiferimentoAreaManager")
                                .Include("Sopralluogo")
                                .Include("Sopralluogo.Ditta")
                                .Include("SistemaRichiesto")
                                .Include("RiferimentoVendite")
                                .ToList();
            }
            else
            {
                richieste = null;
            }
            return richieste.Count();
        }
        #endregion RICHIESTA SOPRALUOGO     
        #region RICHIESTA OK tecnico dopo sopralluogo stato 6
        public async Task<List<EntityRichiesta>> GetRichiesteSopralluoghiOkTecnico(RichiestaRequestFull richiesta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                              richiesta.Ordinamento.ToUpper());

            List<EntityRichiesta> richieste = new List<EntityRichiesta>();

            List<Int64?> province = new List<Int64?>();

            if (richiesta.Pageable)
            {


                List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
                if (utente.IdZona != null)
                {


                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 6 && x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id == utente.IdZona)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .OrderBy(sortParam)
                   .Include("Richiedente")
                   .Include("Utente")
                   .Include("Location")
                   .Include("Richiedente.TipologiaCliente")
                   .Include("Location.StsComune")
                   .Include("Location.StsComune.ProvinciaSts")
                   .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                   .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                   .Include("Richiedente.CanaleVendita")
                   .Include("Richiedente.CanaleVenditaDettaglio")
                   .Include("Richiedente.AreaVendite")
                   .Include("RiferimentoAreaManager")
                   .Include("RiferimentoVendite")
                   .Include("SistemaRichiesto")
                   .Include("RiferimentoVendite")
                   .Include("Sopralluogo")
                   .Include("Sopralluogo.Ditta")
                   .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                   .Select(x => x)
                   .ToListAsync();

                }
                else if (listUtenteProvincia.Count() > 0)

                {

                    province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();

                    var richieste2 = from r in _RCDDbContext.Richieste
                                     where 6 == r.LastStatusId && province.Contains(r.Location.StsComune.ProvinciaSts.Id)
                                     select r;

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = richieste2
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                        .Include("Richiedente")
                                     .Include("Utente")
                                     .Include("Richiedente.TipologiaCliente")
                                     .Include("Location")
                                     .Include("Location.StsComune")
                                     .Include("Location.StsComune.ProvinciaSts")
                                     .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                                     .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                                     .Include("Richiedente.CanaleVendita")
                                     .Include("Richiedente.CanaleVenditaDettaglio")
                                     .Include("Richiedente.AreaVendite")
                                     .Include("RiferimentoAreaManager")
                                     .Include("Sopralluogo")
                                     .Include("Sopralluogo.Ditta")
                                     .Include("SistemaRichiesto")
                                     .Include("RiferimentoVendite").Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi).ToList();
                }
                else
                {
                    richieste = null;
                }

            }
            else
            {
                //ListaRichiesteManager richiesteManager = new ListaRichiesteManager(_RCDDbContext);
                //var listUtenteProvincia = richiesteManager.GetUtentiProvinceByUtente(utente);

                List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
                if (utente.IdZona != null)
                {


                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 6 && x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id == utente.IdZona)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                   .OrderBy(sortParam)
                   .Include("Richiedente")
                   .Include("Utente")
                   .Include("Location")
                   .Include("Richiedente.TipologiaCliente")
                   .Include("Location.StsComune")
                   .Include("Location.StsComune.ProvinciaSts")
                   .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                   .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                   .Include("Richiedente.CanaleVendita")
                   .Include("Richiedente.CanaleVenditaDettaglio")
                   .Include("Richiedente.AreaVendite")
                   .Include("RiferimentoAreaManager")
                   .Include("SistemaRichiesto")
                   .Include("RiferimentoVendite")
                   .Include("Sopralluogo")
                   .Include("Sopralluogo.Ditta")
                   .Select(x => x)
                   .ToListAsync();

                }
                else if (listUtenteProvincia.Count() > 0)

                {

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();


                    var richieste2 = from r in _RCDDbContext.Richieste
                                     where 6 == r.LastStatusId && province.Contains(r.Location.StsComune.ProvinciaSts.Id)
                                     select r;


                    richieste = richieste2
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                        .Include("Richiedente")
                                    .Include("Utente")
                                    .Include("Location")
                                    .Include("Location.StsComune")
                                    .Include("Location.StsComune.ProvinciaSts")
                                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                                    .Include("Richiedente.CanaleVendita")
                                    .Include("Richiedente.CanaleVenditaDettaglio")
                                    .Include("Richiedente.AreaVendite")
                                    .Include("RiferimentoAreaManager")
                                    .Include("Sopralluogo")
                                    .Include("Sopralluogo.Ditta")
                                    .Include("SistemaRichiesto")
                                    .Include("RiferimentoVendite")
                                    .OrderBy(sortParam).ToList();



                }
                else
                {
                    richieste = null;
                }

            }

            return richieste;
        }

        public async Task<Int32> GetRichiesteSopralluoghiOkTecnicoTot(RichiestaRequestFull richiesta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                              richiesta.Ordinamento.ToUpper());

            List<EntityRichiesta> richieste = new List<EntityRichiesta>();
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();

            //ListaRichiesteManager richiesteManager = new ListaRichiesteManager(_RCDDbContext);
            //var listUtenteProvincia = richiesteManager.GetUtentiProvinceByUtente(utente);

            List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
            if (utente.IdZona != null)
            {

                _RCDDbContext.Database.SetCommandTimeout(300);
                richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 6 && x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id == utente.IdZona)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

               .OrderBy(sortParam)
               .Include("Richiedente")
               .Include("Utente")
               .Include("Location")
               .Include("Richiedente.TipologiaCliente")
               .Include("Location.StsComune")
               .Include("Location.StsComune.ProvinciaSts")
               .Include("Location.StsComune.ProvinciaSts.RegioneSts")
               .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
               .Include("Richiedente.CanaleVendita")
               .Include("Richiedente.CanaleVenditaDettaglio")
               .Include("Richiedente.AreaVendite")
               .Include("RiferimentoAreaManager")
               .Include("SistemaRichiesto")
               .Include("RiferimentoVendite")
               .Include("Sopralluogo")
               .Include("Sopralluogo.Ditta")
               .Select(x => x)
               .ToListAsync();

            }
            else if (listUtenteProvincia.Count() > 0)

            {
                _RCDDbContext.Database.SetCommandTimeout(300);
                province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();


                var richieste2 = from r in _RCDDbContext.Richieste
                                 where 6 == r.LastStatusId && province.Contains(r.Location.StsComune.ProvinciaSts.Id)
                                 select r;


                richieste = richieste2
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .Include("Richiedente")
                                .Include("Utente")
                                .Include("Location")
                                .Include("Location.StsComune")
                                .Include("Location.StsComune.ProvinciaSts")
                                .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                                .Include("Richiedente.CanaleVendita")
                                .Include("Richiedente.CanaleVenditaDettaglio")
                                .Include("Richiedente.AreaVendite")
                                .Include("RiferimentoAreaManager")
                                .Include("Sopralluogo")
                                .Include("Sopralluogo.Ditta")
                                .Include("SistemaRichiesto")
                                .Include("RiferimentoVendite")
                                .ToList();
            }
            else
            {
                richieste = null;
            }
            return richieste.Count();
        }
        #endregion OK tecnico dopo sopralluogo

        #region Attesa OK installazione fuori governance STATO 7
        public async Task<List<EntityRichiesta>> GetRichiesteKoGovernanceDopoSopralluogo(RichiestaRequestFull richiesta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                              richiesta.Ordinamento.ToUpper());

            List<EntityRichiesta> richieste = new List<EntityRichiesta>();


            if (richiesta.Pageable)
            {

                if ((bool)utente.TipologiaUtente.IsVendita)
                {
                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 7)
                    .WhereIf(utente.AreaVendita != null, x => x.Richiedente.AreaVendite.Id.Equals(utente.AreaVendita.Id))
                    .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                    .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                   .OrderBy(sortParam)
                .Include("Richiedente")
                .Include("Utente")
                .Include("Location")
                .Include("Richiedente.TipologiaCliente")
                .Include("Location.StsComune")
                .Include("Location.StsComune.ProvinciaSts")
                .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                .Include("Richiedente.CanaleVendita")
                .Include("Richiedente.CanaleVenditaDettaglio")
                .Include("Richiedente.AreaVendite")
                .Include("RiferimentoAreaManager")
                    .Include("Sopralluogo")
                    .Include("Sopralluogo.Ditta")
                .Include("SistemaRichiesto")
                .Include("RiferimentoVendite")
                .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                .ToListAsync();
                }
                else
                {

                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 7)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .OrderBy(sortParam)
                    .Include("Richiedente")
                    .Include("Utente")
                    .Include("Location")
                    .Include("Richiedente.TipologiaCliente")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.AreaVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("Sopralluogo")
                    .Include("Sopralluogo.Ditta")
                    .Include("SistemaRichiesto")
                    .Include("RiferimentoVendite")
                    .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                    .ToListAsync();
                }

            }
            else
            {
                if ((bool)utente.TipologiaUtente.IsVendita)
                {

                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 7)
                     .WhereIf(utente.AreaVendita != null, x => x.Richiedente.AreaVendite.Id.Equals(utente.AreaVendita.Id))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .OrderBy(sortParam)
                    .Include("Richiedente")
                    .Include("Utente")
                    .Include("Location")
                    .Include("Richiedente.TipologiaCliente")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.AreaVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("Sopralluogo")
                    .Include("Sopralluogo.Ditta")
                    .Include("SistemaRichiesto")
                    .Include("RiferimentoVendite")
                    .ToListAsync();
                }
                else
                {

                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 7)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .OrderBy(sortParam)
                    .Include("Richiedente")
                    .Include("Utente")
                    .Include("Location")
                    .Include("Richiedente.TipologiaCliente")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.AreaVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("Sopralluogo")
                    .Include("Sopralluogo.Ditta")
                    .Include("SistemaRichiesto")
                    .Include("RiferimentoVendite")
                    .ToListAsync();
                }
            }

            return richieste;
        }
        public async Task<Int32> GetRichiesteKoGovernanceDopoSopralluogoTot(RichiestaRequestFull richiesta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                              richiesta.Ordinamento.ToUpper());

            List<EntityRichiesta> richieste = new List<EntityRichiesta>();

            if ((bool)utente.TipologiaUtente.IsVendita)
            {

                richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 7)
                .WhereIf(utente.AreaVendita != null, x => x.Richiedente.AreaVendite.Id.Equals(utente.AreaVendita.Id))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                .OrderBy(sortParam)
                .Include("Richiedente")
                .Include("Utente")
                .Include("Location")
                .Include("Richiedente.TipologiaCliente")
                .Include("Location.StsComune")
                .Include("Location.StsComune.ProvinciaSts")
                .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                .Include("Richiedente.CanaleVendita")
                .Include("Richiedente.CanaleVenditaDettaglio")
                .Include("Richiedente.AreaVendite")
                .Include("RiferimentoAreaManager")
                .Include("Sopralluogo")
                .Include("Sopralluogo.Ditta")
                .Include("SistemaRichiesto")
                .Include("RiferimentoVendite")
                .ToListAsync();
            }
            else
            {

                richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 7)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .OrderBy(sortParam)
                 .Include("Richiedente")
                .Include("Utente")
                .Include("Location")
                .Include("Richiedente.TipologiaCliente")
                .Include("Location.StsComune")
                .Include("Location.StsComune.ProvinciaSts")
                .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                .Include("Richiedente.CanaleVendita")
                .Include("Richiedente.CanaleVenditaDettaglio")
                .Include("Richiedente.AreaVendite")
                .Include("RiferimentoAreaManager")
                .Include("Sopralluogo")
                .Include("Sopralluogo.Ditta")
                .Include("SistemaRichiesto")
                .Include("RiferimentoVendite")
                .ToListAsync();
            }

            return richieste.Count();
        }

        #endregion Attesa OK installazione fuori governance STATO 7

        #region RICHIESTA 'Attesa Ok a installazione' STATO 8 
        public async Task<List<EntityRichiesta>> GetRichiesteAttesaOkInstallazione(RichiestaRequestFull richiesta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                              richiesta.Ordinamento.ToUpper());

            List<EntityRichiesta> richieste = new List<EntityRichiesta>();
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();

            if (richiesta.Pageable)
            {


                List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
                if (utente.IdZona != null)
                {
                    
                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 8 && x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.IdZona==utente.IdZona)
                        .WhereIf(utente.TipologiaUtente.IsVendita== true, x=>x.Richiedente.IdAreaVendite == utente.IdAreaVendita)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .Include("Richiedente")
                   .Include("Utente")
                   .Include("Location")
                   .Include("Richiedente.TipologiaCliente")
                   .Include("Location.StsComune")
                   .Include("Location.StsComune.ProvinciaSts")
                   .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                   .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                   .Include("Richiedente.CanaleVendita")
                   .Include("Richiedente.CanaleVenditaDettaglio")
                   .Include("Richiedente.AreaVendite")
                   .Include("RiferimentoAreaManager")
                   .Include("RiferimentoVendite")
                   .Include("SistemaRichiesto")
                   .Include("RiferimentoVendite")
                   .Include("Sopralluogo")
                   .Include("Sopralluogo.Ditta")
                   .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                   .OrderBy(sortParam)
                   .Select(x => x)
                   .ToListAsync();

                }
                else if (listUtenteProvincia.Count() > 0)

                {

                    province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();

                    var richieste2 = from r in _RCDDbContext.Richieste                                   
                                     where 8 == r.LastStatusId && province.Contains(r.Location.StsComune.ProvinciaSts.Id)
                                     select r;

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = richieste2
                     .WhereIf(utente.TipologiaUtente.IsVendita == true, x => x.Richiedente.IdAreaVendite == utente.IdAreaVendita)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .Include("Richiedente")
                    .Include("Utente")
                    .Include("Richiedente.TipologiaCliente")
                    .Include("Location")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.AreaVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("Sopralluogo")
                    .Include("Sopralluogo.Ditta")
                    .Include("SistemaRichiesto")
                    .Include("RiferimentoVendite")
                    .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                    .OrderBy(sortParam)
                    .ToList();
                }
                else
                {
                    richieste = null;
                }

            }
            else
            {
                //ListaRichiesteManager richiesteManager = new ListaRichiesteManager(_RCDDbContext);
                //var listUtenteProvincia = richiesteManager.GetUtentiProvinceByUtente(utente);

                List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
                if (utente.IdZona != null)
                {
                  
                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 8 && x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.IdZona == utente.IdZona)
                        .WhereIf(utente.TipologiaUtente.IsVendita== true , x => x.Richiedente.IdAreaVendite == utente.IdAreaVendita)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                   .Include("Richiedente")
                   .Include("Utente")
                   .Include("Location")
                   .Include("Richiedente.TipologiaCliente")
                   .Include("Location.StsComune")
                   .Include("Location.StsComune.ProvinciaSts")
                   .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                   .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                   .Include("Richiedente.CanaleVendita")
                   .Include("Richiedente.CanaleVenditaDettaglio")
                   .Include("Richiedente.AreaVendite")
                   .Include("RiferimentoAreaManager")
                   .Include("SistemaRichiesto")
                   .Include("RiferimentoVendite")
                   .Include("Sopralluogo")
                   .Include("Sopralluogo.Ditta")
                    .OrderBy(sortParam)
                   .Select(x => x)
                   .ToListAsync();

                }
                else if (listUtenteProvincia.Count() > 0)

                {

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();


                    var richieste2 = from r in _RCDDbContext.Richieste
                                     where 8 == r.LastStatusId && province.Contains(r.Location.StsComune.ProvinciaSts.Id)
                                     select r;


                    richieste = richieste2
                     .WhereIf(utente.TipologiaUtente.IsVendita == true, x => x.Richiedente.IdAreaVendite == utente.IdAreaVendita)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .Include("Richiedente")
                    .Include("Utente")
                    .Include("Location")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.AreaVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("Sopralluogo")
                    .Include("Sopralluogo.Ditta")
                    .Include("SistemaRichiesto")
                    .Include("RiferimentoVendite")
                    .OrderBy(sortParam)
                    .ToList();



                }
                else
                {
                    richieste = null;
                }

            }

            return richieste;
        }

        public async Task<Int32> GetRichiesteAttesaOkInstallazioneTot(RichiestaRequestFull richiesta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                              richiesta.Ordinamento.ToUpper());

            List<EntityRichiesta> richieste = new List<EntityRichiesta>();
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();

            //ListaRichiesteManager richiesteManager = new ListaRichiesteManager(_RCDDbContext);
            //var listUtenteProvincia = richiesteManager.GetUtentiProvinceByUtente(utente);

            List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
            if (utente.IdZona != null)
            {               
                _RCDDbContext.Database.SetCommandTimeout(300);
                richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 8 && x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.IdZona == utente.IdZona)
                    .WhereIf(utente.TipologiaUtente.IsVendita == true, x => x.Richiedente.IdAreaVendite == utente.IdAreaVendita)
                    .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                    .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

               .OrderBy(sortParam)
               .Include("Richiedente")
               .Include("Utente")
               .Include("Location")
               .Include("Richiedente.TipologiaCliente")
               .Include("Location.StsComune")
               .Include("Location.StsComune.ProvinciaSts")
               .Include("Location.StsComune.ProvinciaSts.RegioneSts")
               .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
               .Include("Richiedente.CanaleVendita")
               .Include("Richiedente.CanaleVenditaDettaglio")
               .Include("Richiedente.AreaVendite")
               .Include("RiferimentoAreaManager")
               .Include("SistemaRichiesto")
               .Include("RiferimentoVendite")
               .Include("Sopralluogo")
               .Include("Sopralluogo.Ditta")
               .Select(x => x)
               .ToListAsync();

            }
            else if (listUtenteProvincia.Count() > 0)

            {
               _RCDDbContext.Database.SetCommandTimeout(300);
                province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();
                var richieste2 = from r in _RCDDbContext.Richieste
                                 where 8 == r.LastStatusId && province.Contains(r.Location.StsComune.ProvinciaSts.Id)
                                 select r;

                richieste = richieste2
                     .WhereIf(utente.TipologiaUtente.IsVendita == true, x => x.Richiedente.IdAreaVendite == utente.IdAreaVendita)
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                        richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                        richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                    !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                    q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                .Include("Richiedente")
                .Include("Utente")
                .Include("Location")
                .Include("Location.StsComune")
                .Include("Location.StsComune.ProvinciaSts")
                .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                .Include("Richiedente.CanaleVendita")
                .Include("Richiedente.CanaleVenditaDettaglio")
                .Include("Richiedente.AreaVendite")
                .Include("RiferimentoAreaManager")
                .Include("Sopralluogo")
                .Include("Sopralluogo.Ditta")
                .Include("SistemaRichiesto")
                .Include("RiferimentoVendite")
                .OrderBy(sortParam)
                .ToList();
            }
            else
            {
                richieste = null;
            }
            return richieste.Count();
        }
        #endregion RICHIESTA RICHIESTA 'Attesa Ok a installazione' STATO 8 

        #region RICHIESTA RICHIESTA Ok Installazione STATO 10 
        public async Task<List<EntityRichiesta>> GetRichiesteOKInstallazione(RichiestaRequestFull richiesta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                              richiesta.Ordinamento.ToUpper());

            List<EntityRichiesta> richieste = new List<EntityRichiesta>();
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();

            if (richiesta.Pageable)
            {


                List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
                if (utente.IdZona != null)
                {
                    region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
                   .Select(x => x.Id)
                   .ToList();

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 10 && region.Contains(x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .Include("Richiedente")
                   .Include("Utente")
                   .Include("Location")
                   .Include("Richiedente.TipologiaCliente")
                   .Include("Location.StsComune")
                   .Include("Location.StsComune.ProvinciaSts")
                   .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                   .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                   .Include("Richiedente.CanaleVendita")
                   .Include("Richiedente.CanaleVenditaDettaglio")
                   .Include("Richiedente.AreaVendite")
                   .Include("RiferimentoAreaManager")
                   .Include("RiferimentoVendite")
                   .Include("SistemaRichiesto")
                   .Include("RiferimentoVendite")
                   .Include("Sopralluogo")
                   .Include("Sopralluogo.Ditta")
                   .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                   .OrderBy(sortParam)
                   .Select(x => x)
                   .ToListAsync();

                }
                else if (listUtenteProvincia.Count() > 0)

                {

                    province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();

                    var richieste2 = from r in _RCDDbContext.Richieste
                                     where 10 == r.LastStatusId && province.Contains(r.Location.StsComune.ProvinciaSts.Id)
                                     select r;

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = richieste2
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .Include("Richiedente")
                    .Include("Utente")
                    .Include("Richiedente.TipologiaCliente")
                    .Include("Location")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.AreaVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("Sopralluogo")
                    .Include("Sopralluogo.Ditta")
                    .Include("SistemaRichiesto")
                    .Include("RiferimentoVendite")
                    .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                    .OrderBy(sortParam)
                    .ToList();
                }
                else
                {
                    richieste = null;
                }

            }
            else
            {
                //ListaRichiesteManager richiesteManager = new ListaRichiesteManager(_RCDDbContext);
                //var listUtenteProvincia = richiesteManager.GetUtentiProvinceByUtente(utente);

                List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
                if (utente.IdZona != null)
                {
                    region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
                   .Select(x => x.Id)
                   .ToList();

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 10 && region.Contains(x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                   .Include("Richiedente")
                   .Include("Utente")
                   .Include("Location")
                   .Include("Richiedente.TipologiaCliente")
                   .Include("Location.StsComune")
                   .Include("Location.StsComune.ProvinciaSts")
                   .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                   .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                   .Include("Richiedente.CanaleVendita")
                   .Include("Richiedente.CanaleVenditaDettaglio")
                   .Include("Richiedente.AreaVendite")
                   .Include("RiferimentoAreaManager")
                   .Include("SistemaRichiesto")
                   .Include("RiferimentoVendite")
                   .Include("Sopralluogo")
                   .Include("Sopralluogo.Ditta")
                    .OrderBy(sortParam)
                   .Select(x => x)
                   .ToListAsync();

                }
                else if (listUtenteProvincia.Count() > 0)

                {

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();


                    var richieste2 = from r in _RCDDbContext.Richieste
                                     where 10 == r.LastStatusId && province.Contains(r.Location.StsComune.ProvinciaSts.Id)
                                     select r;

                    richieste = richieste2
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                    .Include("Richiedente")
                    .Include("Utente")
                    .Include("Location")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.AreaVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("Sopralluogo")
                    .Include("Sopralluogo.Ditta")
                    .Include("SistemaRichiesto")
                    .Include("RiferimentoVendite")
                    .OrderBy(sortParam)
                    .ToList();



                }
                else
                {
                    richieste = null;
                }

            }

            return richieste;
        }

        public async Task<Int32> GetRichiesteOKInstallazioneTot(RichiestaRequestFull richiesta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "),
                              richiesta.Ordinamento.ToUpper());

            List<EntityRichiesta> richieste = new List<EntityRichiesta>();
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();

            //ListaRichiesteManager richiesteManager = new ListaRichiesteManager(_RCDDbContext);
            //var listUtenteProvincia = richiesteManager.GetUtentiProvinceByUtente(utente);

            List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
            if (utente.IdZona != null)
            {
                region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
               .Select(x => x.Id)
               .ToList();

                _RCDDbContext.Database.SetCommandTimeout(300);
                richieste = await _RCDDbContext.Richieste.Where(x => x.LastStatusId == 10 && region.Contains(x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))
                    .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                    .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

               .OrderBy(sortParam)
               .Include("Richiedente")
               .Include("Utente")
               .Include("Location")
               .Include("Richiedente.TipologiaCliente")
               .Include("Location.StsComune")
               .Include("Location.StsComune.ProvinciaSts")
               .Include("Location.StsComune.ProvinciaSts.RegioneSts")
               .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
               .Include("Richiedente.CanaleVendita")
               .Include("Richiedente.CanaleVenditaDettaglio")
               .Include("Richiedente.AreaVendite")
               .Include("RiferimentoAreaManager")
               .Include("SistemaRichiesto")
               .Include("RiferimentoVendite")
               .Include("Sopralluogo")
               .Include("Sopralluogo.Ditta")
               .Select(x => x)
               .ToListAsync();

            }
            else if (listUtenteProvincia.Count() > 0)

            {
                _RCDDbContext.Database.SetCommandTimeout(300);
                province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();


                var richieste2 = from r in _RCDDbContext.Richieste
                                 where 10 == r.LastStatusId && province.Contains(r.Location.StsComune.ProvinciaSts.Id)
                                 select r;


                richieste = richieste2
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiesta.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiesta.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                     .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null &&
                        richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                        richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                    !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                    q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiesta.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiesta.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiesta.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiesta.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiesta.Filter.Location.Indirizzo))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiesta.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.StsComune != null && richiesta.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiesta.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiesta.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiesta.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiesta.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiesta.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiesta.Filter.Utente != null && !String.IsNullOrEmpty(richiesta.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiesta.Filter.Utente.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiesta.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiesta.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiesta.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiesta.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiesta.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiesta.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiesta.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiesta.Filter.Richiedente != null && richiesta.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiesta.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiesta.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiesta.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiesta.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiesta.Filter.Location != null && richiesta.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiesta.Filter.Location.NomeInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.CodiceInstallazione != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.CodiceInstallazione.ToString()), q => q.Sopralluogo.CodiceInstallazione.Contains(richiesta.Filter.Sopralluogo.CodiceInstallazione))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.Ditta != null && richiesta.Filter.Sopralluogo.Ditta.RagioneSociale != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale.ToString()), q => q.Sopralluogo.Ditta.RagioneSociale.Contains(richiesta.Filter.Sopralluogo.Ditta.RagioneSociale))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.RdAEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.RdAEmessa.ToString()), q => q.Sopralluogo.RdAEmessa.Equals(richiesta.Filter.Sopralluogo.RdAEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.NclEmessa != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.NclEmessa.ToString()), q => q.Sopralluogo.NclEmessa.Equals(richiesta.Filter.Sopralluogo.NclEmessa))
                    .WhereIf(richiesta.Filter.Sopralluogo != null && richiesta.Filter.Sopralluogo.DataSopralluogoStimata != null && !String.IsNullOrEmpty(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.ToString()), q => q.Sopralluogo.DataSopralluogoStimata.Value.Date.Equals(richiesta.Filter.Sopralluogo.DataSopralluogoStimata.GetValueOrDefault().Date))

                .Include("Richiedente")
                .Include("Utente")
                .Include("Location")
                .Include("Location.StsComune")
                .Include("Location.StsComune.ProvinciaSts")
                .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                .Include("Richiedente.CanaleVendita")
                .Include("Richiedente.CanaleVenditaDettaglio")
                .Include("Richiedente.AreaVendite")
                .Include("RiferimentoAreaManager")
                .Include("Sopralluogo")
                .Include("Sopralluogo.Ditta")
                .Include("SistemaRichiesto")
                .Include("RiferimentoVendite")
                .OrderBy(sortParam)
                .ToList();
            }
            else
            {
                richieste = null;
            }
            return richieste.Count();
        }

        #endregion RICHIESTA Ok Installazione STATO 10
        
        #region Stato Richieste
        public async Task<List<ContractViewReportRichieste>> GetStatoRichieste(ViewRichiesteRequestFull vwReportRichiestaR, long idUtente)
        {
            List<EntityViewReportRichieste> vwReportRichieste;

            EntityUtente utente;
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);
            List<EntityUtentiProvince> listUtenteProvincia = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id).ToList();

            String sortParam = String.Concat(String.Concat(vwReportRichiestaR.CampoOrdinamento, " "), vwReportRichiestaR.Ordinamento.ToUpper());
            if (utente.IdZona != null)
            {
                region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
               .Select(x => x.Id)
               .ToList();
            }
            else if (listUtenteProvincia.Count() > 0)
            {
                province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();
            }

                if (vwReportRichiestaR.Pageable)
            {
                vwReportRichieste = await _RCDDbContext.ViewReportRichieste
                    .WhereIf(utente.IdZona != null, q =>  region.Contains(q.IdRegioneVF.Value))
                    .WhereIf(listUtenteProvincia.Count() > 0, q =>  province.Contains(q.IdProvincia.Value))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(vwReportRichiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(vwReportRichiestaR.Filter.DataRichiesta.Value.Date))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                    .Skip(vwReportRichiestaR.NumeroElementi * vwReportRichiestaR.Page).Take(vwReportRichiestaR.NumeroElementi)
                    .Include("Richiesta")
                    .Include("Richiesta.Sopralluogo")
                    .OrderBy(sortParam)
                    .ToListAsync();

            }
            else
            {
                _RCDDbContext.Database.SetCommandTimeout(300);
                vwReportRichieste = await _RCDDbContext.ViewReportRichieste
                .WhereIf(utente.IdZona != null, q => region.Contains(q.IdRegioneVF.Value))
                .WhereIf(listUtenteProvincia.Count() > 0, q => province.Contains(q.IdProvincia.Value))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(vwReportRichiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(vwReportRichiestaR.Filter.DataRichiesta.Value.Date))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                .OrderBy(sortParam)
                .Include("Richiesta")
                .Include("Richiesta.Sopralluogo")
               .ToListAsync();
 

            }

            List<ContractViewReportRichieste> richiesteElenco = new List<ContractViewReportRichieste>();
            foreach (EntityViewReportRichieste varVwReportRichiesta in vwReportRichieste)
            {
                ContractViewReportRichieste vwReportRichiesta1 = new ContractViewReportRichieste();
                UtilityManager.MapProp(varVwReportRichiesta, vwReportRichiesta1);
                richiesteElenco.Add(vwReportRichiesta1);
            }
            return richiesteElenco;
        }

        public async Task<Int32> GetStatoRichiesteTot(ViewRichiesteRequestFull vwReportRichiestaR,  long idUtente)
        {
            List<EntityViewReportRichieste> vwReportRichieste;
            EntityUtente utente;
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);
            List<EntityUtentiProvince> listUtenteProvincia = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id).ToList();

            String sortParam = String.Concat(String.Concat(vwReportRichiestaR.CampoOrdinamento, " "), vwReportRichiestaR.Ordinamento.ToUpper());
            if (utente.IdZona != null)
            {
                region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
               .Select(x => x.Id)
               .ToList();
            }
            else if (listUtenteProvincia.Count() > 0)
            {
                province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();
            }

            Int32 count = _RCDDbContext.ViewReportRichieste
                .WhereIf(utente.IdZona != null, q => region.Contains(q.IdRegioneVF.Value))
                .WhereIf(listUtenteProvincia.Count() > 0, q => province.Contains(q.IdProvincia.Value)).WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(vwReportRichiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(vwReportRichiestaR.Filter.DataRichiesta.Value.Date))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                .Count();

            return count;//vwReportRichieste.Count();

        }
        #endregion Stato Richieste

        #region Richieste Inserite
        public async Task<List<ContractViewReportRichieste>> GetRichiesteInserite(ViewRichiesteRequestFull vwReportRichiestaR, long idUtente)
        {
            List<EntityViewReportRichieste> vwReportRichieste;

            EntityUtente utente;
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);
            List<EntityUtentiProvince> listUtenteProvincia = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id).ToList();

            String sortParam = String.Concat(String.Concat(vwReportRichiestaR.CampoOrdinamento, " "), vwReportRichiestaR.Ordinamento.ToUpper());

            if (utente.IdZona != null)
            {
                region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
               .Select(x => x.Id)
               .ToList();
            }
            else if (listUtenteProvincia.Count() > 0)
            {
                province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();
            }

            var stati = (from s in _RCDDbContext.Stato
                         where (s.Id == 1 || s.Id == 2 || s.Id == 3) && (s.IsAutomaticChange == true || s.FollowGovernanceRule == true)
                         select s.Id).ToList();

            if (vwReportRichiestaR.Pageable)
            {
                vwReportRichieste = await _RCDDbContext.ViewReportRichieste
                    .Where(x=> stati.Contains(x.IdUltimoStato ))
                    .WhereIf(utente.IdZona != null, q => region.Contains(q.IdRegioneVF.Value))
                    .WhereIf(listUtenteProvincia.Count() > 0, q => province.Contains(q.IdProvincia.Value))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(vwReportRichiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(vwReportRichiestaR.Filter.DataRichiesta.Value.Date))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                    .Skip(vwReportRichiestaR.NumeroElementi * vwReportRichiestaR.Page).Take(vwReportRichiestaR.NumeroElementi)
                    .Include("Richiesta")
                    .Include("Richiesta.Sopralluogo")
                    .OrderBy(sortParam)
                    .ToListAsync();

            }
            else
            {
                _RCDDbContext.Database.SetCommandTimeout(300);
                vwReportRichieste = await _RCDDbContext.ViewReportRichieste
                 .Where(x => stati.Contains(x.IdUltimoStato))
                .WhereIf(utente.IdZona != null, q => region.Contains(q.IdRegioneVF.Value))
                .WhereIf(listUtenteProvincia.Count() > 0, q => province.Contains(q.IdProvincia.Value))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(vwReportRichiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(vwReportRichiestaR.Filter.DataRichiesta.Value.Date))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                .OrderBy(sortParam)
                .Include("Richiesta")
                .Include("Richiesta.Sopralluogo")
               .ToListAsync();


            }

            List<ContractViewReportRichieste> richiesteElenco = new List<ContractViewReportRichieste>();
            foreach (EntityViewReportRichieste varVwReportRichiesta in vwReportRichieste)
            {
                ContractViewReportRichieste vwReportRichiesta1 = new ContractViewReportRichieste();
                UtilityManager.MapProp(varVwReportRichiesta, vwReportRichiesta1);
                richiesteElenco.Add(vwReportRichiesta1);
            }
            return richiesteElenco;
        }

        public async Task<Int32> GetRichiesteInseriteTot(ViewRichiesteRequestFull vwReportRichiestaR, long idUtente)
        {
            List<EntityViewReportRichieste> vwReportRichieste;
            EntityUtente utente;
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);
            List<EntityUtentiProvince> listUtenteProvincia = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id).ToList();

            String sortParam = String.Concat(String.Concat(vwReportRichiestaR.CampoOrdinamento, " "), vwReportRichiestaR.Ordinamento.ToUpper());
            if (utente.IdZona != null)
            {
                region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
               .Select(x => x.Id)
               .ToList();
            }
            else if (listUtenteProvincia.Count() > 0)
            {
                province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();
            }

            var stati = (from s in _RCDDbContext.Stato
                         where (s.Id == 1 || s.Id == 2 || s.Id == 3) && (s.IsAutomaticChange == true || s.FollowGovernanceRule == true)
                         select s.Id).ToList();


            Int32 count = _RCDDbContext.ViewReportRichieste
                 .Where(x => stati.Contains(x.IdUltimoStato))
                .WhereIf(utente.IdZona != null, q => region.Contains(q.IdRegioneVF.Value))
                .WhereIf(listUtenteProvincia.Count() > 0, q => province.Contains(q.IdProvincia.Value)).WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(vwReportRichiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(vwReportRichiestaR.Filter.DataRichiesta.Value.Date))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                .Count();

            return count;//vwReportRichieste.Count();

        }
        #endregion  Richieste Inserite

        #region Richieste in Lavorazione
        public async Task<List<ContractViewReportRichieste>> GetRichiesteInLavorazione(ViewRichiesteRequestFull vwReportRichiestaR, long idUtente)
        {
            List<EntityViewReportRichieste> vwReportRichieste;

            EntityUtente utente;
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);
            List<EntityUtentiProvince> listUtenteProvincia = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id).ToList();

            String sortParam = String.Concat(String.Concat(vwReportRichiestaR.CampoOrdinamento, " "), vwReportRichiestaR.Ordinamento.ToUpper());

            if (utente.IdZona != null)
            {
                region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
               .Select(x => x.Id)
               .ToList();
            }
            else if (listUtenteProvincia.Count() > 0)
            {
                province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();
            }

            var stati = (from s in _RCDDbContext.Stato
                         where s.IsKoState == false && s.IsFinalState == false && s.Id != 1
                         select s.Id).ToList();

            if (vwReportRichiestaR.Pageable)
            {
                vwReportRichieste = await _RCDDbContext.ViewReportRichieste
                    .Where(x => stati.Contains(x.IdUltimoStato))
                    .WhereIf(utente.IdZona != null, q => region.Contains(q.IdRegioneVF.Value))
                    .WhereIf(listUtenteProvincia.Count() > 0, q => province.Contains(q.IdProvincia.Value))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(vwReportRichiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(vwReportRichiestaR.Filter.DataRichiesta.Value.Date))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                    .Skip(vwReportRichiestaR.NumeroElementi * vwReportRichiestaR.Page).Take(vwReportRichiestaR.NumeroElementi)
                    .Include("Richiesta")
                    .Include("Richiesta.Sopralluogo")
                    .OrderBy(sortParam)
                    .ToListAsync();

            }
            else
            {
                _RCDDbContext.Database.SetCommandTimeout(300);
                vwReportRichieste = await _RCDDbContext.ViewReportRichieste
                 .Where(x => stati.Contains(x.IdUltimoStato))
                .WhereIf(utente.IdZona != null, q => region.Contains(q.IdRegioneVF.Value))
                .WhereIf(listUtenteProvincia.Count() > 0, q => province.Contains(q.IdProvincia.Value))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(vwReportRichiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(vwReportRichiestaR.Filter.DataRichiesta.Value.Date))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                .OrderBy(sortParam)
                .Include("Richiesta")
                .Include("Richiesta.Sopralluogo")
               .ToListAsync();


            }

            List<ContractViewReportRichieste> richiesteElenco = new List<ContractViewReportRichieste>();
            foreach (EntityViewReportRichieste varVwReportRichiesta in vwReportRichieste)
            {
                ContractViewReportRichieste vwReportRichiesta1 = new ContractViewReportRichieste();
                UtilityManager.MapProp(varVwReportRichiesta, vwReportRichiesta1);
                richiesteElenco.Add(vwReportRichiesta1);
            }
            return richiesteElenco;
        }

        public async Task<Int32> GetRichiesteInLavorazioneTot(ViewRichiesteRequestFull vwReportRichiestaR, long idUtente)
        {
            List<EntityViewReportRichieste> vwReportRichieste;
            EntityUtente utente;
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);
            List<EntityUtentiProvince> listUtenteProvincia = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id).ToList();

            String sortParam = String.Concat(String.Concat(vwReportRichiestaR.CampoOrdinamento, " "), vwReportRichiestaR.Ordinamento.ToUpper());
            if (utente.IdZona != null)
            {
                region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
               .Select(x => x.Id)
               .ToList();
            }
            else if (listUtenteProvincia.Count() > 0)
            {
                province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();
            }

            var stati = (from s in _RCDDbContext.Stato
                         where s.IsKoState == false && s.IsFinalState == false && s.Id != 1
                         select s.Id).ToList();


            Int32 count = _RCDDbContext.ViewReportRichieste
                 .Where(x => stati.Contains(x.IdUltimoStato))
                .WhereIf(utente.IdZona != null, q => region.Contains(q.IdRegioneVF.Value))
                .WhereIf(listUtenteProvincia.Count() > 0, q => province.Contains(q.IdProvincia.Value)).WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(vwReportRichiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(vwReportRichiestaR.Filter.DataRichiesta.Value.Date))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                .Count();

            return count;//vwReportRichieste.Count();

        }
        #endregion  Richieste In Lavorazione

        #region Richieste Concluse
        public async Task<List<ContractViewReportRichieste>> GetRichiesteConcluse(ViewRichiesteRequestFull vwReportRichiestaR, long idUtente)
        {
            List<EntityViewReportRichieste> vwReportRichieste;

            EntityUtente utente;
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);
            List<EntityUtentiProvince> listUtenteProvincia = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id).ToList();

            String sortParam = String.Concat(String.Concat(vwReportRichiestaR.CampoOrdinamento, " "), vwReportRichiestaR.Ordinamento.ToUpper());

            if (utente.IdZona != null)
            {
                region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
               .Select(x => x.Id)
               .ToList();
            }
            else if (listUtenteProvincia.Count() > 0)
            {
                province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();
            }

            var stati = (from s in _RCDDbContext.Stato
                          where s.IsKoState == false && s.IsFinalState == true                             
                         select s.Id).ToList();

            if (vwReportRichiestaR.Pageable)
            {
                vwReportRichieste = await _RCDDbContext.ViewReportRichieste
                    .Where(x => stati.Contains(x.IdUltimoStato))
                    .WhereIf(utente.IdZona != null, q => region.Contains(q.IdRegioneVF.Value))
                    .WhereIf(listUtenteProvincia.Count() > 0, q => province.Contains(q.IdProvincia.Value))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(vwReportRichiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(vwReportRichiestaR.Filter.DataRichiesta.Value.Date))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                    .Skip(vwReportRichiestaR.NumeroElementi * vwReportRichiestaR.Page).Take(vwReportRichiestaR.NumeroElementi)
                    .Include("Richiesta")
                    .Include("Richiesta.Sopralluogo")
                    .OrderBy(sortParam)
                    .ToListAsync();

            }
            else
            {
                _RCDDbContext.Database.SetCommandTimeout(300);
                vwReportRichieste = await _RCDDbContext.ViewReportRichieste
                 .Where(x => stati.Contains(x.IdUltimoStato))
                .WhereIf(utente.IdZona != null, q => region.Contains(q.IdRegioneVF.Value))
                .WhereIf(listUtenteProvincia.Count() > 0, q => province.Contains(q.IdProvincia.Value))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(vwReportRichiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(vwReportRichiestaR.Filter.DataRichiesta.Value.Date))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                .OrderBy(sortParam)
                .Include("Richiesta")
                .Include("Richiesta.Sopralluogo")
               .ToListAsync();


            }

            List<ContractViewReportRichieste> richiesteElenco = new List<ContractViewReportRichieste>();
            foreach (EntityViewReportRichieste varVwReportRichiesta in vwReportRichieste)
            {
                ContractViewReportRichieste vwReportRichiesta1 = new ContractViewReportRichieste();
                UtilityManager.MapProp(varVwReportRichiesta, vwReportRichiesta1);
                richiesteElenco.Add(vwReportRichiesta1);
            }
            return richiesteElenco;
        }

        public async Task<Int32> GetRichiesteConcluseTot(ViewRichiesteRequestFull vwReportRichiestaR, long idUtente)
        {
            List<EntityViewReportRichieste> vwReportRichieste;
            EntityUtente utente;
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);
            List<EntityUtentiProvince> listUtenteProvincia = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id).ToList();

            String sortParam = String.Concat(String.Concat(vwReportRichiestaR.CampoOrdinamento, " "), vwReportRichiestaR.Ordinamento.ToUpper());
            if (utente.IdZona != null)
            {
                region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
               .Select(x => x.Id)
               .ToList();
            }
            else if (listUtenteProvincia.Count() > 0)
            {
                province = listUtenteProvincia.Select(x => x.IdProvincia).ToList();
            }

            var stati = (from s in _RCDDbContext.Stato
                         where s.IsKoState == false && s.IsFinalState == true
                         select s.Id).ToList();


            Int32 count = _RCDDbContext.ViewReportRichieste
                 .Where(x => stati.Contains(x.IdUltimoStato))
                .WhereIf(utente.IdZona != null, q => region.Contains(q.IdRegioneVF.Value))
                .WhereIf(listUtenteProvincia.Count() > 0, q => province.Contains(q.IdProvincia.Value)).WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(vwReportRichiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(vwReportRichiestaR.Filter.DataRichiesta.Value.Date))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                .Count();

            return count;//vwReportRichieste.Count();

        }
        # endregion  Richieste Cocluse
    }

}