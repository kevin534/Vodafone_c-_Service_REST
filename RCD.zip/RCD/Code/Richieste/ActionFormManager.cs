﻿using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;
using System.Text;

namespace RCD.Code.Richieste
{
    public class ActionFormManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        private long? idAreaBudget = 0;
        private DateTime dataRichiesta;
        List<long?> IdDittaFittizia = new List<long?> { 1, 2, 3, 4 };

        #region "COSTANTI"
        private const string NEW = "NEW";
        //   private const string ATTESA_OK_INSTALL_DOPO_GOV = "ATTESA_OK_INSTALL_DOPO_GOV";
        private const string OK_SOPRALLUOGO = "OK_SOPRALLUOGO";
        private const string SOPRALLUOGO_EFFETTUATO = "SOPRALLUOGO_EFFETTUATO";
        private const string KO_TECNICO_DOPO_SOPRALLUOGO = "KO_TECNICO_DOPO_SOPRALLUOGO";
        private const string OK_TECNICO_DOPO_SOPRALLUOGO = "OK_TECNICO_DOPO_SOPRALLUOGO";
        private const string ATTESA_OK_SOPRALLUOGO = "ATTESA_OK_SOPRALLUOGO";
        private const string ATTESA_OK_INSTALLAZIONE_DOPO_GOVERNANCE = "ATTESA_OK_INSTALLAZIONE_DOPO_GOVERNANCE";
        private const string ATTESA_OK_INSTALLAZIONE = "ATTESA_OK_INSTALLAZIONE";
        private const string OK_INSTALLAZIONE = "OK_INSTALLAZIONE";
        private const string KO_CLIENTE = "KO_CLIENTE";
        private const string KO_VENDITE_DOPO_SOPRALLUOGO = "KO_VENDITE_DOPO_SOPRALLUOGO";
        private const string KO_VENDITE = "KO_VENDITE";
        private const string INSTALLAZIONE_AVVENUTA = "INSTALLAZIONE_AVVENUTA";
        private const string INSTALLAZIONE_RIMOSSA = "INSTALLAZIONE_RIMOSSA";
        #endregion "COSTANTI"

        private enum STATUS_ID_WKF
        {
            NEW = 0,
            ATTESA_OK_SOPRALLUOGO = 1,
            KO_DOPO_GOVERNANCE = 2,
            OK_SOPRALLUOGO = 3,
            SOPRALLUOGO_EFFETTUATO = 4,
            KO_TECNICO_DOPO_SOPRALLUOGO = 5,
            OK_TECNICO_DOPO_SOPRALLUOGO = 6,
            ATTESA_OK_INSTALLAZIONE_DOPO_GOVERNANCE = 7,
            ATTESA_OK_INSTALLAZIONE = 8,
            KO_VENDITE_DOPO_SOPRALLUOGO = 9,
            OK_INSTALLAZIONE = 10,
            INSTALLAZIONE_AVVENUTA = 11,
            INSTALLAZIONE_RIMOSSA = 12,
            KO_CLIENTE = 13,
            KO_VENDITE = 14
        }

        public ActionFormManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        #region "SERVIZI"

        public long? InsertNewRichiesta(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            long? idRichiesta = 0;
            try
            {
                idRichiesta = SaveNextStatus(STATUS_ID_WKF.NEW, richiesta, userId, isAutomaticChange);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return idRichiesta;
        }

        //Salvataggio da OK Sopralluogo (3) senza passaggio di stato - SAVE
        public void OnConfirmSave(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                UpdateRichiesta(richiesta, userId, isAutomaticChange, STATUS_ID_WKF.OK_SOPRALLUOGO);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        //Salvataggio da OK Installazione (10) senza passaggio di stato - SAVE
        public void OnConfirmSaveOkInstallazione(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                UpdateRichiesta(richiesta, userId, isAutomaticChange, STATUS_ID_WKF.OK_INSTALLAZIONE);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        /// <summary>
        ///Salvataggio da OK Sopralluogo (3) senza passaggio di stato - SAVE
        /// </summary>
        /// <param name="richiesta"></param>
        /// <param name="userId"></param>
        /// <param name="isAutomaticChange"></param>
        /// <exception cref="Exception"></exception>
        public void OnConfirmSaveSopralluogoEffettuato(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                UpdateRichiesta(richiesta, userId, isAutomaticChange, STATUS_ID_WKF.SOPRALLUOGO_EFFETTUATO);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Salvataggio da OK Installazione (10) a installazione avvenuta(11)
        /// </summary>
        /// <param name="richiesta"></param>
        /// <param name="userId"></param>
        /// <param name="isAutomaticChange"></param>
        /// <exception cref="Exception"></exception>
        public void OnConfirmInstallazioneAvvenuta(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                UpdateRichiesta(richiesta, userId, isAutomaticChange, STATUS_ID_WKF.INSTALLAZIONE_AVVENUTA);
                SaveNextStatus(STATUS_ID_WKF.INSTALLAZIONE_AVVENUTA, richiesta, userId, isAutomaticChange);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Fa transitare una richiesta nello stato 'Sopralluogo' - 3
        /// </summary>
        /// <param name="richiesta"></param>
        /// <param name="userId"></param>
        /// <param name="isAutomaticChange"></param>
        /// <exception cref="Exception"></exception>
        public void OKSopralluogo(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                UpdateRichiesta(richiesta, userId, isAutomaticChange, STATUS_ID_WKF.OK_SOPRALLUOGO);
                SaveNextStatus(STATUS_ID_WKF.OK_SOPRALLUOGO, richiesta, userId, isAutomaticChange);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Fa transitare una richiesta nello stato 'Sopralluogo effettuato'
        /// </summary>
        /// <param name="richiesta"></param>
        /// <param name="userId"></param>
        /// <param name="isAutomaticChange"></param>
        /// <exception cref="Exception"></exception>
        public void SopralluogoEffettuato(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                SaveNextStatus(STATUS_ID_WKF.SOPRALLUOGO_EFFETTUATO, richiesta, userId, isAutomaticChange);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void OnConfirmAttesaOkSopralluogo(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                SaveNextStatus(STATUS_ID_WKF.ATTESA_OK_SOPRALLUOGO, richiesta, userId, isAutomaticChange);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        /// <summary>
        /// Fa transitare una richiesta nello stato 'KO tecnico dopo sopralluogo'
        /// </summary>
        /// <param name="richiesta"></param>
        /// <param name="userId"></param>
        /// <param name="isAutomaticChange"></param>
        /// <exception cref="Exception"></exception>
        public void KoTecnicoDopoSopralluogo(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                SaveNextStatus(STATUS_ID_WKF.KO_TECNICO_DOPO_SOPRALLUOGO, richiesta, userId, false);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Fa transitare una richiesta nello stato 'OK tecnico dopo sopralluogo'
        /// </summary>
        /// <param name="richiesta"></param>
        /// <param name="userId"></param>
        /// <param name="isAutomaticChange"></param>
        /// <exception cref="Exception"></exception>
        public void OkTecnicoDopoSopralluogo(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                if (richiesta.Sopralluogo is not null)
                {
                    //Salvare Descrizione sopralluogo se esiste e fare passaggio di stato)
                    if (!string.IsNullOrEmpty(richiesta.Sopralluogo.DescrizioneSopralluogo))
                    {
                        UpdateRichiesta(richiesta, userId, isAutomaticChange, STATUS_ID_WKF.OK_TECNICO_DOPO_SOPRALLUOGO);
                    }
                }

                SaveNextStatus(STATUS_ID_WKF.OK_TECNICO_DOPO_SOPRALLUOGO, richiesta, userId, isAutomaticChange);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Fa transitare una richiesta nello stato 'Ok Installazione'
        /// </summary>
        /// <param name="richiesta"></param>
        /// <param name="userId"></param>
        /// <param name="isAutomaticChange"></param>
        /// <exception cref="Exception"></exception>
        public void AttesaOkInstallazioneDopoGov(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                SaveNextStatus(STATUS_ID_WKF.ATTESA_OK_INSTALLAZIONE_DOPO_GOVERNANCE, richiesta, userId, isAutomaticChange);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Fa transitare una richiesta nello stato 'Ok Installazione'
        /// </summary>
        /// <param name="richiesta"></param>
        /// <param name="userId"></param>
        /// <param name="isAutomaticChange"></param>
        /// <exception cref="Exception"></exception>
        public void OkInstallazioneFuoriGovernance(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                SaveNextStatus(STATUS_ID_WKF.OK_INSTALLAZIONE, richiesta, userId, isAutomaticChange);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void OnConfirmAttesaOkInstallazione(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                if (richiesta.Sopralluogo is not null)
                {
                    if (!string.IsNullOrEmpty(richiesta.Sopralluogo.DescrizioneSopralluogo))
                    {
                        UpdateRichiesta(richiesta, userId, isAutomaticChange, STATUS_ID_WKF.ATTESA_OK_INSTALLAZIONE);
                    }
                }
                SaveNextStatus(STATUS_ID_WKF.ATTESA_OK_INSTALLAZIONE, richiesta, userId, isAutomaticChange);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        //public void AttesaOkInstallazione(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        //{
        //    try
        //    {
        //        SaveNextStatus(STATUS_ID_WKF.ATTESA_OK_INSTALLAZIONE, richiesta, userId, isAutomaticChange);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message);
        //    }
        //}


        /// <summary>
        /// Fa transitare una richiesta nello stato 'Ko Cliente'
        /// </summary>
        /// <param name="richiesta"></param>
        /// <param name="userId"></param>
        /// <param name="isAutomaticChange"></param>
        /// <exception cref="Exception"></exception>
        public void KoClienteDopoOkTecnico(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                SaveNextStatus(STATUS_ID_WKF.KO_CLIENTE, richiesta, userId, isAutomaticChange);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        /// <summary>
        /// Fa transitare una richiesta nello stato 'Ko Cliente' sopralluogo
        /// </summary>
        /// <param name="richiesta"></param>
        /// <param name="userId"></param>
        /// <param name="isAutomaticChange"></param>
        /// <exception cref="Exception"></exception>
        public void KoClienteSopralluogo(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                SaveNextStatus(STATUS_ID_WKF.KO_CLIENTE, richiesta, userId, isAutomaticChange);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public void KoClienteInstallazione(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                SaveNextStatus(STATUS_ID_WKF.KO_CLIENTE, richiesta, userId, isAutomaticChange);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Fa transitare una richiesta allo stato 'Ko vendite dopo sopralluogo'
        /// </summary>
        /// <param name="richiesta"></param>
        /// <param name="userId"></param>
        /// <param name="isAutomaticChange"></param>
        /// <exception cref="Exception"></exception>
        public void KoVenditeDopoSopralluogo(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                SaveNextStatus(STATUS_ID_WKF.KO_VENDITE_DOPO_SOPRALLUOGO, richiesta, userId, false);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Fa transitare una richiesta allo stato 'Ko vendite' - 14
        /// </summary>
        /// <param name="richiesta"></param>
        /// <param name="userId"></param>
        /// <param name="isAutomaticChange"></param>
        /// <exception cref="Exception"></exception>
        public void KoVendite(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                SaveNextStatus(STATUS_ID_WKF.KO_VENDITE, richiesta, userId, false);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Fa transitare una richiesta nello stato 'Ko Cliente'
        /// </summary>
        /// <param name="richiesta"></param>
        /// <param name="userId"></param>
        /// <param name="isAutomaticChange"></param>
        /// <exception cref="Exception"></exception>
        public void KoClienteFuoriGovernance(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                SaveNextStatus(STATUS_ID_WKF.KO_CLIENTE, richiesta, userId, isAutomaticChange);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #endregion "SERVIZI"

        #region "GOVERNANCE"

        /// <summary>
        /// Ritorna l'elenco delle governance in base alla tipologia di autorizzazione (determinata dall stato) e al canale vendita di dettaglio
        /// </summary>
        /// <param name="idStato"></param>
        /// <param name="idCanaleVenditeDettaglio"></param>
        /// <returns></returns>
        public List<EntityGovernance> GetGovernanceByStatoECanale(long? idStato, long? idCanaleVenditeDettaglio)
        {
            var listGov = _RCDDbContext.Governances.Include("TipologiaAutorizzazione")
                .Where(x => x.Id == idCanaleVenditeDettaglio && x.TipologiaAutorizzazione.Stato.Id == idStato).ToList();

            List<EntityGovernance?> elencoGov = new List<EntityGovernance?>();
            for (int i = 0; i < listGov.Count; i++)
            {
                elencoGov.Add(listGov[i]);
            }
            return elencoGov;

        }

        /// <summary>
        /// verifica Governance
        /// </summary>
        /// <param name="actualStatus"></param>
        /// <param name="richiesta"></param>
        /// <param name="isAutomaticChange"></param>
        /// <returns></returns>
        private Boolean CheckGovernance(EntityStato actualStatus, EntityRichiesta richiesta, Boolean isAutomaticChange)
        {
            Boolean isCheckedGovernance = false;
            // Se lo stato richiede controllo delle governance
            //if (actualStatus.FollowGovernanceRule == true)
            //{
            if (richiesta.Richiedente is not null)
            {
                if ((actualStatus.Id != null) && (richiesta.Richiedente.IdCanaleVenditeDettaglio != null))
                {
                    long? statusId = actualStatus.Id;
                    long? richiedenteCVD_Id = richiesta.Richiedente.IdCanaleVenditeDettaglio;

                    List<EntityGovernance> listGov = GetGovernanceByStatoECanale(statusId, richiedenteCVD_Id);

                    bool checkedGovernance = false;
                    foreach (EntityGovernance g in listGov)
                    {
                        string descTipologiaAuto = string.Empty;
                        descTipologiaAuto = g.TipologiaAutorizzazione.TipologiaAutorizzazione;

                        //recupero del Sistema -- DA VERIFICARE
                        EntitySistemaRichiesto sistemaR = _RCDDbContext.SistemaRichiesto.Where(x => x.Id == richiesta.IdSistemaRichiesto).FirstOrDefault();
                        // EntitySistemaRichiesto sistemaR = richiesta.SistemaRichiesto

                        //bool? skipGovSopralluogo = richiesta.SistemaRichiesto.SkipGovSopralluogo;
                        bool? skipGovSopralluogo = sistemaR.SkipGovSopralluogo;
                        if ((skipGovSopralluogo == true && descTipologiaAuto.Equals("sopralluogo", StringComparison.InvariantCultureIgnoreCase))
                            || (skipGovSopralluogo == true && g.TipologiaAutorizzazione.TipologiaAutorizzazione.Equals("installazione", StringComparison.InvariantCultureIgnoreCase)))
                        {
                            checkedGovernance = true;
                        }
                        else
                        {
                            //recupero del Sopralluogo -- DA VERIFICARE
                            EntitySopralluogo sopralluogoR = _RCDDbContext.Sopralluogo.Where(x => x.Id == richiesta.IdSopralluogo).FirstOrDefault();

                            Double? stimaIntervento = 0;
                            if (sopralluogoR != null)
                                stimaIntervento = sopralluogoR.StimaIntervento;

                            bool continueValue = checkGovernancesValues(g, richiesta.Richiedente, stimaIntervento);

                            if (continueValue == true && checkedGovernance == false)
                            {
                                checkedGovernance = true;
                            }
                        }

                    }

                    isCheckedGovernance = checkedGovernance;

                }
                //}

            }

            return isCheckedGovernance;
        }

        private bool checkGovernancesValues(EntityGovernance g, EntityRichiedente richiedente, Double? stimaIntervento)
        {
            bool continueValue = false;
            if (g.NumeroSimVoce.HasValue)
            {
                if (richiedente.NumeroSIM >= g.NumeroSimVoce)
                {
                    continueValue = true;
                }
                else
                {
                    continueValue = false;
                }
            }
            if (g.NumeroInterniVruc.HasValue)
            {
                if (continueValue && richiedente.NumeroInterniVRUC >= g.NumeroInterniVruc)
                {
                    continueValue = true;
                }
                else
                {
                    continueValue = false;
                }
            }
            if (g.FatturatoBimestrale.HasValue)
            {
                if (continueValue && richiedente.FatturatoMedioBimestrale >= g.FatturatoBimestrale)
                {
                    continueValue = true;
                }
                else
                {
                    continueValue = false;
                }
            }
            // Controlla nel caso la tipologia autorizzazione applicata sia 'Installazione' 
            if (g.CostoSopralluogo.HasValue && g.IdTipologiaAutorizzazioneApplicata.Equals(2))
            {
                if (continueValue && stimaIntervento <= g.CostoSopralluogo.Value)
                {
                    continueValue = true;
                }
                else
                {
                    continueValue = false;
                }
            }

            return continueValue;
        }

        #endregion "GOVERNANCE"

        #region "SET NEXT STATUS"

        public EntityStato GetNextStatus(string strStatus, EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            try
            {
                EntityStato nextStatus = new EntityStato();
                EntityStato actualStatus;
                // Se la richiesta non è nuova
                if (richiesta.Id > 0)
                {
                    //recupero l'ultimo stato della richiesta 
                    EntityStatiRichiesta statiRichiesta = _RCDDbContext.StatiRichiesta.Where(x => x.IdRichiesta == richiesta.Id).OrderByDescending(x => x.InsertDate).FirstOrDefault();

                    //recupero lo stato dell'ultima richiesta inserita
                    actualStatus = _RCDDbContext.Stato.Where(x => x.Id == statiRichiesta.IdStato).FirstOrDefault();

                    //strStatus.Equals(ATTESA_OK_INSTALLAZIONE_DOPO_GOVERNANCE)
                    if (actualStatus.FollowGovernanceRule == true)
                    {
                        Boolean checkedGovernance = CheckGovernance(actualStatus, richiesta, isAutomaticChange);

                        //La governance è verificata
                        if (checkedGovernance == true)
                        {
                            EntityWorkflow wkf = _RCDDbContext.Workflow
                                .Where(x => x.IdInitialState == actualStatus.Id && x.ConditionValue == 1 && x.FinalState.IsAutomaticChange == false).FirstOrDefault();

                            nextStatus = getNextStatus(wkf);

                        }   // La governance non è verificata
                        else
                        {
                            EntityWorkflow wkf = _RCDDbContext.Workflow
                                .Where(x => x.IdInitialState == actualStatus.Id && x.ConditionValue == 0 && x.FinalState.IsAutomaticChange == true).FirstOrDefault();

                            nextStatus = getNextStatus(wkf);
                        }
                    }
                    // Se lo stato non richiede controllo delle governance
                    else
                    {
                        EntityWorkflow wkf;
                        if (strStatus.Equals(ATTESA_OK_INSTALLAZIONE_DOPO_GOVERNANCE))
                        {
                            wkf = _RCDDbContext.Workflow
                                       .Where(x => x.InitialState.Id == actualStatus.Id && x.FinalState.IsAutomaticChange == isAutomaticChange).FirstOrDefault();
                        }
                        else
                        {
                            Int32 condition = SetConditionByStatusWkf(strStatus);
                            wkf = GetWorkflowByCondition(condition, actualStatus.Id, isAutomaticChange);

                        }
                        nextStatus = getNextStatus(wkf);
                    }


                }
                else  //se la richiesta è nuova
                {
                    actualStatus = _RCDDbContext.Stato.Where(x => x.Id == 1).FirstOrDefault();
                    Boolean checkedGovernance = CheckGovernance(actualStatus, richiesta, isAutomaticChange);

                    if (checkedGovernance == true)
                    {

                        EntityWorkflow wkf = _RCDDbContext.Workflow
                            .Where(x => x.IdInitialState == actualStatus.Id && x.ConditionValue == 1 && x.FinalState.IsAutomaticChange == false).FirstOrDefault();

                        nextStatus = getNextStatus(wkf);

                    }   // La governance non è verificata
                    else
                    {
                        EntityWorkflow wkf = _RCDDbContext.Workflow
                            .Where(x => x.IdInitialState == actualStatus.Id && x.ConditionValue == 0 && x.FinalState.IsAutomaticChange == true).FirstOrDefault();

                        nextStatus = getNextStatus(wkf);
                    }
                }
                return nextStatus;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }


        private Int32 SetConditionByStatusWkf(String strStatus)
        {
            Int32 condition;
            switch (strStatus)
            {
                case OK_SOPRALLUOGO:
                    condition = 1;
                    break;
                case SOPRALLUOGO_EFFETTUATO:
                    condition = 1;
                    break;
                case KO_CLIENTE:
                    condition = -1;
                    break;
                case KO_TECNICO_DOPO_SOPRALLUOGO:
                    condition = 0;
                    break;
                case OK_TECNICO_DOPO_SOPRALLUOGO:
                    condition = 1;
                    break;
                case ATTESA_OK_INSTALLAZIONE_DOPO_GOVERNANCE:
                    condition = 0;
                    break;
                case ATTESA_OK_INSTALLAZIONE:
                    condition = 1;
                    break;
                case INSTALLAZIONE_AVVENUTA:
                    condition = 1;
                    break;
                case OK_INSTALLAZIONE:
                    condition = 1;
                    break;
                case KO_VENDITE_DOPO_SOPRALLUOGO:
                    condition = 0;
                    break;
                case KO_VENDITE:
                    condition = -1;
                    break;

                default:
                    condition = -2;
                    break;
            }
            return condition;
        }


        private EntityWorkflow GetWorkflowByCondition(Int32 condition, long? initialState, bool isAutomaticChange)
        {
            EntityWorkflow wkf;

            wkf = _RCDDbContext.Workflow
                       .Where(x => x.InitialState.Id == initialState && x.ConditionValue == condition && x.FinalState.IsAutomaticChange == isAutomaticChange).FirstOrDefault();

            return wkf;
        }


        private EntityStato getNextStatus(EntityWorkflow wkf)
        {
            EntityStato nextStatus = new EntityStato();
            if (wkf.IdFinalState != null)
            {
                nextStatus = _RCDDbContext.Stato.Where(x => x.Id == wkf.IdFinalState).FirstOrDefault();
            }
            return nextStatus;
        }

        private long? SaveNextStatus(STATUS_ID_WKF statusId, EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        {
            long? idRichiesta = 0;
            String prefixStatus = String.Empty;
            EntityStato nextStato = new EntityStato();
            EntityRichiesta richiestaToAdd = new EntityRichiesta();
            //Salvataggio tabella T_RICHIESTA - T_RICHIEDENTE - T_LOCATION
            UtilityManager.MapProp(richiesta, richiestaToAdd);
            richiestaToAdd.IdUserInsert = userId;
            //  string strStatus = string.Empty;

            switch (statusId)
            {
                case STATUS_ID_WKF.NEW:
                    prefixStatus = NEW;
                    break;
                case STATUS_ID_WKF.ATTESA_OK_SOPRALLUOGO:
                    prefixStatus = ATTESA_OK_SOPRALLUOGO;
                    break;
                case STATUS_ID_WKF.OK_SOPRALLUOGO:
                    prefixStatus = OK_SOPRALLUOGO;
                    break;
                case STATUS_ID_WKF.SOPRALLUOGO_EFFETTUATO:
                    prefixStatus = SOPRALLUOGO_EFFETTUATO;
                    break;
                case STATUS_ID_WKF.KO_TECNICO_DOPO_SOPRALLUOGO:
                    prefixStatus = KO_TECNICO_DOPO_SOPRALLUOGO;
                    break;
                case STATUS_ID_WKF.OK_TECNICO_DOPO_SOPRALLUOGO:
                    prefixStatus = OK_TECNICO_DOPO_SOPRALLUOGO;
                    break;
                case STATUS_ID_WKF.ATTESA_OK_INSTALLAZIONE_DOPO_GOVERNANCE:
                    prefixStatus = ATTESA_OK_INSTALLAZIONE_DOPO_GOVERNANCE;
                    break;
                case STATUS_ID_WKF.ATTESA_OK_INSTALLAZIONE:
                    prefixStatus = ATTESA_OK_INSTALLAZIONE;
                    break;
                case STATUS_ID_WKF.OK_INSTALLAZIONE:
                    prefixStatus = OK_INSTALLAZIONE;
                    break;
                case STATUS_ID_WKF.KO_CLIENTE:
                    prefixStatus = KO_CLIENTE;
                    break;
                case STATUS_ID_WKF.KO_VENDITE_DOPO_SOPRALLUOGO:
                    prefixStatus = KO_VENDITE_DOPO_SOPRALLUOGO;
                    break;
                case STATUS_ID_WKF.KO_VENDITE:
                    prefixStatus = KO_VENDITE;
                    break;
                case STATUS_ID_WKF.INSTALLAZIONE_AVVENUTA:
                    prefixStatus = INSTALLAZIONE_AVVENUTA;
                    break;
                case STATUS_ID_WKF.INSTALLAZIONE_RIMOSSA:
                    prefixStatus = INSTALLAZIONE_RIMOSSA;
                    break;

                default:
                    prefixStatus = String.Empty;
                    break;
            }

            nextStato = GetNextStatus(prefixStatus, richiestaToAdd, userId, isAutomaticChange);

            idRichiesta = richiesta.Id;
            if (nextStato != null)
            {

                // OLD RICHIESTA
                if (idRichiesta > 0)
                {
                    //var result = _RCDDbContext.Update(richiesta);
                    //_RCDDbContext.SaveChanges();
                    saveStatoRichiesta(userId, richiestaToAdd, nextStato.Id);

                }
                else //NUOVA RICHIESTA
                {
                    var richiedenteUpdate = new EntityRichiedente();
                    if (richiesta.Richiedente != null)
                    {
                        long? idRichiedenteOld = richiesta.Richiedente.Id;
                        if (idRichiedenteOld != null)
                        {
                            //UPDATE T_RICHIEDENTe SET IDRICHIEDENTE WHERE ID=IDRIchiedente passato da parametro
                            richiedenteUpdate = _RCDDbContext.Richiedente.First(g => g.Id == idRichiedenteOld);

                            if (richiedenteUpdate != null)
                            {
                                updateRichiedente(userId, richiesta.Richiedente, richiedenteUpdate, idRichiedenteOld);
                            }

                            //var richiedenteUpdated = _RCDDbContext.Richiedente.First(g => g.Id == idRichiedenteOld);
                            //richiesta.Richiedente = richiedenteUpdated;

                            //richiedenteUpdate.Id = idRichiedenteOld;
                            //_RCDDbContext.SaveChanges();

                            richiesta.Richiedente = null;
                            richiesta.IdRichiedente = richiedenteUpdate.Id;
                        }

                    }

                    var locationUpdate = new EntityLocation();
                    if (richiesta.Location != null)   //richiesta.IdLocation
                    {
                        long? idLocationOld = richiesta.Location.Id;
                        if (idLocationOld != null)
                        {
                            //UPDATE T_location SET IDlocation WHERE ID=IDLocation passato da parametro
                            locationUpdate = _RCDDbContext.Location.First(g => g.Id == idLocationOld);

                            if (locationUpdate != null)
                            {
                                updateLocation(userId, richiesta.Location, locationUpdate, idLocationOld);
                            }

                            //var richiedenteUpdated = _RCDDbContext.Richiedente.First(g => g.Id == idRichiedenteOld);
                            //richiesta.Richiedente = richiedenteUpdated;

                            //richiedenteUpdate.Id = idRichiedenteOld;
                            //_RCDDbContext.SaveChanges();

                            richiesta.Location = null;
                            richiesta.IdLocation = locationUpdate.Id;
                        }
                    }

                    //Salvataggio nuova richiesta
                    var result = _RCDDbContext.Add(richiesta);
                    _RCDDbContext.SaveChanges();
                    idRichiesta = _RCDDbContext.Richieste.OrderByDescending(x => x.Id).Select(r => r.Id).FirstOrDefault();
                    //      .OrderByDescending(x => x.Id).FirstOrDefault();

                    //DA TERMINARE !!!!!!!!!!!!!!!
                    //long? idRichiedente = richiesta.Richiedente.Id;
                    //long? idLocation = richiesta.Location.Id;

                    if (richiesta.IdLocation != null)
                    {
                        //UPDATE T_LOCATION SET IDRICHIEDENTE WHERE ID = IDLOCATION
                        var locationRichiesta = _RCDDbContext.Location.First(g => g.Id == richiesta.IdLocation);
                        locationRichiesta.IdRichiedente = richiesta.IdRichiedente;
                        _RCDDbContext.SaveChanges();
                    }



                    saveStatoRichiesta(userId, richiesta, 1);
                    saveStatoRichiesta(userId, richiesta, nextStato.Id);

                }
            }
            return idRichiesta;
        }

        #endregion "SET NEXT STATUS"

        #region "SALVATAGGI"

        /// <summary>
        /// Salvataggio T_STATI_RICHIESTA
        /// </summary>
        /// <param name="idUtente"></param>
        /// <param name="richiesta"></param>
        /// <param name="idStato"></param>
        private void saveStatoRichiesta(long idUtente, EntityRichiesta richiesta, long? idStato)
        {
            EntityStatiRichiesta nextSR = new EntityStatiRichiesta();
            nextSR.IdStato = idStato;
            nextSR.IdUtente = idUtente;
            nextSR.InsertDate = DateTime.Now;
            nextSR.IdRichiesta = richiesta.Id;

            //NON FATTA LA PARTE BUDGET 

            var result = _RCDDbContext.Add(nextSR);
            _RCDDbContext.Add(nextSR);
            _RCDDbContext.SaveChanges();

        }

        private void updateRichiedente(long idUtente, EntityRichiedente filterRichiedente, EntityRichiedente richiedenteUpdate, long? idRichiedente)
        {

            richiedenteUpdate.CognomeRiferimento = filterRichiedente.CognomeRiferimento;
            richiedenteUpdate.NomeRiferimento = filterRichiedente.NomeRiferimento;
            richiedenteUpdate.TelefonoRiferimento = filterRichiedente.TelefonoRiferimento;
            richiedenteUpdate.MailRiferimento = filterRichiedente.MailRiferimento;
            richiedenteUpdate.NumeroSIM = filterRichiedente.NumeroSIM;
            richiedenteUpdate.FatturatoMedioBimestrale = filterRichiedente.FatturatoMedioBimestrale;
            richiedenteUpdate.IdTipologiaCliente = filterRichiedente.IdTipologiaCliente;
            richiedenteUpdate.NumeroInterniVRUC = filterRichiedente.NumeroInterniVRUC;
            richiedenteUpdate.IdCanaleVendita = filterRichiedente.IdCanaleVendita;
            richiedenteUpdate.IdCanaleVenditeDettaglio = filterRichiedente.IdCanaleVenditeDettaglio;
            richiedenteUpdate.IdArea = filterRichiedente.IdArea;
            richiedenteUpdate.IdAreaVendite = filterRichiedente.IdAreaVendite;

            _RCDDbContext.Update(richiedenteUpdate);
            _RCDDbContext.SaveChanges();

            _RCDDbContext.Entry(richiedenteUpdate).State = Microsoft.EntityFrameworkCore.EntityState.Detached;

        }

        private void updateLocation(long idUtente, EntityLocation filterLocation, EntityLocation locationUpdate, long? idLocation)
        {
            locationUpdate.IdDisponibilitaAccessoAlTetto = filterLocation.IdDisponibilitaAccessoAlTetto;
            locationUpdate.IdCoperturaIndoorAltriGestori = filterLocation.IdCoperturaIndoorAltriGestori;
            locationUpdate.StabileDiProprieta = filterLocation.StabileDiProprieta;
            locationUpdate.ProprietaEdificio = filterLocation.ProprietaEdificio;
            locationUpdate.FullNameReferenteLocale = filterLocation.FullNameReferenteLocale;
            locationUpdate.EmailReferenteLocale = filterLocation.EmailReferenteLocale;
            locationUpdate.TelefonoReferenteLocale = filterLocation.TelefonoReferenteLocale;


            //"indirizzo":"via xxx modificato",
            //"vincolo":false,
            //"isDismesso":false,
            //"stabileDiProprieta":false

            _RCDDbContext.Update(locationUpdate);
            _RCDDbContext.SaveChanges();

            _RCDDbContext.Entry(locationUpdate).State = Microsoft.EntityFrameworkCore.EntityState.Detached;

        }


        private void UpdateRichiesta(EntityRichiesta richiesta, long userID, bool IsAutomaticChange, STATUS_ID_WKF statusId)
        {
            try
            {

                EntityRichiesta richiestaToUpdate = new EntityRichiesta();
                EntityRichiesta richiestaOld = _RCDDbContext.Richieste.Where(x => x.Id == richiesta.Id)
                    .Include("Location")
                    .Include("Sopralluogo")
                    .Include("Installazione")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    //.Include("Location.LocationApparati")
                    .FirstOrDefault();
                UtilityManager.MapProp(richiestaOld, richiestaToUpdate);


                switch (statusId)
                {
                    #region "OK SOPRALLUOGO , SOPRALLUOGO EFFETTUATO"

                    case STATUS_ID_WKF.OK_SOPRALLUOGO:
                    case STATUS_ID_WKF.SOPRALLUOGO_EFFETTUATO:

                        if ((richiestaOld.LastStatusId != 2 && richiestaOld.LastStatusId != 1))  //!!! DA VERIFICARE !!! SE PROVIENE DA KO DOPO GOVERNANCE FA SOLO IL PASSAGGIO DI STATO E NESSUN SALVATAGGIO
                        {
                            //Site Manager NI
                            //Progettista RAN
                            if (richiesta.SiteManagerNI != null)
                                richiestaToUpdate.SiteManagerNI = richiesta.SiteManagerNI;
                            if (richiesta.ProgettistaRan != null)
                                richiestaToUpdate.ProgettistaRan = richiesta.ProgettistaRan;

                            if (richiestaToUpdate.Location != null)
                            {
                                if (richiesta.Location != null)
                                {
                                    long? idLocation = richiesta.Location.Id;
                                    if (idLocation > 0)
                                    {
                                        //if (richiesta.Location.Id > 0)
                                        //{
                                        if (!string.IsNullOrEmpty(richiesta.Location.NomeInstallazione))
                                            richiestaToUpdate.Location.NomeInstallazione = richiesta.Location.NomeInstallazione;
                                        if (richiesta.Location.LatitudineGradi is not null)
                                            richiestaToUpdate.Location.LatitudineGradi = richiesta.Location.LatitudineGradi;
                                        if (richiesta.Location.LatitudinePrimi is not null)
                                            richiestaToUpdate.Location.LatitudinePrimi = richiesta.Location.LatitudinePrimi;
                                        if (richiesta.Location.LatitudineSecondi is not null)
                                            richiestaToUpdate.Location.LatitudineSecondi = richiesta.Location.LatitudineSecondi;
                                        if (richiesta.Location.LatitudineUTM is not null)
                                            richiestaToUpdate.Location.LatitudineUTM = richiesta.Location.LatitudineUTM;
                                        if (richiesta.Location.LongitudineGradi is not null)
                                            richiestaToUpdate.Location.LongitudineGradi = richiesta.Location.LongitudineGradi;
                                        if (richiesta.Location.LongitudinePrimi is not null)
                                            richiestaToUpdate.Location.LongitudinePrimi = richiesta.Location.LongitudinePrimi;
                                        if (richiesta.Location.LongitudineSecondi is not null)
                                            richiestaToUpdate.Location.LongitudineSecondi = richiesta.Location.LongitudineSecondi;
                                        if (richiesta.Location.LongitudineUTM is not null)
                                            richiestaToUpdate.Location.LongitudineUTM = richiesta.Location.LongitudineUTM;
                                        if (richiesta.Location.SLM is not null)
                                            richiestaToUpdate.Location.SLM = richiesta.Location.SLM;

                                    }
                                    else
                                    {
                                        //non esiste l'Id e quindi viene creata la location nuova
                                        if (richiesta.Location != null)
                                        {
                                            EntityLocation newLocation = new EntityLocation();
                                            UtilityManager.MapProp(richiesta.Location, newLocation);

                                            if (richiesta.Location.StabileDiProprieta == null)
                                                newLocation.StabileDiProprieta = true;

                                            if (richiesta.Location.IsDismesso == null)
                                                newLocation.IsDismesso = false;

                                            if (richiesta.Location.Vincolo == null)
                                                newLocation.Vincolo = false;

                                            if ((richiesta.Location.IdComune == null) || (richiesta.Location.Indirizzo == null))
                                                throw new Exception("inserire il comune o l'indirizzo della location");
                                           else
                                            {
                                                EntityStsComune? stsComune = _RCDDbContext.StsComune.Where(x => x.Id == richiesta.Location.IdComune)
                                               .Include("ProvinciaSts")
                                               .Include("ProvinciaSts.Provincia")
                                               .Include("ProvinciaSts.Provincia.RegioneVF")
                                               .Include("ProvinciaSts.Provincia.RegioneVF.Zona")
                                               //.Include("Location.LocationApparati")
                                               .First();

                                                newLocation.StsComune = stsComune;
                                             //   richiestaToUpdate.Location.StsComune = stsComune;
                                            }

                                            //if (richiesta.IdLocation != null)
                                            //{
                                            //    newLocation.IdRichiedente = richiestaToUpdate.IdRichiedente;
                                            //    //UPDATE T_LOCATION SET IDRICHIEDENTE WHERE ID = IDLOCATION
                                            //    var locationRichiesta = _RCDDbContext.Location.First(g => g.Id == richiesta.IdLocation);
                                            //    locationRichiesta.IdRichiedente = richiesta.IdRichiedente;
                                            //    _RCDDbContext.SaveChanges();
                                            //}
                                            newLocation.IdRichiedente = richiestaToUpdate.IdRichiedente;
                                            richiestaToUpdate.Location = newLocation;

                                        }
                                        else
                                            throw new Exception("errore: location della richiesta ha valore null");
                                    }

                                }
                            }



                            if (richiestaToUpdate.Sopralluogo != null)
                            {
                                if (richiesta.Sopralluogo != null)
                                {
                                    if (IdDittaFittizia.Contains(richiesta.Sopralluogo.IdDittaIncaricata) && richiesta.Sopralluogo.DataPresaInCaricoDitta == null)
                                    {
                                        richiestaToUpdate.Sopralluogo.DataPresaInCaricoDitta = DateTime.Now;
                                    }

                                    bool sendMailDitta = false;
                                    if (richiestaToUpdate != null && richiestaToUpdate.Sopralluogo != null && richiestaToUpdate.Sopralluogo.IdDittaIncaricata == richiesta.Sopralluogo.IdDittaIncaricata)
                                    {
                                        sendMailDitta = false;
                                    }
                                    else //DA FARE
                                    {
                                        //DA FARE
                                        //if ((richiesta.Sopralluogo.EntityState == EntityState.New || richiesta.Sopralluogo.EntityState == EntityState.Modified) && cmbDitta.SelectedItem != null)
                                        //{
                                        //    sendMailDitta = true;
                                        //}
                                    }


                                    // DA FARE
                                    //ActionForm af = new ActionForm();
                                    //af.Completed += (s1, e1) =>
                                    //{
                                    //    if (af.HasError)
                                    //    {
                                    //        ctx.RejectChanges();
                                    //        checkConsistency();
                                    //        app.HideBusyIndicator();
                                    //        app.Log(af.Error, true);
                                    //        //14/09/2011 by Pannacci: "installazione" -> "richiesta"
                                    //        app.ShowErrorMessage("Errore in fase di generazione del codice richiesta.", af.Error);
                                    //    }
                                    //    else
                                    //    {
                                    //        SubmitOperation submitChangeCompleted = ctx.SubmitChanges();
                                    //        submitChangeCompleted.Completed += (ss, ee) =>
                                    //        {
                                    //            if (submitChangeCompleted.HasError)
                                    //            {
                                    //                ctx.RejectChanges();
                                    //                checkConsistency();
                                    //                app.HideBusyIndicator();
                                    //                app.Log(submitChangeCompleted.Error, true);
                                    //                app.ShowErrorMessage("Errore in fase di salvataggio della richiesta.", submitChangeCompleted.Error);
                                    //            }
                                    //            else
                                    //            {
                                    //                if (sendMailDitta)
                                    //                {
                                    //                    try
                                    //                    {
                                    //                        //InvokeOperation invOp = ctx.SendMailDittaIncaricataSopralluogo(submitChangeCompleted.ChangeSet.ModifiedEntities.OfType<Richiesta>().FirstOrDefault<Richiesta>().Sopralluogo);
                                    //                        InvokeOperation invOp = ctx.SendMailDittaIncaricataSopralluogo(richiesta.Sopralluogo);
                                    //                        invOp.Completed += (sss, eee) =>
                                    //                        {
                                    //                            try
                                    //                            {
                                    //                                if (invOp.HasError)
                                    //                                {
                                    //                                    //vsData.Visibility = System.Windows.Visibility.Collapsed;
                                    //                                    app.HideBusyIndicator();
                                    //                                    app.Log(invOp.Error, true);
                                    //                                    app.ShowErrorMessage("Errore in fase di invio della mail di assegnazione del sopralluogo alla ditta.", invOp.Error);
                                    //                                }
                                    //                                else
                                    //                                {
                                    //                                    //vsData.Visibility = System.Windows.Visibility.Collapsed;
                                    //                                    setForm(richiesta);
                                    //                                    setButton(richiesta);
                                    //                                    app.HideBusyIndicator();
                                    //                                    app.ShowInfoMessage("Salvataggio richiesta avvenuto", "La richiesta è stata salvata con successo.\nLa mail di assegnazione del sopralluogo alla ditta è stata inoltrata.\nSono stati messi in copia i DM, RAN ed NI interessati.");
                                    //                                }
                                    //                            }
                                    //                            catch (Exception ex)
                                    //                            {
                                    //                                //vsData.Visibility = System.Windows.Visibility.Collapsed;
                                    //                                app.HideBusyIndicator();
                                    //                                app.Log(ex, true);
                                    //                                app.ShowErrorMessage("Errore in fase di salvataggio della richiesta.", ex);
                                    //                            }
                                    //                        };
                                    //                    }
                                    //                    catch (Exception ex)
                                    //                    {
                                    //                        //vsData.Visibility = System.Windows.Visibility.Collapsed;
                                    //                        app.HideBusyIndicator();
                                    //                        app.Log(ex, true);
                                    //                        app.ShowErrorMessage("Errore in fase di salvataggio della richiesta.", ex);
                                    //                    }
                                    //                }
                                    //                else
                                    //                {
                                    //                    ////vsData.Visibility = System.Windows.Visibility.Collapsed;
                                    //                    setForm(richiesta);
                                    //                    setButton(richiesta);
                                    //                    btnInviaMail.IsEnabled = cmbDitta.SelectedItem != null;
                                    //                    app.HideBusyIndicator();
                                    //                    app.ShowInfoMessage("Salvataggio richiesta avvenuto", "La richiesta è stata salvata con successo.");
                                    //                }
                                    //            }
                                    //        };
                                    //    }
                                    //};
                                }
                            }
                            else
                            {
                                if (richiesta.Sopralluogo != null)
                                {
                                    EntitySopralluogo newSopralluogo = new EntitySopralluogo();

                                    newSopralluogo.NumeroMiniGsmRichiesti = 0;
                                    newSopralluogo.NumeroMiniUmtsRichiesti = 0;
                                    newSopralluogo.NumeroMiniLteRichiesti = 0;
                                    newSopralluogo.NumeroCompactGsmRichiesti = 0;
                                    newSopralluogo.NumeroCompactUmtsRichiesti = 0;
                                    newSopralluogo.NumeroCompactLteRichiesti = 0;
                                    newSopralluogo.NumeroApparatiFemto = 0;
                                    newSopralluogo.NumeroApparatiFemtoLte = 0;
                                    newSopralluogo.NumeroPicoUmts = 0;
                                    newSopralluogo.NumeroPicoLte = 0;
                                    newSopralluogo.NumeroApparatiDualBand = 0;
                                    newSopralluogo.VincoliAreaPresenti = false;
                                    newSopralluogo.MicrocelleMacrosito = false;
                                    newSopralluogo.TotaleApparatiNuovi = 0;
                                    newSopralluogo.TotaleApparatiRiuso = 0;
                                    newSopralluogo.AutorizzazioneCliente = false;
                                    newSopralluogo.Preventivo = false;
                                    newSopralluogo.TotaleCostiSostenuti = 0;
                                    newSopralluogo.Piattaforma = false;
                                    newSopralluogo.PermessoNecessario = false;
                                    newSopralluogo.RdAEmessa = false;
                                    newSopralluogo.OdAEmessa = false;
                                    newSopralluogo.NclEmessa = false;
                                    newSopralluogo.IdDittaIncaricata = 0;
                                    richiestaToUpdate.Sopralluogo = newSopralluogo;
                                }
                                else
                                    throw new Exception("errore: sopralluogo ha valore null");

                            }

                            
                            richiestaToUpdate = SetRichiesteSopralluogo(richiesta,richiestaToUpdate);

                            DetachedStateRichiestaOld(richiestaOld);

                            if (richiestaOld.IdSopralluogo != null)
                            {
                                _RCDDbContext.Entry(richiestaOld.Sopralluogo).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                                _RCDDbContext.Entry(richiestaToUpdate.Sopralluogo).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                            }


                            Save_RichiestaSopralluogoLocation(richiestaToUpdate, userID, false);
                        }

                        #endregion "OK SOPRALLUOGO SOPRALLUOGO EFFETTUATO"

                        break;

                    case STATUS_ID_WKF.KO_TECNICO_DOPO_SOPRALLUOGO:

                        break;
                    case STATUS_ID_WKF.OK_TECNICO_DOPO_SOPRALLUOGO:

                        #region "OK TECNICO DOPO SOPRALLUOGO"

                        DetachedStateRichiestaOld(richiestaOld);

                        if (richiestaOld.IdSopralluogo != null)
                        {
                            _RCDDbContext.Entry(richiestaOld.Sopralluogo).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                            _RCDDbContext.Entry(richiestaToUpdate.Sopralluogo).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        }

                        if (richiesta.Sopralluogo.DescrizioneSopralluogo != null)
                            richiestaToUpdate.Sopralluogo.DescrizioneSopralluogo = richiesta.Sopralluogo.DescrizioneSopralluogo;

                        if (richiestaToUpdate.Sopralluogo != null)
                        {
                            var sopralluogoUpdate = richiestaToUpdate.Sopralluogo;
                            //_RCDDbContext.Entry(richiesta.Sopralluogo).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                            _RCDDbContext.Update(sopralluogoUpdate);
                            _RCDDbContext.SaveChanges();

                            _RCDDbContext.Entry(richiesta.Sopralluogo).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        }

                        #endregion "OK TECNICO DOPO SOPRALLUOGO"

                        break;

                    //non fa salvataggi ma solo passaggi di stato
                    case STATUS_ID_WKF.ATTESA_OK_INSTALLAZIONE_DOPO_GOVERNANCE:
                    case STATUS_ID_WKF.ATTESA_OK_INSTALLAZIONE:

                        #region " ATTESA OK INSTALLAZIONE DOPO GOV e ATTESA OK INSTALLAZIONE"
                        DetachedStateRichiestaOld(richiestaOld);

                        if (richiestaOld.IdSopralluogo != null)
                        {
                            _RCDDbContext.Entry(richiestaOld.Sopralluogo).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                            _RCDDbContext.Entry(richiestaToUpdate.Sopralluogo).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        }

                        if (richiesta.Sopralluogo.DescrizioneSopralluogo != null)
                            richiestaToUpdate.Sopralluogo.DescrizioneSopralluogo = richiesta.Sopralluogo.DescrizioneSopralluogo;

                        if (richiestaToUpdate.Sopralluogo != null)
                        {
                            var sopralluogoUpdate = richiestaToUpdate.Sopralluogo;
                            //_RCDDbContext.Entry(richiesta.Sopralluogo).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                            _RCDDbContext.Update(sopralluogoUpdate);
                            _RCDDbContext.SaveChanges();

                            _RCDDbContext.Entry(richiesta.Sopralluogo).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        }


                        #endregion " ATTESA OK INSTALLAZIONE DOPO GOV e ATTESA OK INSTALLAZIONE"

                        break;

                    case STATUS_ID_WKF.OK_INSTALLAZIONE:

                        #region "OK INSTALLAZIONE"

                        bool sendMailDittaI = false;
                        bool sendMailFdV = false;

                        if (richiestaToUpdate.Installazione != null)
                        {
                            //DA FARE
                            //if (richiesta.Installazione.EntityState == EntityState.New || richiesta.Installazione.EntityState == EntityState.Modified)
                            //{
                            //    if (cmbDitta.SelectedItem != null && cmbDitta.IsEnabled != false)
                            //    {
                            //        sendMailDittaI = true;
                            //        //sendMailDittaI = mainSendEmail;
                            //    }

                            //    if (richiesta.Installazione.DataOnAirStimata.HasValue && richiesta.Installazione.EntityState == EntityState.New)
                            //    {
                            //        sendMailFdV = true;
                            //    }
                            //    if (!sendMailFdV)
                            //    {
                            //        Installazione originalInstall = richiesta.Installazione.GetOriginal() as Installazione;
                            //        if (richiesta.Installazione.DataOnAirStimata.HasValue && originalInstall != null)
                            //        {
                            //            if (!originalInstall.DataOnAirStimata.HasValue)
                            //            {
                            //                sendMailFdV = true;
                            //            }
                            //            else if (originalInstall.DataOnAirStimata.Value != richiesta.Installazione.DataOnAirStimata)
                            //            {
                            //                sendMailFdV = true;
                            //            }

                            //        }
                            //    }
                            //}

                            if ((richiestaToUpdate.Location != null) && (richiesta.Location != null))
                            {
                                if (richiesta.Location.IdOffice != null)
                                {
                                    EntityOffice office = _RCDDbContext.Office.Where(x => x.IdOffice == richiesta.Location.IdOffice).FirstOrDefault();
                                    richiestaToUpdate.Location.IdOffice = richiesta.Location.IdOffice;
                                    richiestaToUpdate.Location.Office = office.OfficeSigla;
                                }
                            }

                        }
                        else
                        {
                            EntityInstallazione newInstallazione = new EntityInstallazione();

                            newInstallazione.NumeroMiniGsmInstallati = 0;
                            newInstallazione.NumeroMiniUmtsInstallati = 0;
                            newInstallazione.NumeroMiniLteInstallati = 0;
                            newInstallazione.NumeroCompactGsmInstallati = 0;
                            newInstallazione.NumeroCompactUmtsInstallati = 0;
                            newInstallazione.NumeroCompactLteInstallati = 0;
                            newInstallazione.NumeroApparatiDualBand = 0;
                            newInstallazione.NumeroApparatiFemtoLte = 0;
                            newInstallazione.NumeroApparatiFemto = 0;
                            newInstallazione.NumeroPicoLte = 0;
                            newInstallazione.NumeroPicoUmts = 0;
                            newInstallazione.TotaleApparatiNuovi = 0;
                            newInstallazione.TotaleApparatiRiuso = 0;
                            newInstallazione.SimNecessarie = false;
                            newInstallazione.RarfStsAperta = false;
                            newInstallazione.NominaRLInviataAllaDitta = false;
                            newInstallazione.RdAEmessa = false;
                            newInstallazione.RdAEmessa = false;
                            newInstallazione.NcLEmessa = false;
                            newInstallazione.CtaConsegnatoVo = false;
                            newInstallazione.OdAEmessa = false;
                            newInstallazione.CtaConsegnatoVo = false;

                            richiestaToUpdate.Installazione = newInstallazione;

                        }

                        //da vericare
                        if (richiesta.Installazione.IdDittaInstallazione != null)
                            richiestaToUpdate.Installazione.IdDittaInstallazione = richiesta.Installazione.IdDittaInstallazione;
                        if (richiesta.Installazione.SimNecessarie != null)
                            richiestaToUpdate.Installazione.SimNecessarie = richiesta.Installazione.SimNecessarie;
                        if (richiesta.Installazione.CtaConsegnatoVo != null)
                            richiestaToUpdate.Installazione.CtaConsegnatoVo = richiesta.Installazione.CtaConsegnatoVo;
                        if (richiesta.Installazione.NominaRLInviataAllaDitta != null)
                            richiestaToUpdate.Installazione.NominaRLInviataAllaDitta = richiesta.Installazione.NominaRLInviataAllaDitta;
                        if (!String.IsNullOrEmpty(richiesta.Installazione.CognomeRL))
                            richiestaToUpdate.Installazione.CognomeRL = richiesta.Installazione.CognomeRL;
                        if (!String.IsNullOrEmpty(richiesta.Installazione.NomeRL))
                            richiestaToUpdate.Installazione.NomeRL = richiesta.Installazione.NomeRL;
                        if (richiesta.Installazione.DataPermessoPresentato != null)
                            richiestaToUpdate.Installazione.DataPermessoPresentato = richiesta.Installazione.DataPermessoPresentato;
                        if (richiesta.Installazione.DataOnAirStimata != null)
                            richiestaToUpdate.Installazione.DataOnAirStimata = richiesta.Installazione.DataOnAirStimata;
                        if (richiesta.Installazione.DataOnAirConsuntivata != null)
                            richiestaToUpdate.Installazione.DataOnAirConsuntivata = richiesta.Installazione.DataOnAirConsuntivata;


                        //le due opzioni office censito o no , se censito selezionare office
                        //DA SALVARE OFFICE --DA FARE

                        DetachedStateRichiestaOld(richiestaOld);

                        if (richiestaOld.IdInstallazione != null)
                        {
                            _RCDDbContext.Entry(richiestaOld.Installazione).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                            _RCDDbContext.Entry(richiestaToUpdate.Installazione).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        }


                        //VERIFICARE
                        //Save_RichiestaInstallazioneLocation(richiestaToUpdate, userID, false);
                        SaveLocationInstallazioneRichiesta(richiestaToUpdate, userID, IsAutomaticChange);

                        #endregion "OK INSTALLAZIONE"

                        break;
                    case STATUS_ID_WKF.KO_CLIENTE:

                        break;
                    case STATUS_ID_WKF.KO_VENDITE_DOPO_SOPRALLUOGO:

                        break;
                    case STATUS_ID_WKF.INSTALLAZIONE_AVVENUTA:

                        if (richiestaToUpdate.Installazione != null)
                        {
                            if ((richiestaToUpdate.Location != null) && (richiesta.Location != null))
                            {
                                if (richiesta.Location != null)
                                {
                                    if (richiesta.Location.IdOffice != null)
                                    {
                                        EntityOffice office = _RCDDbContext.Office.Where(x => x.IdOffice == richiesta.Location.IdOffice).FirstOrDefault();
                                        richiestaToUpdate.Location.IdOffice = richiesta.Location.IdOffice;
                                        richiestaToUpdate.Location.Office = office.OfficeSigla;

                                        _RCDDbContext.Entry(richiestaToUpdate.Location).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                                        _RCDDbContext.Entry(richiesta.Location).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                                    }
                                }

                                //if (richiesta.Location.LocationApparati != null)
                                //{
                                //    richiestaToUpdate.Location.LocationApparati = richiesta.Location.LocationApparati;
                                //}
                            }

                            if (richiestaToUpdate.Installazione != null)
                            {
                                richiestaToUpdate = SetRichiesteInstallazione(richiesta, richiestaToUpdate);
                            }
                            DetachedStateRichiestaOld(richiestaOld);
                            DetachedStateRichiestaOld(richiestaToUpdate);
                            InstallazioneCompletata(richiestaToUpdate, userID, IsAutomaticChange);

                            // SaveLocationInstallazioneRichiesta(richiestaToUpdate, userID, IsAutomaticChange);


                        }

                        break;
                    case STATUS_ID_WKF.INSTALLAZIONE_RIMOSSA:

                        break;

                    default:

                        break;
                }
            }

            //_RCDDbContext.Entry(richiestaOld).State = Microsoft.EntityFrameworkCore.EntityState.Detached;

            //var result = _RCDDbContext.Update(richiestaToUpdate);
            //_RCDDbContext.SaveChanges();


            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        private EntityRichiesta SetRichiesteSopralluogo(EntityRichiesta richiestaInput,EntityRichiesta updateRichiesta)
        {

            if (richiestaInput.Sopralluogo is not null)
            {
                if (richiestaInput.Sopralluogo.DataSopralluogoStimata != null)
                    updateRichiesta.Sopralluogo.DataSopralluogoStimata = richiestaInput.Sopralluogo.DataSopralluogoStimata;
                if (richiestaInput.Sopralluogo.DataSopralluogoConsuntivata != null)
                    updateRichiesta.Sopralluogo.DataSopralluogoConsuntivata = richiestaInput.Sopralluogo.DataSopralluogoConsuntivata;
                if (richiestaInput.Sopralluogo.DataInstallazioneStimata != null)
                    updateRichiesta.Sopralluogo.DataInstallazioneStimata = richiestaInput.Sopralluogo.DataInstallazioneStimata;

                if (richiestaInput.Sopralluogo.DataInvioStima != null)
                    updateRichiesta.Sopralluogo.DataInvioStima = richiestaInput.Sopralluogo.DataInvioStima;

                if (richiestaInput.Sopralluogo.DataPresentazionePermesso != null)
                    updateRichiesta.Sopralluogo.DataPresentazionePermesso = richiestaInput.Sopralluogo.DataPresentazionePermesso;
                if (richiestaInput.Sopralluogo.StudioProgettazione != null)
                    updateRichiesta.Sopralluogo.StudioProgettazione = richiestaInput.Sopralluogo.StudioProgettazione;
                if (richiestaInput.Sopralluogo.NoteRANVO != null)
                    updateRichiesta.Sopralluogo.NoteRANVO = richiestaInput.Sopralluogo.NoteRANVO;
                if (richiestaInput.Sopralluogo.DeliveryManager != null)
                    updateRichiesta.Sopralluogo.DeliveryManager = richiestaInput.Sopralluogo.DeliveryManager;
                if (richiestaInput.Sopralluogo.IdDittaIncaricata != null)
                    updateRichiesta.Sopralluogo.IdDittaIncaricata = richiestaInput.Sopralluogo.IdDittaIncaricata;

                if (richiestaInput.Sopralluogo.NumeroProtocolloRichiesta != null)
                    updateRichiesta.Sopralluogo.NumeroProtocolloRichiesta = richiestaInput.Sopralluogo.NumeroProtocolloRichiesta;
                if (richiestaInput.Sopralluogo.NumeroSimNecessarie != null)
                    updateRichiesta.Sopralluogo.NumeroSimNecessarie = richiestaInput.Sopralluogo.NumeroSimNecessarie;
                if (richiestaInput.Sopralluogo.StimaOttenimentoPermesso != null)
                    updateRichiesta.Sopralluogo.StimaOttenimentoPermesso = richiestaInput.Sopralluogo.StimaOttenimentoPermesso;
                if (richiestaInput.Sopralluogo.IdTipoCantiere != null)
                    updateRichiesta.Sopralluogo.IdTipoCantiere = richiestaInput.Sopralluogo.IdTipoCantiere;
                if (richiestaInput.Sopralluogo.AutorizzazioneCliente != null)
                    updateRichiesta.Sopralluogo.AutorizzazioneCliente = richiestaInput.Sopralluogo.AutorizzazioneCliente;
                if (richiestaInput.Sopralluogo.Preventivo != null)
                    updateRichiesta.Sopralluogo.Preventivo = richiestaInput.Sopralluogo.Preventivo;
                if (richiestaInput.Sopralluogo.PermessoNecessario != null)
                    updateRichiesta.Sopralluogo.PermessoNecessario = richiestaInput.Sopralluogo.PermessoNecessario;
                if (richiestaInput.Sopralluogo.VincoliAreaPresenti != null)
                    updateRichiesta.Sopralluogo.VincoliAreaPresenti = richiestaInput.Sopralluogo.VincoliAreaPresenti;
                if (richiestaInput.Sopralluogo.NecessitaRelazione != null)
                    updateRichiesta.Sopralluogo.NecessitaRelazione = richiestaInput.Sopralluogo.NecessitaRelazione;
                if (richiestaInput.Sopralluogo.TipologiaVincolo != null)
                    updateRichiesta.Sopralluogo.TipologiaVincolo = richiestaInput.Sopralluogo.TipologiaVincolo;
                if (richiestaInput.Sopralluogo.DescrizioneSopralluogo != null)
                    updateRichiesta.Sopralluogo.DescrizioneSopralluogo = richiestaInput.Sopralluogo.DescrizioneSopralluogo;


            }
            return updateRichiesta;
        }

        private EntityRichiesta SetRichiesteInstallazione(EntityRichiesta richiestaInput, EntityRichiesta updateRichiesta)
        {
            if (richiestaInput.Installazione is not null)
            {
                if (richiestaInput.Installazione.IdDittaInstallazione != null)
                    updateRichiesta.Installazione.IdDittaInstallazione = richiestaInput.Installazione.IdDittaInstallazione;
                if (richiestaInput.Installazione.SimNecessarie != null)
                    updateRichiesta.Installazione.SimNecessarie = richiestaInput.Installazione.SimNecessarie;
                if (richiestaInput.Installazione.CtaConsegnatoVo != null)
                    updateRichiesta.Installazione.CtaConsegnatoVo = richiestaInput.Installazione.CtaConsegnatoVo;
                //if (richiestaInput.Installazione.NominaRLInviataAllaDitta != null)
                //    updateRichiesta.Installazione.NominaRLInviataAllaDitta = richiestaInput.Installazione.NominaRLInviataAllaDitta;
                //if (!String.IsNullOrEmpty(richiestaInput.Installazione.CognomeRL))
                //    updateRichiesta.Installazione.CognomeRL = richiestaInput.Installazione.CognomeRL;
                //if (!String.IsNullOrEmpty(richiestaInput.Installazione.NomeRL))
                //    updateRichiesta.Installazione.NomeRL = richiestaInput.Installazione.NomeRL;
                if (richiestaInput.Installazione.DataPermessoPresentato != null)
                    updateRichiesta.Installazione.DataPermessoPresentato = richiestaInput.Installazione.DataPermessoPresentato;
                if (richiestaInput.Installazione.DataOnAirStimata != null)
                    updateRichiesta.Installazione.DataOnAirStimata = richiestaInput.Installazione.DataOnAirStimata;
                if (richiestaInput.Installazione.DataOnAirConsuntivata != null)
                    updateRichiesta.Installazione.DataOnAirConsuntivata = richiestaInput.Installazione.DataOnAirConsuntivata;
                if (richiestaInput.Installazione.IdStatoConsegnaLetteraEmf != null)
                    updateRichiesta.Installazione.IdStatoConsegnaLetteraEmf = richiestaInput.Installazione.IdStatoConsegnaLetteraEmf;
                if (richiestaInput.Installazione.IdStatoConsegnaLetteraComodatoUso != null)
                    updateRichiesta.Installazione.IdStatoConsegnaLetteraComodatoUso = richiestaInput.Installazione.IdStatoConsegnaLetteraComodatoUso;
                if (richiestaInput.Installazione.DescrizioneInstallazione != null)
                    updateRichiesta.Installazione.DescrizioneInstallazione = richiestaInput.Installazione.DescrizioneInstallazione;
                if (richiestaInput.Installazione.NoteInstallazione != null)
                    updateRichiesta.Installazione.NoteInstallazione = richiestaInput.Installazione.NoteInstallazione;

                if (richiestaInput.Installazione.NominaRLInviataAllaDitta != null)
                {
                    updateRichiesta.Installazione.NominaRLInviataAllaDitta = richiestaInput.Installazione.NominaRLInviataAllaDitta;

                    if (updateRichiesta.Installazione.NominaRLInviataAllaDitta == true)
                    {
                        if (richiestaInput.Installazione.CognomeRL is not null)
                            updateRichiesta.Installazione.CognomeRL = richiestaInput.Installazione.CognomeRL;
                        else
                        {
                            if (updateRichiesta.Installazione.CognomeRL is null)
                                throw new Exception("Immettere il cognome del responsabile lavori.");
                        }

                        if (richiestaInput.Installazione.NomeRL is not null)
                            updateRichiesta.Installazione.NomeRL = richiestaInput.Installazione.NomeRL;
                        else
                        {
                            if (updateRichiesta.Installazione.NomeRL is null)
                                throw new Exception("Immettere il nome del responsabile lavori.");
                        }
                    }
                }

            }
            return updateRichiesta;
        }

        private void DetachedStateRichiestaOld(EntityRichiesta richiestaOld)
        {
            if (richiestaOld != null)
            {
                if (richiestaOld.Location != null)
                {
                    if (richiestaOld.Location.StsComune != null)
                    {
                        _RCDDbContext.Entry(richiestaOld.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        _RCDDbContext.Entry(richiestaOld.Location.StsComune.ProvinciaSts.Provincia.RegioneVF).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        _RCDDbContext.Entry(richiestaOld.Location.StsComune.ProvinciaSts.Provincia).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        _RCDDbContext.Entry(richiestaOld.Location.StsComune.ProvinciaSts).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        _RCDDbContext.Entry(richiestaOld.Location.StsComune).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        _RCDDbContext.Entry(richiestaOld.Location).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    
                    }
                  //  _RCDDbContext.Entry(richiestaOld.Location).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                }

                _RCDDbContext.Entry(richiestaOld).State = Microsoft.EntityFrameworkCore.EntityState.Detached;

                if (richiestaOld.Sopralluogo != null)
                {
                    _RCDDbContext.Entry(richiestaOld.Sopralluogo).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                }
                if (richiestaOld.Installazione != null)
                {
                    _RCDDbContext.Entry(richiestaOld.Installazione).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                }
            }
        }


        /// <summary>
        /// Esegue il salvataggio del sopralluogo
        /// </summary>
        /// <param name="richiesta">Richiesta da gestire</param>
        /// <param name="userID">Id dell'utente che compie l'operazione</param>
        /// <param name="IsAutomaticChange">Se è un'operazione di cambio stato automatica</param>
        /// <param name="ctx">Il contesto</param>
        public void Save_RichiestaSopralluogoLocation(EntityRichiesta richiesta, long userID, bool IsAutomaticChange)
        {
            //Genera il codice installazione fittizio dell'anagrafica di Co.De.(GetSopralluogoForProgressivo) --se c'è già recupero il vecchio
            //aggiorno tab t_richiesta con idLocation, inserisco idSopralluogo
            //aggiorna la tabella T_LOCATION con i dati aggiornati(NomeInstallazione, Indirizzo, idComune
            try
            {
                if (richiesta.Sopralluogo.CodiceInstallazione == null || richiesta.Sopralluogo.CodiceInstallazione.Trim().Equals(""))
                {
                    GenerateCodiceInstallazione(richiesta, userID, IsAutomaticChange);
                }
                else
                {
                    ConvertiCoordinate_And_SaveSopralluogoLocationRichiesta(richiesta, userID, IsAutomaticChange);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Esegue il salvataggio del sopralluogo
        /// </summary>
        /// <param name="richiesta">Richiesta da gestire</param>
        /// <param name="userID">Id dell'utente che compie l'operazione</param>
        /// <param name="IsAutomaticChange">Se è un'operazione di cambio stato automatica</param>
        /// <param name="ctx">Il contesto</param>
        //public void Save_RichiestaInstallazioneLocation(EntityRichiesta richiesta, long userID, bool IsAutomaticChange)
        //{
        //    //Genera il codice installazione fittizio dell'anagrafica di Co.De.(GetSopralluogoForProgressivo) --se c'è già recupero il vecchio
        //    //aggiorno tab t_richiesta con idLocation, inserisco idSopralluogo
        //    //aggiorna la tabella T_LOCATION con i dati aggiornati(NomeInstallazione, Indirizzo, idComune
        //    try
        //    {
        //        if (richiesta.Sopralluogo.CodiceInstallazione == null || richiesta.Sopralluogo.CodiceInstallazione.Trim().Equals(""))
        //        {
        //            GenerateCodiceInstallazione(richiesta, userID, IsAutomaticChange);
        //        }
        //        else
        //        {
        //            ConvertiCoordinate_And_SaveSopralluogoLocationRichiesta(richiesta, userID, IsAutomaticChange);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message);
        //    }
        //}

        ///// <summary>
        /// Esegue la conversione delle coordinate
        /// </summary>
        /// <param name = "richiesta" > Richiesta da gestire</param>
        /// <param name = "userID" > Utente che compie l'operazione</param>
        /// <param name = "IsAutomaticChange" > Se è un cambiamento automatica</param>
        /// <param name = "ctx" > Contesto </ param >
        private void ConvertiCoordinate_And_SaveSopralluogoLocationRichiesta(EntityRichiesta richiesta, long userID, bool IsAutomaticChange)
        {
            try
            {
                EntityLocation locationNew = null;
                ConverterManager.Coordinate latitudine = null;
                ConverterManager.Coordinate longitudine = null;
                if (richiesta.Location.LatitudineGradi.HasValue && richiesta.Location.LatitudinePrimi.HasValue && richiesta.Location.LatitudineSecondi.HasValue)
                {
                    latitudine = new ConverterManager.Coordinate(richiesta.Location.LatitudineGradi.Value, richiesta.Location.LatitudinePrimi.Value, decimal.Parse(richiesta.Location.LatitudineSecondi.Value.ToString()), ConverterManager.CardinalDirection.North);
                }
                if (richiesta.Location.LongitudineGradi.HasValue && richiesta.Location.LongitudinePrimi.HasValue && richiesta.Location.LongitudineSecondi.HasValue)
                {
                    longitudine = new ConverterManager.Coordinate(richiesta.Location.LongitudineGradi.Value, richiesta.Location.LongitudinePrimi.Value, decimal.Parse(richiesta.Location.LongitudineSecondi.Value.ToString()), ConverterManager.CardinalDirection.East);
                }
                if (latitudine != null && longitudine != null)
                {
                    ConverterManager.UTM utm = new ConverterManager.UTM(latitudine, longitudine);
                    richiesta.Location.LatitudineUTM = utm.Northing;
                    richiesta.Location.LongitudineUTM = utm.Easting;
                    locationNew = richiesta.Location;
                }

                //SALVATAGGIO IN T_SOPRALLUOGO
                var sopralluogoNew = new EntitySopralluogo();

                if (richiesta.IdSopralluogo is null)
                {
                    sopralluogoNew = richiesta.Sopralluogo;
                    _RCDDbContext.Add(sopralluogoNew);
                    _RCDDbContext.SaveChanges();

                    _RCDDbContext.Entry(sopralluogoNew).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    richiesta.IdSopralluogo = sopralluogoNew.Id;
                }
                else
                {
                    if (richiesta.IdSopralluogo != null)
                    {
                        var sopralluogoUpdate = richiesta.Sopralluogo;
                        _RCDDbContext.Entry(richiesta.Sopralluogo).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        _RCDDbContext.Update(sopralluogoUpdate);
                        _RCDDbContext.SaveChanges();

                        _RCDDbContext.Entry(richiesta.Sopralluogo).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    }
                }

                //SALVATAGGIO LOCATION
                //if (richiesta.IdLocation != null)
                if (richiesta.Location.Id != null)
                {
                    var locationUpdate = richiesta.Location;

                    //if (richiesta.Location != null)
                    //{
                    //    _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    //    _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts.Provincia.RegioneVF).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    //    _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts.Provincia).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    //    _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    //    _RCDDbContext.Entry(richiesta.Location.StsComune).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    //    _RCDDbContext.Entry(richiesta.Location).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    //}

                    //_RCDDbContext.Entry(locationUpdate.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    //_RCDDbContext.Entry(locationUpdate.StsComune.ProvinciaSts.Provincia.RegioneVF).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    //_RCDDbContext.Entry(locationUpdate.StsComune.ProvinciaSts.Provincia).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    //_RCDDbContext.Entry(locationUpdate.StsComune.ProvinciaSts).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    //_RCDDbContext.Entry(locationUpdate.StsComune).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    //_RCDDbContext.Entry(locationUpdate).State = Microsoft.EntityFrameworkCore.EntityState.Detached;


                    _RCDDbContext.Update(locationUpdate);
                    _RCDDbContext.SaveChanges();

                   
                }

                _RCDDbContext.Entry(richiesta.Location).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                _RCDDbContext.Entry(richiesta.Location.StsComune).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts.Provincia).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts.Provincia.RegioneVF).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona).State = Microsoft.EntityFrameworkCore.EntityState.Detached;

                EntityRichiesta updateRichiesta = new EntityRichiesta();
                UtilityManager.MapProp(richiesta, updateRichiesta);
                _RCDDbContext.Update(updateRichiesta);
                _RCDDbContext.SaveChanges();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        private void SaveLocationInstallazioneRichiesta(EntityRichiesta richiesta, long userID, bool IsAutomaticChange)
        {
            try
            {

                //SALVATAGGIO IN T_INSTALLAZIONI
                var installazioneNew = new EntityInstallazione();
                if (richiesta.IdInstallazione is null)
                {
                    installazioneNew = richiesta.Installazione;
                    _RCDDbContext.Add(installazioneNew);
                    _RCDDbContext.SaveChanges();

                    _RCDDbContext.Entry(installazioneNew).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    richiesta.IdInstallazione = installazioneNew.Id;

                }
                else
                {
                    if (richiesta.IdInstallazione != null)
                    {
                        var installazioneUpdate = richiesta.Installazione;
                        _RCDDbContext.Entry(richiesta.Installazione).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        _RCDDbContext.Update(installazioneUpdate);
                        _RCDDbContext.SaveChanges();

                        _RCDDbContext.Entry(richiesta.Installazione).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    }
                }



                //SALVATAGGIO LOCATION
                if (richiesta.IdLocation != null)
                {
                    var locationUpdate = richiesta.Location;

                    if (richiesta.Location != null)
                    {
                        _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts.Provincia.RegioneVF).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts.Provincia).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        _RCDDbContext.Entry(richiesta.Location.StsComune).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                        _RCDDbContext.Entry(richiesta.Location).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    }

                    _RCDDbContext.Update(locationUpdate);
                    _RCDDbContext.SaveChanges();

                    _RCDDbContext.Entry(locationUpdate.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    _RCDDbContext.Entry(locationUpdate.StsComune.ProvinciaSts.Provincia.RegioneVF).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    _RCDDbContext.Entry(locationUpdate.StsComune.ProvinciaSts.Provincia).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    _RCDDbContext.Entry(locationUpdate.StsComune.ProvinciaSts).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    _RCDDbContext.Entry(locationUpdate.StsComune).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                    _RCDDbContext.Entry(locationUpdate).State = Microsoft.EntityFrameworkCore.EntityState.Detached;

                }

                EntityRichiesta updateRichiesta = new EntityRichiesta();
                UtilityManager.MapProp(richiesta, updateRichiesta);
                _RCDDbContext.Update(updateRichiesta);
                _RCDDbContext.SaveChanges();

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Genera il codice installazione fittizio dell'anagrafica di Co.De.
        /// </summary>
        /// <param name="richiesta">Richiesta da elaborare</param>
        /// <param name="userID">Id dell'utente che stà eseguendo l'operazione</param>
        /// <param name="IsAutomaticChange">Se il passaggio è automatica</param>
        /// <param name="ctx">Il contesto</param>
        private void GenerateCodiceInstallazione(EntityRichiesta richiesta, long userID, bool IsAutomaticChange)
        {
            string siglaCodiceInstallazione = richiesta.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.SiglaCodiceInstallazione;

            //ctx.GetSopralluogoForProgressivoQuery(siglaCodiceInstallazione);
            var sopralluogo = _RCDDbContext.Sopralluogo.Where(x => x.SiglaCodiceInstallazione == siglaCodiceInstallazione)
                .OrderByDescending(x => x.ProgressivoCodiceInstallazione).AsNoTracking().FirstOrDefault();

            Int32? maxProgressiveCodiceInstallazione = sopralluogo.ProgressivoCodiceInstallazione;
            if (!maxProgressiveCodiceInstallazione.HasValue)
            {
                maxProgressiveCodiceInstallazione = 0;
            }
            int newProgressiveCodiceInstallazione = maxProgressiveCodiceInstallazione.Value + 1;
            string newCodiceInstallazione = siglaCodiceInstallazione + newProgressiveCodiceInstallazione.ToString().PadLeft(5, '0');
            richiesta.Sopralluogo.SiglaCodiceInstallazione = siglaCodiceInstallazione;
            richiesta.Sopralluogo.ProgressivoCodiceInstallazione = newProgressiveCodiceInstallazione;
            richiesta.Sopralluogo.CodiceInstallazione = newCodiceInstallazione;

            ConvertiCoordinate_And_SaveSopralluogoLocationRichiesta(richiesta, userID, IsAutomaticChange);
        }

        /// <summary>
        /// Completa l'installazione della richiesta 
        /// </summary>
        /// <param name="richiesta">Richiesta da gestire</param>
        /// <param name="userID">Id dell'utente che compie l'operazione</param>
        /// <param name="IsAutomaticChange">Se è un'operazione di cambio stato automatica</param>
        /// <param name="ctx">Il contesto</param>
        public void InstallazioneCompletata(EntityRichiesta richiesta, long userID, bool IsAutomaticChange)
        {
            try
            {
                if (richiesta.Location.DataOnAir == null)
                {
                    if (richiesta.Installazione.DataOnAirConsuntivata != null)
                        richiesta.Location.DataOnAir = richiesta.Installazione.DataOnAirConsuntivata.Value;
                }

                if (!richiesta.Location.IdOffice.HasValue)
                {
                    GenerateOffice(richiesta, userID, IsAutomaticChange);
                }
                else
                {
                    GetMaterialiMagazzino(richiesta, userID, IsAutomaticChange);
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #endregion "SALVATAGGI"

      
        /// <summary>
        /// Genera il codice office fittizio dell'anagrafica di Co.De.
        /// </summary>
        /// <param name="richiesta">Richiesta da elaborare</param>
        /// <param name="userID">Id dell'utente che stà eseguendo l'operazione</param>
        /// <param name="condition">Condizione per l'eventuale passaggio di stato</param>
        /// <param name="IsAutomaticChange">Se il passaggio è automatica</param>
        /// <param name="ctx">Il contesto</param>
        private void GenerateOffice(EntityRichiesta richiesta, long userID, bool IsAutomaticChange)
        {
            long idZona = richiesta.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id;

            _RCDDbContext.Database.SetCommandTimeout(400);
            var location = _RCDDbContext.Location.Where(x => x.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id == idZona)
                .OrderByDescending(x => x.ProgressivoOffice).AsNoTracking().FirstOrDefault();

            //_RCDDbContext.Entry(location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona).State = Microsoft.EntityFrameworkCore.EntityState.Detached;

            long? maxProgressiveOffice = location.ProgressivoOffice;
            if (!maxProgressiveOffice.HasValue)
            {
                maxProgressiveOffice = 0;
            }
            long newProgressivoOffice = maxProgressiveOffice.Value + 1;

            long idProvincia = (long)richiesta.Location.StsComune.ProvinciaSts.IdProvincia;
            var provincia = _RCDDbContext.Provincia
                 .Include("RegioneVF").Include("RegioneVF.Zona")
                .Where(x => x.Id == idProvincia)
                .AsNoTracking()
                .FirstOrDefault();

            if (provincia != null)
            {
                if (provincia.RegioneVF != null)
                {
                    if (provincia.RegioneVF.Zona != null)
                        _RCDDbContext.Entry(provincia.RegioneVF.Zona).State = Microsoft.EntityFrameworkCore.EntityState.Detached;

                    _RCDDbContext.Entry(provincia.RegioneVF).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                }
                _RCDDbContext.Entry(provincia).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
            }
           

            string newOffice = provincia.RegioneVF.Zona.ProgressivoZona.ToString() + "CD" + newProgressivoOffice.ToString().PadLeft(5, '0');
            richiesta.Location.ProgressivoOffice = newProgressivoOffice;
            richiesta.Location.Office = newOffice;


            _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
            _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts.Provincia.RegioneVF).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
            _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts.Provincia).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
            _RCDDbContext.Entry(richiesta.Location.StsComune.ProvinciaSts).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
            _RCDDbContext.Entry(richiesta.Location.StsComune).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
            _RCDDbContext.Entry(richiesta.Location).State = Microsoft.EntityFrameworkCore.EntityState.Detached;

            //TODO: chiamata a WCF di N+
            GetMaterialiMagazzino(richiesta, userID, IsAutomaticChange);

            ConvertiCoordinate_And_SaveSopralluogoLocationRichiesta(richiesta, userID, IsAutomaticChange);

        }

        /// <summary>
        /// Genera i codici apparato fittizi dell'anagrafica di Co.De.
        /// </summary>
        /// <param name="richiesta">Richiesta da elaborare</param>
        /// <param name="userID">Id dell'utente che stà eseguendo l'operazione</param>
        /// <param name="IsAutomaticChange">Se il passaggio è automatica</param>
        private void GenerateCodiciApparati(EntityRichiesta richiesta, long userID, bool IsAutomaticChange)
        {
            long IdZona = richiesta.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id;
            string siglaProvincia = richiesta.Location.StsComune.ProvinciaSts.Sigla;


            string siglaCodice = "";
            string codiceApparato = "";
            int? maxProgressivo = 0;
            Dictionary<string?, int?> listaProgressivi = new Dictionary<string?, int?>();

            List<EntityView_TipologiaApparatoProgressivo> progressivo = _RCDDbContext.VistaTipologiaApparatoProgressivo.Where(tipologia => tipologia.IdZona == IdZona) // || tipologia.IdZona == 0)
                    .Select(tipologia => tipologia).ToList();

            listaProgressivi = progressivo.ToDictionary(mc => mc.SiglaCodice,
                                 mc => mc.Progressivo,
                                 StringComparer.OrdinalIgnoreCase);

            List<EntityInstallazioneApparati> listaInstallazioneApparati = _RCDDbContext.InstallazioneApparati
                .Include("Apparati").Include("Apparati.TipologiaApparato")
                .Where(x => x.IdInstallazione == richiesta.Installazione.Id).ToList();

          

            foreach (EntityInstallazioneApparati ia in listaInstallazioneApparati)
            {
                siglaCodice = ia.Apparati.TipologiaApparato.Sigla.ToUpper();

                //if (siglaCodice != "COMPACT")
                //{
                if (listaProgressivi.ContainsKey(siglaCodice))
                {
                    maxProgressivo = listaProgressivi[siglaCodice];
                    maxProgressivo++;
                    listaProgressivi[siglaCodice] = maxProgressivo;
                }
                else
                {
                    maxProgressivo = 1;
                    listaProgressivi.Add(siglaCodice, 1);
                }

                ia.ProgressivoCodiceApparato = maxProgressivo;
                ia.SiglaCodice = siglaCodice;
                ia.SiglaProvincia = siglaProvincia;
                ia.IdZona = IdZona;
                codiceApparato = IdZona.ToString() + "-" + siglaProvincia + "-" + siglaCodice + "-" + maxProgressivo.ToString().PadLeft(5, '0');
                ia.Codice = codiceApparato;
                //}

                _RCDDbContext.Entry(ia.Apparati.TipologiaApparato).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
            }

            // DA VERIFICARE
           
            _RCDDbContext.InstallazioneApparati.Where(x => x.IdInstallazione == richiesta.Installazione.Id && x.DataAttivazioneApparato == null).ToList().ForEach(ap => ap.DataAttivazioneApparato = richiesta.Installazione.DataOnAirConsuntivata);
            SalvaInstallazioneInLocation(richiesta, userID, IsAutomaticChange);
        }

       

        #region "Chiusura installazione"
        /// <summary>
        /// Esegue il salvataggio delle installazioni nello storico della location
        /// </summary>
        /// <param name="richiesta">Richiesta da elaborare</param>
        /// <param name="userID">Id dell'utente che stà eseguendo l'operazione</param>
        /// <param name="condition">Condizione per l'eventuale passaggio di stato</param>
        /// <param name="IsAutomaticChange">Se il passaggio è automatica</param>
        /// <param name="ctx">Il contesto</param>
        private void SalvaInstallazioneInLocation(EntityRichiesta richiesta, long userID, bool IsAutomaticChange)
        {
            try
            {
                List<EntityInstallazioneApparati> listInstallazioneApparati = _RCDDbContext.InstallazioneApparati
                .Where(i => i.IdInstallazione == richiesta.IdInstallazione).ToList();
                
                List<EntityLocationApparato?> listLocatApparati = new List<EntityLocationApparato?>();

                foreach (EntityInstallazioneApparati ia in listInstallazioneApparati)
                {
                    EntityLocationApparato la = new EntityLocationApparato();
                    la.AltezzaApparato = ia.AltezzaApparato;
                    la.IdApparato = ia.IdApparato;  //apparati
                    la.BcchSc = ia.BcchSc;
                    la.CellaRipetuta = ia.CellaRipetuta;
                    la.CellaRipetutaLte = ia.CellaRipetutaLte;

                    //if (ia.Codice == null) Aggiungi codice
                    la.Codice = ia.Codice;
                    //if (ia.DataOnAirConsuntivata == null) Aggiungi data da installazione
                    la.DataOnAir = richiesta.Installazione.DataOnAirConsuntivata.Value;
                    la.OldCode = ia.Codice;
                    la.Frequenze = ia.Frequenze;
                    la.IdClasse = ia.IdClasse;
                    la.IdZona = ia.IdZona;
                    la.MatricolaApparato = ia.MatricolaApparato;
                    la.NomeApparato = ia.NomeApparato;
                    la.Note = ia.Note;
                    la.NumeroSim = ia.NumeroSim;
                    la.PosizioneApparato = ia.PosizioneApparato;
                    la.PrezzoTotale = ia.PrezzoTotale;
                    la.ProgressivoCodiceApparato = ia.ProgressivoCodiceApparato;
                    la.Raggiungibilita = ia.Raggiungibilita;
                    la.Refarming = ia.Refarming;
                    la.SerialeApparato = ia.SerialeApparato;
                    la.SerialeSim = ia.SerialeSim;
                    la.SiglaCodice = ia.SiglaCodice;
                    la.SiglaProvincia = ia.SiglaProvincia;
                    la.IdStatoApparato = ia.IdStatoApparato; //StatoApparato
                    la.IdPosizioneApparato = ia.IdPosizioneApparato;    //ApparatoPosizione             //Modificato per nuova gestione 19/06/12
                    la.IdRaggiungibilita = ia.IdRaggiungibilita;  //RaggiungibilitaApparato 
                    la.IdPosizioneInstallazioneApparato = ia.IdPosizioneInstallazioneApparato;  //InstallazionePosizioneApparato
                    la.DataAttivazioneApparato = ia.DataAttivazioneApparato;
                    la.ProprietaCliente = ia.ProprietaCliente;

                    //DA RECUPERARE DATIDI 
                    //INSERIMENTO CAMPI NON NULL
                    if (la.InRecupero != null)
                        la.InRecupero = ia.InRecupero;
                    else
                        la.InRecupero = false;

                    if (la.CheckFrequenze != null)
                        la.CheckFrequenze = ia.CheckFrequenze;
                    else
                        la.CheckFrequenze = false;

                    if (la.Quantita != null)
                        la.Quantita = ia.Quantita;
                    else
                        la.Quantita = 0;

                    if (la.Riuso != null)
                        la.Riuso = ia.Riuso;
                    else
                        la.Riuso = false;

                    if (la.Recuperato != null)
                        la.Recuperato = ia.Recuperato;
                    else
                        la.Recuperato = false;

                    if (la.ProprietaCliente != null)
                        la.ProprietaCliente = ia.ProprietaCliente;
                    else
                        la.ProprietaCliente = false;

                    listLocatApparati.Add(la);
                   
                 //   richiesta.Location.LocationApparati.Add(la);
                }

                richiesta.Location.LocationApparati = new List<EntityLocationApparato>();
                richiesta.Location.LocationApparati = listLocatApparati;
               // UtilityManager.MapProp(listLocatApparati, richiesta.Location.LocationApparati);

                richiesta.Location.LocationApparati.Where(ap => ap.DataAttivazioneApparato == null && ap.Recuperato == false).ToList().ForEach(ap => ap.DataAttivazioneApparato = richiesta.Location.DataOnAir);
                richiesta.Location.LocationApparati.Where(ap => ap.DataOnAir == null && ap.Recuperato == false).ToList().ForEach(ap => ap.DataOnAir = richiesta.Location.DataOnAir);

                List<EntityLocationFemTo> listLocatFemTo = new List<EntityLocationFemTo>();

                List<EntityInstallazioneFemto> listInstallazioneFemto = _RCDDbContext.InstallazioneFemto
                        .Where(i => i.IdInstallazione == richiesta.IdInstallazione).ToList();

                foreach (EntityInstallazioneFemto inf in listInstallazioneFemto)
                {
                    EntityLocationFemTo lf = new EntityLocationFemTo();
                    lf.AmbitoCopertura = inf.AmbitoCopertura;
                    lf.GestoreLan = inf.GestoreLan;
                    lf.IsOpen = inf.IsOpen;
                    lf.NumeroFemtoGroupAppartenenza = inf.NumeroFemtoGroupAppartenenza;
                    lf.NumeroSimGestite = inf.NumeroSimGestite;
                    lf.SerialVfBooster = inf.SerialVfBooster;
                    lf.TipoLan = inf.TipoLan;

                    listLocatFemTo.Add(lf);
                }
                richiesta.Location.LocationFemTo = new List<EntityLocationFemTo>();
                richiesta.Location.LocationFemTo = listLocatFemTo;

                List<EntityLocationAntenna> listLocatAntenna = new List<EntityLocationAntenna>();

                List<EntityInstallazioneAntenne> listInstallazioneAntenne = _RCDDbContext.InstallazioneAntenne
                        .Where(i => i.IdInstallazione == richiesta.IdInstallazione).ToList();

                foreach (EntityInstallazioneAntenne ia in listInstallazioneAntenne)
                {
                    EntityLocationAntenna la = new EntityLocationAntenna();
                    la.Accessibilita = ia.Accessibilita;
                    la.AltezzaBaseAntenna = ia.AltezzaBaseAntenna;
                    la.AltezzaCentroElettrico = ia.AltezzaCentroElettrico;

                    la.IdAntenna = ia.IdAntenna;  

                    if (ia.Azimuth != null)
                        la.Azimuth = ia.Azimuth;
                    else
                        la.Azimuth = 0;

                    la.Codice = ia.Codice;
                    la.Localizzazione = ia.Localizzazione;
                    la.Note = ia.Note;
                    la.ObiettiviCopertura = ia.ObiettiviCopertura;

                    if (ia.Piattaforma != null)
                        la.Piattaforma = ia.Piattaforma;
                    else
                        la.Piattaforma = false;

                    la.PotenzaAlConnettore = ia.PotenzaAlConnettore;
                    la.PrezzoTotale = ia.PrezzoTotale;

                    if (ia.Quantita != null)
                        la.Quantita = ia.Quantita;
                    else
                        la.Quantita = 0;

                    if (ia.Riuso != null)
                        la.Riuso = ia.Riuso;
                    else
                        la.Riuso = false;

                    if (ia.InRecupero != null)
                        la.InRecupero = ia.InRecupero;
                    else
                        la.InRecupero = false;

                    if (ia.Recuperato != null)
                        la.Recuperato = ia.Recuperato;
                    else
                        la.Recuperato = false;

                    la.IdTipologiaSegnaleAntenna = ia.IdTipologiaSegnaleAntenna;   
                    la.IdAccessibilitaAntenna = ia.IdAccessibilitaAntenna;    //Modificato per nuova gestione 19/06/12
                    la.IdLocalizzazioneAntenna = ia.IdLocalizzazioneAntenna; 
                                                                              //DA FARE la.insa = ia.InstallazionePosizioneAntenna;  //InstallazionePosizioneAntenna
                    listLocatAntenna.Add(la);
                }

                richiesta.Location.LocationAntenne = new List<EntityLocationAntenna>();
                richiesta.Location.LocationAntenne = listLocatAntenna;

                List<EntityLocationAccessori> listLocatAccessori = new List<EntityLocationAccessori>();

                List<EntityInstallazioneAccessori> listInstallazioneAccessori = _RCDDbContext.InstallazioneAccessori
                    .Where(i => i.IdInstallazione == richiesta.IdInstallazione).ToList();

                foreach (EntityInstallazioneAccessori ia in listInstallazioneAccessori)
                {
                    EntityLocationAccessori la = new EntityLocationAccessori();
                    la.IdAccessorio = ia.IdAccessorio;   //Accessorio
                    la.Codice = ia.Codice;
                    la.Metri = ia.Metri;
                    la.Note = ia.Note;
                    la.Posizione = ia.Posizione;

                    la.PrezzoTotale = ia.PrezzoTotale;

                    if (ia.Quantita != null)
                        la.Quantita = ia.Quantita;
                    else
                        la.Quantita = 0;

                    la.Riuso = ia.Riuso;

                    if (ia.InRecupero != null)
                        la.InRecupero = ia.InRecupero;
                    else
                        la.InRecupero = false;

                    if (ia.Recuperato != null)
                        la.Recuperato = ia.Recuperato;
                    else
                        la.Recuperato = false;

                    listLocatAccessori.Add(la);
                }

                richiesta.Location.LocationAccessori = new List<EntityLocationAccessori>();
                richiesta.Location.LocationAccessori = listLocatAccessori;


                List<EntityLocationMisure> listLocatMisure = new List<EntityLocationMisure>();

                List<EntityInstallazioneMisure> listInstallazioneMisure = _RCDDbContext.InstallazioneMisure
                    .Where(i => i.IdInstallazione == richiesta.IdInstallazione).ToList();

                foreach (EntityInstallazioneMisure im in listInstallazioneMisure)
                {
                    EntityLocationMisure lm = new EntityLocationMisure();
                    lm.Descrizione = im.Descrizione;
                    lm.LivelloAccesso = im.LivelloAccesso;
                    lm.LivelloSpento = im.LivelloSpento;
                    lm.IdTipologiaMisura = im.IdTipologiaMisura;   //TipologiaMisura
                    lm.BcchSc = im.BcchSc;
                    lm.CellId = im.CellId;
                    lm.QualitaEcIoRxQ = im.QualitaEcIoRxQ;  
                    lm.Note = im.Note;
                    lm.IdSistema = im.IdSistema;  //Sistema

                    listLocatMisure.Add(lm);
                }

                richiesta.Location.LocationMisure = new List<EntityLocationMisure>();
                richiesta.Location.LocationMisure = listLocatMisure;

                List<EntityLocationCme> listLocatCme = new List<EntityLocationCme>();

                List<EntityInstallazioneCme> listInstallazioneCme = _RCDDbContext.InstallazioneCme
                .Where(i => i.IdInstallazione == richiesta.IdInstallazione).ToList();

                foreach (EntityInstallazioneCme cme in listInstallazioneCme)
                {
                    EntityLocationCme lcm = new EntityLocationCme();
                    lcm.IdListino = cme.IdListino;  
                    lcm.PrezzoTotale = cme.PrezzoTotale;

                    if (cme.Quantita != null)
                        lcm.Quantità = cme.Quantita;
                    else
                        lcm.Quantità = 0;

                    lcm.TargaTecnica = cme.TargaTecnica;

                    listLocatCme.Add(lcm);
                }

                richiesta.Location.LocationCme = new List<EntityLocationCme>();
                richiesta.Location.LocationCme = listLocatCme;

                List<EntityLocationCrowdcell> listLocatCrowdcell = new List<EntityLocationCrowdcell>();

                List<EntityInstallazioneCrowdcell> listInstallazioneCrowdcell = _RCDDbContext.InstallazioneCrowdcell
               .Where(i => i.IdInstallazione == richiesta.IdInstallazione).ToList();

                foreach (EntityInstallazioneCrowdcell ic in listInstallazioneCrowdcell)
                {
                    EntityLocationCrowdcell lc = new EntityLocationCrowdcell();
                    lc.AccessoDACoverage = ic.AccessoDACoverage;
                    lc.Nome = ic.Nome;
                    lc.Altezza = ic.Altezza;
                    lc.AttenuazioneCoverage = ic.AttenuazioneCoverage;
                    lc.CodiceCellaCoverage = ic.CodiceCellaCoverage;
                    lc.CodiceCellaDonor = ic.CodiceCellaDonor;
                    lc.DataAttivazione = ic.DataAttivazione;
                    lc.IdCriticitaEmf = ic.IdCriticitaEmf;
                 //   lc.tipolo = ic.TipologiaCriticitaEMF;  //TipologiaCriticitaEMF  DA FARE
                    lc.IDFrequenzaCoverage = ic.IdFrequenzaCoverage;
                  //  lc.tipolog = ic.TipologiaFrequenzaLTECoverage;  DA FARE
                    lc.IDFrequenzaDonor = ic.IdFrequenzaDonor;
                   // lc.tipo = ic.TipologiaFrequenzaLTEDonor;  DA FARE
                    lc.IdInstallazioneAntenna = ic.IdInstallazioneAntenna;
                  //  lc.TipologiaPosizioneInstallazioneAntenna = ic.TipologiaPosizioneInstallazioneAntenna;
                    lc.IdLocalizzazioneAntenna = ic.IdLocalizzazioneAntenna;
                //    lc.TipologiaLocalizzazioneAntenna = ic.TipologiaLocalizzazioneAntenna;
                    lc.IdRaggiungibilita = ic.IdRaggiungibilita;
                //    lc.TipologiaRaggiungibilitaApparato = ic.TipologiaRaggiungibilitaApparato;
                    lc.TargaTecnica = ic.TargaTecnica;
                    lc.LatenzaCoverage = ic.LatenzaCoverage;
                    lc.LatenzaDonor = ic.LatenzaDonor;
                    lc.LivelloDonor = ic.LivelloDonor;
                    lc.MsIsdn = ic.MsIsdn;
                    lc.NoteCoverage = ic.NoteCoverage;
                    lc.NoteDonor = ic.NoteDonor;
                    lc.NotePosizione = ic.NotePosizione;
                    lc.PCICoverage = ic.PCICoverage;
                    lc.PCIDonor = ic.PCIDonor;
                    lc.Puk = ic.Puk;
                    lc.SerialeApparato = ic.SerialeApparato;
                    lc.SerialeSim = ic.SerialeSim;
                    lc.SNRCoverage = ic.SNRCoverage;
                    lc.SNRDonor = ic.SNRDonor;
                    lc.SpeedTestDownCoverage = ic.SpeedTestDownCoverage;
                    lc.SpeedTestDownDonor = ic.SpeedTestDownDonor;
                    lc.SpeedTestUpCoverage = ic.SpeedTestUpCoverage;
                    lc.SpeedTestUpDonor = ic.SpeedTestUpDonor;

                    listLocatCrowdcell.Add(lc);
                }
                richiesta.Location.LocationCrowdcell = new List<EntityLocationCrowdcell>();
                richiesta.Location.LocationCrowdcell = listLocatCrowdcell;

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #endregion "Chiusura Installazione"

        #region Gestione materiali magazzino
        private void GetMaterialiMagazzino(EntityRichiesta richiesta, long userID, bool IsAutomaticChange)
        {
            // Recupero stato materiale 'Nuovo' id=1 - Nuovo
            EntityStatoMateriale statoMaterialeNuovo = _RCDDbContext.StatoMateriale.Where(x => x.Id == 1).FirstOrDefault();

            // Recupero stato materiale 'Riuso'
            EntityStatoMateriale statoMaterialeRiuso = _RCDDbContext.StatoMateriale.Where(x => x.Id == 2).FirstOrDefault();

            // Recupero magazzino ditta
            EntityDitta magazzinoDitta = richiesta.Installazione.Ditta;

            long idZona = richiesta.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id;
            // Recupero magazzino virtuale Vodafone di competenza   ---- DA VERIFICARE!!! 
            //var magazzino =  _RCDDbContext.Magazzino.Include("Zona")
            //    //.Include("AccessoriMagazzino").Include("AntenneMagazzino").Include("ApparatiMagazzino")
            //    //            .Include("AccessoriMagazzino.Accessorio").Include("AccessoriMagazzino.StatoMateriale")
            //    //            .Include("AccessoriMagazzino.Accessorio.Fornitore").Include("AccessoriMagazzino.Accessorio.Sistema").Include("AccessoriMagazzino.Accessorio.TipologiaAccessorio")
            //    //            .Include("AntenneMagazzino.Antenna").Include("AntenneMagazzino.StatoMateriale")
            //    //            .Include("AntenneMagazzino.Antenna.Fornitore").Include("AntenneMagazzino.Antenna.Sistema").Include("AntenneMagazzino.Antenna.TipologiaAntenna")
            //    //            .Include("ApparatiMagazzino.Apparato").Include("ApparatiMagazzino.StatoMateriale")
            //    //            .Include("ApparatiMagazzino.Apparato.Fornitore").Include("ApparatiMagazzino.Apparato.Sistema").Include("ApparatiMagazzino.Apparato.TipologiaApparato")
            //           //     .Include("Zona.RegioniVF").Include("Zona.RegioniVF.Province")
            //                .Where(x => x.Zona.Id == idZona).FirstOrDefault();

            ////o bisogna definire classe (da VERIFICARE)
            //bool magazzinoFounded = false;
            //if (magazzino != null)
            //{
            //    magazzinoFounded = true;
            //}
            //else
            //{
            //    magazzinoFounded = false;
            //}
            //DA VERIFICARE
          //  DiscardMaterial(richiesta, statoMaterialeNuovo, statoMaterialeRiuso, magazzinoDitta, magazzino);

            
            GenerateCodiciApparati(richiesta, userID, IsAutomaticChange);


        }

        /// <summary>
        /// Esegue lo scarico dei materiali dal magazzino virtuale o il magazzino ditta in base al dettaglio costi di installazione
        /// </summary>
        /// <param name="richiesta">Richiesta da esaminare</param>
        /// <param name="nuovo">Stato materiale 'Nuovo'</param>
        /// <param name="riuso">Stato materiale 'Riuso'</param>
        /// <param name="magazzinoDitta">Magazzino della ditta</param>
        /// <param name="magazzino">Magazzino virtuale Vodafone di competenza</param>
        /// <returns></returns>
        private string DiscardMaterial(EntityRichiesta richiesta, EntityStatoMateriale nuovo, EntityStatoMateriale riuso, EntityDitta magazzinoDitta, EntityMagazzino magazzino)
        {
            StringBuilder sb = new StringBuilder();

            List<EntityInstallazioneApparati>? installazioneApparatiRiuso = _RCDDbContext.InstallazioneApparati
                .Where(i => i.IdInstallazione == richiesta.IdInstallazione && i.Riuso == true).ToList();


            foreach (EntityInstallazioneApparati ia in installazioneApparatiRiuso)
            {
                int? totaleApparatiDaInstallare = ia.Quantita;
                // Scarico l'apparato da riuso dal magazzino ditta
                List<EntityApparatoMagazzinoDitta> apparatiInStockDitta = _RCDDbContext.ApparatoMagazzinoDitta
                .Where(i => i.IdDitta == magazzinoDitta.Id && i.Apparato.Id == ia.Apparati.Id && i.StatoMateriale.Id == riuso.Id).ToList();

                if (apparatiInStockDitta.Count() > 0)
                {
                    foreach (EntityApparatoMagazzinoDitta amd in apparatiInStockDitta)
                    {
                        if (amd.Quantita <= totaleApparatiDaInstallare)
                        {
                            totaleApparatiDaInstallare -= amd.Quantita;
                            amd.Quantita = 0;
                        }
                        else
                        {
                            amd.Quantita -= totaleApparatiDaInstallare;
                            totaleApparatiDaInstallare = 0;
                        }
                    }
                }
                if (totaleApparatiDaInstallare > 0 && magazzino != null)
                {
                    // Se il numero di apparati necessari è più alto degli apparati in stock alla ditta ed ho individuato il magazzino virtuale di competenza, scarico dal magazzino virtuale VF
                    List<EntityApparatoMagazzino> apparatiInStockVodafone = _RCDDbContext.ApparatoMagazzino
                            .Where(i => i.IdMagazzino == magazzino.Id && i.Apparato.Id == ia.Apparati.Id && i.StatoMateriale.Id == riuso.Id).ToList();

                    if (apparatiInStockVodafone.Count() > 0)
                    {
                        foreach (EntityApparatoMagazzino am in apparatiInStockVodafone)
                        {
                            if (am.Quantita <= totaleApparatiDaInstallare)
                            {
                                totaleApparatiDaInstallare -= am.Quantita;
                                am.Quantita = 0;

                                ///DA VERIFICARE!!!!!!!!!!!!!!
                                //var result = _RCDDbContext.Remove(am);
                                //_RCDDbContext.SaveChanges();
                              
                                //magazzino.ApparatiMagazzino.Remove(am);
                                //ctx.ApparatoMagazzinos.Remove(am);
                            }
                            else
                            {
                                am.Quantita -= totaleApparatiDaInstallare;
                                totaleApparatiDaInstallare = 0;
                            }
                        }
                    }
                }
                if (totaleApparatiDaInstallare > 0)
                {
                    // Se servono ancora apparati porto a valore negativo un ordinativo nel magazzino ditta
                    EntityApparatoMagazzinoDitta apparatoSottoDimensione =
                        _RCDDbContext.ApparatoMagazzinoDitta
                            .Where(i => i.IdDitta == magazzinoDitta.Id && i.Apparato.Id == ia.Apparati.Id && i.StatoMateriale.Id == riuso.Id).FirstOrDefault();

                    if (apparatoSottoDimensione != null)
                    {
                        apparatoSottoDimensione.Quantita -= totaleApparatiDaInstallare;
                    }
                    else
                    {
                        sb.Append("Apparato: " + ia.Apparati.Modello + " - Stato: Riuso - Quantità non disponibile: " + totaleApparatiDaInstallare.ToString() + "\n");
                    }
                }
                //  Rimuovo tutti gli ordini con quantità = 0 nel magazzino ditta
                List<EntityApparatoMagazzinoDitta> apparatiToRemove = _RCDDbContext.ApparatoMagazzinoDitta
                .Where(i => i.IdDitta == magazzinoDitta.Id && i.Apparato.Id == ia.Apparati.Id && i.Quantita == 0 && i.StatoMateriale.Id == riuso.Id).ToList();

                foreach (EntityApparatoMagazzinoDitta amd in apparatiToRemove)
                {
                    ///DA VERIFICARE!!!!!!!!!!!!!!
                    //var result = _RCDDbContext.Remove(amd);
                    //_RCDDbContext.SaveChanges();

                    //magazzinoDitta.ApparatoMagazzinoDitta.Remove(amd);
                    //ctx.ApparatoMagazzinoDittas.Remove(amd);
                }
            }

            // Antenne da riuso
            List<EntityInstallazioneAntenne> installazioneAntenneRiuso = _RCDDbContext.InstallazioneAntenne
                .Where(ia => ia.IdInstallazione == richiesta.IdInstallazione && ia.Riuso == true).ToList();

            foreach (EntityInstallazioneAntenne ia in installazioneAntenneRiuso)
            {
                int? totaleAntenneDaInstallare = ia.Quantita;
                // Scarico l'antenna da riuso dal magazzino ditta
                List<EntityAntennaMagazzinoDitta> antenneInStockDitta = _RCDDbContext.AntennaMagazzinoDitta
                .Where(i => i.IdDitta == magazzinoDitta.Id && i.Antenna.Id == ia.Antenna.Id && i.StatoMateriale.Id == riuso.Id).ToList();

                if (antenneInStockDitta.Count() > 0)
                {
                    foreach (EntityAntennaMagazzinoDitta amd in antenneInStockDitta)
                    {
                        if (amd.Quantita <= totaleAntenneDaInstallare)
                        {
                            totaleAntenneDaInstallare -= amd.Quantita;
                            amd.Quantita = 0;
                        }
                        else
                        {
                            amd.Quantita -= totaleAntenneDaInstallare;
                            totaleAntenneDaInstallare = 0;
                        }
                    }
                }
                if (totaleAntenneDaInstallare > 0 && magazzino != null)
                {
                    // Se il numero di antenne necessarie è più alto delle antenne in stock alla ditta ed ho individuato il magazzino virtuale di competenza, scarico dal magazzino virtuale VF
                    List<EntityAntennaMagazzino> antenneInStockVodafone = _RCDDbContext.AntennaMagazzino
                            .Where(i => i.IdMagazzino == magazzino.Id && i.Antenna.Id == ia.Antenna.Id && i.StatoMateriale.Id == riuso.Id).ToList();

                    if (antenneInStockVodafone.Count() > 0)
                    {
                        foreach (EntityAntennaMagazzino am in antenneInStockVodafone)
                        {
                            if (am.Quantita <= totaleAntenneDaInstallare)
                            {
                                totaleAntenneDaInstallare -= am.Quantita;
                                am.Quantita = 0;

                                ///DA VERIFICARE!!!!!!!!!!!!!!
                                //var result = _RCDDbContext.Remove(am);
                                //_RCDDbContext.SaveChanges();

                                //magazzino.AntenneMagazzino.Remove(am);
                                //ctx.AntennaMagazzinos.Remove(am);
                            }
                            else
                            {
                                am.Quantita -= totaleAntenneDaInstallare;
                                totaleAntenneDaInstallare = 0;
                            }
                        }
                    }
                }
                if (totaleAntenneDaInstallare > 0)
                {
                    // Se servono ancora antenne porto a valore negativo un ordinativo nel magazzino ditta
                    EntityAntennaMagazzinoDitta antennaSottoDimensione =
                         _RCDDbContext.AntennaMagazzinoDitta
                            .Where(i => i.IdDitta == magazzinoDitta.Id && i.Antenna.Id == ia.Antenna.Id && i.StatoMateriale.Id == riuso.Id).FirstOrDefault();

                    if (antennaSottoDimensione != null)
                    {
                        antennaSottoDimensione.Quantita -= totaleAntenneDaInstallare;
                    }
                    else
                    {
                        sb.Append("Antenna: " + ia.Antenna.Modello + " - Stato: Riuso - Quantità non disponibile: " + totaleAntenneDaInstallare.ToString() + "\n");
                    }
                }
                //  Rimuovo tutti gli ordini con quantità = 0 nel magazzino ditta
                List<EntityAntennaMagazzinoDitta> antenneToRemove = _RCDDbContext.AntennaMagazzinoDitta
                .Where(i => i.IdDitta == magazzinoDitta.Id && i.Antenna.Id == ia.Antenna.Id && i.Quantita == 0 && i.StatoMateriale.Id == riuso.Id).ToList();

                foreach (EntityAntennaMagazzinoDitta amd in antenneToRemove)
                {
                    ///DA VERIFICARE!!!!!!!!!!!!!!
                    //var result = _RCDDbContext.Remove(amd);
                    //_RCDDbContext.SaveChanges();

                    //magazzinoDitta.AntenneMagazzinoDitta.Remove(amd);
                    //ctx.AntennaMagazzinoDittas.Remove(amd);
                }

            }

            // Accessori da riuso
            List<EntityInstallazioneAccessori> installazioneAccessoriRiuso =
                _RCDDbContext.InstallazioneAccessori
                .Where(ia => ia.IdInstallazione == richiesta.IdInstallazione && ia.Riuso == true).ToList();

            foreach (EntityInstallazioneAccessori ia in installazioneAccessoriRiuso)
            {
                int? totaleAccessoriDaInstallare = ia.Quantita;
                // Scarico l'accessorio da riuso dal magazzino ditta
                List<EntityAccessorioMagazzinoDitta> accessoriInStockDitta = _RCDDbContext.AccessorioMagazzinoDitta
                .Where(i => i.IdDitta == magazzinoDitta.Id && i.Accessorio.Id == ia.Accessorio.Id && i.StatoMateriale.Id == riuso.Id).ToList();

                if (accessoriInStockDitta.Count() > 0)
                {
                    foreach (EntityAccessorioMagazzinoDitta amd in accessoriInStockDitta)
                    {
                        if (amd.Quantita <= totaleAccessoriDaInstallare)
                        {
                            totaleAccessoriDaInstallare -= amd.Quantita;
                            amd.Quantita = 0;
                        }
                        else
                        {
                            amd.Quantita -= totaleAccessoriDaInstallare;
                            totaleAccessoriDaInstallare = 0;
                        }
                    }
                }
                if (totaleAccessoriDaInstallare > 0 && magazzino != null)
                {
                    // Se il numero di accessori necessari è più alto degli accessori in stock alla ditta ed ho individuato il magazzino virtuale di competenza, scarico dal magazzino virtuale VF
                    List<EntityAccessorioMagazzino> accessoriInStockVodafone = _RCDDbContext.AccessorioMagazzino
                            .Where(i => i.IdMagazzino == magazzino.Id && i.Accessorio.Id == ia.Accessorio.Id && i.StatoMateriale.Id == riuso.Id).ToList();

                    if (accessoriInStockVodafone.Count() > 0)
                    {
                        foreach (EntityAccessorioMagazzino am in accessoriInStockVodafone)
                        {
                            if (am.Quantita <= totaleAccessoriDaInstallare)
                            {
                                totaleAccessoriDaInstallare -= am.Quantita;
                                am.Quantita = 0;

                                ///DA VERIFICARE!!!!!!!!!!!!!!
                                //var result = _RCDDbContext.Remove(am);
                                //_RCDDbContext.SaveChanges();

                                //magazzino.AccessoriMagazzino.Remove(am);
                                //ctx.AccessorioMagazzinos.Remove(am);
                            }
                            else
                            {
                                am.Quantita -= totaleAccessoriDaInstallare;
                                totaleAccessoriDaInstallare = 0;
                            }
                        }
                    }
                }
                if (totaleAccessoriDaInstallare > 0)
                {
                    // Se servono ancora antenne porto a valore negativo un ordinativo nel magazzino ditta
                    EntityAccessorioMagazzinoDitta accessoriSottoDimensione = _RCDDbContext.AccessorioMagazzinoDitta
                            .Where(i => i.IdDitta == magazzinoDitta.Id && i.Accessorio.Id == ia.Accessorio.Id && i.StatoMateriale.Id == riuso.Id).FirstOrDefault();

                    if (accessoriSottoDimensione != null)
                    {
                        accessoriSottoDimensione.Quantita -= totaleAccessoriDaInstallare;
                    }
                    else
                    {
                        sb.Append("Accessorio: " + ia.Accessorio.Modello + " - Stato: Riuso - Quantità non disponibile: " + totaleAccessoriDaInstallare.ToString() + "\n");
                    }
                }
                //  Rimuovo tutti gli ordini con quantità = 0 nel magazzino ditta
                List<EntityAccessorioMagazzinoDitta> accessoriToRemove = _RCDDbContext.AccessorioMagazzinoDitta
                .Where(i => i.IdDitta == magazzinoDitta.Id && i.Accessorio.Id == ia.Accessorio.Id && i.Quantita == 0 && i.StatoMateriale.Id == riuso.Id).ToList();

                foreach (EntityAccessorioMagazzinoDitta amd in accessoriToRemove)
                {
                    ///DA VERIFICARE!!!!!!!!!!!!!!
                    //var result = _RCDDbContext.Remove(amd);
                    //_RCDDbContext.SaveChanges();

                    //magazzinoDitta.AccessoriMagazzinoDitta.Remove(amd);
                    //ctx.AccessorioMagazzinoDittas.Remove(amd);
                }
            }

            // Apparati nuovi
            List<EntityInstallazioneApparati> installazioneApparatiNuovi =_RCDDbContext.InstallazioneApparati
                .Where(ia => ia.IdInstallazione == richiesta.IdInstallazione && ia.Riuso == false).ToList();

            foreach (EntityInstallazioneApparati ia in installazioneApparatiNuovi)
            {
                int? totaleApparatiDaInstallare = ia.Quantita;
                // Scarico l'apparato nuovo dal magazzino ditta
                List<EntityApparatoMagazzinoDitta> apparatiInStockDitta =_RCDDbContext.ApparatoMagazzinoDitta
                .Where(i => i.IdDitta == magazzinoDitta.Id && i.Apparato.Id == ia.Apparati.Id && i.StatoMateriale.Id == nuovo.Id).ToList();

                if (apparatiInStockDitta.Count() > 0)
                {
                    foreach (EntityApparatoMagazzinoDitta amd in apparatiInStockDitta)
                    {
                        if (amd.Quantita <= totaleApparatiDaInstallare)
                        {
                            totaleApparatiDaInstallare -= amd.Quantita;
                            amd.Quantita = 0;
                        }
                        else
                        {
                            amd.Quantita -= totaleApparatiDaInstallare;
                            totaleApparatiDaInstallare = 0;
                        }
                    }
                }
                if (totaleApparatiDaInstallare > 0 && magazzino != null)
                {
                    // Se il numero di apparati necessari è più alto degli apparati in stock alla ditta ed ho individuato il magazzino virtuale di competenza, scarico dal magazzino virtuale VF
                    List<EntityApparatoMagazzino> apparatiInStockVodafone = _RCDDbContext.ApparatoMagazzino
                            .Where(i => i.IdMagazzino == magazzino.Id && i.Apparato.Id == ia.Apparati.Id && i.StatoMateriale.Id == nuovo.Id).ToList();

                    if (apparatiInStockVodafone.Count() > 0)
                    {
                        foreach (EntityApparatoMagazzino am in apparatiInStockVodafone)
                        {
                            if (am.Quantita <= totaleApparatiDaInstallare)
                            {
                                totaleApparatiDaInstallare -= am.Quantita;
                                am.Quantita = 0;

                                ///DA VERIFICARE!!!!!!!!!!!!!!
                                //var result = _RCDDbContext.Remove(am);
                                //_RCDDbContext.SaveChanges();

                                //magazzino.ApparatiMagazzino.Remove(am);
                                //ctx.ApparatoMagazzinos.Remove(am);
                            }
                            else
                            {
                                am.Quantita -= totaleApparatiDaInstallare;
                                totaleApparatiDaInstallare = 0;
                            }
                        }
                    }
                }
                if (totaleApparatiDaInstallare > 0)
                {
                    // Se servono ancora apparati porto a valore negativo un ordinativo nel magazzino ditta
                    EntityApparatoMagazzinoDitta apparatoSottoDimensione = _RCDDbContext.ApparatoMagazzinoDitta
                            .Where(i => i.IdDitta == magazzinoDitta.Id && i.Apparato.Id == ia.Apparati.Id && i.StatoMateriale.Id == nuovo.Id).FirstOrDefault();

                    if (apparatoSottoDimensione != null)
                    {
                        apparatoSottoDimensione.Quantita -= totaleApparatiDaInstallare;
                    }
                    else
                    {
                        sb.Append("Apparato: " + ia.Apparati.Modello + " - Stato: Nuovo - Quantità non disponibile: " + totaleApparatiDaInstallare + "\n");
                    }
                }
                //  Rimuovo tutti gli ordini con quantità = 0 nel magazzino ditta
                List<EntityApparatoMagazzinoDitta> apparatiToRemove = _RCDDbContext.ApparatoMagazzinoDitta
                .Where(i => i.IdDitta == magazzinoDitta.Id && i.Apparato.Id == ia.Apparati.Id && i.Quantita == 0 && i.StatoMateriale.Id == nuovo.Id).ToList();

                foreach (EntityApparatoMagazzinoDitta amd in apparatiToRemove)
                {
                    ///DA VERIFICARE!!!!!!!!!!!!!!
                    //var result = _RCDDbContext.Remove(amd);
                    //_RCDDbContext.SaveChanges();

                    //magazzinoDitta.ApparatoMagazzinoDitta.Remove(amd);
                    //ctx.ApparatoMagazzinoDittas.Remove(amd);
                }
            }

            // Antenne nuove
            List<EntityInstallazioneAntenne> installazioneAntenneNuove = _RCDDbContext.InstallazioneAntenne
                .Where(ia => ia.IdInstallazione == richiesta.IdInstallazione && ia.Riuso == false).ToList();

            foreach (EntityInstallazioneAntenne ia in installazioneAntenneNuove)
            {
                int? totaleAntenneDaInstallare = ia.Quantita;
                // Scarico l'antenna nuova dal magazzino ditta
                List<EntityAntennaMagazzinoDitta> antenneInStockDitta = _RCDDbContext.AntennaMagazzinoDitta
                .Where(i => i.IdDitta == magazzinoDitta.Id && i.Antenna.Id == ia.Antenna.Id && i.StatoMateriale.Id == nuovo.Id).ToList();

                if (antenneInStockDitta.Count() > 0)
                {
                    foreach (EntityAntennaMagazzinoDitta amd in antenneInStockDitta)
                    {
                        if (amd.Quantita <= totaleAntenneDaInstallare)
                        {
                            totaleAntenneDaInstallare -= amd.Quantita;
                            amd.Quantita = 0;
                        }
                        else
                        {
                            amd.Quantita -= totaleAntenneDaInstallare;
                            totaleAntenneDaInstallare = 0;
                        }
                    }
                }
                if (totaleAntenneDaInstallare > 0 && magazzino != null)
                {
                    // Se il numero di antenne necessarie è più alto delle antenne in stock alla ditta ed ho individuato il magazzino virtuale di competenza, scarico dal magazzino virtuale VF
                    List<EntityAntennaMagazzino> antenneInStockVodafone = _RCDDbContext.AntennaMagazzino
                            .Where(i => i.IdMagazzino == magazzino.Id && i.Antenna.Id == ia.Antenna.Id && i.StatoMateriale.Id == nuovo.Id).ToList();

                    if (antenneInStockVodafone.Count() > 0)
                    {
                        foreach (EntityAntennaMagazzino am in antenneInStockVodafone)
                        {
                            if (am.Quantita <= totaleAntenneDaInstallare)
                            {
                                totaleAntenneDaInstallare -= am.Quantita;
                                am.Quantita = 0;

                                //var result = _RCDDbContext.Remove(am);
                                //_RCDDbContext.SaveChanges();

                                //magazzino.AntenneMagazzino.Remove(am);
                                //ctx.AntennaMagazzinos.Remove(am);
                            }
                            else
                            {
                                am.Quantita -= totaleAntenneDaInstallare;
                                totaleAntenneDaInstallare = 0;
                            }
                        }
                    }
                }
                if (totaleAntenneDaInstallare > 0)
                {
                    // Se servono ancora antenne porto a valore negativo un ordinativo nel magazzino ditta
                    EntityAntennaMagazzinoDitta antennaSottoDimensione = _RCDDbContext.AntennaMagazzinoDitta
                            .Where(i => i.IdDitta == magazzinoDitta.Id && i.Antenna.Id == ia.Antenna.Id && i.StatoMateriale.Id == nuovo.Id).FirstOrDefault();

                    if (antennaSottoDimensione != null)
                    {
                        antennaSottoDimensione.Quantita -= totaleAntenneDaInstallare;
                    }
                    else
                    {
                        sb.Append("Antenna: " + ia.Antenna.Modello + " - Stato: Nuovo - Quantità non disponibile: " + totaleAntenneDaInstallare.ToString() + "\n");
                    }
                }
                //  Rimuovo tutti gli ordini con quantità = 0 nel magazzino ditta
                List<EntityAntennaMagazzinoDitta> antenneToRemove = _RCDDbContext.AntennaMagazzinoDitta
                .Where(i => i.IdDitta == magazzinoDitta.Id && i.Antenna.Id == ia.Antenna.Id && i.Quantita == 0 && i.StatoMateriale.Id == nuovo.Id).ToList();

                foreach (EntityAntennaMagazzinoDitta amd in antenneToRemove)
                {
                    ///DA VERIFICARE!!!!!!!!!!!!!!
                    //var result = _RCDDbContext.Remove(amd);
                    //_RCDDbContext.SaveChanges();

                    //  magazzinoDitta.AntenneMagazzinoDitta.Remove(amd);
                    //ctx.AntennaMagazzinoDittas.Remove(amd);
                }
            }

            // Accessori nuovi
            List<EntityInstallazioneAccessori> installazioneAccessoriNuovi = _RCDDbContext.InstallazioneAccessori
                .Where(ia => ia.IdInstallazione == richiesta.IdInstallazione && ia.Riuso == false).ToList();

            foreach (EntityInstallazioneAccessori ia in installazioneAccessoriNuovi)
            {
                int? totaleAccessoriDaInstallare = ia.Quantita;
                // Scarico l'accessorio nuovo dal magazzino ditta
                List<EntityAccessorioMagazzinoDitta> accessoriInStockDitta = _RCDDbContext.AccessorioMagazzinoDitta
                .Where(i => i.IdDitta == magazzinoDitta.Id && i.Accessorio.Id == ia.Accessorio.Id && i.StatoMateriale.Id == nuovo.Id).ToList();

                if (accessoriInStockDitta.Count() > 0)
                {
                    foreach (EntityAccessorioMagazzinoDitta amd in accessoriInStockDitta)
                    {
                        if (amd.Quantita <= totaleAccessoriDaInstallare)
                        {
                            totaleAccessoriDaInstallare -= amd.Quantita;
                            amd.Quantita = 0;
                        }
                        else
                        {
                            amd.Quantita -= totaleAccessoriDaInstallare;
                            totaleAccessoriDaInstallare = 0;
                        }
                    }
                }
                if (totaleAccessoriDaInstallare > 0 && magazzino != null)
                {
                    // Se il numero di accessori necessari è più alto degli accessori in stock alla ditta ed ho individuato il magazzino virtuale di competenza, scarico dal magazzino virtuale VF
                    List<EntityAccessorioMagazzino> accessoriInStockVodafone = _RCDDbContext.AccessorioMagazzino
                            .Where(i => i.IdMagazzino == magazzino.Id && i.Accessorio.Id == ia.Accessorio.Id && i.StatoMateriale.Id == nuovo.Id).ToList();

                    if (accessoriInStockVodafone.Count() > 0)
                    {
                        foreach (EntityAccessorioMagazzino am in accessoriInStockVodafone)
                        {
                            if (am.Quantita <= totaleAccessoriDaInstallare)
                            {
                                totaleAccessoriDaInstallare -= am.Quantita;
                                am.Quantita = 0;

                                //var result = _RCDDbContext.Remove(am);
                                //_RCDDbContext.SaveChanges();

                                //magazzino.AccessoriMagazzino.Remove(am);
                                //ctx.AccessorioMagazzinos.Remove(am);
                            }
                            else
                            {
                                am.Quantita -= totaleAccessoriDaInstallare;
                                totaleAccessoriDaInstallare = 0;
                            }
                        }
                    }
                }
                if (totaleAccessoriDaInstallare > 0)
                {
                    // Se servono ancora antenne porto a valore negativo un ordinativo nel magazzino ditta
                    EntityAccessorioMagazzinoDitta accessoriSottoDimensione = _RCDDbContext.AccessorioMagazzinoDitta
                            .Where(i => i.IdDitta == magazzinoDitta.Id && i.Accessorio.Id == ia.Accessorio.Id && i.StatoMateriale.Id == nuovo.Id).FirstOrDefault();

                    if (accessoriSottoDimensione != null)
                    {
                        accessoriSottoDimensione.Quantita -= totaleAccessoriDaInstallare;
                    }
                    else
                    {
                        sb.Append("Accessorio: " + ia.Accessorio.Modello + " - Stato: Nuovo - Quantità non disponibile: " + totaleAccessoriDaInstallare.ToString() + "\n");
                    }
                }
                //  Rimuovo tutti gli ordini con quantità = 0 nel magazzino ditta
                List<EntityAccessorioMagazzinoDitta> accessoriToRemove = _RCDDbContext.AccessorioMagazzinoDitta
                .Where(i => i.IdDitta == magazzinoDitta.Id && i.Accessorio.Id == ia.Accessorio.Id && i.Quantita == 0 && i.StatoMateriale.Id == nuovo.Id).ToList();

                foreach (EntityAccessorioMagazzinoDitta amd in accessoriToRemove)
                {
                    ///DA VERIFICARE!!!!!!!!!!!!!!
                    //var result = _RCDDbContext.Remove(amd);
                    //_RCDDbContext.SaveChanges();

                    //magazzinoDitta.AccessoriMagazzinoDitta.Remove(amd);
                    //ctx.AccessorioMagazzinoDittas.Remove(amd);
                }
            }
            string messageReturn = sb.ToString();
            return messageReturn;
        }

        #endregion Gestione materiali magazzino

        #region "DA CANCELLARE"
        private EntityStato checkGovernanceOld(EntityStato actualStatus, EntityRichiesta richiesta, Boolean isAutomaticChange)
        {
            EntityStato nextStatus = new EntityStato();
            // Se lo stato richiede controllo delle governance
            if (actualStatus.FollowGovernanceRule == true)
            {
                if (richiesta.Richiedente is not null)
                {
                    if ((actualStatus.Id != null) && (richiesta.Richiedente.IdCanaleVenditeDettaglio != null))
                    {
                        long? statusId = actualStatus.Id;
                        long? richiedenteCVD_Id = richiesta.Richiedente.IdCanaleVenditeDettaglio;

                        List<EntityGovernance> listGov = GetGovernanceByStatoECanale(statusId, richiedenteCVD_Id);

                        bool checkedGovernance = false;
                        foreach (EntityGovernance g in listGov)
                        {
                            string descTipologiaAuto = string.Empty;
                            descTipologiaAuto = g.TipologiaAutorizzazione.TipologiaAutorizzazione;

                            //recupero del Sistema -- DA VERIFICARE
                            EntitySistemaRichiesto sistemaR = _RCDDbContext.SistemaRichiesto.Where(x => x.Id == richiesta.IdSistemaRichiesto).FirstOrDefault();
                            // EntitySistemaRichiesto sistemaR = richiesta.SistemaRichiesto

                            //bool? skipGovSopralluogo = richiesta.SistemaRichiesto.SkipGovSopralluogo;
                            bool? skipGovSopralluogo = sistemaR.SkipGovSopralluogo;
                            if ((skipGovSopralluogo == true && descTipologiaAuto.Equals("sopralluogo", StringComparison.InvariantCultureIgnoreCase))
                                || (skipGovSopralluogo == true && g.TipologiaAutorizzazione.TipologiaAutorizzazione.Equals("installazione", StringComparison.InvariantCultureIgnoreCase)))
                            {
                                checkedGovernance = true;
                            }
                            else
                            {
                                //recupero del Sopralluogo -- DA VERIFICARE
                                EntitySopralluogo sopralluogoR = _RCDDbContext.Sopralluogo.Where(x => x.Id == richiesta.IdSopralluogo).FirstOrDefault();

                                Double? stimaIntervento = 0;
                                if (sopralluogoR != null)
                                    stimaIntervento = sopralluogoR.StimaIntervento;

                                bool continueValue = checkGovernancesValues(g, richiesta.Richiedente, stimaIntervento);

                                if (continueValue == true && checkedGovernance == false)
                                {
                                    checkedGovernance = true;
                                }
                            }

                        }
                        //Fine verifica governance
                        //La governance è verificata
                        if (checkedGovernance == true)
                        {

                            EntityWorkflow wkf = _RCDDbContext.Workflow
                                .Where(x => x.IdInitialState == actualStatus.Id && x.ConditionValue == 1 && x.FinalState.IsAutomaticChange == false).FirstOrDefault();

                            nextStatus = getNextStatus(wkf);

                        }   // La governance non è verificata
                        else
                        {
                            EntityWorkflow wkf = _RCDDbContext.Workflow
                                .Where(x => x.IdInitialState == actualStatus.Id && x.ConditionValue == 0 && x.FinalState.IsAutomaticChange == true).FirstOrDefault();

                            nextStatus = getNextStatus(wkf);
                        }
                    }
                }

            }
            // Se lo stato non richiede controllo delle governance
            else
            {
                EntityWorkflow wkf = _RCDDbContext.Workflow
                           .Where(x => x.InitialState.Id == actualStatus.Id && x.FinalState.IsAutomaticChange == isAutomaticChange).FirstOrDefault();

                nextStatus = getNextStatus(wkf);
            }

            return nextStatus;

        }

        //public EntityStato SetNextStatus(EntityRichiesta richiesta, long userId, Boolean isAutomaticChange)
        //{
        //    try
        //    {
        //        EntityStato nextStatus = new EntityStato();
        //        EntityStato actualStatus;
        //        // Se la richiesta non è nuova
        //        if (richiesta.Id > 0)
        //        {
        //            //recupero l'ultimo stato richiesta 
        //            EntityStatiRichiesta statiRichiesta = _RCDDbContext.StatiRichiesta.Where(x => x.IdRichiesta == richiesta.Id).OrderByDescending(x => x.InsertDate).FirstOrDefault();

        //            //recupero lo stato dell'ultima richiesta inserita
        //            actualStatus = _RCDDbContext.Stato.Where(x => x.Id == statiRichiesta.IdStato).FirstOrDefault();


        //            nextStatus = checkGovernance(actualStatus,richiesta, isAutomaticChange);


        //            var result = _RCDDbContext.Update(richiesta);
        //            _RCDDbContext.SaveChanges();

        //        }
        //        else  //se la richiesta è nuova
        //        {
        //            actualStatus = _RCDDbContext.Stato.Where(x => x.Id == 1).FirstOrDefault();
        //            nextStatus = checkGovernance(actualStatus, richiesta, isAutomaticChange);

        //            var result = _RCDDbContext.Add(richiesta);
        //            _RCDDbContext.SaveChanges();

        //            long? idRichiedente = richiesta.Richiedente.Id;
        //            long? idLocation = richiesta.Location.Id;

        //            //UPDATE T_LOCATION SET IDRICHIEDENTE WHERE ID=IDLOCATION
        //            var locationRichiesta = _RCDDbContext.Location.First(g => g.Id == idLocation);
        //            locationRichiesta.IdRichiedente = idRichiedente;
        //            _RCDDbContext.SaveChanges();

        //            //// Se lo stato richiede controllo delle governance
        //            //if (actualStatus.FollowGovernanceRule == true)
        //            //{

        //            //    //recupero CanaleVenditaDettaglio
        //            //    //    EntityRichiedente richiedente = _RCDDbContext.Richiedente.Where(x => x.Id == richiesta.IdRichiedente).FirstOrDefault();

        //            //    if (richiesta.Richiedente is not null)
        //            //    {
        //            //        if ((actualStatus.Id != null) && (richiesta.Richiedente.IdCanaleVenditeDettaglio != null))
        //            //        {
        //            //            long? statusId = actualStatus.Id;
        //            //            long? richiedenteCVD_Id = richiesta.Richiedente.IdCanaleVenditeDettaglio;

        //            //            List<EntityGovernance> listGov = GetGovernanceByStatoECanale(statusId, richiedenteCVD_Id);

        //            //            bool checkedGovernance = false;
        //            //            foreach (EntityGovernance g in listGov)
        //            //            {
        //            //                string descTipologiaAuto = string.Empty;
        //            //                descTipologiaAuto = g.TipologiaAutorizzazione.TipologiaAutorizzazione;

        //            //                //recupero del Sistema -- DA VERIFICARE
        //            //                EntitySistemaRichiesto sistemaR = _RCDDbContext.SistemaRichiesto.Where(x => x.Id == richiesta.IdSistemaRichiesto).FirstOrDefault();
        //            //                // sistemaR = richiesta.SistemaRichiesto

        //            //                //bool? skipGovSopralluogo = richiesta.SistemaRichiesto.SkipGovSopralluogo;
        //            //                bool? skipGovSopralluogo = sistemaR.SkipGovSopralluogo;
        //            //                if ((skipGovSopralluogo == true && descTipologiaAuto.Equals("sopralluogo", StringComparison.InvariantCultureIgnoreCase))
        //            //                    || (skipGovSopralluogo == true && g.TipologiaAutorizzazione.TipologiaAutorizzazione.Equals("installazione", StringComparison.InvariantCultureIgnoreCase)))
        //            //                {
        //            //                    checkedGovernance = true;
        //            //                }
        //            //                else
        //            //                {
        //            //                    //recupero del Sopralluogo -- DA VERIFICARE
        //            //                    EntitySopralluogo sopralluogoR = _RCDDbContext.Sopralluogo.Where(x => x.Id == richiesta.IdSopralluogo).FirstOrDefault();

        //            //                    Double? stimaIntervento = 0;
        //            //                    if (sopralluogoR != null)
        //            //                        stimaIntervento = sopralluogoR.StimaIntervento;

        //            //                    bool continueValue = checkGovernancesValues(g, richiesta.Richiedente, stimaIntervento);

        //            //                    if (continueValue == true && checkedGovernance == false)
        //            //                    {
        //            //                        checkedGovernance = true;
        //            //                    }
        //            //                }
        //            //            }

        //            //            //Fine verifica governance
        //            //            //La governance è verificata
        //            //            if (checkedGovernance == true)
        //            //            {
        //            //                EntityWorkflow wkf = _RCDDbContext.Workflow
        //            //                    .Where(x => x.IdInitialState == actualStatus.Id && x.ConditionValue == 1 && x.FinalState.IsAutomaticChange == false).FirstOrDefault();

        //            //                nextStatus = getNextStatus(wkf);

        //            //            }   // La governance non è verificata
        //            //            else
        //            //            {
        //            //                EntityWorkflow wkf = _RCDDbContext.Workflow
        //            //                    .Where(x => x.IdInitialState == actualStatus.Id && x.ConditionValue == 0 && x.FinalState.IsAutomaticChange == true).FirstOrDefault();

        //            //                nextStatus = getNextStatus(wkf);
        //            //            }
        //            //        }
        //            //    }
        //            //}
        //            //// Se lo stato non richiede controllo delle governance
        //            //else
        //            //{
        //            //    EntityWorkflow wkf = _RCDDbContext.Workflow
        //            //               .Where(x => x.InitialState.Id == actualStatus.Id && x.FinalState.IsAutomaticChange == isAutomaticChange).FirstOrDefault();

        //            //    nextStatus = getNextStatus(wkf);
        //            //}
        //        }
        //        return nextStatus;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message);
        //    }
        //}

        //DA CANCELLARE
        //public void InsertNewRichiestaOld(RichiestaRequest richiesta, long userId, Boolean isAutomaticChange)
        //{
        //    try
        //    {

        //        EntityRichiesta richiestaToAdd = new EntityRichiesta();
        //        /// ????????????????? problema map richiedente (da inserire nella richiesta  
        //        UtilityManager.MapProp(richiesta, richiestaToAdd);
        //        richiestaToAdd.IdUserInsert = userId;

        //        EntityStato nextStato = SetNextStatus(richiestaToAdd, userId, isAutomaticChange);
        //        //  richiestaToAdd.IdUserInsert = userId;
        //        //richiestaToAdd.abilitato = true;
        //        var result = _RCDDbContext.Add(richiestaToAdd);
        //        _RCDDbContext.SaveChanges();

        //        //  long id actualStatus = _RCDDbContext.Richieste.Where(x => x.Id == 1).FirstOrDefault();

        //        if (nextStato != null)
        //        {
        //            saveStatoRichiesta(userId, richiestaToAdd, nextStato.Id);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message);
        //    }

        //}


        //public EntityRichiedente SaveRichiedente(EntityRichiesta richiesta)
        //{
        //    try
        //    {


        //        var result = _RCDDbContext.Add(richiesta);
        //        _RCDDbContext.SaveChanges();

        //        return richiedente;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message);
        //    }
        //}

        #endregion "DA CANCELLARE"


    }
}

