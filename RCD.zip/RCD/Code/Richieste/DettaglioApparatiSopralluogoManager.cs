﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;

namespace RCD.Code.Richieste
{
    public class DettaglioApparatoSopralluogoManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;


        public DettaglioApparatoSopralluogoManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        #region DETTAGLIO APPARATI 
        public async Task<List<ContractSopralluogoApparati>> GetApparatiSopralluogo(ApparatiSopralluogoRequestFull apparatoSopralluogo)
        {
            List<EntitySopralluogoApparati> sopralluoghiApparati;

            String sortParam = String.Concat(String.Concat(apparatoSopralluogo.CampoOrdinamento, " "), apparatoSopralluogo.Ordinamento.ToUpper());

            if (apparatoSopralluogo.Pageable)
            {
                sopralluoghiApparati = await _RCDDbContext.SopralluogoApparati.Where(x => x.IdSopralluogo.Equals(apparatoSopralluogo.Filter.IdSopralluogo))
                .Include("Apparati")
                .Include("Apparati.TipologiaApparato")
                .Include("Apparati.Sistema")
                .Include("Apparati.Fornitore")
                .Include("RaggiungibilitaApparato")
                .Include("InstallazioneApparato")
                .Include("PosizioneApparati")
                .OrderBy(sortParam)
                .Skip(apparatoSopralluogo.NumeroElementi * apparatoSopralluogo.Page).Take(apparatoSopralluogo.NumeroElementi)
                .ToListAsync();

            }
            else
            {
                sopralluoghiApparati = await _RCDDbContext.SopralluogoApparati.Where(x => x.IdSopralluogo.Equals(apparatoSopralluogo.Filter.IdSopralluogo))
                .Include("Apparati")
                .Include("Apparati.TipologiaApparato")
                .Include("Apparati.Sistema")
                .Include("Apparati.Fornitore")
                .Include("RaggiungibilitaApparato")
                .Include("InstallazioneApparato")
                .Include("PosizioneApparati")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractSopralluogoApparati> sopralluoghiApparatiElenco = new List<ContractSopralluogoApparati>();
            foreach (EntitySopralluogoApparati varSopralluoghiApparato in sopralluoghiApparati)
            {
                ContractSopralluogoApparati sopralluoghiApparati1 = new ContractSopralluogoApparati();
                UtilityManager.MapProp(varSopralluoghiApparato, sopralluoghiApparati1);
                sopralluoghiApparatiElenco.Add(sopralluoghiApparati1);
            }
            return sopralluoghiApparatiElenco;
        }
        public async Task<Int32> GetApparatiSopralluogoTot(ApparatiSopralluogoRequestFull apparatoSopralluogo)
        {

            Int32 count =  _RCDDbContext.SopralluogoApparati.Where(x => x.IdSopralluogo.Equals(apparatoSopralluogo.Filter.IdSopralluogo))
            .Include("Apparati")
            .Include("Apparati.TipologiaApparato")
            .Include("Apparati.Sistema")
            .Include("Apparati.Fornitore")
            .Include("RaggiungibilitaApparato")
            .Include("InstallazioneApparato")
            .Include("PosizioneApparati")
            .Count();

            return count;

        }
        public void AddApparatiSopralluogo(ApparatiSopralluogoRequest EntitySopralluogoApparati)
        {
            try
            {
                EntitySopralluogoApparati EntitySopralluogoApparatiToAdd = new EntitySopralluogoApparati();
                UtilityManager.MapProp(EntitySopralluogoApparati, EntitySopralluogoApparatiToAdd);
                var result = _RCDDbContext.Add(EntitySopralluogoApparatiToAdd);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(EntitySopralluogoApparati.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateApparatiSopralluogo(ApparatiSopralluogoRequest EntitySopralluogoApparati)
        {
            try
            {
                EntitySopralluogoApparati SopralluogoApparatiToEdit = new EntitySopralluogoApparati();
                UtilityManager.MapProp(EntitySopralluogoApparati, SopralluogoApparatiToEdit);

                var result = _RCDDbContext.Update(SopralluogoApparatiToEdit);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(EntitySopralluogoApparati.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteApparatiSopralluogo(ApparatiSopralluogoRequest EntitySopralluogoApparati)
        {
            try
            {
                EntitySopralluogoApparati SopralluogoApparatiToRemove = new EntitySopralluogoApparati();
                UtilityManager.MapProp(EntitySopralluogoApparati, SopralluogoApparatiToRemove);
                var result = _RCDDbContext.Remove(SopralluogoApparatiToRemove);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(EntitySopralluogoApparati.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
           
        }
        #endregion DETTAGLIO APPARATI 

        #region DETTAGLIO CROWDCELL 
        public async Task<List<ContractSopralluogoCrowdcell>> GetCrowdcellSopralluogo(CrowdcellSopralluogoRequestFull crowdcellSopralluogo)
        {
            List<EntitySopralluogoCrowdcell> sopralluoghiCrowdcell;

            String sortParam = String.Concat(String.Concat(crowdcellSopralluogo.CampoOrdinamento, " "), crowdcellSopralluogo.Ordinamento.ToUpper());

            if (crowdcellSopralluogo.Pageable)
            {
                sopralluoghiCrowdcell = await _RCDDbContext.SopralluogoCrowdcell.Where(x => x.IdSopralluogo.Equals(crowdcellSopralluogo.Filter.IdSopralluogo))
                .Include("TTFrequenzaLte")
                .Include("TTFrequenzaLte1")
                .Include("TTLocalizzazioneAntenna")
                .Include("TTInstallazioneAntenna")
                .Include("TTRaggiungibilitaApparato")
                .Include("TTCriticitaEmf")
                .OrderBy(sortParam)
                .Skip(crowdcellSopralluogo.NumeroElementi * crowdcellSopralluogo.Page).Take(crowdcellSopralluogo.NumeroElementi)
                .ToListAsync();

            }
            else
            {
                sopralluoghiCrowdcell = await _RCDDbContext.SopralluogoCrowdcell.Where(x => x.IdSopralluogo.Equals(crowdcellSopralluogo.Filter.IdSopralluogo))
                .Include("TTFrequenzaLte")
                .Include("TTFrequenzaLte1")
                .Include("TTLocalizzazioneAntenna")
                .Include("TTInstallazioneAntenna")
                .Include("TTRaggiungibilitaApparato")
                .Include("TTCriticitaEmf")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractSopralluogoCrowdcell> sopralluoghiCrowdcellElenco = new List<ContractSopralluogoCrowdcell>();
            foreach (EntitySopralluogoCrowdcell varSopralluoghiCrowdcell in sopralluoghiCrowdcell)
            {
                ContractSopralluogoCrowdcell sopralluoghiCrowdcell1 = new ContractSopralluogoCrowdcell();
                UtilityManager.MapProp(varSopralluoghiCrowdcell, sopralluoghiCrowdcell1);
                sopralluoghiCrowdcellElenco.Add(sopralluoghiCrowdcell1);
            }
            return sopralluoghiCrowdcellElenco;
        }
        public async Task<Int32> GetCrowdcellSopralluogoTot(CrowdcellSopralluogoRequestFull crowdcellSopralluogo)
        {

            Int32 count = _RCDDbContext.SopralluogoCrowdcell.Where(x => x.IdSopralluogo.Equals(crowdcellSopralluogo.Filter.IdSopralluogo))
                .Include("TTFrequenzaLte")
                .Include("TTFrequenzaLte1")
                .Include("TTLocalizzazioneAntenna")
                .Include("TTInstallazioneAntenna")
                .Include("TTRaggiungibilitaApparato")
                .Include("TTCriticitaEmf")
            .Count();

            return count;

        }
        public void AddCrowdcellSopralluogo(CrowdcellSopralluogoRequest crowdcellSopralluogo)
        {
            try
            {
                EntitySopralluogoCrowdcell EntitySopralluogoCrowdcellToAdd = new EntitySopralluogoCrowdcell();
                UtilityManager.MapProp(crowdcellSopralluogo, EntitySopralluogoCrowdcellToAdd);
                var result = _RCDDbContext.Add(EntitySopralluogoCrowdcellToAdd);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(crowdcellSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public void UpdateCrowdcellSopralluogo(CrowdcellSopralluogoRequest crowdcellSopralluogo)
        {
            try
            {
                EntitySopralluogoCrowdcell EntitySopralluogoCrowdcellToEdit = new EntitySopralluogoCrowdcell();
                UtilityManager.MapProp(crowdcellSopralluogo, EntitySopralluogoCrowdcellToEdit);

                var result = _RCDDbContext.Update(EntitySopralluogoCrowdcellToEdit);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(crowdcellSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteCrowdcellSopralluogo(CrowdcellSopralluogoRequest crowdcellSopralluogo)
        {
            try
            {
                EntitySopralluogoCrowdcell EntitySopralluogoCrowdcellToRemove = new EntitySopralluogoCrowdcell();
                UtilityManager.MapProp(crowdcellSopralluogo, EntitySopralluogoCrowdcellToRemove);
                var result = _RCDDbContext.Remove(EntitySopralluogoCrowdcellToRemove);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(crowdcellSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        #endregion DETTAGLIO CROWDCELL 

        #region DETTAGLIO FEMTO 

        public async Task<List<ContractSopralluogoFemto>> GetFemtoSopralluogo(FemtoSopralluogoRequestFull femtoSopralluogo)
        {
            List<EntitySopralluogoFemto> sopralluoghiFemto;

            String sortParam = String.Concat(String.Concat(femtoSopralluogo.CampoOrdinamento, " "), femtoSopralluogo.Ordinamento.ToUpper());

            if (femtoSopralluogo.Pageable)
            {
                sopralluoghiFemto = await _RCDDbContext.SopralluogoFemto.Where(x => x.IdSopralluogo.Equals(femtoSopralluogo.Filter.IdSopralluogo))
                .Include("TipologiaCopertura")
                .Include("TipologiaLan")
                .OrderBy(sortParam)
                .Skip(femtoSopralluogo.NumeroElementi * femtoSopralluogo.Page).Take(femtoSopralluogo.NumeroElementi)
                .ToListAsync();

            }
            else
            {
                sopralluoghiFemto = await _RCDDbContext.SopralluogoFemto.Where(x => x.IdSopralluogo.Equals(femtoSopralluogo.Filter.IdSopralluogo))
                .Include("TipologiaCopertura")
                .Include("TipologiaLan")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractSopralluogoFemto> sopralluoghiFemtoElenco = new List<ContractSopralluogoFemto>();
            foreach (EntitySopralluogoFemto varSopralluoghiFemto in sopralluoghiFemto)
            {
                ContractSopralluogoFemto sopralluoghiFemto1 = new ContractSopralluogoFemto();
                UtilityManager.MapProp(varSopralluoghiFemto, sopralluoghiFemto1);
                sopralluoghiFemtoElenco.Add(sopralluoghiFemto1);
            }
            return sopralluoghiFemtoElenco;
        }
        public async Task<Int32> GetFemtoSopralluogoTot(FemtoSopralluogoRequestFull femtoSopralluogo)
        {
            Int32 count = _RCDDbContext.SopralluogoFemto.Where(x => x.IdSopralluogo.Equals(femtoSopralluogo.Filter.IdSopralluogo))
            .Include("TipologiaCopertura")
            .Include("TipologiaLan")
            .Count();

            return count;

        }

        public void AddFemtoSopralluogo(FemtoSopralluogoRequest femtoSopralluogo)
        {
            try
            {
                EntitySopralluogoFemto EntitySopralluogoFemtoToAdd = new EntitySopralluogoFemto();
                UtilityManager.MapProp(femtoSopralluogo, EntitySopralluogoFemtoToAdd);
                var result = _RCDDbContext.Add(EntitySopralluogoFemtoToAdd);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(femtoSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateFemtoSopralluogo(FemtoSopralluogoRequest femtoSopralluogo)
        {
            try
            {
                EntitySopralluogoFemto EntitySopralluogoFemtoToEdit = new EntitySopralluogoFemto();
                UtilityManager.MapProp(femtoSopralluogo, EntitySopralluogoFemtoToEdit);

                var result = _RCDDbContext.Update(EntitySopralluogoFemtoToEdit);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(femtoSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteFemtoSopralluogo(FemtoSopralluogoRequest femtoSopralluogo)
        {
            try
            {
                EntitySopralluogoFemto EntitySopralluogoFemtoToRemove = new EntitySopralluogoFemto();
                UtilityManager.MapProp(femtoSopralluogo, EntitySopralluogoFemtoToRemove);
                var result = _RCDDbContext.Remove(EntitySopralluogoFemtoToRemove);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(femtoSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        #endregion DETTAGLIO FEMTO 

        #region DETTAGLIO MISURE

        public async Task<List<ContractSopralluogoMisure>> GetMisureSopralluogo(MisuraSopralluogoRequestFull misuraSopralluogo)
        {
            List<EntitySopralluogoMisure> sopralluoghiMisure;

            String sortParam = String.Concat(String.Concat(misuraSopralluogo.CampoOrdinamento, " "), misuraSopralluogo.Ordinamento.ToUpper());

            if (misuraSopralluogo.Pageable)
            {
                sopralluoghiMisure = await _RCDDbContext.SopralluogoMisure.Where(x => x.IdSopralluogo.Equals(misuraSopralluogo.Filter.IdSopralluogo))
                .Include("Sistema")
                .Include("TipologiaMisura")
                .OrderBy(sortParam)
                .Skip(misuraSopralluogo.NumeroElementi * misuraSopralluogo.Page).Take(misuraSopralluogo.NumeroElementi)
                .ToListAsync();

            }
            else
            {
                sopralluoghiMisure = await _RCDDbContext.SopralluogoMisure.Where(x => x.IdSopralluogo.Equals(misuraSopralluogo.Filter.IdSopralluogo))
                .Include("Sistema")
                .Include("TipologiaMisura")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractSopralluogoMisure> sopralluoghiMisureElenco = new List<ContractSopralluogoMisure>();
            foreach (EntitySopralluogoMisure varSopralluoghiMisure in sopralluoghiMisure)
            {
                ContractSopralluogoMisure sopralluoghiMisure1 = new ContractSopralluogoMisure();
                UtilityManager.MapProp(varSopralluoghiMisure, sopralluoghiMisure1);
                sopralluoghiMisureElenco.Add(sopralluoghiMisure1);
            }
            return sopralluoghiMisureElenco;
        }
        public async Task<Int32> GetMisureSopralluogoTot(MisuraSopralluogoRequestFull misuraSopralluogo)
        {
            Int32 count = _RCDDbContext.SopralluogoMisure.Where(x => x.IdSopralluogo.Equals(misuraSopralluogo.Filter.IdSopralluogo))
            .Include("Sistema")
            .Include("TipologiaMisura")
            .Count();

            return count;

        }
        public void AddMisuraSopralluogo(MisuraSopralluogoRequest misuraSopralluogo)
        {
            try
            {
                EntitySopralluogoMisure SopralluogoMisureToAdd = new EntitySopralluogoMisure();
                UtilityManager.MapProp(misuraSopralluogo, SopralluogoMisureToAdd);
                var result = _RCDDbContext.Add(SopralluogoMisureToAdd);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(misuraSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateMisuraSopralluogo(MisuraSopralluogoRequest misuraSopralluogo)
        {
            try
            {
                EntitySopralluogoMisure SopralluogoMisureToEdit = new EntitySopralluogoMisure();
                UtilityManager.MapProp(misuraSopralluogo, SopralluogoMisureToEdit);

                var result = _RCDDbContext.Update(SopralluogoMisureToEdit);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(misuraSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteMisuraSopralluogo(MisuraSopralluogoRequest misuraSopralluogo)
        {
            try
            {
                EntitySopralluogoMisure SopralluogoMisureToRemove = new EntitySopralluogoMisure();
                UtilityManager.MapProp(misuraSopralluogo, SopralluogoMisureToRemove);
                var result = _RCDDbContext.Remove(SopralluogoMisureToRemove);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(misuraSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion DETTAGLIO MISURE 

        #region DETTAGLIO ANTENNE

        public async Task<List<ContractSopralluogoAntenne>> GetAntenneSopralluogo(AntennaSopralluogoRequestFull antennaSopralluogo)
        {
            List<EntitySopralluogoAntenne> sopralluoghiAntenne;

            String sortParam = String.Concat(String.Concat(antennaSopralluogo.CampoOrdinamento, " "), antennaSopralluogo.Ordinamento.ToUpper());

            if (antennaSopralluogo.Pageable)
            {
                sopralluoghiAntenne = await _RCDDbContext.SopralluogoAntenne.Where(x => x.IdSopralluogo.Equals(antennaSopralluogo.Filter.IdSopralluogo))
                .Include("Antenna")
                .Include("Antenna.Sistema")
                .Include("Antenna.Fornitore")
                .Include("Antenna.TipologiaAntenna")
                .Include("TipologiaSegnaleAntenna")
                .Include("TTAccessibilitaAntenna")
                .Include("TTLocalizzazioneAntenna")
                .Include("TTInstallazioneAntenna")
                .OrderBy(sortParam)
                .Skip(antennaSopralluogo.NumeroElementi * antennaSopralluogo.Page).Take(antennaSopralluogo.NumeroElementi)
                .ToListAsync();
            }
            else
            {
                sopralluoghiAntenne = await _RCDDbContext.SopralluogoAntenne.Where(x => x.IdSopralluogo.Equals(antennaSopralluogo.Filter.IdSopralluogo))
                .Include("Antenna")
                .Include("Antenna.Sistema")
                .Include("Antenna.Fornitore")
                .Include("Antenna.TipologiaAntenna")
                .Include("TipologiaSegnaleAntenna")
                .Include("TTAccessibilitaAntenna")
                .Include("TTLocalizzazioneAntenna")
                .Include("TTInstallazioneAntenna")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractSopralluogoAntenne> sopralluoghiAntenneElenco = new List<ContractSopralluogoAntenne>();
            foreach (EntitySopralluogoAntenne varSopralluoghiAntenne in sopralluoghiAntenne)
            {
                ContractSopralluogoAntenne sopralluoghiAntenne1 = new ContractSopralluogoAntenne();
                UtilityManager.MapProp(varSopralluoghiAntenne, sopralluoghiAntenne1);
                sopralluoghiAntenneElenco.Add(sopralluoghiAntenne1);
            }
            return sopralluoghiAntenneElenco;
        }
        public async Task<Int32> GetAntenneSopralluogoTot(AntennaSopralluogoRequestFull antennaSopralluogo)
        {

            Int32 count = _RCDDbContext.SopralluogoAntenne.Where(x => x.IdSopralluogo.Equals(antennaSopralluogo.Filter.IdSopralluogo))
                .Include("Antenna")
                .Include("Antenna.Sistema")
                .Include("Antenna.Fornitore")
                .Include("Antenna.TipologiaAntenna")
                .Include("TipologiaSegnaleAntenna")
                .Include("TTAccessibilitaAntenna")
                .Include("TTLocalizzazioneAntenna")
                .Include("TTInstallazioneAntenna")
            .Count();

            return count;

        }

        public void AddAntenneSopralluogo(AntennaSopralluogoRequest antennaSopralluogo)
        {
            try
            {
                EntitySopralluogoAntenne antennaSopralluogoToAdd = new EntitySopralluogoAntenne();
                UtilityManager.MapProp(antennaSopralluogo, antennaSopralluogoToAdd);
                var result = _RCDDbContext.Add(antennaSopralluogoToAdd);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(antennaSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateAntenneSopralluogo(AntennaSopralluogoRequest antennaSopralluogo)
        {
            try
            {
                EntitySopralluogoAntenne antennaSopralluogoToEdit = new EntitySopralluogoAntenne();
                UtilityManager.MapProp(antennaSopralluogo, antennaSopralluogoToEdit);

                var result = _RCDDbContext.Update(antennaSopralluogoToEdit);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(antennaSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteAntenneSopralluogo(AntennaSopralluogoRequest antennaSopralluogo)
        {
            try
            {
                EntitySopralluogoAntenne antennaSopralluogoToRemove = new EntitySopralluogoAntenne();
                UtilityManager.MapProp(antennaSopralluogo, antennaSopralluogoToRemove);
                var result = _RCDDbContext.Remove(antennaSopralluogoToRemove);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(antennaSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion DETTAGLIO ANTENNE 

        #region DETTAGLIO ACCESSORI

        public async Task<List<ContractSopralluogoAccessori>> GetAccessoriSopralluogo(AccessorioSopralluogoRequestFull accessorioSopralluogo)
        {
            List<EntitySopralluogoAccessori> sopralluoghiAccessori;

            String sortParam = String.Concat(String.Concat(accessorioSopralluogo.CampoOrdinamento, " "), accessorioSopralluogo.Ordinamento.ToUpper());

            if (accessorioSopralluogo.Pageable)
            {
                sopralluoghiAccessori = await _RCDDbContext.SopralluogoAccessori.Where(x => x.IdSopralluogo.Equals(accessorioSopralluogo.Filter.IdSopralluogo))
                .Include("Accessorio")   
                .Include("Accessorio.Sistema")
                .Include("Accessorio.Fornitore")
                .Include("Accessorio.TipologiaAccessorio")
                .OrderBy(sortParam)
                .Skip(accessorioSopralluogo.NumeroElementi * accessorioSopralluogo.Page).Take(accessorioSopralluogo.NumeroElementi)
                .ToListAsync();
            }
            else
            {
                sopralluoghiAccessori = await _RCDDbContext.SopralluogoAccessori.Where(x => x.IdSopralluogo.Equals(accessorioSopralluogo.Filter.IdSopralluogo))
                .Include("Accessorio")
                .Include("Accessorio.Sistema")
                .Include("Accessorio.Fornitore")
                .Include("Accessorio.TipologiaAccessorio")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractSopralluogoAccessori> sopralluoghiAccessoriElenco = new List<ContractSopralluogoAccessori>();
            foreach (EntitySopralluogoAccessori varSopralluoghiAccessori in sopralluoghiAccessori)
            {
                ContractSopralluogoAccessori sopralluoghiAccessori1 = new ContractSopralluogoAccessori();
                UtilityManager.MapProp(varSopralluoghiAccessori, sopralluoghiAccessori1);
                sopralluoghiAccessoriElenco.Add(sopralluoghiAccessori1);
            }
            return sopralluoghiAccessoriElenco;
        }
        public async Task<Int32> GetAccessoriSopralluogoTot(AccessorioSopralluogoRequestFull accessorioSopralluogo)
        {

            Int32 count = _RCDDbContext.SopralluogoAccessori.Where(x => x.IdSopralluogo.Equals(accessorioSopralluogo.Filter.IdSopralluogo))
                .Include("Accessorio")
                .Include("Accessorio.Sistema")
                .Include("Accessorio.Fornitore")
                .Include("Accessorio.TipologiaAccessorio")
            .Count();

            return count;

        }
 
        public void AddAccessoriSopralluogo(AccessorioSopralluogoRequest accessorioSopralluogo)
        {
            try
            {
                EntitySopralluogoAccessori accessorioSopralluogoToAdd = new EntitySopralluogoAccessori();
                UtilityManager.MapProp(accessorioSopralluogo, accessorioSopralluogoToAdd);
                var result = _RCDDbContext.Add(accessorioSopralluogoToAdd);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(accessorioSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateAccessoriSopralluogo(AccessorioSopralluogoRequest accessorioSopralluogo)
        {
            try
            {
                EntitySopralluogoAccessori accessorioSopralluogoToEdit = new EntitySopralluogoAccessori();
                UtilityManager.MapProp(accessorioSopralluogo, accessorioSopralluogoToEdit);

                var result = _RCDDbContext.Update(accessorioSopralluogoToEdit);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(accessorioSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteAccessoriSopralluogo(AccessorioSopralluogoRequest accessorioSopralluogo)
        {
            try
            {
                EntitySopralluogoAccessori accessorioSopralluogoToRemove = new EntitySopralluogoAccessori();
                UtilityManager.MapProp(accessorioSopralluogo, accessorioSopralluogoToRemove);
                var result = _RCDDbContext.Remove(accessorioSopralluogoToRemove);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(accessorioSopralluogo.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion DETTAGLIO ACCESSORI 

        /// <summary>
        /// Esegue il ricalcolo dei dati inerenti il sopralluogo in base ai dati presenti
        /// </summary>
        private void RecalculateCosti(Int64? idSopralluogo)
        {
            EntitySopralluogo sopralluogo = _RCDDbContext.Sopralluogo
                                        .Where(x => x.Id == idSopralluogo)
                                        .Include("SopralluogoCme")
                                        .Include("SopralluogoApparati")
                                        .Include("SopralluogoApparati.Apparati.TipologiaApparato")
                                        .Include("SopralluogoApparati.Apparati.Sistema")
                                        .Include("SopralluogoAntenne")
                                        .Include("SopralluogoAccessori")
                                        .FirstOrDefault();
            decimal? TotaleCosti = 0;
            decimal? TotaleCostiApparatiAccessori = 0;
            decimal? TotaleCostiSostenuti = 0;
            int? TotaleRiuso = 0;
            int? TotaleNuovo = 0;
            int? TotaleRighe = 0;

            decimal? TotaleCostiCME = 0;
            decimal? TotaleCostiApparati = 0;
            decimal? TotaleCostiAccessori = 0;
            decimal? TotaleCostiAntenne = 0;
            int? TotaleApparatiNuovi = 0;
            int? TotaleApparatiRiuso = 0;
            int? TotaleAccessoriNuovi = 0;
            int? TotaleAccessoriRiuso = 0;
            int? TotaleAntenneNuovi = 0;
            int? TotaleAntenneRiuso = 0;

            int? TotaleMiniGsm = 0;
            int? TotaleCompactGsm = 0;
            int? TotaleMiniUmts = 0;
            int? TotaleCompactUmts = 0;
            int? TotaleMiniLte = 0;
            int? TotaleCompactLte = 0;
            int? TotalePicoUmts = 0;
            int? TotalePicoLte = 0;
            int? TotaleFemto = 0;
            int? TotaleFemtoLte = 0;

            int? TotaleDualBand = 0;

            TotaleCostiCME = sopralluogo.SopralluogoCme.Sum(cme => cme.PrezzoTotale);
            TotaleCostiSostenuti = sopralluogo.SopralluogoCme.Where(cme => cme.CostoSostenuto == true).Sum(cme => cme.PrezzoTotale);
            TotaleRighe += sopralluogo.SopralluogoCme.Count();

            TotaleCostiApparati = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Riuso == false && sApp.ProprietaCliente == false).Sum(sApp => sApp.PrezzoTotale);
            TotaleApparatiNuovi = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Riuso == false).Sum(sApp => sApp.Quantita);
            TotaleApparatiRiuso = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Riuso == true).Sum(sApp => sApp.Quantita);
            TotaleMiniGsm = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "mini" && sApp.Apparati.Sistema.Sistema.ToLower() == "gsm").Sum(sApp => sApp.Quantita);
            TotaleCompactGsm = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "compact" && sApp.Apparati.Sistema.Sistema.ToLower() == "gsm").Sum(sApp => sApp.Quantita);
            TotaleMiniUmts = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "mini" && sApp.Apparati.Sistema.Sistema.ToLower() == "umts").Sum(sApp => sApp.Quantita);
            TotaleCompactUmts = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "compact" && sApp.Apparati.Sistema.Sistema.ToLower() == "umts").Sum(sApp => sApp.Quantita);
            TotaleMiniLte = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "mini" && sApp.Apparati.Sistema.Sistema.ToLower() == "lte").Sum(sApp => sApp.Quantita);
            TotaleCompactLte = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "compact" && sApp.Apparati.Sistema.Sistema.ToLower() == "lte").Sum(sApp => sApp.Quantita);
            TotalePicoUmts = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "pico" && sApp.Apparati.Sistema.Sistema.ToLower() == "umts").Sum(sApp => sApp.Quantita);
            TotalePicoLte = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "pico" && sApp.Apparati.Sistema.Sistema.ToLower() == "lte").Sum(sApp => sApp.Quantita);
            // Aggiunto filtro Umts
            TotaleFemto = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "femto" && sApp.Apparati.Sistema.Sistema.ToLower() == "umts").Sum(sApp => sApp.Quantita);
            TotaleFemtoLte = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "femto" && sApp.Apparati.Sistema.Sistema.ToLower() == "lte").Sum(sApp => sApp.Quantita);
            TotaleDualBand = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.Sistema.Sistema.ToLower() == "gsm/umts").Sum(sApp => sApp.Quantita);
            TotaleRighe += sopralluogo.SopralluogoApparati.Count();

            TotaleCostiAntenne = sopralluogo.SopralluogoAntenne.Where(sAnt => sAnt.Riuso == false).Sum(sAnt => sAnt.PrezzoTotale);
            TotaleAntenneNuovi = sopralluogo.SopralluogoAntenne.Where(sAnt => sAnt.Riuso == false).Sum(sAnt => sAnt.Quantita);
            TotaleAntenneRiuso = sopralluogo.SopralluogoAntenne.Where(sAnt => sAnt.Riuso == true).Sum(sAnt => sAnt.Quantita);
            TotaleRighe += sopralluogo.SopralluogoAntenne.Count();

            TotaleCostiAccessori = sopralluogo.SopralluogoAccessori.Where(sAcc => sAcc.Riuso == false).Sum(sAcc => sAcc.PrezzoTotale);
            TotaleAccessoriNuovi = sopralluogo.SopralluogoAccessori.Where(sAcc => sAcc.Riuso == false).Sum(sAcc => sAcc.Quantita);
            TotaleAccessoriRiuso = sopralluogo.SopralluogoAccessori.Where(sAcc => sAcc.Riuso == true).Sum(sAcc => sAcc.Quantita);
            TotaleRighe += sopralluogo.SopralluogoAccessori.Count();

            // Calcolo totali
            if (TotaleRighe > 0)
            {
                TotaleCosti = TotaleCostiCME + TotaleCostiApparati + TotaleCostiAntenne + TotaleCostiAccessori;
                sopralluogo.StimaIntervento = (double)TotaleCosti;
                TotaleCostiApparatiAccessori = TotaleCostiApparati + TotaleCostiAntenne + TotaleCostiAccessori;
                sopralluogo.CostoAccessoriApparatiStimato = (double)TotaleCostiApparatiAccessori;
                TotaleNuovo = TotaleApparatiNuovi + TotaleAntenneNuovi + TotaleAccessoriNuovi;
                sopralluogo.TotaleApparatiNuovi = TotaleApparatiNuovi;
                TotaleRiuso = TotaleApparatiRiuso + TotaleAntenneRiuso + TotaleAccessoriRiuso;
                sopralluogo.TotaleApparatiRiuso = TotaleApparatiRiuso;
                sopralluogo.TotaleCostiSostenuti = (double)TotaleCostiSostenuti;
                sopralluogo.NumeroMiniGsmRichiesti = TotaleMiniGsm;
                sopralluogo.NumeroMiniUmtsRichiesti = TotaleMiniUmts;
                sopralluogo.NumeroMiniLteRichiesti = TotaleMiniLte;
                sopralluogo.NumeroPicoUmts = TotalePicoUmts;
                sopralluogo.NumeroPicoLte = TotalePicoLte;
                sopralluogo.NumeroCompactGsmRichiesti = TotaleCompactGsm;
                sopralluogo.NumeroCompactUmtsRichiesti = TotaleCompactUmts;
                sopralluogo.NumeroCompactLteRichiesti = TotaleCompactLte;
                sopralluogo.NumeroApparatiFemto = TotaleFemto;
                sopralluogo.NumeroApparatiFemtoLte = TotaleFemtoLte;
                sopralluogo.NumeroApparatiDualBand = TotaleDualBand;
            }
            var result = _RCDDbContext.Update(sopralluogo);
            _RCDDbContext.SaveChanges();
        }

    }
}
