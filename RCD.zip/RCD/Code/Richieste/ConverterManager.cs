﻿using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;

namespace RCD.Code.Richieste
{
    public class ConverterManager
    {

        #region Enums
        public enum CardinalDirection
        {
            North,
            East,
            South,
            West
        }

        internal enum UTMLat
        {
            North = CardinalDirection.North,
            South = CardinalDirection.South
        }

        public enum CoordinateType
        {
            Latitude,
            Longitude
        }

        public enum UTMDatum
        {
            WGS84,
            NAD83,
            GRS80,
            WGS72,
            Australian1965,
            Krasovsky1940,
            NorthAmerican1927,
            International1924,
            Hayford1909,
            Clarke1880,
            Clarke1866,
            Airy1830,
            Bessel1841,
            Everest1830
        }
        #endregion

        #region Structures
        public class Coordinate
        {
            internal Int32 Degrees;
            internal Int32 Minutes;
            internal decimal Seconds;

            public CardinalDirection Direction;

            /// <summary>
            /// Costruttore per la creazione di una coordinata in formato Sessagesimale.
            /// </summary>
            /// <param name="Degrees"></param>
            /// <param name="Minutes"></param>
            /// <param name="seconds"></param>
            /// <param name="Direction">Specificare la direzione cardinale</param>
            public Coordinate(Int32 Degrees, Int32 Minutes, decimal seconds, CardinalDirection Direction)
            {
                this.Degrees = Degrees;
                this.Minutes = Minutes;
                this.Seconds = seconds;
                this.Direction = Direction;
            }

            /// <summary>
            ///  Costruttore per la creazione di una coordinata in formato Sessagesimale/Decimale.Sud e Ovest si esprimono con 
            ///  valori in negativo.
            /// </summary>
            /// <param name="Degrees">Gradi in formato decimale</param>
            /// <param name="Type">Specificare se si tratta di longitudine o latitudine</param>

            public Coordinate(double Degree, CoordinateType Type)
            {
                decimal Degrees = Convert.ToDecimal(Degree);
                Degrees = Math.Abs(Degrees);

                this.Degrees = Convert.ToInt32(decimal.Truncate(Degrees));
                this.Minutes = Convert.ToInt32(decimal.Truncate((Degrees - (decimal.Truncate(Degrees))) * 60m));
                this.Seconds = (Degrees - decimal.Truncate(Degrees) - Convert.ToDecimal(this.Minutes) / 60) * 3600;

                if (Type == CoordinateType.Latitude)
                {
                    if (Degrees > 90 || Degrees < -90)
                        throw new InvalidOperationException("La Latitudine deve essere compresa fra -90° e 90°");
                    this.Direction = Degrees < 0 ? CardinalDirection.South : CardinalDirection.North;
                }
                else
                {
                    if (Degrees > 180 || Degrees < -180)
                        throw new InvalidOperationException("La Longitudine deve essere compresa fra -180° e 180°");
                    this.Direction = Degrees < 0 ? CardinalDirection.West : CardinalDirection.East;
                }


            }

            public override string ToString()
            {
                return string.Format("{0}° {1}' {2:f3}\" {3}", Degrees, Minutes, Seconds, Direction);
            }

            private CardinalDirection FlipDirection(CardinalDirection Direction)
            {

                CardinalDirection _dir = Direction;
                switch (Direction)
                {
                    case CardinalDirection.North:
                        _dir = CardinalDirection.South;
                        break;
                    case CardinalDirection.East:
                        _dir = CardinalDirection.West;
                        break;
                    case CardinalDirection.South:
                        _dir = CardinalDirection.North;
                        break;
                    case CardinalDirection.West:
                        _dir = CardinalDirection.East;
                        break;
                }
                return _dir;
            }

            internal decimal GetAbsoluteDecimalCoordinate()
            {
                return Convert.ToDecimal(Degrees) + Convert.ToDecimal(Minutes) / 60m + Seconds / 3600m;
            }

            internal decimal GetDecimalCoordinate()
            {
                decimal dec = Convert.ToDecimal(Degrees) + Convert.ToDecimal(Minutes) / 60m + Seconds / 3600m;
                return (Direction == CardinalDirection.North || Direction == CardinalDirection.East) ? dec : -dec;
            }
        }
        #endregion

        #region "UTM Object"
        public sealed class UTM
        {

            private const double k0 = 0.9996;
            private Coordinate cooLat = new Coordinate(0, CoordinateType.Latitude);
            private Coordinate cooLong = new Coordinate(0, CoordinateType.Longitude);
            private UTMDatum utmDat;
            private double dblNorthing = 0;
            private double dblEasting = 0;
            private UTMLat utmL = UTMLat.North;

            private Int32 intZone;
            #region "Properties"

 
            public Coordinate Latitude
            {
                get { return cooLat; }
            }

            public Coordinate Longitude
            {
                get { return cooLong; }
            }

            public Int32 Zone
            {
                get { return intZone; }
                set
                {
                    intZone = value;
                    GetLatLong();
                }
            }

            public double Easting
            {
                get { return dblEasting; }
                set
                {
                    dblEasting = value;
                    GetLatLong();
                }
            }

            public double Northing
            {
                get { return dblNorthing; }
                set
                {
                    dblNorthing = value;
                    GetLatLong();
                }
            }

            #endregion

            #region "Constructors"
            /// <summary>
            /// Utilizzare questo costruttore per Convertire le coordinate a UTM
            /// </summary>
            /// <param name="Latitude">Oggetto di tipo Coordinate per la Latitudine</param>
            /// <param name="Longitude">Oggetto di tipo Coordinate per la Longitudine</param>
            /// <param name="EllipsoidComputationModel">(Opzionale). Modello Ellissoidale di Calcolo</param>
            public UTM(Coordinate Latitude, Coordinate Longitude, UTMDatum EllipsoidComputationModel = UTMDatum.WGS84)
            {
                cooLat = Latitude;
                cooLong = Longitude;
                intZone = GetZone();
                utmDat = EllipsoidComputationModel;
                utmL = (UTMLat)cooLat.Direction;
                GetUTM();
            }
            /// <summary>
            /// Utilizzare questo costruttore per Convertire da UTM
            /// </summary>
            /// <param name="Northing">Latitudine in formato UTM (virgola mobile)</param>
            /// <param name="Easting">Latitudine in formato UTM (virgola mobile)</param>
            /// <param name="Zone">Zona di riferimento</param>
            /// <param name="EllipsoidComputationModel">(Opzionale). Modello Ellissoidale di Calcolo</param>
            public UTM(double Northing, double Easting, Int32 Zone, UTMDatum EllipsoidComputationModel = UTMDatum.WGS84)
            {
                dblNorthing = Northing;
                dblEasting = Easting;
                intZone = Zone;
                utmDat = EllipsoidComputationModel;
                GetLatLong();
            }
            #endregion

            internal Int32 GetZone()
            {
                decimal decLongAbs = cooLong.GetDecimalCoordinate();
                if (cooLong.Direction == CardinalDirection.West)
                {
                    return Convert.ToInt32(decimal.Ceiling((180 + decLongAbs) / 6));
                }
                else
                {
                    return Convert.ToInt32(decimal.Ceiling(decLongAbs / 6) + 30);
                }

            }

            internal Int32 GetZoneCM()
            {
                return 6 * intZone - 183;
            }

            internal void GetUTM()
            {
                double a = LookupA();
                double b = LookupB();
                double f = (a - b) / a;
                double invf = 1 / f;
                double rm = Math.Pow((a * b), 0.5);
                double e = Math.Sqrt(1 - Math.Pow((b / a), 2));
                double e1sq = Math.Pow(e, 2) / (1 - Math.Pow(e, 2));
                double n = (a - b) / (a + b);
                double latRad = ((Convert.ToDouble(cooLat.GetDecimalCoordinate()) * Math.PI) / 180);
                double rho = a * (1 - Math.Pow(e, 2)) / (Math.Pow((1 - Math.Pow((e * Math.Sin(latRad)), 2)), (3d / 2)));
                double nu = a / (Math.Pow((1 - Math.Pow((e * Math.Sin(latRad)), 2)), (1d / 2)));

                double a0 = a * (1 - n + (5d * n * n / 4d) * (1d - n) + (81d * Math.Pow(n, 4) / 64d) * (1d - n));
                double b0 = (3 * a * n / 2d) * (1 - n - (7 * n * n / 8d) * (1 - n) + 55 * Math.Pow(n, 4) / 64d);
                double c0 = (15 * a * n * n / 16d) * (1 - n + (3 * n * n / 4d) * (1 - n));
                double d0 = (35 * a * Math.Pow(n, 3) / 48d) * (1 - n + 11 * n * n / 16d);
                double e0 = (315 * a * Math.Pow(n, 4) / 51d) * (1 - n);
                double s = a0 * latRad - b0 * Math.Sin(2 * latRad) + c0 * Math.Sin(4 * latRad) - d0 * Math.Sin(6 * latRad) + e0 * Math.Sin(8 * latRad);

                double p = (double)((cooLong.GetDecimalCoordinate() - GetZoneCM()) * 3600 / 10000);
                double sin1 = Math.PI / (180 * 3600);

                double ki = s * k0;
                double kii = nu * Math.Sin(latRad) * Math.Cos(latRad) * Math.Pow(sin1, 2) * k0 * (100000000) / 2d;
                double kiii = ((Math.Pow(sin1, 4) * nu * Math.Sin(latRad) * Math.Pow(Math.Cos(latRad), 3)) / 24d) * (5 - Math.Pow(Math.Tan(latRad), 2) + 9 * e1sq * Math.Pow(Math.Cos(latRad), 2) + 4 * Math.Pow(e1sq, 2) * Math.Pow(Math.Cos(latRad), 4)) * k0 * (10000000000000000L);
                double kiv = nu * Math.Cos(latRad) * sin1 * k0 * 10000;
                double kv = Math.Pow((sin1 * Math.Cos(latRad)), 3) * (nu / 6d) * (1 - Math.Pow(Math.Tan(latRad), 2) + e1sq * Math.Pow(Math.Cos(latRad), 2)) * k0 * (1000000000000L);
                double a6 = (Math.Pow((p * sin1), 6) * nu * Math.Sin(latRad) * Math.Pow(Math.Cos(latRad), 5) / 720d) * (61 - 58 * Math.Pow(Math.Tan(latRad), 2) + Math.Pow(Math.Tan(latRad), 4) + 270 * e1sq * Math.Pow(Math.Cos(latRad), 2) - 330 * e1sq * Math.Pow(Math.Sin(latRad), 2)) * k0 * (1E+24);

                dblEasting = 500000 + (kiv * p + kv * Math.Pow(p, 3));
                dblNorthing = (ki + kii * p * p + kiii * Math.Pow(p, 4));
                if (cooLat.Direction == CardinalDirection.South)
                    dblNorthing = 10000000 + dblNorthing;
            }

            internal void GetLatLong()
            {
                double a = LookupA();
                double b = LookupB();
                double f = (a - b) / a;
                double invf = 1d / f;
                double rm = Math.Pow((a * b), 0.5);
                double ec = Math.Sqrt(1 - Math.Pow((b / a), 2));
                double eisq = Math.Pow(ec, 2) / (1 - Math.Pow(ec, 2));

                dblNorthing = utmL == UTMLat.North ? dblNorthing : 10000000 - dblNorthing;

                double arc = dblNorthing / k0;
                double mu = arc / (a * (1 - Math.Pow(ec, 2) / 4 - 3 * Math.Pow(ec, 4) / 64 - 5 * Math.Pow(ec, 6) / 256));
                double ei = (1 - Math.Pow((1 - ec * ec), (1d / 2))) / (1 + Math.Pow((1 - ec * ec), (1d / 2)));
                double ca = 3 * ei / 2 - 27 * Math.Pow(ei, 3) / 32;
                double cb = 21 * Math.Pow(ei, 2) / 16 - 55 * Math.Pow(ei, 4) / 32;
                double ccc = 151 * Math.Pow(ei, 3) / 96d;
                double cd = 1097 * Math.Pow(ei, 4) / 512d;
                double phi1 = mu + ca * Math.Sin(2 * mu) + cb * Math.Sin(4 * mu) + ccc * Math.Sin(6 * mu) + cd * Math.Sin(8 * mu);


                double q0 = eisq * Math.Pow(Math.Cos(phi1), 2);
                double t0 = Math.Pow(Math.Tan(phi1), 2);
                double n0 = a / Math.Pow((1 - Math.Pow((ec * Math.Sin(phi1)), 2)), (1d / 2));
                double r0 = a * (1 - ec * ec) / Math.Pow((1 - Math.Pow((ec * Math.Sin(phi1)), 2)), (3d / 2));
                double dd0 = (500000 - dblEasting) / (n0 * k0);

                double fact1 = n0 * Math.Tan(phi1) / r0;
                double fact2 = dd0 * dd0 / 2;
                double fact3 = (5 + 3 * t0 + 10 * q0 - 4 * q0 * q0 - 9 * eisq) * Math.Pow(dd0, 4) / 24d;
                double fact4 = (61 + 90 * t0 + 298 * q0 + 45 * t0 * t0 - 252 * eisq - 3 * q0 * q0) * Math.Pow(dd0, 6) / 720d;

                double lof1 = dd0;
                double lof2 = (1 + 2 * t0 + q0) * Math.Pow(dd0, 3) / 6d;
                double lof3 = (5 - 2 * q0 + 28 * t0 - 3 * Math.Pow(q0, 2) + 8 * eisq + 24 * Math.Pow(t0, 2)) * Math.Pow(dd0, 5) / 120d;

                double lat = 180 * (phi1 - fact1 * (fact2 + fact3 + fact4)) / Math.PI;
                if (utmL == UTMLat.South)
                    lat = -lat;
                cooLat = new Coordinate(lat, CoordinateType.Latitude);

                double lon = GetZoneCM() - ((lof1 - lof2 + lof3) / Math.Cos(phi1)) * 180 / Math.PI;

                cooLong = new Coordinate(lon, CoordinateType.Longitude);
            }

            private double LookupA()
            {

                switch (utmDat)
                {
                    case UTMDatum.NAD83:
                    case UTMDatum.WGS84:
                    case UTMDatum.GRS80:
                        return 6378137;
                    case UTMDatum.WGS72:
                        return 6378135;
                    case UTMDatum.Australian1965:
                        return 6378160;
                    case UTMDatum.Krasovsky1940:
                        return 6378245;
                    case UTMDatum.NorthAmerican1927:
                        return 6378206.4;
                    case UTMDatum.International1924:
                    case UTMDatum.Hayford1909:
                        return 6378388;
                    case UTMDatum.Clarke1880:
                        return 6378249.1;
                    case UTMDatum.Clarke1866:
                        return 6378206.4;
                    case UTMDatum.Bessel1841:
                        return 6377397.2;
                    case UTMDatum.Airy1830:
                        return 6377563.4;
                    case UTMDatum.Everest1830:
                        return 6377276.3;
                }
                return 0;
            }

            private double LookupB()
            {
                switch (utmDat)
                {
                    case UTMDatum.NAD83:
                    case UTMDatum.WGS84:
                        return 6356752.3142;
                    case UTMDatum.GRS80:
                        return 6356752.3141;
                    case UTMDatum.WGS72:
                        return 6356750.5;
                    case UTMDatum.Australian1965:
                        return 6356774.7;
                    case UTMDatum.Krasovsky1940:
                        return 6356863;
                    case UTMDatum.NorthAmerican1927:
                        return 6356583.8;
                    case UTMDatum.International1924:
                    case UTMDatum.Hayford1909:
                        return 6356911.9;
                    case UTMDatum.Clarke1880:
                        return 6356514.9;
                    case UTMDatum.Clarke1866:
                        return 6356583.8;
                    case UTMDatum.Bessel1841:
                        return 6356079;
                    case UTMDatum.Airy1830:
                        return 6356256.9;
                    case UTMDatum.Everest1830:
                        return 6356075.4;
                }
                return 0;
            }

        }
        #endregion
    }
}
