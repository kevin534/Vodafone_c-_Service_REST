﻿using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;

namespace RCD.Code.Richieste
{
    public class ListaRichiesteManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;


        public ListaRichiesteManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        /// <summary>
        /// Restituisce la lista delle richieste (vista report_richieste), se parametro isKo è true 
        /// restituisce solo le richieste con ultimo stato KO, altrimenti se isKo è false restituisce tutte le richieste
        /// </summary>
        /// <param name="vwReportRichiestaR"></param>
        /// <param name="isKo"></param>
        /// <returns></returns>
        public async Task<List<ContractViewReportRichieste>> GetViewReportRichieste(ViewRichiesteRequestFull vwReportRichiestaR, Boolean isKo, long idUtente)
        {
            List<EntityViewReportRichieste> vwReportRichieste;

            Amministrazione.UtentiManager utentiManager;
            EntityUtente utente;
            bool conditStatiKo_reg = false;
            bool conditStatiKo_prov = false;

            // REPORT KO
            if (isKo == true)
            {
                utentiManager = new Amministrazione.UtentiManager(_RCDDbContext);
                utente = await utentiManager.GetUtenteById(idUtente);
                if (utente != null)
                {
                    if (utente.IdZona != null)
                    {
                        vwReportRichiestaR.IdRegioni = GetRegionByIdZona(utente.IdZona);
                        vwReportRichiestaR.StatiKo = ListStatoKO(); // { 2, 5, 7, 9, 13, 14 };

                        if (vwReportRichiestaR.StatiKo != null && vwReportRichiestaR.IdRegioni != null)
                            conditStatiKo_reg = vwReportRichiestaR.StatiKo.Any() && vwReportRichiestaR.IdRegioni.Any();
                    }
                    else
                    {
                        vwReportRichiestaR.IdProvince = GetUtentiProvinceByUtente(utente);
                        vwReportRichiestaR.StatiKo = ListStatoKO();

                        if (vwReportRichiestaR.StatiKo != null && vwReportRichiestaR.IdProvince != null)
                            conditStatiKo_prov = isKo && vwReportRichiestaR.StatiKo.Any() && vwReportRichiestaR.IdProvince.Any();
                    }
                }

            }

            String sortParam = String.Concat(String.Concat(vwReportRichiestaR.CampoOrdinamento, " "), vwReportRichiestaR.Ordinamento.ToUpper());

            if (vwReportRichiestaR.Pageable)
            {
                vwReportRichieste = await _RCDDbContext.ViewReportRichieste
                    .WhereIf(conditStatiKo_reg, q => vwReportRichiestaR.StatiKo.Contains(q.IdUltimoStato.Value) && vwReportRichiestaR.IdRegioni.Contains(q.IdRegioneVF.Value))
                    .WhereIf(conditStatiKo_prov, q => vwReportRichiestaR.StatiKo.Contains(q.IdUltimoStato.Value) && vwReportRichiestaR.IdProvince.Contains(q.IdProvincia.Value))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Equals(vwReportRichiestaR.Filter.DataRichiesta))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                    .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                    .Skip(vwReportRichiestaR.NumeroElementi * vwReportRichiestaR.Page).Take(vwReportRichiestaR.NumeroElementi)
                    .Include("Richiesta")
                    .Include("Richiesta.Sopralluogo")
                    .OrderBy(sortParam)
                    .ToListAsync();

                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.ToString().Equals(vwReportRichiestaR.Filter.DataRichiesta.ToString("yyyy-MM-ddTHH:mm:ss.fff")))

                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Richiedente), q => q.Richiedente.Contains(vwReportRichiestaR.Filter.Richiedente))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCopertura), q => q.TipologiaCopertura.Contains(vwReportRichiestaR.Filter.TipologiaCopertura))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaRichiesto), q => q.SistemaRichiesto.Contains(vwReportRichiestaR.Filter.SistemaRichiesto))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.ServizioRichiesto), q => q.ServizioRichiesto.Contains(vwReportRichiestaR.Filter.ServizioRichiesto))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.MancanzaSegnaleEsterno), q => q.MancanzaSegnaleEsterno.Contains(vwReportRichiestaR.Filter.MancanzaSegnaleEsterno))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.MancanzaSegnaleInterno), q => q.MancanzaSegnaleInterno.Contains(vwReportRichiestaR.Filter.MancanzaSegnaleInterno))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StabileDiProprieta.ToString()), q => q.StabileDiProprieta.Equals(vwReportRichiestaR.Filter.StabileDiProprieta))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaStabile), q => q.TipologiaStabile.Contains(vwReportRichiestaR.Filter.TipologiaStabile))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.MetriQuadriDaCoprire.ToString()), q => q.MetriQuadriDaCoprire.Equals(vwReportRichiestaR.Filter.MetriQuadriDaCoprire))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PianiDaCoprire.ToString()), q => q.PianiDaCoprire.Equals(vwReportRichiestaR.Filter.PianiDaCoprire))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AccessibilitaTetto), q => q.AccessibilitaTetto.Contains(vwReportRichiestaR.Filter.AccessibilitaTetto))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DisponibilitaOspitareRepeater.ToString()), q => q.DisponibilitaOspitareRepeater.Equals(vwReportRichiestaR.Filter.DisponibilitaOspitareRepeater))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.MotivoRichiesta), q => q.MotivoRichiesta.Contains(vwReportRichiestaR.Filter.MotivoRichiesta))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCliente), q => q.TipologiaCliente.Contains(vwReportRichiestaR.Filter.TipologiaCliente))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUtente.ToString()), q => q.IdUtente.Equals(vwReportRichiestaR.Filter.IdUtente))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdRegioneVF.ToString()), q => q.IdRegioneVF.Equals(vwReportRichiestaR.Filter.IdRegioneVF))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Equals(vwReportRichiestaR.Filter.DataUltimaModifica))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaLTE.ToString()), q => q.SistemaLTE.Equals(vwReportRichiestaR.Filter.SistemaLTE))

                //.OrderBy(sortParam)

            }
            else
            {
                _RCDDbContext.Database.SetCommandTimeout(300);
                vwReportRichieste = await _RCDDbContext.ViewReportRichieste
                .WhereIf(conditStatiKo_reg, q => vwReportRichiestaR.StatiKo.Contains(q.IdUltimoStato.Value) && vwReportRichiestaR.IdRegioni.Contains(q.IdRegioneVF.Value))
                .WhereIf(conditStatiKo_prov, q => vwReportRichiestaR.StatiKo.Contains(q.IdUltimoStato.Value) && vwReportRichiestaR.IdProvince.Contains(q.IdProvincia.Value))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Equals(vwReportRichiestaR.Filter.DataRichiesta))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                .OrderBy(sortParam)
                .Include("Richiesta")
                .Include("Richiesta.Sopralluogo")
               .ToListAsync();
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Richiedente), q => q.Richiedente.Contains(vwReportRichiestaR.Filter.Richiedente))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCopertura), q => q.TipologiaCopertura.Contains(vwReportRichiestaR.Filter.TipologiaCopertura))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaRichiesto), q => q.SistemaRichiesto.Contains(vwReportRichiestaR.Filter.SistemaRichiesto))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.ServizioRichiesto), q => q.ServizioRichiesto.Contains(vwReportRichiestaR.Filter.ServizioRichiesto))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.MancanzaSegnaleEsterno), q => q.MancanzaSegnaleEsterno.Contains(vwReportRichiestaR.Filter.MancanzaSegnaleEsterno))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.MancanzaSegnaleInterno), q => q.MancanzaSegnaleInterno.Contains(vwReportRichiestaR.Filter.MancanzaSegnaleInterno))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StabileDiProprieta.ToString()), q => q.StabileDiProprieta.Equals(vwReportRichiestaR.Filter.StabileDiProprieta))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaStabile), q => q.TipologiaStabile.Contains(vwReportRichiestaR.Filter.TipologiaStabile))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.MetriQuadriDaCoprire.ToString()), q => q.MetriQuadriDaCoprire.Equals(vwReportRichiestaR.Filter.MetriQuadriDaCoprire))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PianiDaCoprire.ToString()), q => q.PianiDaCoprire.Equals(vwReportRichiestaR.Filter.PianiDaCoprire))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AccessibilitaTetto), q => q.AccessibilitaTetto.Contains(vwReportRichiestaR.Filter.AccessibilitaTetto))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DisponibilitaOspitareRepeater.ToString()), q => q.DisponibilitaOspitareRepeater.Equals(vwReportRichiestaR.Filter.DisponibilitaOspitareRepeater))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.MotivoRichiesta), q => q.MotivoRichiesta.Contains(vwReportRichiestaR.Filter.MotivoRichiesta))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCliente), q => q.TipologiaCliente.Contains(vwReportRichiestaR.Filter.TipologiaCliente))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUtente.ToString()), q => q.IdUtente.Equals(vwReportRichiestaR.Filter.IdUtente))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdRegioneVF.ToString()), q => q.IdRegioneVF.Equals(vwReportRichiestaR.Filter.IdRegioneVF))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Equals(vwReportRichiestaR.Filter.DataUltimaModifica))
                //.WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaLTE.ToString()), q => q.SistemaLTE.Equals(vwReportRichiestaR.Filter.SistemaLTE))

                // .OrderBy(sortParam)

            }

            List<ContractViewReportRichieste> richiesteElenco = new List<ContractViewReportRichieste>();
            foreach (EntityViewReportRichieste varVwReportRichiesta in vwReportRichieste)
            {
                ContractViewReportRichieste vwReportRichiesta1 = new ContractViewReportRichieste();
                UtilityManager.MapProp(varVwReportRichiesta, vwReportRichiesta1);
                richiesteElenco.Add(vwReportRichiesta1);
            }
            return richiesteElenco;
        }

        public async Task<Int32> GetViewReportRichiesteTot(ViewRichiesteRequestFull vwReportRichiestaR, Boolean isKo, long idUtente)
        {
            List<EntityViewReportRichieste> vwReportRichieste;

            Amministrazione.UtentiManager utentiManager;
            EntityUtente utente;
            bool conditStatiKo_reg = false;
            bool conditStatiKo_prov = false;


            // REPORT KO
            if (isKo == true)
            {
                utentiManager = new Amministrazione.UtentiManager(_RCDDbContext);
                utente = await utentiManager.GetUtenteById(idUtente);
                if (utente != null)
                {
                    utente.Zona = GetZonaByIdZona(utente.IdZona);
                    if (utente.Zona != null)
                    {
                        vwReportRichiestaR.IdRegioni = GetRegionByIdZona(utente.IdZona);
                        vwReportRichiestaR.StatiKo = ListStatoKO(); // { 2, 5, 7, 9, 13, 14 };

                        if (vwReportRichiestaR.StatiKo != null && vwReportRichiestaR.IdRegioni != null)
                            conditStatiKo_reg = vwReportRichiestaR.StatiKo.Any() && vwReportRichiestaR.IdRegioni.Any();
                    }
                    else
                    {
                        vwReportRichiestaR.IdProvince = GetUtentiProvinceByUtente(utente);
                        vwReportRichiestaR.StatiKo = ListStatoKO();

                        if (vwReportRichiestaR.StatiKo != null && vwReportRichiestaR.IdProvince != null)
                            conditStatiKo_prov = isKo && vwReportRichiestaR.StatiKo.Any() && vwReportRichiestaR.IdProvince.Any();
                    }
                }

            }

            Int32 count = _RCDDbContext.ViewReportRichieste
                 .WhereIf(conditStatiKo_reg, q => vwReportRichiestaR.StatiKo.Contains(q.IdUltimoStato.Value) && vwReportRichiestaR.IdRegioni.Contains(q.IdRegioneVF.Value))
                 .WhereIf(conditStatiKo_prov, q => vwReportRichiestaR.StatiKo.Contains(q.IdUltimoStato.Value) && vwReportRichiestaR.IdProvince.Contains(q.IdProvincia.Value))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Id.ToString()), q => q.Id.Equals(vwReportRichiestaR.Filter.Id))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.UltimoStato), q => q.UltimoStato.Equals(vwReportRichiestaR.Filter.UltimoStato))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdUltimoStato.ToString()), q => q.IdUltimoStato.Equals(vwReportRichiestaR.Filter.IdUltimoStato))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Zona), q => q.Zona.Contains(vwReportRichiestaR.Filter.Zona))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceNazionale), q => q.CodiceNazionale.Contains(vwReportRichiestaR.Filter.CodiceNazionale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CodiceCliente), q => q.CodiceCliente.Contains(vwReportRichiestaR.Filter.CodiceCliente))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PartitaIVA), q => q.PartitaIVA.Contains(vwReportRichiestaR.Filter.PartitaIVA))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RagioneSociale), q => q.RagioneSociale.Contains(vwReportRichiestaR.Filter.RagioneSociale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(vwReportRichiestaR.Filter.NomeInstallazione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Indirizzo), q => q.Indirizzo.Contains(vwReportRichiestaR.Filter.Indirizzo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Comune), q => q.Comune.Contains(vwReportRichiestaR.Filter.Comune))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AreaVendite), q => q.AreaVendite.Contains(vwReportRichiestaR.Filter.AreaVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori), q => q.CoperturaIndoorAltriGestori.Contains(vwReportRichiestaR.Filter.CoperturaIndoorAltriGestori))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Provincia), q => q.Provincia.Contains(vwReportRichiestaR.Filter.Provincia))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.IdProvincia.ToString()), q => q.IdProvincia.Equals(vwReportRichiestaR.Filter.IdProvincia))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Regione), q => q.Regione.Contains(vwReportRichiestaR.Filter.Regione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Equals(vwReportRichiestaR.Filter.DataRichiesta))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoStimata.ToString()), q => q.DataSopralluogoStimata.Equals(vwReportRichiestaR.Filter.DataSopralluogoStimata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata.ToString()), q => q.DataSopralluogoConsuntivata.Equals(vwReportRichiestaR.Filter.DataSopralluogoConsuntivata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirStimata.ToString()), q => q.DataOnAirStimata.Equals(vwReportRichiestaR.Filter.DataOnAirStimata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataOnAirConsuntivata.ToString()), q => q.DataOnAirConsuntivata.Equals(vwReportRichiestaR.Filter.DataOnAirConsuntivata))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta.ToString()), q => q.DataInvioIncaricoVersoDitta.Equals(vwReportRichiestaR.Filter.DataInvioIncaricoVersoDitta))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DittaInstallatrice), q => q.DittaInstallatrice.Contains(vwReportRichiestaR.Filter.DittaInstallatrice))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.StudioProgettazione), q => q.StudioProgettazione.Contains(vwReportRichiestaR.Filter.StudioProgettazione))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RAN), q => q.RAN.Contains(vwReportRichiestaR.Filter.RAN))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NI), q => q.NI.Contains(vwReportRichiestaR.Filter.NI))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.InseritoDa), q => q.InseritoDa.Contains(vwReportRichiestaR.Filter.InseritoDa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoAM), q => q.RiferimentoAM.Contains(vwReportRichiestaR.Filter.RiferimentoAM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoVendite), q => q.RiferimentoVendite.Contains(vwReportRichiestaR.Filter.RiferimentoVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVendita), q => q.CanaleVendita.Contains(vwReportRichiestaR.Filter.CanaleVendita))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CanaleVenditaDettaglio), q => q.CanaleVenditaDettaglio.Contains(vwReportRichiestaR.Filter.CanaleVenditaDettaglio))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.DistrettoVendite), q => q.DistrettoVendite.Contains(vwReportRichiestaR.Filter.DistrettoVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.Distretto), q => q.Distretto.Contains(vwReportRichiestaR.Filter.Distretto))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.AgenziaRiferimento), q => q.AgenziaRiferimento.Contains(vwReportRichiestaR.Filter.AgenziaRiferimento))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RDAEmessa.ToString()), q => q.RDAEmessa.Equals(vwReportRichiestaR.Filter.RDAEmessa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroODA), q => q.NumeroODA.Contains(vwReportRichiestaR.Filter.NumeroODA))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NCLEmessa.ToString()), q => q.NCLEmessa.Equals(vwReportRichiestaR.Filter.NCLEmessa))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroNCL), q => q.NumeroNCL.Contains(vwReportRichiestaR.Filter.NumeroNCL))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMini.ToString()), q => q.TotaleMini.Equals(vwReportRichiestaR.Filter.TotaleMini))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleCompact.ToString()), q => q.TotaleCompact.Equals(vwReportRichiestaR.Filter.TotaleCompact))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleMaxi.ToString()), q => q.TotaleMaxi.Equals(vwReportRichiestaR.Filter.TotaleMaxi))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleFemTo.ToString()), q => q.TotaleFemTo.Equals(vwReportRichiestaR.Filter.TotaleFemTo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiNuovi.ToString()), q => q.TotaleApparatiNuovi.Equals(vwReportRichiestaR.Filter.TotaleApparatiNuovi))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TotaleApparatiRiuso.ToString()), q => q.TotaleApparatiRiuso.Equals(vwReportRichiestaR.Filter.TotaleApparatiRiuso))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGSM.ToString()), q => q.SistemaGSM.Equals(vwReportRichiestaR.Filter.SistemaGSM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTS.ToString()), q => q.SistemaUMTS.Equals(vwReportRichiestaR.Filter.SistemaUMTS))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaUMTSLTE.ToString()), q => q.SistemaUMTSLTE.Equals(vwReportRichiestaR.Filter.SistemaUMTSLTE))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmUmts.ToString()), q => q.SistemaGsmUmts.Equals(vwReportRichiestaR.Filter.SistemaGsmUmts))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.SistemaGsmLTE.ToString()), q => q.SistemaGsmLTE.Equals(vwReportRichiestaR.Filter.SistemaGsmLTE))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoPreventivo.ToString()), q => q.CostoPreventivo.Equals(vwReportRichiestaR.Filter.CostoPreventivo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.CostoConsuntivo.ToString()), q => q.CostoConsuntivo.Equals(vwReportRichiestaR.Filter.CostoConsuntivo))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TipologiaCantiere), q => q.TipologiaCantiere.Contains(vwReportRichiestaR.Filter.TipologiaCantiere))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.VincoliAreaPresenti.ToString()), q => q.VincoliAreaPresenti.Equals(vwReportRichiestaR.Filter.VincoliAreaPresenti))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PermessoNecessario.ToString()), q => q.PermessoNecessario.Equals(vwReportRichiestaR.Filter.PermessoNecessario))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroSIM.ToString()), q => q.NumeroSIM.Equals(vwReportRichiestaR.Filter.NumeroSIM))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.FatturatoMedioBimestrale.ToString()), q => q.FatturatoMedioBimestrale.Equals(vwReportRichiestaR.Filter.FatturatoMedioBimestrale))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.NumeroInterniVRUC.ToString()), q => q.NumeroInterniVRUC.Equals(vwReportRichiestaR.Filter.NumeroInterniVRUC))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrevistaVruVruc.ToString()), q => q.PrevistaVruVruc.Equals(vwReportRichiestaR.Filter.PrevistaVruVruc))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.PrioritaVendite), q => q.PrioritaVendite.Contains(vwReportRichiestaR.Filter.PrioritaVendite))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.RiferimentoDce), q => q.RiferimentoDce.Contains(vwReportRichiestaR.Filter.RiferimentoDce))
                 .WhereIf(!String.IsNullOrEmpty(vwReportRichiestaR.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(vwReportRichiestaR.Filter.TelefonoRiferimento))
                .Count();

            return count;//vwReportRichieste.Count();

        }

        public async Task<ContractRichiesta> GetRichiestaInstallazioneById(RichiestaRequestFull richiestaR)
        {
            List<EntityRichiesta> richieste;
            //bool conditionInstallazione = richiestaR.Filter.Richiesta.Installazione is not null;

            String sortParam = String.Concat(String.Concat(richiestaR.CampoOrdinamento, " "), richiestaR.Ordinamento.ToUpper());

            if (richiestaR.Pageable)
            {

                richieste = await _RCDDbContext.Richieste
                    .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.Id.ToString()), q => q.Id.Equals(richiestaR.Filter.Id))
                    .Include("Installazione")
                    .Include("Installazione.Ditta")
                    .Include("Installazione.TipologiaCosto")
                    .Skip(richiestaR.NumeroElementi * richiestaR.Page).Take(richiestaR.NumeroElementi)
                    .ToListAsync();


            }
            else
            {
                richieste = await _RCDDbContext.Richieste
                .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.Id.ToString()), q => q.Id.Equals(richiestaR.Filter.Id))
                .Include("Installazione")
                .Include("Installazione.Ditta")
                .Include("Installazione.TipologiaCosto")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractRichiesta> richiesteElenco = new List<ContractRichiesta>();
            foreach (EntityRichiesta varRichiesta in richieste)
            {
                ContractRichiesta richiesta1 = new ContractRichiesta();
                UtilityManager.MapProp(varRichiesta, richiesta1);
                richiesteElenco.Add(richiesta1);
            }
            return richiesteElenco[0];
        }


        public async Task<ContractRichiesta> GetRichiestaLocationById(RichiestaRequestFull richiestaR)
        {
            List<EntityRichiesta> richieste;

            String sortParam = String.Concat(String.Concat(richiestaR.CampoOrdinamento, " "), richiestaR.Ordinamento.ToUpper());

            if (richiestaR.Pageable)
            {

                richieste = await _RCDDbContext.Richieste
                    .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.Id.ToString()), q => q.Id.Equals(richiestaR.Filter.Id))
                    .OrderBy(sortParam)
                    .Include("Location")
                    .Include("Location.TipologiaStabile")
                    .Include("Location.AccessibilitaTetto")
                    .Include("Location.Gestori")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF")
                    //.Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")    // dà eccezione in utility manager
                    .Skip(richiestaR.NumeroElementi * richiestaR.Page).Take(richiestaR.NumeroElementi)
                    .ToListAsync();

            }
            else
            {
                richieste = await _RCDDbContext.Richieste
                    .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.Id.ToString()), q => q.Id.Equals(richiestaR.Filter.Id))
                    .Include("Location")
                    .Include("Location.TipologiaStabile")
                    .Include("Location.AccessibilitaTetto")
                    .Include("Location.Gestori")
                    .Include("Location.StsComune")
                    .Include("Location.StsComune.ProvinciaSts")
                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                    .Include("Location.StsComune.ProvinciaSts.Provincia")
                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF")
                //.Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")   // dà eccezione in utility manager
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractRichiesta> richiesteElenco = new List<ContractRichiesta>();
            foreach (EntityRichiesta varRichiesta in richieste)
            {
                ContractRichiesta richiesta1 = new ContractRichiesta();
                UtilityManager.MapProp(varRichiesta, richiesta1);
                richiesteElenco.Add(richiesta1);
            }
            return richiesteElenco[0];
        }

        public async Task<List<ContractRichiesta>> GetRichiesteAttesaOkSopralluogo(RichiestaRequestFull richiestaR, long idUtente)
        {
            String sortParam = String.Concat(String.Concat(richiestaR.CampoOrdinamento, " "), richiestaR.Ordinamento.ToUpper());

            Amministrazione.UtentiManager utentiManager;
            EntityUtente utente;

            utentiManager = new Amministrazione.UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);
            List<ContractRichiesta> richiesteElenco = new List<ContractRichiesta>();
            List<EntityRichiesta> richieste;

            if (utente != null)
            {
                bool? conditionIsVendita = utente.TipologiaUtente.IsVendita;
                List<Int64?> utentiProvince = _RCDDbContext.UtentiProvince.WhereIf(utente != null && utente.IdZona == null, q => q.IdUtente == utente.Id).Select(q => q.Id).ToList();


                if (utente.IdZona != null)
                {
                    var regioni = GetRegionByIdZona(utente.IdZona);

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    if (richiestaR.Pageable)
                    {

                        richieste = await _RCDDbContext.Richieste
                                    .WhereIf(regioni is not null, x => x.LastStatusId == 1 && regioni.Contains(x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))
                                    .WhereIf(conditionIsVendita == true, q => q.Richiedente.AreaVendite.Id == utente.AreaVendita.Id)
                     .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiestaR.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))

                     .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiestaR.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiestaR.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiestaR.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiestaR.Filter.Location.Indirizzo))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiestaR.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiestaR.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiestaR.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiestaR.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiestaR.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiestaR.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiestaR.Filter.Utente != null && !String.IsNullOrEmpty(richiestaR.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiestaR.Filter.Utente.FullName))
                    .WhereIf(richiestaR.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiestaR.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiestaR.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiestaR.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiestaR.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiestaR.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiestaR.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiestaR.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiestaR.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiestaR.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiestaR.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiestaR.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiestaR.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiestaR.Filter.Location.NomeInstallazione))
                                    .Include("Richiedente")
                                    .Include("Utente")
                                    .Include("Location")
                                    .Include("Richiedente.TipologiaCliente")
                                    .Include("Location.StsComune")
                                    .Include("Location.StsComune.ProvinciaSts")
                                    .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                                    .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                                    .Include("Richiedente.CanaleVendita")
                                    .Include("Richiedente.CanaleVenditaDettaglio")
                                    .Include("Richiedente.AreaVendite")
                                    .Include("RiferimentoAreaManager")
                                    .Include("RiferimentoVendite")
                                    .Include("SistemaRichiesto")
                                    .Include("RiferimentoVendite")
                                    .Include("Sopralluogo")
                                    .Include("Sopralluogo.Ditta")
                                    //  .Include("StatiRichiesta")  
                                    //  .Include("StatiRichiesta.Stato")     
                                    .Skip(richiestaR.NumeroElementi * richiestaR.Page).Take(richiestaR.NumeroElementi)
                                    .OrderBy(sortParam)
                                    .ToListAsync();
                    }
                    else
                    {

                        richieste = await _RCDDbContext.Richieste
                                .WhereIf(regioni is not null, x => x.LastStatusId == 1 && regioni.Contains(x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))
                                .WhereIf(conditionIsVendita == true, q => q.Richiedente.AreaVendite.Id == utente.AreaVendita.Id)
                     .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiestaR.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))

                     .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiestaR.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiestaR.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiestaR.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiestaR.Filter.Location.Indirizzo))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiestaR.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiestaR.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiestaR.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiestaR.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiestaR.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiestaR.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiestaR.Filter.Utente != null && !String.IsNullOrEmpty(richiestaR.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiestaR.Filter.Utente.FullName))
                    .WhereIf(richiestaR.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiestaR.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiestaR.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiestaR.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiestaR.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiestaR.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiestaR.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiestaR.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiestaR.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiestaR.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiestaR.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiestaR.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiestaR.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiestaR.Filter.Location.NomeInstallazione))
                    .Include("Richiedente")
                                .Include("Utente")
                                .Include("Location")
                                .Include("Richiedente.TipologiaCliente")
                                .Include("Location.StsComune")
                                .Include("Location.StsComune.ProvinciaSts")
                                .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                                .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                                .Include("Richiedente.CanaleVendita")
                                .Include("Richiedente.CanaleVenditaDettaglio")
                                .Include("Richiedente.AreaVendite")
                                .Include("RiferimentoAreaManager")
                                .Include("RiferimentoVendite")
                                .Include("SistemaRichiesto")
                                .Include("RiferimentoVendite")
                                .Include("Sopralluogo")
                                .Include("Sopralluogo.Ditta")
                          //  .Include("StatiRichiesta")  
                          //   .Include("StatiRichiesta.Stato")     
                                .OrderBy(sortParam)
                                .ToListAsync();
                    }
                }
                else  //if utente.UtenteProvincia.Count > 0
                if (utentiProvince.Count > 0)
                {

                    var province = GetUtentiProvinceByUtente(utente);


                    //var province = cqGetIdProvinceByIdUtente(this, userId);

                    var richieste2 = from r in _RCDDbContext.Richieste
                                     join v in _RCDDbContext.ViewRichiestaStatoProvincia on r.Id equals v.IdRichiesta
                                     where 1 == v.IdStatoRichiesta && province.Contains(v.IdProvinciaSts.Value)
                                     select r;

                    _RCDDbContext.Database.SetCommandTimeout(300);
                    if (richiestaR.Pageable)
                    {
                   
                        richieste = richieste2
                            .WhereIf(conditionIsVendita == true && (utente.AreaVendita is not null), q => q.Richiedente.AreaVendite.Id == utente.AreaVendita.Id)
                     .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiestaR.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))

                     .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiestaR.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiestaR.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiestaR.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiestaR.Filter.Location.Indirizzo))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiestaR.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiestaR.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiestaR.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiestaR.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiestaR.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiestaR.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiestaR.Filter.Utente != null && !String.IsNullOrEmpty(richiestaR.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiestaR.Filter.Utente.FullName))
                    .WhereIf(richiestaR.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiestaR.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiestaR.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiestaR.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiestaR.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiestaR.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiestaR.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiestaR.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiestaR.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiestaR.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiestaR.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiestaR.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiestaR.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiestaR.Filter.Location.NomeInstallazione))
                    .Include("Richiedente")                   
                            .Include("Utente")
                            .Include("Location")
                            .Include("Richiedente.TipologiaCliente")
                            .Include("Location.StsComune")
                            .Include("Location.StsComune.ProvinciaSts")
                            .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                            .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                            .Include("Richiedente.CanaleVendita")
                            .Include("Richiedente.CanaleVenditaDettaglio")
                            .Include("Richiedente.AreaVendite")
                            .Include("RiferimentoAreaManager")
                            .Include("RiferimentoVendite")
                            .Include("SistemaRichiesto")
                            .Include("RiferimentoVendite")
                            .Include("Sopralluogo")
                            .Include("Sopralluogo.Ditta")
                            .Skip(richiestaR.NumeroElementi * richiestaR.Page).Take(richiestaR.NumeroElementi)
                            .OrderBy(sortParam)
                            .ToList();

                    }
                    else   //!richiestaR.Pageable
                    {
                        richieste = richieste2
                            .WhereIf(conditionIsVendita == true && (utente.AreaVendita is not null), q => q.Richiedente.AreaVendite.Id == utente.AreaVendita.Id)
                     .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiestaR.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))

                     .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiestaR.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiestaR.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiestaR.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiestaR.Filter.Location.Indirizzo))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiestaR.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiestaR.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiestaR.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiestaR.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiestaR.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiestaR.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiestaR.Filter.Utente != null && !String.IsNullOrEmpty(richiestaR.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiestaR.Filter.Utente.FullName))
                    .WhereIf(richiestaR.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiestaR.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiestaR.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiestaR.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiestaR.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiestaR.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiestaR.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiestaR.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiestaR.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiestaR.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiestaR.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiestaR.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiestaR.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiestaR.Filter.Location.NomeInstallazione))
                    .Include("Richiedente")
                            .Include("Utente")
                            .Include("Location")
                            .Include("Richiedente.TipologiaCliente")
                            .Include("Location.StsComune")
                            .Include("Location.StsComune.ProvinciaSts")
                            .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                            .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                            .Include("Richiedente.CanaleVendita")
                            .Include("Richiedente.CanaleVenditaDettaglio")
                            .Include("Richiedente.AreaVendite")
                            .Include("RiferimentoAreaManager")
                            .Include("RiferimentoVendite")
                            .Include("SistemaRichiesto")
                            .Include("RiferimentoVendite")
                            .Include("Sopralluogo")
                            .Include("Sopralluogo.Ditta")
                            .OrderBy(sortParam)
                            .ToList();

                    }
                }
                else
                {
                    richieste = null;
                }

                //user.TipologiaUtente.IsVendita
               // List<EntityRichiesta> richiesta3 = new List<EntityRichiesta>();
                //if ((conditionIsVendita == true) && (utente.AreaVendita is not null))
                //{
                //    var richiesteN = from r in richieste
                //                where r.Richiedente.AreaVendite.Id == utente.AreaVendita.Id
                //                select r;
                //    richieste = richiesteN.OrderByDescending(r => r.DataUltimaModifica).ToList();
                //}


                foreach (EntityRichiesta varRichiesta in richieste)
                {
                    ContractRichiesta richiesta1 = new ContractRichiesta();
                    UtilityManager.MapProp(varRichiesta, richiesta1);
                    richiesteElenco.Add(richiesta1);
                }
            }

            return richiesteElenco;
        }

        public async Task<Int32> GetRichiesteAttesaOkSopralluogoTot(RichiestaRequestFull richiestaR, long idUtente)
        {
          //  String sortParam = String.Concat(String.Concat(richiestaR.CampoOrdinamento, " "), richiestaR.Ordinamento.ToUpper());

            Amministrazione.UtentiManager utentiManager;
            EntityUtente utente;
            Int32 countRichieste = 0;

            utentiManager = new Amministrazione.UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);
            List<ContractRichiesta> richiesteElenco = new List<ContractRichiesta>();
            List<EntityRichiesta> richieste;

            if (utente != null)
            {
                bool? conditionIsVendita = utente.TipologiaUtente.IsVendita;
                if (utente.IdZona != null)
                {
                    var regioni = GetRegionByIdZona(utente.IdZona);

                    _RCDDbContext.Database.SetCommandTimeout(300);
                   

                        richieste = await _RCDDbContext.Richieste
                        .WhereIf(regioni is not null, x => x.LastStatusId == 1 && regioni.Contains(x.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))
                        .WhereIf(conditionIsVendita == true, q => q.Richiedente.AreaVendite.Id == utente.AreaVendita.Id)
                     .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiestaR.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))

                     .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiestaR.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiestaR.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiestaR.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiestaR.Filter.Location.Indirizzo))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiestaR.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiestaR.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiestaR.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiestaR.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiestaR.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiestaR.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiestaR.Filter.Utente != null && !String.IsNullOrEmpty(richiestaR.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiestaR.Filter.Utente.FullName))
                    .WhereIf(richiestaR.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiestaR.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiestaR.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiestaR.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiestaR.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiestaR.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiestaR.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiestaR.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiestaR.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiestaR.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiestaR.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiestaR.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiestaR.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiestaR.Filter.Location.NomeInstallazione))
                    .Include("Richiedente")
                            .Include("Utente")
                            .Include("Location")
                            .Include("Richiedente.TipologiaCliente")
                            .Include("Location.StsComune")
                            .Include("Location.StsComune.ProvinciaSts")
                            .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                            .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                            .Include("Richiedente.CanaleVendita")
                            .Include("Richiedente.CanaleVenditaDettaglio")
                            .Include("Richiedente.AreaVendite")
                            .Include("RiferimentoAreaManager")
                            .Include("RiferimentoVendite")
                            .Include("SistemaRichiesto")
                            .Include("RiferimentoVendite")
                            .Include("Sopralluogo")
                            .Include("Sopralluogo.Ditta")
                            .ToListAsync();
                }
                else  //if utente.UtenteProvincia.Count > 0
                if (utente.ListUtenteProvincia.Count > 0)
                {

                    var province = GetUtentiProvinceByUtente(utente);


                    //var province = cqGetIdProvinceByIdUtente(this, userId);

                    var richieste2 = from r in _RCDDbContext.Richieste
                                     join v in _RCDDbContext.ViewRichiestaStatoProvincia on r.Id equals v.IdRichiesta
                                     where 1 == v.IdStatoRichiesta && province.Contains(v.IdProvinciaSts.Value)
                                     select r;
                   
                    richieste = richieste2
                     .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.DataRichiesta.ToString()), q => q.DataRichiesta.Value.Date.Equals(richiestaR.Filter.DataRichiesta.GetValueOrDefault().Date))
                     .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.DataUltimaModifica.ToString()), q => q.DataUltimaModifica.Value.Date.Equals(richiestaR.Filter.DataUltimaModifica.GetValueOrDefault().Date))

                     .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.ProvinciaSts != null &&
                            richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia != null && richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF != null &&
                            richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null &&
                        !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.ToString()),
                        q => q.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Equals(richiestaR.Filter.Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CodiceCliente != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CodiceCliente.ToString()), q => q.Richiedente.CodiceCliente.Equals(richiestaR.Filter.Richiedente.CodiceCliente))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.PartitaIVA != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.PartitaIVA.ToString()), q => q.Richiedente.PartitaIVA.Equals(richiestaR.Filter.Richiedente.PartitaIVA))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.RagioneSociale != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.RagioneSociale.ToString()), q => q.Richiedente.RagioneSociale.Contains(richiestaR.Filter.Richiedente.RagioneSociale))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.Indirizzo != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.Indirizzo.ToString()), q => q.Location.Indirizzo.Equals(richiestaR.Filter.Location.Indirizzo))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.Descrizione != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.Descrizione.ToString()), q => q.Location.StsComune.Descrizione.Equals(richiestaR.Filter.Location.StsComune.Descrizione))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.StsComune != null && richiestaR.Filter.Location.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.StsComune.ProvinciaSts.Sigla.ToString()), q => q.Location.StsComune.ProvinciaSts.Sigla.Equals(richiestaR.Filter.Location.StsComune.ProvinciaSts.Sigla))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CanaleVendita != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CanaleVendita.Canale.ToString()), q => q.Richiedente.CanaleVendita.Canale.Equals(richiestaR.Filter.Richiedente.CanaleVendita.Canale))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.CanaleVenditaDettaglio != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione.ToString()), q => q.Richiedente.CanaleVenditaDettaglio.Descrizione.Equals(richiestaR.Filter.Richiedente.CanaleVenditaDettaglio.Descrizione))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.AreaVendite != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.AreaVendite.Descrizione.ToString()), q => q.Richiedente.AreaVendite.Descrizione.Equals(richiestaR.Filter.Richiedente.AreaVendite.Descrizione))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.AgenziaRiferimento != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.AgenziaRiferimento.ToString()), q => q.Richiedente.AgenziaRiferimento.Equals(richiestaR.Filter.Richiedente.AgenziaRiferimento))
                    .WhereIf(richiestaR.Filter.Utente != null && !String.IsNullOrEmpty(richiestaR.Filter.Utente.FullName.ToString()), q => q.Utente.FullName.Contains(richiestaR.Filter.Utente.FullName))
                    .WhereIf(richiestaR.Filter.RiferimentoVendite != null && !String.IsNullOrEmpty(richiestaR.Filter.RiferimentoVendite.FullName.ToString()), q => q.RiferimentoVendite.FullName.Contains(richiestaR.Filter.RiferimentoVendite.FullName))
                    .WhereIf(richiestaR.Filter.RiferimentoAreaManager != null && !String.IsNullOrEmpty(richiestaR.Filter.RiferimentoAreaManager.FullName.ToString()), q => q.RiferimentoAreaManager.FullName.Contains(richiestaR.Filter.RiferimentoAreaManager.FullName))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.NumeroSIM != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(richiestaR.Filter.Richiedente.NumeroSIM))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.FatturatoMedioBimestrale != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.FatturatoMedioBimestrale.ToString()), q => q.Richiedente.FatturatoMedioBimestrale.Equals(richiestaR.Filter.Richiedente.FatturatoMedioBimestrale))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.NumeroInterniVRUC != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(richiestaR.Filter.Richiedente.NumeroInterniVRUC))
                    .WhereIf(richiestaR.Filter.Richiedente != null && richiestaR.Filter.Richiedente.TipologiaCliente != null && !String.IsNullOrEmpty(richiestaR.Filter.Richiedente.TipologiaCliente.TipologiaCliente.ToString()), q => q.Richiedente.TipologiaCliente.TipologiaCliente.Equals(richiestaR.Filter.Richiedente.TipologiaCliente.TipologiaCliente))
                    .WhereIf(richiestaR.Filter.SistemaRichiesto != null && !String.IsNullOrEmpty(richiestaR.Filter.SistemaRichiesto.Sistema.ToString()), q => q.SistemaRichiesto.Sistema.Equals(richiestaR.Filter.SistemaRichiesto.Sistema))
                    .WhereIf(richiestaR.Filter.Location != null && richiestaR.Filter.Location.NomeInstallazione != null && !String.IsNullOrEmpty(richiestaR.Filter.Location.NomeInstallazione.ToString()), q => q.Location.NomeInstallazione.Contains(richiestaR.Filter.Location.NomeInstallazione))
                    .Include("Richiedente")
                                         .Include("Utente")
                                         .Include("Richiedente.TipologiaCliente")
                                         .Include("Location")
                                         .Include("Location.StsComune")
                                         .Include("Location.StsComune.ProvinciaSts")
                                         .Include("Location.StsComune.ProvinciaSts.RegioneSts")
                                         .Include("Location.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                                         .Include("Richiedente.CanaleVendita")
                                         .Include("Richiedente.CanaleVenditaDettaglio")
                                         .Include("Richiedente.AreaVendite")
                                         .Include("RiferimentoAreaManager")
                                         .Include("Sopralluogo")
                                         .Include("Sopralluogo.Ditta")
                                         .Include("SistemaRichiesto")
                                         .Include("RiferimentoVendite")
                                         .ToList();

                }
                else
                {
                    richieste = null;
                }

                //user.TipologiaUtente.IsVendita
                // List<EntityRichiesta> richiesta3 = new List<EntityRichiesta>();
                if ((conditionIsVendita == true) && (utente.AreaVendita is not null))
                {
                    var richiesteN = from r in richieste
                                     where r.Richiedente.AreaVendite.Id == utente.AreaVendita.Id
                                     select r;
                    richieste = richiesteN.OrderByDescending(r => r.DataUltimaModifica).ToList();
                }

                if (richieste is not null)
                    countRichieste = richieste.Count;
            }

            return countRichieste;
        }

        public async Task<ContractRichiesta> GetRichiestaUtentiById(RichiestaRequestFull richiestaR)
        {
            List<EntityRichiesta> richieste;


            String sortParam = String.Concat(String.Concat(richiestaR.CampoOrdinamento, " "), richiestaR.Ordinamento.ToUpper());

            if (richiestaR.Pageable)
            {

                richieste = await _RCDDbContext.Richieste
                    .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.Id.ToString()), q => q.Id.Equals(richiestaR.Filter.Id))
                    .Include("Utente")
                    .Include("Richiedente")
                    .Include("Richiedente.CanaleVendita")
                    .Include("Richiedente.CanaleVenditaDettaglio")
                    .Include("Richiedente.Area")
                    .Include("Richiedente.AreaVendite")
                    .Include("Richiedente.Distretto")
                    .Include("Richiedente.TipologiaCliente")
                    .Include("MotivoRichiesta")
                    .Include("RiferimentoVendite")
                    .Include("RiferimentoAreaManager")
                    .Include("RiferimentoDce")
                    .Include("PrioritaVendite")
                    .Include("TipologiaCopertura")
                    .Include("SistemaRichiesto")
                    .Include("Servizio")
                    .Include("MancanzaSegnaleEsterno")
                    .Include("MancanzaSegnaleInterno")
                    .Include("ProgettistaRan")
                    .Include("SiteManagerNI")
                    //  .Include("StatiRichiesta")  
                    //  .Include("StatiRichiesta.Stato")     
                    .Skip(richiestaR.NumeroElementi * richiestaR.Page).Take(richiestaR.NumeroElementi)
                    .ToListAsync();

            }
            else
            {
                richieste = await _RCDDbContext.Richieste
                   .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.Id.ToString()), q => q.Id.Equals(richiestaR.Filter.Id))
                   .Include("Utente")
                   .Include("Richiedente")
                   .Include("Richiedente.CanaleVendita")
                   .Include("Richiedente.CanaleVenditaDettaglio")
                   .Include("Richiedente.Area")
                   .Include("Richiedente.AreaVendite")
                   .Include("Richiedente.Distretto")
                   .Include("Richiedente.TipologiaCliente")
                   .Include("MotivoRichiesta")
                   .Include("RiferimentoVendite")
                   .Include("RiferimentoAreaManager")
                   .Include("RiferimentoDce")
                   .Include("PrioritaVendite")
                   .Include("TipologiaCopertura")
                   .Include("SistemaRichiesto")
                   .Include("Servizio")
                   .Include("MancanzaSegnaleEsterno")
                   .Include("MancanzaSegnaleInterno")
                   .Include("ProgettistaRan")
                   .Include("SiteManagerNI")
                   //  .Include("StatiRichiesta")  
                   //   .Include("StatiRichiesta.Stato")     
                   .OrderBy(sortParam)
                   .ToListAsync();

            }

            List<ContractRichiesta> richiesteElenco = new List<ContractRichiesta>();
            foreach (EntityRichiesta varRichiesta in richieste)
            {
                ContractRichiesta richiesta1 = new ContractRichiesta();
                UtilityManager.MapProp(varRichiesta, richiesta1);
                richiesteElenco.Add(richiesta1);
            }
            return richiesteElenco[0];
        }


        public async Task<ContractRichiesta> GetRichiestaSopralluogoById(RichiestaRequestFull richiestaR)
        {
            List<EntityRichiesta> richieste;


            String sortParam = String.Concat(String.Concat(richiestaR.CampoOrdinamento, " "), richiestaR.Ordinamento.ToUpper());

            if (richiestaR.Pageable)
            {

                richieste = await _RCDDbContext.Richieste
                    .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.Id.ToString()), q => q.Id.Equals(richiestaR.Filter.Id))
                    .OrderBy(sortParam)
                    .Include("Sopralluogo")
                    .Include("Sopralluogo.Ditta")
                    .Include("Sopralluogo.DeliveryManager")
                    .Include("Sopralluogo.TipologiaCantiere")
                    /* .Include("Sopralluogo.SopralluogoCme")   
                     .Include("Sopralluogo.SopralluogoApparati")
                     .Include("Sopralluogo.SopralluogoAntenne")
                     .Include("Sopralluogo.SopralluogoAccessori")
                     .Include("Sopralluogo.SopralluogoFemto")
                     .Include("Sopralluogo.SopralluogoCrowdcell")*/
                    .Skip(richiestaR.NumeroElementi * richiestaR.Page).Take(richiestaR.NumeroElementi)
                    .ToListAsync();

            }
            else
            {
                richieste = await _RCDDbContext.Richieste
                .WhereIf(!String.IsNullOrEmpty(richiestaR.Filter.Id.ToString()), q => q.Id.Equals(richiestaR.Filter.Id))
                .Include("Sopralluogo")
                .Include("Sopralluogo.Ditta")
                .Include("Sopralluogo.DeliveryManager")
                .Include("Sopralluogo.TipologiaCantiere")
                /* .Include("Sopralluogo.SopralluogoCme")
                 .Include("Sopralluogo.SopralluogoApparati")
                 .Include("Sopralluogo.SopralluogoAntenne")
                 .Include("Sopralluogo.SopralluogoAccessori")
                 .Include("Sopralluogo.SopralluogoFemto")
                 .Include("Sopralluogo.SopralluogoCrowdcell")*/
                .OrderBy(sortParam)
                .ToListAsync();

            }

            List<ContractRichiesta> richiesteElenco = new List<ContractRichiesta>();
            foreach (EntityRichiesta varRichiesta in richieste)
            {
                ContractRichiesta richiesta1 = new ContractRichiesta();
                UtilityManager.MapProp(varRichiesta, richiesta1);
                richiesteElenco.Add(richiesta1);
            }
            return richiesteElenco[0];
        }

        public List<long?> ListStatoKO()
        {
            var elencoStatiKO = _RCDDbContext.Stato.Where(x => x.IsKoState == true && x.IsFinalState == true).ToList();
            List<long?> elencoIdKo = new List<long?>();
            for (int i = 0; i < elencoStatiKO.Count; i++)
            {
                elencoIdKo.Add(elencoStatiKO[i].Id);
            }
            return elencoIdKo;
        }



        public EntityZona GetZonaByIdZona(long? idZona)
        {
            var zona = _RCDDbContext.Zona.Where(x => x.Id == idZona).FirstOrDefault();
            return zona;
        }

        public List<long?> GetRegionByIdZona(long? idZona)
        {
            var elencoRegioni = _RCDDbContext.RegioneVF.Where(x => x.IdZona == idZona).ToList();
            List<long?> elencoIdRegioni = new List<long?>();
            for (int i = 0; i < elencoRegioni.Count; i++)
            {
                elencoIdRegioni.Add(elencoRegioni[i].Id);
            }
            return elencoIdRegioni;
        }

        public List<long?> GetUtentiProvinceByUtente(EntityUtente utente)
        {
            List<EntityUtentiProvince> elencoUtentiProvince = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id).ToList();
            List<long?> elencoIdProvince = new List<long?>();
            if (elencoUtentiProvince.Count > 0)
            {
                for (int i = 0; i < elencoUtentiProvince.Count; i++)
                {
                    elencoIdProvince.Add(elencoUtentiProvince[i].IdProvincia);
                }
            }
            return elencoIdProvince;
        }
    }
}
