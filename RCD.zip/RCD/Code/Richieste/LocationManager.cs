﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Richieste
{
    public class LocationManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public LocationManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
       
        public async Task<List<EntityLocation>> GetLocationByIdRichiedente(LocationRequestFull location)
        {

            List<EntityLocation> locations;

            String sortParam = String.Concat(String.Concat(location.CampoOrdinamento, " "), location.Ordinamento.ToUpper());

            if (location.Pageable)
            {

                locations = await _RCDDbContext.Location.Where(x => x.IdRichiedente.Equals(location.Filter.IdRichiedente))
                                //.WhereIf(!String.IsNullOrEmpty(location.Filter.StsComune.Descrizione), x => x.StsComune.Descrizione.Equals(location.Filter.StsComune.Descrizione))
                                //.WhereIf(!String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Descrizione), x => x.StsComune.ProvinciaSts.Descrizione.Equals(location.Filter.StsComune.ProvinciaSts.Id))
                                // .Where(x => x.StsComune.ProvinciaSts.IdProvincia.Equals(location.Filter.StsComune.ProvinciaSts.Provincia.Id))

                                // .Where(x => x.StsComune.ProvinciaSts.Provincia.IdRegioneVF.Equals(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))
                                //.Where(x => x.StsComune.ProvinciaSts.Provincia.RegioneVF.IdZona.Equals(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id))
                                .Where(x => x.IsDismesso == false)
                                .WhereIf(location.Filter.StsComune != null && !String.IsNullOrEmpty(location.Filter.StsComune.Descrizione), q => q.StsComune.Descrizione.Contains(location.Filter.StsComune.Descrizione))
                                .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Descrizione), q => q.StsComune.ProvinciaSts.Descrizione.Contains(location.Filter.StsComune.ProvinciaSts.Descrizione))
                                //.WhereIf(!String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.RegioneSts.Descrizione), q => q.StsComune.ProvinciaSts.RegioneSts.Descrizione.Contains(location.Filter.StsComune.ProvinciaSts.RegioneSts.Descrizione))
                    
                                //.WhereIf(!String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona), q => q.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Contains(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                                .WhereIf(!String.IsNullOrEmpty(location.Filter.FullNameReferenteLocale), q => q.FullNameReferenteLocale.Contains(location.Filter.FullNameReferenteLocale))
                                .WhereIf(!String.IsNullOrEmpty(location.Filter.TelefonoReferenteLocale), q => q.TelefonoReferenteLocale.Contains(location.Filter.TelefonoReferenteLocale))
                                .WhereIf(!String.IsNullOrEmpty(location.Filter.EmailReferenteLocale), q => q.EmailReferenteLocale.Contains(location.Filter.EmailReferenteLocale))
                                .OrderBy(sortParam)
                                .Skip(location.NumeroElementi * location.Page).Take(location.NumeroElementi)
                                .Include("Richiedente")
                                .Include("StsComune")
                                .Include("StsComune.ProvinciaSts")
                                .Include("StsComune.ProvinciaSts.RegioneSts")
                                .Include("StsComune.ProvinciaSts.Provincia")
                                .Include("StsComune.ProvinciaSts.Provincia.RegioneVF")
                                .Include("StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                                .ToListAsync();
            }
            else
            {


                locations = await _RCDDbContext.Location.Where(x => x.IdRichiedente.Equals(location.Filter.IdRichiedente))
                    .Where(x => x.IsDismesso == false)
                    //.Where(x => x.IdComune.Equals(location.Filter.StsComune.Id))
                    //.Where(x => x.StsComune.IdProvinciaSts.Equals(location.Filter.StsComune.ProvinciaSts.Id))
                    //.Where(x => x.StsComune.ProvinciaSts.IdProvincia.Equals(location.Filter.StsComune.ProvinciaSts.Provincia.Id))
                    //.Where(x => x.StsComune.ProvinciaSts.Provincia.IdRegioneVF.Equals(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))
                    //.Where(x => x.StsComune.ProvinciaSts.Provincia.RegioneVF.IdZona.Equals(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id))
                    .WhereIf(location.Filter.StsComune != null && !String.IsNullOrEmpty(location.Filter.StsComune.Descrizione), q => q.StsComune.Descrizione.Contains(location.Filter.StsComune.Descrizione))
                    .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Descrizione), q => q.StsComune.ProvinciaSts.Descrizione.Contains(location.Filter.StsComune.ProvinciaSts.Descrizione))
                     //.WhereIf(!String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.RegioneSts.Descrizione), q => q.StsComune.ProvinciaSts.RegioneSts.Descrizione.Contains(location.Filter.StsComune.ProvinciaSts.RegioneSts.Descrizione))
                     
                    // .WhereIf(!String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona), q => q.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Contains(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                    .WhereIf(!String.IsNullOrEmpty(location.Filter.FullNameReferenteLocale), q => q.FullNameReferenteLocale.Contains(location.Filter.FullNameReferenteLocale))
                    .WhereIf(!String.IsNullOrEmpty(location.Filter.TelefonoReferenteLocale), q => q.TelefonoReferenteLocale.Contains(location.Filter.TelefonoReferenteLocale))
                    .WhereIf(!String.IsNullOrEmpty(location.Filter.EmailReferenteLocale), q => q.EmailReferenteLocale.Contains(location.Filter.EmailReferenteLocale))
                    .OrderBy(sortParam)
                    .Include("Richiedente")
                    .Include("StsComune")
                    .Include("StsComune.ProvinciaSts")
                    .Include("StsComune.ProvinciaSts.RegioneSts")
                    .Include("StsComune.ProvinciaSts.Provincia")
                    .Include("StsComune.ProvinciaSts.Provincia.RegioneVF")
                    .Include("StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .ToListAsync();
            }

            return locations;
        }

        public async Task<Int32> GetLocationByIdRichiedenteTot(LocationRequestFull location)
        {
            String sortParam = String.Concat(String.Concat(location.CampoOrdinamento, " "), location.Ordinamento.ToUpper());
            Int32 count = _RCDDbContext.Location.Where(x => x.IdRichiedente.Equals(location.Filter.IdRichiedente))
                     .Where(x => x.IsDismesso == false)
                     //.Where(x => x.IdComune.Equals(location.Filter.StsComune.Id))
                     //.Where(x => x.StsComune.IdProvinciaSts.Equals(location.Filter.StsComune.ProvinciaSts.Id))
                     //.Where(x => x.StsComune.ProvinciaSts.IdProvincia.Equals(location.Filter.StsComune.ProvinciaSts.Provincia.Id))
                     //.Where(x => x.StsComune.ProvinciaSts.Provincia.IdRegioneVF.Equals(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))

                    // .Where(x => x.StsComune.ProvinciaSts.Provincia.RegioneVF.IdZona.Equals(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id))

                     .WhereIf(location.Filter.StsComune != null && !String.IsNullOrEmpty(location.Filter.StsComune.Descrizione), q => q.StsComune.Descrizione.Contains(location.Filter.StsComune.Descrizione))
                     .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Descrizione), q => q.StsComune.ProvinciaSts.Descrizione.Contains(location.Filter.StsComune.ProvinciaSts.Descrizione))
                     //.WhereIf(!String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.RegioneSts.Descrizione), q => q.StsComune.ProvinciaSts.RegioneSts.Descrizione.Contains(location.Filter.StsComune.ProvinciaSts.RegioneSts.Descrizione))
                     
                   //.WhereIf(!String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona), q => q.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Contains(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                      .WhereIf(!String.IsNullOrEmpty(location.Filter.FullNameReferenteLocale), q => q.FullNameReferenteLocale.Contains(location.Filter.FullNameReferenteLocale))
                    .WhereIf(!String.IsNullOrEmpty(location.Filter.TelefonoReferenteLocale), q => q.TelefonoReferenteLocale.Contains(location.Filter.TelefonoReferenteLocale))
                     .WhereIf(!String.IsNullOrEmpty(location.Filter.EmailReferenteLocale), q => q.EmailReferenteLocale.Contains(location.Filter.EmailReferenteLocale))
                     .OrderBy(sortParam)
                    .Include("Richiedente")
                    .Include("StsComune")
                    .Include("StsComune.ProvinciaSts")
                    .Include("StsComune.ProvinciaSts.RegioneSts")
                    .Include("StsComune.ProvinciaSts.Provincia")
                    .Include("StsComune.ProvinciaSts.Provincia.RegioneVF")
                    .Include("StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                .Count();

            return count;
        }

    }

}