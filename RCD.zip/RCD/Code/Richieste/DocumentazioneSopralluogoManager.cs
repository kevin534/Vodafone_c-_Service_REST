﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine.Entities;

namespace RCD.Code.Richieste
{
    public class DocumentazioneSopralluogoManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public DocumentazioneSopralluogoManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
        public async Task<List<EntityDocumentazioneSopralluogo>> GetDocumentazioneSopralluogobySopralluogoId(DocumentazioneSopralluogoRequestFull docSpralluogo)
        {

            List<EntityDocumentazioneSopralluogo> docSpralluoghi;

            String sortParam = String.Concat(String.Concat(docSpralluogo.CampoOrdinamento, " "), docSpralluogo.Ordinamento.ToUpper());
            DateTime newDate = DateTime.MinValue;
            if (docSpralluogo.Filter.DataInserimento != newDate)
                newDate = docSpralluogo.Filter.DataInserimento.Date;

            if (docSpralluogo.Pageable)
            {
                docSpralluoghi = await _RCDDbContext.DocSopralluogo.Where(x => x.Active == true && x.IdSopralluogo.Equals(docSpralluogo.Filter.IdSopralluogo))
                    .WhereIf(!String.IsNullOrEmpty(docSpralluogo.Filter.Nome.ToString()), q => q.Nome.Equals(docSpralluogo.Filter.Nome))
                    .WhereIf(!docSpralluogo.Filter.DataInserimento.ToString("dd/MM/yyyy HH:mm:ss").Equals(DateTime.MinValue.ToString("dd/MM/yyyy HH:mm:ss")), q => q.DataInserimento.Date == newDate)
                    .OrderBy(sortParam)
                    .Skip(docSpralluogo.NumeroElementi * docSpralluogo.Page).Take(docSpralluogo.NumeroElementi)
                    .Include("Sopralluogo")
                    .ToListAsync();
            }
            else
            {
                docSpralluoghi = await _RCDDbContext.DocSopralluogo
                    .Where(x => x.Active == true && x.IdSopralluogo.Equals(docSpralluogo.Filter.IdSopralluogo))
                    .WhereIf(!String.IsNullOrEmpty(docSpralluogo.Filter.Nome.ToString()), q => q.Nome.Equals(docSpralluogo.Filter.Nome))
                    .WhereIf(!docSpralluogo.Filter.DataInserimento.ToString("dd/MM/yyyy HH:mm:ss").Equals(DateTime.MinValue.ToString("dd/MM/yyyy HH:mm:ss")), q => q.DataInserimento.Date == newDate)
                    .OrderBy(sortParam)
                    .Include("Sopralluogo")
                    .ToListAsync();
            }

            return docSpralluoghi;

        }

        public async Task<Int32> GetDocumentazioneSopralluogobySopralluogoIdTot(DocumentazioneSopralluogoRequestFull docSpralluogo)
        {
            DateTime newDate = DateTime.MinValue;
            if (docSpralluogo.Filter.DataInserimento != newDate)  //se viene inserita data inserimento nel filtro (è diversa da data min)
                newDate = docSpralluogo.Filter.DataInserimento.Date;

            Int32 count = _RCDDbContext.DocSopralluogo.Where(x => x.Active == true && x.IdSopralluogo.Equals(docSpralluogo.Filter.IdSopralluogo))
                     .WhereIf(!String.IsNullOrEmpty(docSpralluogo.Filter.Nome.ToString()), q => q.Nome.Equals(docSpralluogo.Filter.Nome))
                      .WhereIf(!docSpralluogo.Filter.DataInserimento.ToString("dd/MM/yyyy HH:mm:ss").Equals(DateTime.MinValue.ToString("dd/MM/yyyy HH:mm:ss")), q => q.DataInserimento.Date == newDate)
                     // .WhereIf(!String.IsNullOrEmpty(docSpralluogo.Filter.Sopralluogo.Id.ToString()), q => q.Sopralluogo.Id.Equals(docSpralluogo.Filter.Sopralluogo.Id))
                     .Include("Sopralluogo").Count();

            return count;

        }
        public async Task<List<EntityDocumentazioneSopralluogo>> GetDocumentoSopralluogoById(DocumentazioneSopralluogoRequestFull documento)
        {

            List<EntityDocumentazioneSopralluogo> docSpralluoghi;

            String sortParam = String.Concat(String.Concat(documento.CampoOrdinamento, " "), documento.Ordinamento.ToUpper());

            if (documento.Pageable)
            {

                docSpralluoghi = await _RCDDbContext.DocSopralluogo
                    .WhereIf(!String.IsNullOrEmpty(documento.Filter.Id.ToString()), q => q.Id.Equals(documento.Filter.Id))
                     .OrderBy(sortParam)
                            .Skip(documento.NumeroElementi * documento.Page).Take(documento.NumeroElementi)
                            .ToListAsync();
            }
            else
            {

                docSpralluoghi = await _RCDDbContext.DocSopralluogo
                    .WhereIf(!String.IsNullOrEmpty(documento.Filter.Id.ToString()), q => q.Id.Equals(documento.Filter.Id))
                     .OrderBy(sortParam)
                            .ToListAsync();
            }

            return docSpralluoghi;


        }
        public async Task<Int32> GetDocumentoSopralluogoByIdTot(DocumentazioneSopralluogoRequestFull documento)
        {
            List<EntityDocumentazioneSopralluogo> docSpralluoghi;

            String sortParam = String.Concat(String.Concat(documento.CampoOrdinamento, " "), documento.Ordinamento.ToUpper());

            docSpralluoghi = await _RCDDbContext.DocSopralluogo
                    .WhereIf(!String.IsNullOrEmpty(documento.Filter.Id.ToString()), q => q.Id.Equals(documento.Filter.Id))
                     .OrderBy(sortParam)
                            .ToListAsync();

            return docSpralluoghi.Count();
        }


    }

}