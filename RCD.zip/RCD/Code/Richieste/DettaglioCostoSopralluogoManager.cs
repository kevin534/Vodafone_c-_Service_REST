﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;

namespace RCD.Code.Richieste
{
    public class DettaglioCostoSopralluogoManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;


        public DettaglioCostoSopralluogoManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractSopralluogoCme>> GetCostiSopralluogoCME(SopralluogoCMERequestFull sopralluogoCme)
        {
            List<EntitySopralluogoCme> sopralluoghiCME;

            String sortParam = String.Concat(String.Concat(sopralluogoCme.CampoOrdinamento, " "), sopralluogoCme.Ordinamento.ToUpper());

            if (sopralluogoCme.Pageable)
            {
                sopralluoghiCME = await _RCDDbContext.SopralluogoCme
                    .Where(q => q.IdSopralluogo.Equals(sopralluogoCme.Filter.IdSopralluogo))
                .Include("Listino")
               // .Include("Sopralluogo") se aggiunto va in loop
                .Include("SopralluogoApparati").AsNoTracking()
                .OrderBy(sortParam)
                .Skip(sopralluogoCme.NumeroElementi * sopralluogoCme.Page).Take(sopralluogoCme.NumeroElementi)
                .ToListAsync();

            }
            else
            {
                sopralluoghiCME = await _RCDDbContext.SopralluogoCme
                     .Where(q => q.IdSopralluogo.Equals(sopralluogoCme.Filter.IdSopralluogo))
                .Include("Listino")
                .Include("SopralluogoApparati")
                //.Include("Sopralluogo")se aggiunto va in loop
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractSopralluogoCme> sopralluoghiCmeElenco = new List<ContractSopralluogoCme>();
            foreach (EntitySopralluogoCme varSopralluoghiCme in sopralluoghiCME)
            {
                ContractSopralluogoCme sopralluoghiCme1 = new ContractSopralluogoCme();
                UtilityManager.MapProp(varSopralluoghiCme, sopralluoghiCme1);
                sopralluoghiCmeElenco.Add(sopralluoghiCme1);
            }
            return sopralluoghiCmeElenco;
        }
        public async Task<Int32> GetCostiSopralluogoCMETot(SopralluogoCMERequestFull sopralluogoCme)
        {
            List<EntitySopralluogoCme> sopralluoghiCme;
                 sopralluoghiCme = await _RCDDbContext.SopralluogoCme
                 .Where(q => q.IdSopralluogo.Equals(sopralluogoCme.Filter.IdSopralluogo))
                //  .WhereIf(string.IsNullOrEmpty(sopralluogoCme.Filter.IdSopralluogo.ToString()), q => q.IdSopralluogo.Equals(sopralluogoCme.Filter.IdSopralluogo))
                .Include("Listino")
                .Include("SopralluogoApparati")
                .Include("Sopralluogo")
                .ToListAsync();

            return sopralluoghiCme.Count();

        }

        public void AddCostiSopralluogoCME(SopralluogoCMERequest entitySopralluogoCME)
        {
            try
            {
                EntitySopralluogoCme EntitySopralluogoCmeToAdd = new EntitySopralluogoCme();
                UtilityManager.MapProp(entitySopralluogoCME, EntitySopralluogoCmeToAdd);
                var result = _RCDDbContext.Add(EntitySopralluogoCmeToAdd);
                _RCDDbContext.SaveChanges();

                RecalculateCosti(entitySopralluogoCME.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateCostiSopralluogoCME(SopralluogoCMERequest entitySopralluogoCME)
        {
            try
            {
                EntitySopralluogoCme EntitySopralluogoCmeToEdit = new EntitySopralluogoCme();
                UtilityManager.MapProp(entitySopralluogoCME, EntitySopralluogoCmeToEdit);

                var result = _RCDDbContext.Update(EntitySopralluogoCmeToEdit);
                _RCDDbContext.SaveChanges();

                RecalculateCosti(entitySopralluogoCME.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteCostiSopralluogoCME(SopralluogoCMERequest entitySopralluogoCME)
        {
            try
            {
                EntitySopralluogoCme EntitySopralluogoCmeToRemove = new EntitySopralluogoCme();
                UtilityManager.MapProp(entitySopralluogoCME, EntitySopralluogoCmeToRemove);
                var result = _RCDDbContext.Remove(EntitySopralluogoCmeToRemove);
                _RCDDbContext.SaveChanges();

                RecalculateCosti(entitySopralluogoCME.IdSopralluogo);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        public async Task<List<ContractListinoPreconfigurato>> GetDescrizioneFiscalYearByListinoPreconfigurato(ListinoPreconfiguratoRequestFull listinoPreconfigurato)
        {
            List<EntityListinoPreconfigurato> listiniPreconfigurati;

            String sortParam = String.Concat(String.Concat(listinoPreconfigurato.CampoOrdinamento, " "), listinoPreconfigurato.Ordinamento.ToUpper());

            if (listinoPreconfigurato.Pageable)
            {
                listiniPreconfigurati = await _RCDDbContext.ListinoPreconfigurato
                    .WhereIf(!String.IsNullOrEmpty(listinoPreconfigurato.Filter.Valore), q => q.Valore.Equals(listinoPreconfigurato.Filter.Valore))
                         .OrderBy(sortParam)
                        .Skip(listinoPreconfigurato.NumeroElementi * listinoPreconfigurato.Page).Take(listinoPreconfigurato.NumeroElementi)
                        .ToListAsync();

            }
            else
            {
                listiniPreconfigurati = await _RCDDbContext.ListinoPreconfigurato
                     .WhereIf(!String.IsNullOrEmpty(listinoPreconfigurato.Filter.Valore), q => q.Valore.Equals(listinoPreconfigurato.Filter.Valore))
                         .OrderBy(sortParam)
                        .ToListAsync();
            }

            List<ContractListinoPreconfigurato> listiniPreconfiguratiElenco = new List<ContractListinoPreconfigurato>();
            foreach (EntityListinoPreconfigurato varListinoPreconfigurato in listiniPreconfigurati)
            {
                ContractListinoPreconfigurato listinoPreconfigurato1 = new ContractListinoPreconfigurato();
                UtilityManager.MapProp(varListinoPreconfigurato, listinoPreconfigurato1);
                listiniPreconfiguratiElenco.Add(listinoPreconfigurato1);
            }
            return listiniPreconfiguratiElenco;
        }

        public async Task<Int32> GetDescrizioneFiscalYearByListinoPreconfiguratoTot(ListinoPreconfiguratoRequestFull listinoPreconfigurato)
        {
            List<EntityListinoPreconfigurato> listiniPreconfigurati;

            listiniPreconfigurati = await _RCDDbContext.ListinoPreconfigurato
                    .WhereIf(!String.IsNullOrEmpty(listinoPreconfigurato.Filter.Valore), q => q.Valore.Equals(listinoPreconfigurato.Filter.Valore))
                        .ToListAsync();

            return listiniPreconfigurati.Count();

        }

        /// <summary>
        /// Esegue il ricalcolo dei dati inerenti il sopralluogo in base ai dati presenti
        /// </summary>
        private void RecalculateCosti(Int64? idSopralluogo)
        {
            EntitySopralluogo sopralluogo = _RCDDbContext.Sopralluogo
                                        .Where(x => x.Id == idSopralluogo)
                                        .Include("SopralluogoCme")
                                        .Include("SopralluogoApparati")
                                        .Include("SopralluogoApparati.Apparati.TipologiaApparato")
                                        .Include("SopralluogoApparati.Apparati.Sistema")
                                        .Include("SopralluogoAntenne")
                                        .Include("SopralluogoAccessori")
                                        .FirstOrDefault();
            decimal? TotaleCosti = 0;
            decimal? TotaleCostiApparatiAccessori = 0;
            decimal? TotaleCostiSostenuti = 0;
            int? TotaleRiuso = 0;
            int? TotaleNuovo = 0;
            int? TotaleRighe = 0;

            decimal? TotaleCostiCME = 0;
            decimal? TotaleCostiApparati = 0;
            decimal? TotaleCostiAccessori = 0;
            decimal? TotaleCostiAntenne = 0;
            int? TotaleApparatiNuovi = 0;
            int? TotaleApparatiRiuso = 0;
            int? TotaleAccessoriNuovi = 0;
            int? TotaleAccessoriRiuso = 0;
            int? TotaleAntenneNuovi = 0;
            int? TotaleAntenneRiuso = 0;

            int? TotaleMiniGsm = 0;
            int? TotaleCompactGsm = 0;
            int? TotaleMiniUmts = 0;
            int? TotaleCompactUmts = 0;
            int? TotaleMiniLte = 0;
            int? TotaleCompactLte = 0;
            int? TotalePicoUmts = 0;
            int? TotalePicoLte = 0;
            int? TotaleFemto = 0;
            int? TotaleFemtoLte = 0;

            int? TotaleDualBand = 0;

            TotaleCostiCME = sopralluogo.SopralluogoCme.Sum(cme => cme.PrezzoTotale);
            TotaleCostiSostenuti = sopralluogo.SopralluogoCme.Where(cme => cme.CostoSostenuto == true).Sum(cme => cme.PrezzoTotale);
            TotaleRighe += sopralluogo.SopralluogoCme.Count();

            TotaleCostiApparati = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Riuso == false && sApp.ProprietaCliente == false).Sum(sApp => sApp.PrezzoTotale);
            TotaleApparatiNuovi = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Riuso == false).Sum(sApp => sApp.Quantita);
            TotaleApparatiRiuso = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Riuso == true).Sum(sApp => sApp.Quantita);
            TotaleMiniGsm = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "mini" && sApp.Apparati.Sistema.Sistema.ToLower() == "gsm").Sum(sApp => sApp.Quantita);
            TotaleCompactGsm = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "compact" && sApp.Apparati.Sistema.Sistema.ToLower() == "gsm").Sum(sApp => sApp.Quantita);
            TotaleMiniUmts = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "mini" && sApp.Apparati.Sistema.Sistema.ToLower() == "umts").Sum(sApp => sApp.Quantita);
            TotaleCompactUmts = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "compact" && sApp.Apparati.Sistema.Sistema.ToLower() == "umts").Sum(sApp => sApp.Quantita);
            TotaleMiniLte = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "mini" && sApp.Apparati.Sistema.Sistema.ToLower() == "lte").Sum(sApp => sApp.Quantita);
            TotaleCompactLte = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "compact" && sApp.Apparati.Sistema.Sistema.ToLower() == "lte").Sum(sApp => sApp.Quantita);
            TotalePicoUmts = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "pico" && sApp.Apparati.Sistema.Sistema.ToLower() == "umts").Sum(sApp => sApp.Quantita);
            TotalePicoLte = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "pico" && sApp.Apparati.Sistema.Sistema.ToLower() == "lte").Sum(sApp => sApp.Quantita);
            // Aggiunto filtro Umts
            TotaleFemto = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "femto" && sApp.Apparati.Sistema.Sistema.ToLower() == "umts").Sum(sApp => sApp.Quantita);
            TotaleFemtoLte = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.TipologiaApparato.TipologiaApparato.ToLower() == "femto" && sApp.Apparati.Sistema.Sistema.ToLower() == "lte").Sum(sApp => sApp.Quantita);
            TotaleDualBand = sopralluogo.SopralluogoApparati.Where(sApp => sApp.Apparati.Sistema.Sistema.ToLower() == "gsm/umts").Sum(sApp => sApp.Quantita);
            TotaleRighe += sopralluogo.SopralluogoApparati.Count();

            TotaleCostiAntenne = sopralluogo.SopralluogoAntenne.Where(sAnt => sAnt.Riuso == false).Sum(sAnt => sAnt.PrezzoTotale);
            TotaleAntenneNuovi = sopralluogo.SopralluogoAntenne.Where(sAnt => sAnt.Riuso == false).Sum(sAnt => sAnt.Quantita);
            TotaleAntenneRiuso = sopralluogo.SopralluogoAntenne.Where(sAnt => sAnt.Riuso == true).Sum(sAnt => sAnt.Quantita);
            TotaleRighe += sopralluogo.SopralluogoAntenne.Count();

            TotaleCostiAccessori = sopralluogo.SopralluogoAccessori.Where(sAcc => sAcc.Riuso == false).Sum(sAcc => sAcc.PrezzoTotale);
            TotaleAccessoriNuovi = sopralluogo.SopralluogoAccessori.Where(sAcc => sAcc.Riuso == false).Sum(sAcc => sAcc.Quantita);
            TotaleAccessoriRiuso = sopralluogo.SopralluogoAccessori.Where(sAcc => sAcc.Riuso == true).Sum(sAcc => sAcc.Quantita);
            TotaleRighe += sopralluogo.SopralluogoAccessori.Count();

            // Calcolo totali
            if (TotaleRighe > 0)
            {
                TotaleCosti = TotaleCostiCME + TotaleCostiApparati + TotaleCostiAntenne + TotaleCostiAccessori;
                sopralluogo.StimaIntervento = (double)TotaleCosti;
                TotaleCostiApparatiAccessori = TotaleCostiApparati + TotaleCostiAntenne + TotaleCostiAccessori;
                sopralluogo.CostoAccessoriApparatiStimato = (double)TotaleCostiApparatiAccessori;
                TotaleNuovo = TotaleApparatiNuovi + TotaleAntenneNuovi + TotaleAccessoriNuovi;
                sopralluogo.TotaleApparatiNuovi = TotaleApparatiNuovi;
                TotaleRiuso = TotaleApparatiRiuso + TotaleAntenneRiuso + TotaleAccessoriRiuso;
                sopralluogo.TotaleApparatiRiuso = TotaleApparatiRiuso;
                sopralluogo.TotaleCostiSostenuti = (double)TotaleCostiSostenuti;
                sopralluogo.NumeroMiniGsmRichiesti = TotaleMiniGsm;
                sopralluogo.NumeroMiniUmtsRichiesti = TotaleMiniUmts;
                sopralluogo.NumeroMiniLteRichiesti = TotaleMiniLte;
                sopralluogo.NumeroPicoUmts = TotalePicoUmts;
                sopralluogo.NumeroPicoLte = TotalePicoLte;
                sopralluogo.NumeroCompactGsmRichiesti = TotaleCompactGsm;
                sopralluogo.NumeroCompactUmtsRichiesti = TotaleCompactUmts;
                sopralluogo.NumeroCompactLteRichiesti = TotaleCompactLte;
                sopralluogo.NumeroApparatiFemto = TotaleFemto;
                sopralluogo.NumeroApparatiFemtoLte = TotaleFemtoLte;
                sopralluogo.NumeroApparatiDualBand = TotaleDualBand;
            }
            var result = _RCDDbContext.Update(sopralluogo);
            _RCDDbContext.SaveChanges();
        }


    }
}
