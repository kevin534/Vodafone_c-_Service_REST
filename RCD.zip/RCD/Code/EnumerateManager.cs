﻿namespace RCD.Code
{
	public class EnumerateManager
	{
		public enum ENVIRONMENT_TYPE
		{
			PRODUZIONE = 0,
			PRE_PRODUZIONE = 1,
			TEST = 2,
			LOCALHOST = 99,
			UNKNOWN = 999
		}
	}
}
