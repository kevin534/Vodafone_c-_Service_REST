﻿using RCDContracts.Request;
using System.Net;
using System.Text;
using Microsoft.Extensions.Configuration;
using System.Text.Json;
using RCDContracts.Response;
using RCD.Code.Amministrazione;
using RCDEngine.Entities;
using Microsoft.EntityFrameworkCore;
using RCDContracts.Data;
using RCDContracts;

namespace RCD.Code.Main
{
    public class LoginManager
    {
        EnumerateManager.ENVIRONMENT_TYPE environmentType;
        String rootUrl = "";
        Int32 tokenDuration;
        private readonly RCDEngine.RCDDbContext _RCDDbContext;


        public LoginManager(EnumerateManager.ENVIRONMENT_TYPE environmentType, IConfiguration configuration, RCDEngine.RCDDbContext RCDDbContext)
        {
            this.environmentType = environmentType;
            String prefixEnvironment = UtilityManager.PrefixEnvironment(environmentType);
            this.rootUrl = configuration["AppSettings:" + prefixEnvironment + ":ServiceUrl"];
            _RCDDbContext = RCDDbContext;
            this.tokenDuration = Convert.ToInt32(configuration["AppSettings:" + prefixEnvironment + ":TokenDuration"]);
        }

        public async Task<EntityUtente> Login(LoginRequest param)
        {

            EntityUtente resUtente = _RCDDbContext.Utente.Where(x => x.Username == param.Username && x.Abilitato== true)
                                    .Include("Ruolo")
                                    .Include("AreaVendita")
                                    .Include("AreaVendita.CanaleVenditaDettaglio.CanaleVendita")
                                    .Include("TipologiaUtente")
                                    .FirstOrDefault();
            string url = rootUrl + "DomainUserCheck/Validation";
            HttpClient client = new HttpClient();

            try
            {
                string json = JsonSerializer.Serialize(param);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await client.PostAsync(url, data);
                var content = await response.Content.ReadAsStringAsync();

                var options = new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                };
                LoginResponse? loginResponse = JsonSerializer.Deserialize<LoginResponse>(content, options);
                if (loginResponse.IsAuthenticateOnLDAP)
                {
                    //EntityUtente resUtente =  _RCDDbContext.Utente.Where(x => x.Username == param.Username).FirstOrDefault();
                    if (resUtente == null)
                    {
                        throw new Exception("Le credenziali fornite non sono censite nell'applicativo,\r\nma sono comunque presenti sul Controller di Dominio\r\n" +
                            ".Contattare l'amministratore di sistema.");
                    }
                    else
                    {

                        
                    }
                    return resUtente;
                }
                else
                {
                    throw new Exception("L'utente non è presente nel Controller di Dominio \r\n o le credenziali fornite sono errate. " +
                       " Contattare un amministratore di sistema e far aggiungere il proprio utente al dominio");
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public async Task<List<ContractMenuUtente>> GetMenuByUtente(EntityUtente utente)
        {

            List<EntityRuoloPrivilegio> privilegiRuolo = await _RCDDbContext.RuoloPrivilegio.Where(x => x.IdRuolo == utente.IdRuolo)
                                                    .Include("Privilegio")
                                                    .ToListAsync();

            List<ContractMenuUtente> privilegiElenco = new List<ContractMenuUtente>();

            foreach (EntityRuoloPrivilegio varPrivilegio in privilegiRuolo)
            {
                ContractMenuUtente privilegio1 = new ContractMenuUtente();
                if (varPrivilegio.Privilegio != null)
                {
                    privilegio1.Gruppo = varPrivilegio.Privilegio.Gruppo;
                    privilegio1.Privilegio = varPrivilegio.Privilegio.Privilegio;
                    privilegiElenco.Add(privilegio1);
                }
            }
            return privilegiElenco;
        }
        public string CreateTokenAuthenticatedContext(EntityUtente utenteItem)
        {
            String cryptedTokenString = "";
            if (utenteItem != null && utenteItem.Id > 0)
            {
                TokenData token = new TokenData();
                token.CodiceUtente = utenteItem.Id.ToString();
                token.IndiceRuolo = (Int64)utenteItem.IdRuolo;
                token.DateToken = DateTime.Now.AddMinutes(tokenDuration);

                String serializationTokenString = JsonSerializer.Serialize(token);
                SecurityManager securityManager = new SecurityManager();
                cryptedTokenString = securityManager.EncryptTokenKey(serializationTokenString, UtilityManager.TokenKey);
            }
            return cryptedTokenString;
        }
    }
}
