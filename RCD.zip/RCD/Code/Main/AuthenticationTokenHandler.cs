﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using RCDContracts;
using RCDContracts.Data;
using System.Security.Claims;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace RCD.Code.Main

{
    public class AuthenticationTokenHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {
        private const string AuthorizationHeaderName = "Authorization";

        public AuthenticationTokenHandler(IOptionsMonitor<AuthenticationSchemeOptions> options,
            ILoggerFactory logger, UrlEncoder encoder, ISystemClock clock)
            : base(options, logger, encoder, clock)
        {

        }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            string authenticationToken = Request.Headers["Authorization"];

            if (string.IsNullOrWhiteSpace(authenticationToken))
                return AuthenticateResult.Fail("Authorization Header Mancante");

            String[] tokens = authenticationToken.Split(' ');
            SecurityManager securityManager = new SecurityManager();
            String decryptedTokenString = securityManager.DecryptTokenKey(tokens[1], UtilityManager.TokenKey);
            TokenData token = JsonSerializer.Deserialize<TokenData>(decryptedTokenString);
            if(token.DateToken< DateTime.Now)
            {
                return AuthenticateResult.Fail("Token scaduto");
            }

            List<Claim> claims = new List<Claim>();
            claims.Add(new Claim(ClaimTypes.UserData, token.CodiceUtente.ToString()));
            claims.Add(new Claim(ClaimTypes.Role, token.IndiceRuolo.ToString()));
            // var claims = new[] { new Claim(ClaimTypes.UserData, token.CodiceUtente.ToString()) };

            var identity = new ClaimsIdentity(claims, Scheme.Name);
            var principal = new ClaimsPrincipal(identity);
            var ticket = new AuthenticationTicket(principal, Scheme.Name);
            return AuthenticateResult.Success(ticket);
        }
    }
}


