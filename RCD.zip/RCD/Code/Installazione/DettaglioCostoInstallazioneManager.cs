﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;

namespace RCD.Code.Installazione
{
    public class DettaglioCostoInstallazioneManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;


        public DettaglioCostoInstallazioneManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractInstallazioneCme>> GetCostiInstallazioneCME(InstallazioneCMERequestFull installazioneCme)
        {
            List<EntityInstallazioneCme> installazioniCME;

            String sortParam = String.Concat(String.Concat(installazioneCme.CampoOrdinamento, " "), installazioneCme.Ordinamento.ToUpper());

            if (installazioneCme.Pageable)
            {
                installazioniCME = await _RCDDbContext.InstallazioneCme.Where(q => q.IdInstallazione.Equals(installazioneCme.Filter.IdInstallazione))
                                        .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.IdApparato.ToString()), q => q.IdApparato.Equals(installazioneCme.Filter.InstallazioneApparati.Id))
                    /*.WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.InstallazioneApparati.NomeApparato), q => q.InstallazioneApparati.NomeApparato.Contains(installazioneCme.Filter.InstallazioneApparati.NomeApparato))
                    //.WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.IdListino.ToString()), q => q.IdListino.Equals(installazioneCme.Filter.Listino.Id))

                   .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.Listino.PrezzoUnitario.ToString()), q => q.Listino.PrezzoUnitario.Equals(installazioneCme.Filter.Listino.PrezzoUnitario))
                    .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.Listino.DescrizioneInforecord), q => q.Listino.DescrizioneInforecord.Contains(installazioneCme.Filter.Listino.DescrizioneInforecord))
                    .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.Listino.CodiceInforecord), q => q.Listino.CodiceInforecord.Contains(installazioneCme.Filter.Listino.CodiceInforecord))
                    .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.Listino.CodiceMateriale), q => q.Listino.CodiceMateriale.Contains(installazioneCme.Filter.Listino.CodiceMateriale))*/
                .Include("Listino")
                .Include("InstallazioneApparati")
                .OrderBy(sortParam)
                .Skip(installazioneCme.NumeroElementi * installazioneCme.Page).Take(installazioneCme.NumeroElementi)
                .ToListAsync();

            }
            else
            {
                installazioniCME = await _RCDDbContext.InstallazioneCme.Where(q => q.IdInstallazione.Equals(installazioneCme.Filter.IdInstallazione))
                     .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.IdApparato.ToString()), q => q.IdApparato.Equals(installazioneCme.Filter.InstallazioneApparati.Id))
                 /*.WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.InstallazioneApparati.NomeApparato), q => q.InstallazioneApparati.NomeApparato.Contains(installazioneCme.Filter.InstallazioneApparati.NomeApparato))
                  //.WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.IdListino.ToString()), q => q.IdListino.Equals(installazioneCme.Filter.Listino.Id))

                    .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.Listino.PrezzoUnitario.ToString()), q => q.Listino.PrezzoUnitario.Equals(installazioneCme.Filter.Listino.PrezzoUnitario))
                    .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.Listino.DescrizioneInforecord), q => q.Listino.DescrizioneInforecord.Contains(installazioneCme.Filter.Listino.DescrizioneInforecord))
                    .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.Listino.CodiceInforecord), q => q.Listino.CodiceInforecord.Contains(installazioneCme.Filter.Listino.CodiceInforecord))
                    .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.Listino.CodiceMateriale), q => q.Listino.CodiceMateriale.Contains(installazioneCme.Filter.Listino.CodiceMateriale))*/
                 
                .Include("Listino")
                .Include("InstallazioneApparati")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractInstallazioneCme> installazioneCmeElenco = new List<ContractInstallazioneCme>();
            foreach (EntityInstallazioneCme varInstallazioniCme in installazioniCME)
            {
                ContractInstallazioneCme installazioniCme1 = new ContractInstallazioneCme();
                UtilityManager.MapProp(varInstallazioniCme, installazioniCme1);
                installazioneCmeElenco.Add(installazioniCme1);
            }
            return installazioneCmeElenco;
        }

        public async Task<Int32> GetCostiInstallazioneCMETot(InstallazioneCMERequestFull installazioneCme)
        {

            Int32 count =_RCDDbContext.InstallazioneCme.Where(q => q.IdInstallazione.Equals(installazioneCme.Filter.IdInstallazione))
                 .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.IdApparato.ToString()), q => q.IdApparato.Equals(installazioneCme.Filter.InstallazioneApparati.Id))
            /* .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.InstallazioneApparati.NomeApparato), q => q.InstallazioneApparati.NomeApparato.Contains(installazioneCme.Filter.InstallazioneApparati.NomeApparato))
             //.WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.IdListino.ToString()), q => q.IdListino.Equals(installazioneCme.Filter.Listino.Id))

                    .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.Listino.PrezzoUnitario.ToString()), q => q.Listino.PrezzoUnitario.Equals(installazioneCme.Filter.Listino.PrezzoUnitario))
                    .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.Listino.DescrizioneInforecord), q => q.Listino.DescrizioneInforecord.Contains(installazioneCme.Filter.Listino.DescrizioneInforecord))
                    .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.Listino.CodiceInforecord), q => q.Listino.CodiceInforecord.Contains(installazioneCme.Filter.Listino.CodiceInforecord))
                    .WhereIf(!String.IsNullOrEmpty(installazioneCme.Filter.Listino.CodiceMateriale), q => q.Listino.CodiceMateriale.Contains(installazioneCme.Filter.Listino.CodiceMateriale))*/
                .Include("Listino")
                .Include("InstallazioneApparati")
                .Count();

            return count;

        }

        public void AddCostiInstallazioneCME(InstallazioneCMERequest installazioneCme)
        {
            try
            {
                EntityInstallazioneCme installazioneCmeToAdd = new EntityInstallazioneCme();
                UtilityManager.MapProp(installazioneCme, installazioneCmeToAdd);
                var result = _RCDDbContext.Add(installazioneCmeToAdd);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(installazioneCme.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateCostiInstallazioneCME(InstallazioneCMERequest installazioneCme)
        {
            try
            {
                EntityInstallazioneCme installazioneCmeToEdit = new EntityInstallazioneCme();
                UtilityManager.MapProp(installazioneCme, installazioneCmeToEdit);
                var result = _RCDDbContext.Update(installazioneCmeToEdit);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(installazioneCme.IdInstallazione);
            
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteCostiInstallazioneCME(InstallazioneCMERequest installazioneCme)
        {
            try
            {
                EntityInstallazioneCme installazioneCmeToRemove = new EntityInstallazioneCme();
                UtilityManager.MapProp(installazioneCme, installazioneCmeToRemove);
                var result = _RCDDbContext.Remove(installazioneCmeToRemove);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(installazioneCme.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        private void RecalculateCosti(Int64? idInstallazione)
        {

            EntityInstallazione? installazione = _RCDDbContext.Installazione
                                       .Where(x => x.Id == idInstallazione)
                                       .Include("InstallazioneCme")
                                       .Include("InstallazioneApparati")
                                       .Include("InstallazioneApparati.Apparati.TipologiaApparato")
                                       .Include("InstallazioneApparati.Apparati.Sistema")
                                       .Include("InstallazioneAntenne")
                                       .Include("InstallazioneAccessori")
                                       .FirstOrDefault();
            EntityRichiesta? richiesta = _RCDDbContext.Richieste
                .Where(x => x.IdInstallazione == idInstallazione)
                .Include("Sopralluogo")
                .AsNoTracking()
                .FirstOrDefault();

            decimal? TotaleCosti = 0;
            decimal? TotaleCostiApparatiAccessori = 0;
            int? TotaleRiuso = 0;
            int? TotaleNuovo = 0;
            int? TotaleRighe = 0;

            decimal? TotaleCostiCME = 0;
            decimal? TotaleCostiApparati = 0;
            decimal? TotaleCostiAccessori = 0;
            decimal? TotaleCostiAntenne = 0;
            int? TotaleApparatiNuovi = 0;
            int? TotaleApparatiRiuso = 0;
            int? TotaleAccessoriNuovi = 0;
            int? TotaleAccessoriRiuso = 0;
            int? TotaleAntenneNuovi = 0;
            int? TotaleAntenneRiuso = 0;

            TotaleCostiCME = installazione.InstallazioneCme.Sum(cme => cme.PrezzoTotale);
            TotaleRighe += installazione.InstallazioneCme.Count();

            TotaleCostiApparati = installazione.InstallazioneApparati.Where(sApp => sApp.Riuso == false).Sum(sApp => sApp.PrezzoTotale);
            TotaleApparatiNuovi = installazione.InstallazioneApparati.Where(sApp => sApp.Riuso == false).Sum(sApp => sApp.Quantita);
            TotaleApparatiRiuso = installazione.InstallazioneApparati.Where(sApp => sApp.Riuso == true).Sum(sApp => sApp.Quantita);
            TotaleRighe += installazione.InstallazioneApparati.Count();

            TotaleCostiAntenne = installazione.InstallazioneAntenne.Where(sAnt => sAnt.Riuso == false).Sum(sAnt => sAnt.PrezzoTotale);
            TotaleAntenneNuovi = installazione.InstallazioneAntenne.Where(sAnt => sAnt.Riuso == false).Sum(sAnt => sAnt.Quantita);
            TotaleAntenneRiuso = installazione.InstallazioneAntenne.Where(sAnt => sAnt.Riuso == true).Sum(sAnt => sAnt.Quantita);
            TotaleRighe += installazione.InstallazioneAntenne.Count();

            TotaleCostiAccessori = installazione.InstallazioneAccessori.Where(sAcc => sAcc.Riuso == false).Sum(sAcc => sAcc.PrezzoTotale);
            TotaleAccessoriNuovi = installazione.InstallazioneAccessori.Where(sAcc => sAcc.Riuso == false).Sum(sAcc => sAcc.Quantita);
            TotaleAccessoriRiuso = installazione.InstallazioneAccessori.Where(sAcc => sAcc.Riuso == true).Sum(sAcc => sAcc.Quantita);
            TotaleRighe += installazione.InstallazioneAccessori.Count();

            // Calcolo totali
            if (TotaleRighe > 0)
            {
                TotaleCosti = TotaleCostiCME + TotaleCostiApparati + TotaleCostiAntenne + TotaleCostiAccessori;
                installazione.CostoTotaleConsuntivato = (double)TotaleCosti;
                installazione.DeltaStimatoConsuntivato = richiesta.Sopralluogo.StimaIntervento - installazione.CostoTotaleConsuntivato;
                TotaleCostiApparatiAccessori = TotaleCostiApparati + TotaleCostiAntenne + TotaleCostiAccessori;
                installazione.CostoApparatiAccessoriConsuntivato = (double)TotaleCostiApparatiAccessori;
                TotaleNuovo = TotaleApparatiNuovi + TotaleAntenneNuovi + TotaleAccessoriNuovi;
                installazione.TotaleApparatiNuovi = TotaleApparatiNuovi;
                TotaleRiuso = TotaleApparatiRiuso + TotaleAntenneRiuso + TotaleAccessoriRiuso;
                installazione.TotaleApparatiRiuso = TotaleApparatiRiuso;
            }
            var result = _RCDDbContext.Update(installazione);
            _RCDDbContext.SaveChanges();
        }

    }
}
