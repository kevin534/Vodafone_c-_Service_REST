﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;

namespace RCD.Code.Installazione
{
    public class DocumentazioneInstallazioneManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public DocumentazioneInstallazioneManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<EntityDocumentazioneInstallazione>> GetDocumentazioneInstallazionebyInstallazioneId(DocumentazioneInstallazioneRequestFull docInstallazione)
        {
            List<EntityDocumentazioneInstallazione> docInstallazioni;

            String sortParam = String.Concat(String.Concat(docInstallazione.CampoOrdinamento, " "), docInstallazione.Ordinamento.ToUpper());
            DateTime newDate = DateTime.MinValue;
            if (docInstallazione.Filter.DataInserimento != newDate)
                newDate = docInstallazione.Filter.DataInserimento.Date;

            if (docInstallazione.Pageable)
            {
                docInstallazioni = await _RCDDbContext.DocInstallazione.Where(x => x.Active == true && x.IdInstallazione.Equals(docInstallazione.Filter.IdInstallazione))
                    .WhereIf(!docInstallazione.Filter.DataInserimento.ToString("dd/MM/yyyy HH:mm:ss").Equals(DateTime.MinValue.ToString("dd/MM/yyyy HH:mm:ss")), q => q.DataInserimento.Date == newDate)
                    .WhereIf(!String.IsNullOrEmpty(docInstallazione.Filter.Nome.ToString()), q => q.Nome.Equals(docInstallazione.Filter.Nome))
                    .OrderBy(sortParam)
                    .Skip(docInstallazione.NumeroElementi * docInstallazione.Page).Take(docInstallazione.NumeroElementi)
                    .Include("Installazione")
                    .ToListAsync();
            }
            else
            {
                docInstallazioni = await _RCDDbContext.DocInstallazione.Where(x => x.Active == true && x.IdInstallazione.Equals(docInstallazione.Filter.IdInstallazione))
                    //.WhereIf(!String.IsNullOrEmpty(docInstallazione.Filter.Installazione.Id.ToString()), q => q.Installazione.Id.Equals(docInstallazione.Filter.Installazione.Id))
                    .WhereIf(!docInstallazione.Filter.DataInserimento.ToString("dd/MM/yyyy HH:mm:ss").Equals(DateTime.MinValue.ToString("dd/MM/yyyy HH:mm:ss")), q => q.DataInserimento.Date == newDate)
                    .WhereIf(!String.IsNullOrEmpty(docInstallazione.Filter.Nome.ToString()), q => q.Nome.Equals(docInstallazione.Filter.Nome))
                    .OrderBy(sortParam)
                    .Include("Installazione")
                    .ToListAsync();
            }

            return docInstallazioni;


        }

        public async Task<Int32> GetDocumentazioneInstallazionebyInstallazioneIdTot(DocumentazioneInstallazioneRequestFull docInstallazione)
        {

            DateTime newDate = DateTime.MinValue;
            if (docInstallazione.Filter.DataInserimento != newDate)
                newDate = docInstallazione.Filter.DataInserimento.Date;

            Int32 countDocInstallazioni = _RCDDbContext.DocInstallazione.Where(x => x.Active == true && x.IdInstallazione.Equals(docInstallazione.Filter.IdInstallazione))
                 .WhereIf(!docInstallazione.Filter.DataInserimento.ToString("dd/MM/yyyy HH:mm:ss").Equals(DateTime.MinValue.ToString("dd/MM/yyyy HH:mm:ss")), q => q.DataInserimento.Date == newDate)
                 .WhereIf(!String.IsNullOrEmpty(docInstallazione.Filter.Nome.ToString()), q => q.Nome.Equals(docInstallazione.Filter.Nome))
                 //.WhereIf(!String.IsNullOrEmpty(docInstallazione.Filter.Installazione.Id.ToString()), q => q.Installazione.Id.Equals(docInstallazione.Filter.Installazione.Id))
                 .Include("Installazione")
                 .Count();

            return countDocInstallazioni;
        }


    }
}
