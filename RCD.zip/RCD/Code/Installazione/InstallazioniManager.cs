﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Request;
using RCDEngine.Entities;
using RCDContracts.Data;
using RCD.Code.Amministrazione;
using System;
using RCD.Code.Richieste;

namespace RCD.Code.Installazione
{
    public class InstallazioniManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public InstallazioniManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        public async Task<List<ContractRichiedente>> GetRichiedente(RichiedenteRequestFull richiedente)
        {
            List<EntityRichiedente> richiedenti;

            String sortParam = String.Concat(String.Concat(richiedente.CampoOrdinamento, " "), richiedente.Ordinamento.ToUpper());

            if (richiedente.Pageable)
            {

                richiedenti = await _RCDDbContext.Richiedente
                    //.Where(x => x.Id.Equals(richiedente.Filter.Id))
                        .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.PartitaIVA), q => q.PartitaIVA.Contains(richiedente.Filter.PartitaIVA))
                        .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.RagioneSociale), q => q.RagioneSociale.Contains(richiedente.Filter.RagioneSociale))
                        .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.CodiceCliente), q => q.CodiceCliente.Contains(richiedente.Filter.CodiceCliente))
                         .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.RiferimentoFullName), q => q.RiferimentoFullName.Contains(richiedente.Filter.RiferimentoFullName))
                          .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.MailRiferimento), q => q.MailRiferimento.Contains(richiedente.Filter.MailRiferimento))
                           .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(richiedente.Filter.TelefonoRiferimento))
                        .OrderBy(sortParam)
                        .Skip(richiedente.NumeroElementi * richiedente.Page).Take(richiedente.NumeroElementi)
                        .Include("TipologiaCliente")
                        .Include("CanaleVendita")
                        .Include("CanaleVenditaDettaglio")
                        .Include("Area")
                        .Include("AreaVendite")
                        .Include("Distretto")
                        .ToListAsync();
            }
            else
            {
                richiedenti = await _RCDDbContext.Richiedente
                    //.Where(x => x.Id.Equals(richiedente.Filter.Id))
                        .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.PartitaIVA), q => q.PartitaIVA.Contains(richiedente.Filter.PartitaIVA))
                        .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.RagioneSociale), q => q.RagioneSociale.Contains(richiedente.Filter.RagioneSociale))
                        .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.CodiceCliente), q => q.CodiceCliente.Contains(richiedente.Filter.CodiceCliente))
                         .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.RiferimentoFullName), q => q.RiferimentoFullName.Contains(richiedente.Filter.RiferimentoFullName))
                          .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.MailRiferimento), q => q.MailRiferimento.Contains(richiedente.Filter.MailRiferimento))
                           .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(richiedente.Filter.TelefonoRiferimento))
                        .OrderBy(sortParam)
                        .Include("TipologiaCliente")
                        .Include("CanaleVendita")
                        .Include("CanaleVenditaDettaglio")
                        .Include("Area")
                        .Include("AreaVendite")
                        .Include("Distretto")
                        .ToListAsync();
            }

            List<ContractRichiedente> richiedenteElenco = new List<ContractRichiedente>();
            foreach (EntityRichiedente varRichiedente in richiedenti)
            {
                ContractRichiedente richiedente1 = new ContractRichiedente();
                UtilityManager.MapProp(varRichiedente, richiedente1);
                richiedenteElenco.Add(richiedente1);
            }
            return richiedenteElenco;
        }
        public async Task<Int32> GetRichiedenteTot(RichiedenteRequestFull richiedente)
        {
            String sortParam = String.Concat(String.Concat(richiedente.CampoOrdinamento, " "), richiedente.Ordinamento.ToUpper());
            Int32 count =  _RCDDbContext.Richiedente
                //.Where(x => x.Id.Equals(richiedente.Filter.Id))
                        .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.PartitaIVA), q => q.PartitaIVA.Contains(richiedente.Filter.PartitaIVA))
                        .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.RagioneSociale), q => q.RagioneSociale.Contains(richiedente.Filter.RagioneSociale))
                        .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.CodiceCliente), q => q.CodiceCliente.Contains(richiedente.Filter.CodiceCliente))
                         .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.RiferimentoFullName), q => q.RiferimentoFullName.Contains(richiedente.Filter.RiferimentoFullName))
                          .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.MailRiferimento), q => q.MailRiferimento.Contains(richiedente.Filter.MailRiferimento))
                           .WhereIf(!String.IsNullOrEmpty(richiedente.Filter.TelefonoRiferimento), q => q.TelefonoRiferimento.Contains(richiedente.Filter.TelefonoRiferimento))
                        .OrderBy(sortParam)
                        .Include("TipologiaCliente")
                        .Include("CanaleVendita")
                        .Include("CanaleVenditaDettaglio")
                        .Include("Area")
                        .Include("AreaVendite")
                        .Include("Distretto")
                        .Count();

            return count;
        }

        #region INSTALLAZIONE COMPLETE
        public async Task<List<ContractLocation>> GetInstallazioniComplete(LocationRequestFull location ,Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(location.CampoOrdinamento, " "),
                              location.Ordinamento.ToUpper()); 

            List<ContractLocation> locations = new List<ContractLocation>();
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();

            if (utente.IdZona != null)
            {

                region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
                   .Select(x => x.Id)
                   .ToList();
            }
            else {
                List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                   .ToListAsync();
                if (listUtenteProvincia.Count() > 0)
                {

                    province = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente.Equals(utente.Id))
                        .Select(x => x.StsProvincia.Id)
                        .ToList();
                }
                else
                {
                    return null;
                }
            }
            

            if (location.Pageable)
            {
                    locations = await _RCDDbContext.Location
                        .Where(q => (q.LocationApparati.Count() > 0 || q.LocationAntenne.Count() > 0 || q.LocationAccessori.Count() > 0)
                         && q.IsDismesso == false)
                        .WhereIf(region.Count()>0 ,q=> region.Contains(q.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))
                        .WhereIf(province.Count() > 0 , q => province.Contains(q.StsComune.ProvinciaSts.Id))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.Id.ToString()), q => q.Id.Equals(location.Filter.Id))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdRichiedente.ToString()), q => q.IdRichiedente.Equals(location.Filter.IdRichiedente))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdComune.ToString()), q => q.IdComune.Equals(location.Filter.IdComune))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdOffice.ToString()), q => q.IdOffice.Equals(location.Filter.IdOffice))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdCoperturaIndoorAltriGestori.ToString()), q => q.IdCoperturaIndoorAltriGestori.Equals(location.Filter.IdCoperturaIndoorAltriGestori))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdDisponibilitaAccessoAlTetto.ToString()), q => q.IdDisponibilitaAccessoAlTetto.Equals(location.Filter.IdDisponibilitaAccessoAlTetto))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdTipologiaStabile.ToString()), q => q.IdTipologiaStabile.Equals(location.Filter.IdTipologiaStabile))

                        .WhereIf(!String.IsNullOrEmpty(location.Filter.CodiceRepeater), q => q.CodiceRepeater.Contains(location.Filter.CodiceRepeater))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(location.Filter.NomeInstallazione))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.Indirizzo), q => q.Indirizzo.Contains(location.Filter.Indirizzo))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.CAP), q => q.CAP.Contains(location.Filter.CAP))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.Office), q => q.Office.Contains(location.Filter.Office))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.ProgressivoOffice.ToString()), q => q.ProgressivoOffice.Equals(location.Filter.ProgressivoOffice))

                        .WhereIf(!String.IsNullOrEmpty(location.Filter.FullNameReferenteLocale), q => q.FullNameReferenteLocale.Contains(location.Filter.FullNameReferenteLocale))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.TelefonoReferenteLocale), q => q.TelefonoReferenteLocale.Contains(location.Filter.TelefonoReferenteLocale))

                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.CognomeRiferimento), q => q.Richiedente.CognomeRiferimento.Contains(location.Filter.Richiedente.CognomeRiferimento))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.CodicePosAgenzia), q => q.Richiedente.CodicePosAgenzia.Contains(location.Filter.Richiedente.CodicePosAgenzia))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.AgenziaRiferimento), q => q.Richiedente.AgenziaRiferimento.Contains(location.Filter.Richiedente.AgenziaRiferimento))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.MailRiferimento), q => q.Richiedente.MailRiferimento.Contains(location.Filter.Richiedente.MailRiferimento))

                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.CodiceCliente), q => q.Richiedente.CodiceCliente.Contains(location.Filter.Richiedente.CodiceCliente))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.PartitaIVA), q => q.Richiedente.PartitaIVA.Contains(location.Filter.Richiedente.PartitaIVA))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.RagioneSociale), q => q.Richiedente.RagioneSociale.Contains(location.Filter.Richiedente.RagioneSociale))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.NomeRiferimento), q => q.Richiedente.NomeRiferimento.Contains(location.Filter.Richiedente.NomeRiferimento))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.MailRiferimento), q => q.Richiedente.MailRiferimento.Contains(location.Filter.Richiedente.MailRiferimento))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(location.Filter.Richiedente.NumeroInterniVRUC))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(location.Filter.Richiedente.NumeroSIM))

                        .WhereIf(location.Filter.StsComune != null && !String.IsNullOrEmpty(location.Filter.StsComune.Descrizione), q => q.StsComune.Descrizione.Contains(location.Filter.StsComune.Descrizione))
                        .WhereIf(location.Filter.StsComune != null && !String.IsNullOrEmpty(location.Filter.StsComune.Cap), q => q.StsComune.Cap.Contains(location.Filter.StsComune.Cap))
                        .WhereIf(location.Filter.StsComune != null && !String.IsNullOrEmpty(location.Filter.StsComune.CodiceIstat), q => q.StsComune.CodiceIstat.Contains(location.Filter.StsComune.CodiceIstat))
                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Descrizione), q => q.StsComune.ProvinciaSts.Descrizione.Contains(location.Filter.StsComune.ProvinciaSts.Descrizione))
                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Sigla), q => q.StsComune.ProvinciaSts.Sigla.Contains(location.Filter.StsComune.ProvinciaSts.Sigla))

                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null
                                && location.Filter.StsComune.ProvinciaSts.RegioneSts != null && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.RegioneSts.Descrizione), q => q.StsComune.ProvinciaSts.RegioneSts.Descrizione.Contains(location.Filter.StsComune.ProvinciaSts.RegioneSts.Descrizione))
                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null
                                     && location.Filter.StsComune.ProvinciaSts.Provincia != null && location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF != null
                                    && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Region), q => q.StsComune.ProvinciaSts.Provincia.RegioneVF.Region.Contains(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Region))
                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null
                                     && location.Filter.StsComune.ProvinciaSts.Provincia != null && location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF != null
                                     && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.SiglaCodiceInstallazione), q => q.StsComune.ProvinciaSts.Provincia.RegioneVF.SiglaCodiceInstallazione.Contains(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.SiglaCodiceInstallazione))

                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null
                                     && location.Filter.StsComune.ProvinciaSts.Provincia != null && location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF != null
                                     && location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null
                        && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona), q => q.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Contains(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                        .OrderBy(sortParam)
                        .Include("Richiedente")
                        .Include("StsComune")
                        .Include("StsComune.ProvinciaSts")
                        .Include("StsComune.ProvinciaSts.RegioneSts")
                        .Include("StsComune.ProvinciaSts.Provincia")
                        .Include("StsComune.ProvinciaSts.Provincia.RegioneVF")
                        .Include("StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                        .Include("Richiedente.TipologiaCliente")
                        .Include("Richiedente.CanaleVendita")
                        .Include("Richiedente.CanaleVenditaDettaglio")
                        .Include("Richiedente.Area")
                        .Include("Richiedente.AreaVendite")
                        .Include("Richiedente.Distretto")
                        .Include("TipologiaStabile")
                        .Include("AccessibilitaTetto")
                        .Include("Gestori")
                        .Skip(location.NumeroElementi * location.Page).Take(location.NumeroElementi)
                        .Select(q => new ContractLocation()
                        {
                            Id = q.Id,
                            IdRichiedente = q.IdRichiedente,
                            IdComune = q.IdComune,
                            IdTipologiaStabile = q.IdTipologiaStabile,
                            IdDisponibilitaAccessoAlTetto = q.IdDisponibilitaAccessoAlTetto,
                            IdCoperturaIndoorAltriGestori = q.IdCoperturaIndoorAltriGestori,
                            CodiceRepeater = q.CodiceRepeater,
                            NomeInstallazione = q.NomeInstallazione,
                            Indirizzo = q.Indirizzo,
                            CAP = q.CAP,
                            ProprietaEdificio = q.ProprietaEdificio,
                            ParticellaCatastale = q.ParticellaCatastale,
                            Vincolo = q.Vincolo,
                            Office = q.Office,
                            ProgressivoOffice = q.ProgressivoOffice,
                            LatitudineGradi = q.LatitudineGradi,
                            LatitudinePrimi = q.LatitudinePrimi,
                            LatitudineUTM = q.LatitudineUTM,
                            LongitudineGradi = q.LongitudineGradi,
                            LongitudinePrimi = q.LongitudinePrimi,
                            LongitudineUTM = q.LongitudineUTM,
                            SLM = q.SLM,
                            DataOnAir = q.DataOnAir,
                            NoteLocation = q.NoteLocation,
                            DismissioneImpianti = q.DismissioneImpianti,
                            IsDismesso = q.IsDismesso,
                            DataDismissioneImpianti = q.DataDismissioneImpianti,
                            StabileDiProprieta = q.StabileDiProprieta,
                            MotivoDismissione = q.MotivoDismissione,
                            Note = q.Note,
                            IdOffice = q.IdOffice,
                            FullNameReferenteLocale = q.FullNameReferenteLocale,
                            TelefonoReferenteLocale = q.TelefonoReferenteLocale,
                            EmailReferenteLocale = q.EmailReferenteLocale,
                            Richiedente = new ContractRichiedente
                            {
                                Id = q.Richiedente.Id,
                                IdTipologiaCliente = q.Richiedente.Id,
                                IdCanaleVendita = q.Richiedente.IdCanaleVendita,
                                IdCanaleVenditeDettaglio = q.Richiedente.IdCanaleVenditeDettaglio,
                                IdArea = q.Richiedente.IdArea,
                                IdAreaVendite = q.Richiedente.IdAreaVendite,
                                IdDistretto = q.Richiedente.IdDistretto,
                                RagioneSociale = q.Richiedente.RagioneSociale,
                                CodiceCliente = q.Richiedente.CodiceCliente,
                                AgenziaRiferimento = q.Richiedente.AgenziaRiferimento,
                                CodicePosAgenzia = q.Richiedente.CodicePosAgenzia,
                                CognomeRiferimento = q.Richiedente.CognomeRiferimento,
                                NomeRiferimento = q.Richiedente.NomeRiferimento,
                                RiferimentoFullName = q.Richiedente.RiferimentoFullName,
                                TelefonoRiferimento = q.Richiedente.TelefonoRiferimento,
                                MailRiferimento = q.Richiedente.MailRiferimento,
                                NumeroSIM = q.Richiedente.NumeroSIM,
                                NumeroInterniVRUC = q.Richiedente.NumeroInterniVRUC,
                                FatturatoMedioBimestrale = q.Richiedente.FatturatoMedioBimestrale,
                                TipologiaCliente = q.Richiedente.IdTipologiaCliente != null ? new ContractTipologiaCliente
                                {
                                    Id = q.Richiedente.TipologiaCliente.Id,
                                    TipologiaCliente = q.Richiedente.TipologiaCliente.TipologiaCliente
                                } : null,
                                CanaleVendita = q.Richiedente.IdCanaleVendita != null ? new ContractCanaleVendita
                                {
                                    Id = q.Richiedente.CanaleVendita.Id,
                                    Canale = q.Richiedente.CanaleVendita.Canale
                                } : null,
                                CanaleVenditaDettaglio = q.Richiedente.IdCanaleVenditeDettaglio != null ? new ContractCanaleVenditaDettaglio
                                {
                                    Id = q.Richiedente.CanaleVenditaDettaglio.Id,
                                    Descrizione = q.Richiedente.CanaleVenditaDettaglio.Descrizione
                                } : null,
                                Area = q.Richiedente.IdArea != null ? new ContractArea
                                {
                                    Id = q.Richiedente.Area.Id,
                                    Descrizione = q.Richiedente.Area.Descrizione
                                } : null,
                                AreaVendite = q.Richiedente.IdAreaVendite != null ? new ContractAreaVendite
                                {
                                    Id = q.Richiedente.AreaVendite.Id,
                                    Descrizione = q.Richiedente.AreaVendite.Descrizione
                                } : null,
                                Distretto = q.Richiedente.IdDistretto != null ? new ContractDistretto
                                {
                                    Id = q.Richiedente.Distretto.Id,
                                    NomeDistretti = q.Richiedente.Distretto.NomeDistretti
                                } : null,
                            },
                            StsComune= q.StsComune != null ? new ContractStsComune
                            {
                                Id= q.StsComune.Id,
                                IdProvinciaSts = q.StsComune.IdProvinciaSts,
                                Descrizione= q.StsComune.Descrizione,
                                Cap= q.StsComune.Cap,
                                CodiceIstat= q.StsComune.CodiceIstat,
                                ProvinciaSts = q.StsComune.ProvinciaSts != null ? new ContractStsProvincia
                                {
                                    Id= q.StsComune.ProvinciaSts.Id,
                                    IdProvincia= q.StsComune.ProvinciaSts.IdProvincia,
                                    IdRegioneSts = q.StsComune.ProvinciaSts.IdRegioneSts,
                                    Descrizione = q.StsComune.ProvinciaSts.Descrizione,
                                    Sigla= q.StsComune.ProvinciaSts.Sigla,
                                    Provincia = q.StsComune.ProvinciaSts.Provincia != null? new ContractProvincia
                                    {
                                        Id= q.StsComune.ProvinciaSts.Provincia.Id,
                                        IdRegioneVF = q.StsComune.ProvinciaSts.Provincia.IdRegioneVF,
                                        RegioneVF = q.StsComune.ProvinciaSts.Provincia.RegioneVF != null ? new ContractRegioneVF
                                        {
                                            Id= q.StsComune.ProvinciaSts.Provincia.RegioneVF.Id,
                                            IdZona = q.StsComune.ProvinciaSts.Provincia.RegioneVF.IdZona,
                                            Region = q.StsComune.ProvinciaSts.Provincia.RegioneVF.Region,
                                            SiglaCodiceInstallazione = q.StsComune.ProvinciaSts.Provincia.RegioneVF.SiglaCodiceInstallazione,
                                            Zona= q.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null ? new ContractZona
                                            {
                                                Id=q.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id,
                                                Zona = q.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona,
                                                ProgressivoZona = q.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.ProgressivoZona,
                                            } : null
                                        } : null

                                    }: null,
                                    RegioneSts= q.StsComune.ProvinciaSts.RegioneSts != null ? new ContractStsRegione
                                    {
                                        Id= q.StsComune.ProvinciaSts.RegioneSts.Id,
                                        Descrizione = q.StsComune.ProvinciaSts.RegioneSts.Descrizione
                                    }: null
                                } :null
                            }: null,            
                            TipologiaStabile = q.TipologiaStabile != null ? new ContractTipologiaStabile
                            {
                                Id = q.TipologiaStabile.Id,
                                TipologiaStabile = q.TipologiaStabile.TipologiaStabile
                            } : null,
                            AccessibilitaTetto = q.AccessibilitaTetto != null ? new ContractAccessibilitaTetto
                            {
                                Id = q.AccessibilitaTetto.Id,
                                AccessibilitaTetto = q.AccessibilitaTetto.AccessibilitaTetto
                            } : null,
                            Gestori = q.Gestori !=null ? new ContractGestori
                            {
                                Id = q.Gestori.Id,
                                Gestore= q.Gestori.Gestore
                            } :null,

                            NumeriApparatiGsm = q.LocationApparati.Where(r => r.Apparato.Sistema.Sistema.ToLower() == "gsm").Count(),
                            NumeriApparatiUmts = q.LocationApparati.Where(r => r.Apparato.Sistema.Sistema.ToLower() == "umts").Count(),
                            NumeriApparatiLTE = q.LocationApparati.Where(r => r.Apparato.Sistema.Sistema.ToLower() == "lte").Count(),
                            NumeriApparatiGsmUmts = q.LocationApparati.Where(r => r.Apparato.Sistema.Sistema.ToLower() == "gsm/umts").Count(),
                            NumeriApparatiGsmLTE = q.LocationApparati.Where(r => r.Apparato.Sistema.Sistema.ToLower() == "gsm/lte").Count()

                        })
                        .ToListAsync();
            }
            else
            {
                locations = await _RCDDbContext.Location
                        .Where(q => (q.LocationApparati.Count() > 0 || q.LocationAntenne.Count() > 0 || q.LocationAccessori.Count() > 0)
                         && q.IsDismesso == false)
                        .WhereIf(region.Count() > 0, q => region.Contains(q.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))
                        .WhereIf(province.Count() > 0, q => province.Contains(q.StsComune.ProvinciaSts.Id))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.Id.ToString()), q => q.Id.Equals(location.Filter.Id))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdRichiedente.ToString()), q => q.IdRichiedente.Equals(location.Filter.IdRichiedente))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdComune.ToString()), q => q.IdComune.Equals(location.Filter.IdComune))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdOffice.ToString()), q => q.IdOffice.Equals(location.Filter.IdOffice))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdCoperturaIndoorAltriGestori.ToString()), q => q.IdCoperturaIndoorAltriGestori.Equals(location.Filter.IdCoperturaIndoorAltriGestori))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdDisponibilitaAccessoAlTetto.ToString()), q => q.IdDisponibilitaAccessoAlTetto.Equals(location.Filter.IdDisponibilitaAccessoAlTetto))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdTipologiaStabile.ToString()), q => q.IdTipologiaStabile.Equals(location.Filter.IdTipologiaStabile))

                        .WhereIf(!String.IsNullOrEmpty(location.Filter.CodiceRepeater), q => q.CodiceRepeater.Contains(location.Filter.CodiceRepeater))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(location.Filter.NomeInstallazione))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.Indirizzo), q => q.Indirizzo.Contains(location.Filter.Indirizzo))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.CAP), q => q.CAP.Contains(location.Filter.CAP))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.Office), q => q.Office.Contains(location.Filter.Office))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.ProgressivoOffice.ToString()), q => q.ProgressivoOffice.Equals(location.Filter.ProgressivoOffice))

                        .WhereIf(!String.IsNullOrEmpty(location.Filter.FullNameReferenteLocale), q => q.FullNameReferenteLocale.Contains(location.Filter.FullNameReferenteLocale))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.TelefonoReferenteLocale), q => q.TelefonoReferenteLocale.Contains(location.Filter.TelefonoReferenteLocale))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.CognomeRiferimento), q => q.Richiedente.CognomeRiferimento.Contains(location.Filter.Richiedente.CognomeRiferimento))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.CodicePosAgenzia), q => q.Richiedente.CodicePosAgenzia.Contains(location.Filter.Richiedente.CodicePosAgenzia))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.AgenziaRiferimento), q => q.Richiedente.AgenziaRiferimento.Contains(location.Filter.Richiedente.AgenziaRiferimento))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.MailRiferimento), q => q.Richiedente.MailRiferimento.Contains(location.Filter.Richiedente.MailRiferimento))

                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.CodiceCliente), q => q.Richiedente.CodiceCliente.Contains(location.Filter.Richiedente.CodiceCliente))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.PartitaIVA), q => q.Richiedente.PartitaIVA.Contains(location.Filter.Richiedente.PartitaIVA))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.RagioneSociale), q => q.Richiedente.RagioneSociale.Contains(location.Filter.Richiedente.RagioneSociale))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.NomeRiferimento), q => q.Richiedente.NomeRiferimento.Contains(location.Filter.Richiedente.NomeRiferimento))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.MailRiferimento), q => q.Richiedente.MailRiferimento.Contains(location.Filter.Richiedente.MailRiferimento))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(location.Filter.Richiedente.NumeroInterniVRUC))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(location.Filter.Richiedente.NumeroSIM))

                        .WhereIf(location.Filter.StsComune != null && !String.IsNullOrEmpty(location.Filter.StsComune.Descrizione), q => q.StsComune.Descrizione.Contains(location.Filter.StsComune.Descrizione))
                        .WhereIf(location.Filter.StsComune != null && !String.IsNullOrEmpty(location.Filter.StsComune.Cap), q => q.StsComune.Cap.Contains(location.Filter.StsComune.Cap))
                        .WhereIf(location.Filter.StsComune != null && !String.IsNullOrEmpty(location.Filter.StsComune.CodiceIstat), q => q.StsComune.CodiceIstat.Contains(location.Filter.StsComune.CodiceIstat))
                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Descrizione), q => q.StsComune.ProvinciaSts.Descrizione.Contains(location.Filter.StsComune.ProvinciaSts.Descrizione))
                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Sigla), q => q.StsComune.ProvinciaSts.Sigla.Contains(location.Filter.StsComune.ProvinciaSts.Sigla))

                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null
                                && location.Filter.StsComune.ProvinciaSts.RegioneSts != null && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.RegioneSts.Descrizione), q => q.StsComune.ProvinciaSts.RegioneSts.Descrizione.Contains(location.Filter.StsComune.ProvinciaSts.RegioneSts.Descrizione))
                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null
                                     && location.Filter.StsComune.ProvinciaSts.Provincia != null && location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF != null
                                    && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Region), q => q.StsComune.ProvinciaSts.Provincia.RegioneVF.Region.Contains(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Region))
                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null
                                     && location.Filter.StsComune.ProvinciaSts.Provincia != null && location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF != null
                                     && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.SiglaCodiceInstallazione), q => q.StsComune.ProvinciaSts.Provincia.RegioneVF.SiglaCodiceInstallazione.Contains(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.SiglaCodiceInstallazione))

                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null
                                     && location.Filter.StsComune.ProvinciaSts.Provincia != null && location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF != null
                                     && location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null
                        && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona), q => q.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Contains(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                        .OrderBy(sortParam)
                        .Include("Richiedente")
                        .Include("StsComune")
                        .Include("StsComune.ProvinciaSts")
                        .Include("StsComune.ProvinciaSts.RegioneSts")
                        .Include("StsComune.ProvinciaSts.Provincia")
                        .Include("StsComune.ProvinciaSts.Provincia.RegioneVF")
                        .Include("StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                        .Include("Richiedente.CanaleVendita")
                        .Include("Richiedente.CanaleVenditaDettaglio")
                        .Include("Richiedente.Area")
                        .Include("Richiedente.AreaVendite")
                        .Include("Richiedente.Distretto")
                        .Include("TipologiaStabile")
                        .Include("AccessibilitaTetto")
                        .Include("Gestori")
                        .Select(q => new ContractLocation()
                                              {
                                                  Id = q.Id,
                                                  IdRichiedente = q.IdRichiedente,
                                                  IdComune = q.IdComune,
                                                  IdTipologiaStabile = q.IdTipologiaStabile,
                                                  IdDisponibilitaAccessoAlTetto = q.IdDisponibilitaAccessoAlTetto,
                                                  IdCoperturaIndoorAltriGestori = q.IdCoperturaIndoorAltriGestori,
                                                  CodiceRepeater = q.CodiceRepeater,
                                                  NomeInstallazione = q.NomeInstallazione,
                                                  Indirizzo = q.Indirizzo,
                                                  CAP = q.CAP,
                                                  ProprietaEdificio = q.ProprietaEdificio,
                                                  ParticellaCatastale = q.ParticellaCatastale,
                                                  Vincolo = q.Vincolo,
                                                  Office = q.Office,
                                                  ProgressivoOffice = q.ProgressivoOffice,
                                                  LatitudineGradi = q.LatitudineGradi,
                                                  LatitudinePrimi = q.LatitudinePrimi,
                                                  LatitudineUTM = q.LatitudineUTM,
                                                  LongitudineGradi = q.LongitudineGradi,
                                                  LongitudinePrimi = q.LongitudinePrimi,
                                                  LongitudineUTM = q.LongitudineUTM,
                                                  SLM = q.SLM,
                                                  DataOnAir = q.DataOnAir,
                                                  NoteLocation = q.NoteLocation,
                                                  DismissioneImpianti = q.DismissioneImpianti,
                                                  IsDismesso = q.IsDismesso,
                                                  DataDismissioneImpianti = q.DataDismissioneImpianti,
                                                  StabileDiProprieta = q.StabileDiProprieta,
                                                  MotivoDismissione = q.MotivoDismissione,
                                                  Note = q.Note,
                                                  IdOffice = q.IdOffice,
                                                  FullNameReferenteLocale = q.FullNameReferenteLocale,
                                                  TelefonoReferenteLocale = q.TelefonoReferenteLocale,
                                                  EmailReferenteLocale = q.EmailReferenteLocale,
                                                  Richiedente = new ContractRichiedente
                                                  {
                                                      Id = q.Richiedente.Id,
                                                      IdTipologiaCliente = q.Richiedente.Id,
                                                      IdCanaleVendita = q.Richiedente.IdCanaleVendita,
                                                      IdCanaleVenditeDettaglio = q.Richiedente.IdCanaleVenditeDettaglio,
                                                      IdArea = q.Richiedente.IdArea,
                                                      IdAreaVendite = q.Richiedente.IdAreaVendite,
                                                      IdDistretto = q.Richiedente.IdDistretto,
                                                      RagioneSociale = q.Richiedente.RagioneSociale,
                                                      CodiceCliente = q.Richiedente.CodiceCliente,
                                                      AgenziaRiferimento = q.Richiedente.AgenziaRiferimento,
                                                      CodicePosAgenzia = q.Richiedente.CodicePosAgenzia,
                                                      CognomeRiferimento = q.Richiedente.CognomeRiferimento,
                                                      NomeRiferimento = q.Richiedente.NomeRiferimento,
                                                      RiferimentoFullName = q.Richiedente.RiferimentoFullName,
                                                      TelefonoRiferimento = q.Richiedente.TelefonoRiferimento,
                                                      MailRiferimento = q.Richiedente.MailRiferimento,
                                                      NumeroSIM = q.Richiedente.NumeroSIM,
                                                      NumeroInterniVRUC = q.Richiedente.NumeroInterniVRUC,
                                                      FatturatoMedioBimestrale = q.Richiedente.FatturatoMedioBimestrale,
                                                      TipologiaCliente = q.Richiedente.IdTipologiaCliente != null ? new ContractTipologiaCliente
                                                      {
                                                          Id = q.Richiedente.TipologiaCliente.Id,
                                                          TipologiaCliente = q.Richiedente.TipologiaCliente.TipologiaCliente
                                                      } : null,
                                                      CanaleVendita = q.Richiedente.IdCanaleVendita != null ? new ContractCanaleVendita
                                                      {
                                                          Id = q.Richiedente.CanaleVendita.Id,
                                                          Canale = q.Richiedente.CanaleVendita.Canale
                                                      } : null,
                                                      CanaleVenditaDettaglio = q.Richiedente.IdCanaleVenditeDettaglio != null ? new ContractCanaleVenditaDettaglio
                                                      {
                                                          Id = q.Richiedente.CanaleVenditaDettaglio.Id,
                                                          Descrizione = q.Richiedente.CanaleVenditaDettaglio.Descrizione
                                                      } : null,
                                                      Area = q.Richiedente.IdArea != null ? new ContractArea
                                                      {
                                                          Id = q.Richiedente.Area.Id,
                                                          Descrizione = q.Richiedente.Area.Descrizione
                                                      } : null,
                                                      AreaVendite = q.Richiedente.IdAreaVendite != null ? new ContractAreaVendite
                                                      {
                                                          Id = q.Richiedente.AreaVendite.Id,
                                                          Descrizione = q.Richiedente.AreaVendite.Descrizione
                                                      } : null,
                                                      Distretto = q.Richiedente.IdDistretto != null ? new ContractDistretto
                                                      {
                                                          Id = q.Richiedente.Distretto.Id,
                                                          NomeDistretti = q.Richiedente.Distretto.NomeDistretti
                                                      } : null,
                                                  },
                                                  StsComune = q.StsComune != null ? new ContractStsComune
                                                  {
                                                      Id = q.StsComune.Id,
                                                      IdProvinciaSts = q.StsComune.IdProvinciaSts,
                                                      Descrizione = q.StsComune.Descrizione,
                                                      Cap = q.StsComune.Cap,
                                                      CodiceIstat = q.StsComune.CodiceIstat,
                                                      ProvinciaSts = q.StsComune.ProvinciaSts != null ? new ContractStsProvincia
                                                      {
                                                          Id = q.StsComune.ProvinciaSts.Id,
                                                          IdProvincia = q.StsComune.ProvinciaSts.IdProvincia,
                                                          IdRegioneSts = q.StsComune.ProvinciaSts.IdRegioneSts,
                                                          Descrizione = q.StsComune.ProvinciaSts.Descrizione,
                                                          Sigla = q.StsComune.ProvinciaSts.Sigla,
                                                          Provincia = q.StsComune.ProvinciaSts.Provincia != null ? new ContractProvincia
                                                          {
                                                              Id = q.StsComune.ProvinciaSts.Provincia.Id,
                                                              IdRegioneVF = q.StsComune.ProvinciaSts.Provincia.IdRegioneVF,
                                                              RegioneVF = q.StsComune.ProvinciaSts.Provincia.RegioneVF != null ? new ContractRegioneVF
                                                              {
                                                                  Id = q.StsComune.ProvinciaSts.Provincia.RegioneVF.Id,
                                                                  IdZona = q.StsComune.ProvinciaSts.Provincia.RegioneVF.IdZona,
                                                                  Region = q.StsComune.ProvinciaSts.Provincia.RegioneVF.Region,
                                                                  SiglaCodiceInstallazione = q.StsComune.ProvinciaSts.Provincia.RegioneVF.SiglaCodiceInstallazione,
                                                                  Zona = q.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null ? new ContractZona
                                                                  {
                                                                      Id = q.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id,
                                                                      Zona = q.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona,
                                                                      ProgressivoZona = q.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.ProgressivoZona,
                                                                  } : null
                                                              } : null

                                                          } : null,
                                                          RegioneSts = q.StsComune.ProvinciaSts.RegioneSts != null ? new ContractStsRegione
                                                          {
                                                              Id = q.StsComune.ProvinciaSts.RegioneSts.Id,
                                                              Descrizione = q.StsComune.ProvinciaSts.RegioneSts.Descrizione
                                                          } : null
                                                      } : null
                                                  } : null,
                                                  TipologiaStabile = q.TipologiaStabile != null ? new ContractTipologiaStabile
                                                  {
                                                      Id = q.TipologiaStabile.Id,
                                                      TipologiaStabile = q.TipologiaStabile.TipologiaStabile
                                                  } : null,
                                                  AccessibilitaTetto = q.AccessibilitaTetto != null ? new ContractAccessibilitaTetto
                                                  {
                                                      Id = q.AccessibilitaTetto.Id,
                                                      AccessibilitaTetto = q.AccessibilitaTetto.AccessibilitaTetto
                                                  } : null,
                                                  Gestori = q.Gestori != null ? new ContractGestori
                                                  {
                                                      Id = q.Gestori.Id,
                                                      Gestore = q.Gestori.Gestore
                                                  } : null,

                                                  NumeriApparatiGsm = q.LocationApparati.Where(r => r.Apparato.Sistema.Sistema.ToLower() == "gsm").Count(),
                                                  NumeriApparatiUmts = q.LocationApparati.Where(r => r.Apparato.Sistema.Sistema.ToLower() == "umts").Count(),
                                                  NumeriApparatiLTE = q.LocationApparati.Where(r => r.Apparato.Sistema.Sistema.ToLower() == "lte").Count(),
                                                  NumeriApparatiGsmUmts = q.LocationApparati.Where(r => r.Apparato.Sistema.Sistema.ToLower() == "gsm/umts").Count(),
                                                  NumeriApparatiGsmLTE = q.LocationApparati.Where(r => r.Apparato.Sistema.Sistema.ToLower() == "gsm/lte").Count()

                                              })
                        .ToListAsync();
            }
            return locations;
        }

        public async Task<Int32> GetInstallazioniCompleteTot(LocationRequestFull location, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(location.CampoOrdinamento, " "),
                              location.Ordinamento.ToUpper());

          
            List<Int64?> region = new List<Int64?>();
            List<Int64?> province = new List<Int64?>();

            if (utente.IdZona != null)
            {

                region = _RCDDbContext.RegioneVF.Where(x => x.IdZona.Equals(utente.IdZona))
                   .Select(x => x.Id)
                   .ToList();
            }
            else
            {
                List<EntityUtentiProvince> listUtenteProvincia = await _RCDDbContext.UtentiProvince.Where(x => x.IdUtente == utente.Id)
                                                 .ToListAsync();
                if (listUtenteProvincia.Count() > 0)
                {

                    province = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente.Equals(utente.Id))
                        .Select(x => x.StsProvincia.Id)
                        .ToList();
                }
                else
                {
                    return 0;
                }
            }


            Int32 locationsCount = _RCDDbContext.Location
                    .Where(q => (q.LocationApparati.Count() > 0 || q.LocationAntenne.Count() > 0 || q.LocationAccessori.Count() > 0)
                         && q.IsDismesso == false)
                        .WhereIf(region.Count() > 0, q => region.Contains(q.StsComune.ProvinciaSts.Provincia.RegioneVF.Id))
                        .WhereIf(province.Count() > 0, q => province.Contains(q.StsComune.ProvinciaSts.Id))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.Id.ToString()), q => q.Id.Equals(location.Filter.Id))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdRichiedente.ToString()), q => q.IdRichiedente.Equals(location.Filter.IdRichiedente))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdComune.ToString()), q => q.IdComune.Equals(location.Filter.IdComune))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdOffice.ToString()), q => q.IdOffice.Equals(location.Filter.IdOffice))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdCoperturaIndoorAltriGestori.ToString()), q => q.IdCoperturaIndoorAltriGestori.Equals(location.Filter.IdCoperturaIndoorAltriGestori))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdDisponibilitaAccessoAlTetto.ToString()), q => q.IdDisponibilitaAccessoAlTetto.Equals(location.Filter.IdDisponibilitaAccessoAlTetto))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.IdTipologiaStabile.ToString()), q => q.IdTipologiaStabile.Equals(location.Filter.IdTipologiaStabile))

                        .WhereIf(!String.IsNullOrEmpty(location.Filter.CodiceRepeater), q => q.CodiceRepeater.Contains(location.Filter.CodiceRepeater))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.NomeInstallazione), q => q.NomeInstallazione.Contains(location.Filter.NomeInstallazione))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.Indirizzo), q => q.Indirizzo.Contains(location.Filter.Indirizzo))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.CAP), q => q.CAP.Contains(location.Filter.CAP))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.Office), q => q.Office.Contains(location.Filter.Office))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.ProgressivoOffice.ToString()), q => q.ProgressivoOffice.Equals(location.Filter.ProgressivoOffice))

                        .WhereIf(!String.IsNullOrEmpty(location.Filter.FullNameReferenteLocale), q => q.FullNameReferenteLocale.Contains(location.Filter.FullNameReferenteLocale))
                        .WhereIf(!String.IsNullOrEmpty(location.Filter.TelefonoReferenteLocale), q => q.TelefonoReferenteLocale.Contains(location.Filter.TelefonoReferenteLocale))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.CognomeRiferimento), q => q.Richiedente.CognomeRiferimento.Contains(location.Filter.Richiedente.CognomeRiferimento))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.CodicePosAgenzia), q => q.Richiedente.CodicePosAgenzia.Contains(location.Filter.Richiedente.CodicePosAgenzia))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.AgenziaRiferimento), q => q.Richiedente.AgenziaRiferimento.Contains(location.Filter.Richiedente.AgenziaRiferimento))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.MailRiferimento), q => q.Richiedente.MailRiferimento.Contains(location.Filter.Richiedente.MailRiferimento))

                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.CodiceCliente), q => q.Richiedente.CodiceCliente.Contains(location.Filter.Richiedente.CodiceCliente))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.PartitaIVA), q => q.Richiedente.PartitaIVA.Contains(location.Filter.Richiedente.PartitaIVA))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.RagioneSociale), q => q.Richiedente.RagioneSociale.Contains(location.Filter.Richiedente.RagioneSociale))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.NomeRiferimento), q => q.Richiedente.NomeRiferimento.Contains(location.Filter.Richiedente.NomeRiferimento))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.MailRiferimento), q => q.Richiedente.MailRiferimento.Contains(location.Filter.Richiedente.MailRiferimento))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.NumeroInterniVRUC.ToString()), q => q.Richiedente.NumeroInterniVRUC.Equals(location.Filter.Richiedente.NumeroInterniVRUC))
                        .WhereIf(location.Filter.Richiedente != null && !String.IsNullOrEmpty(location.Filter.Richiedente.NumeroSIM.ToString()), q => q.Richiedente.NumeroSIM.Equals(location.Filter.Richiedente.NumeroSIM))

                        .WhereIf(location.Filter.StsComune != null && !String.IsNullOrEmpty(location.Filter.StsComune.Descrizione), q => q.StsComune.Descrizione.Contains(location.Filter.StsComune.Descrizione))
                        .WhereIf(location.Filter.StsComune != null && !String.IsNullOrEmpty(location.Filter.StsComune.Cap), q => q.StsComune.Cap.Contains(location.Filter.StsComune.Cap))
                        .WhereIf(location.Filter.StsComune != null && !String.IsNullOrEmpty(location.Filter.StsComune.CodiceIstat), q => q.StsComune.CodiceIstat.Contains(location.Filter.StsComune.CodiceIstat))
                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Descrizione), q => q.StsComune.ProvinciaSts.Descrizione.Contains(location.Filter.StsComune.ProvinciaSts.Descrizione))
                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Sigla), q => q.StsComune.ProvinciaSts.Sigla.Contains(location.Filter.StsComune.ProvinciaSts.Sigla))

                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null
                                && location.Filter.StsComune.ProvinciaSts.RegioneSts != null && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.RegioneSts.Descrizione), q => q.StsComune.ProvinciaSts.RegioneSts.Descrizione.Contains(location.Filter.StsComune.ProvinciaSts.RegioneSts.Descrizione))
                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null
                                     && location.Filter.StsComune.ProvinciaSts.Provincia != null && location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF != null
                                    && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Region), q => q.StsComune.ProvinciaSts.Provincia.RegioneVF.Region.Contains(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Region))
                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null
                                     && location.Filter.StsComune.ProvinciaSts.Provincia != null && location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF != null
                                     && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.SiglaCodiceInstallazione), q => q.StsComune.ProvinciaSts.Provincia.RegioneVF.SiglaCodiceInstallazione.Contains(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.SiglaCodiceInstallazione))

                        .WhereIf(location.Filter.StsComune != null && location.Filter.StsComune.ProvinciaSts != null
                                     && location.Filter.StsComune.ProvinciaSts.Provincia != null && location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF != null
                                     && location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona != null
                        && !String.IsNullOrEmpty(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona), q => q.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona.Contains(location.Filter.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Zona))
                        .OrderBy(sortParam)
                    //.Include("Richiedente")
                    //.Include("StsComune")
                    //.Include("StsComune.ProvinciaSts")
                    //.Include("StsComune.ProvinciaSts.RegioneSts")
                    //.Include("StsComune.ProvinciaSts.Provincia")
                    //.Include("StsComune.ProvinciaSts.Provincia.RegioneVF")
                    //.Include("StsComune.ProvinciaSts.Provincia.RegioneVF.Zona")
                    .Count();
           
            return locationsCount;
        }

        #endregion INSTALLAZIONE COMPLETE

        #region RICHIESTE BY IDLOCATION

        public async Task<List<ContractRichiesta>> GetRichiestaByIdLocation(RichiestaRequestFull richiesta)
        {
            List<EntityRichiesta> richieste;

            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "), richiesta.Ordinamento.ToUpper());

            if (richiesta.Pageable)
            {

                richieste = await _RCDDbContext.Richieste
                         //.Where(x => x.IdLocation.Equals(richiesta.Filter.IdLocation))
                         .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.IdLocation.ToString()), q => q.IdLocation.Equals(richiesta.Filter.IdLocation))
                        .OrderBy(sortParam)
                        .Include("Utente")
                        .Include("RiferimentoVendite")
                        .Include("RiferimentoAreaManager")
                        .Include("RiferimentoDce")
                        .Include("Richiedente")
                        .Include("Location")
                        .Include("Sopralluogo")
                        .Include("Installazione")
                        .Include("PrioritaVendite")
                        .Include("ProgettistaRan")
                        .Include("SiteManagerNI")
                        .Include("MotivoRichiesta")
                        .Include("TipologiaCopertura")
                        .Include("SistemaRichiesto")
                        .Include("Servizio")
                        .Include("MancanzaSegnaleEsterno")
                        .Include("MancanzaSegnaleInterno")
                        .Skip(richiesta.NumeroElementi * richiesta.Page).Take(richiesta.NumeroElementi)
                        .ToListAsync();
            }
            else
            {
                richieste = await _RCDDbContext.Richieste
                        //.Where(x => x.IdLocation.Equals(richiesta.Filter.IdLocation))
                        .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.IdLocation.ToString()), q => q.IdLocation.Equals(richiesta.Filter.IdLocation))
                       .OrderBy(sortParam)
                       .Include("Utente")
                       .Include("RiferimentoVendite")
                       .Include("RiferimentoAreaManager")
                       .Include("RiferimentoDce")
                       .Include("Richiedente")
                       .Include("Location")
                       .Include("Sopralluogo")
                       .Include("Installazione")
                       .Include("PrioritaVendite")
                       .Include("ProgettistaRan")
                       .Include("SiteManagerNI")
                       .Include("MotivoRichiesta")
                       .Include("TipologiaCopertura")
                       .Include("SistemaRichiesto")
                       .Include("Servizio")
                       .Include("MancanzaSegnaleEsterno")
                       .Include("MancanzaSegnaleInterno")
                       .ToListAsync();
            }

            List<ContractRichiesta> richiestaElenco = new List<ContractRichiesta>();
            foreach (EntityRichiesta varRichiesta in richieste)
            {
                ContractRichiesta richiesta1 = new ContractRichiesta();
                UtilityManager.MapProp(varRichiesta, richiesta1);
                richiestaElenco.Add(richiesta1);
            }
            return richiestaElenco;
        }

        public async Task<Int32> GetRichiestaByIdLocationTot(RichiestaRequestFull richiesta)
        {
            String sortParam = String.Concat(String.Concat(richiesta.CampoOrdinamento, " "), richiesta.Ordinamento.ToUpper());

            Int32 count = _RCDDbContext.Richieste
                        //.Where(x => x.IdLocation.Equals(richiesta.Filter.IdLocation))
                        .WhereIf(!String.IsNullOrEmpty(richiesta.Filter.IdLocation.ToString()), q => q.IdLocation.Equals(richiesta.Filter.IdLocation))
                       .OrderBy(sortParam)
                       .Include("Utente")
                       .Include("RiferimentoVendite")
                       .Include("RiferimentoAreaManager")
                       .Include("RiferimentoDce")
                       .Include("Richiedente")
                       .Include("Location")
                       .Include("Sopralluogo")
                       .Include("Installazione")
                       .Include("PrioritaVendite")
                       .Include("ProgettistaRan")
                       .Include("SiteManagerNI")
                       .Include("MotivoRichiesta")
                       .Include("TipologiaCopertura")
                       .Include("SistemaRichiesto")
                       .Include("Servizio")
                       .Include("MancanzaSegnaleEsterno")
                       .Include("MancanzaSegnaleInterno")
                        .Count();

            return count;
        }

        #endregion RICHIESTE BY IDLOCATION

        /// <summary>
        /// Crea una nuova installazione nel db delle installazioni
        /// </summary>
        /// <param name="location">Location su cui creare l'installazione</param>
        /// <param name="ctx">Contesto</param>
        public void CreaNuovaInstallazione(EntityLocation location)
        {
            location.IsDismesso = false;
            location.Vincolo = false;
            location.StabileDiProprieta = false;
            GenerateOffice(ref location);
            if( location.Richiedente != null)
            {
               
                EntityRichiedente? richiedenteOrig = _RCDDbContext.Richiedente.Where(x => x.Id == location.IdRichiedente)
                              .FirstOrDefault();
               
                 if(location.Richiedente.NomeRiferimento != null)
                    richiedenteOrig.NomeRiferimento= location.Richiedente.NomeRiferimento;
                if (location.Richiedente.CognomeRiferimento != null)
                    richiedenteOrig.CognomeRiferimento = location.Richiedente.CognomeRiferimento;
                if (location.Richiedente.MailRiferimento != null)
                    richiedenteOrig.MailRiferimento = location.Richiedente.MailRiferimento;
                if (location.Richiedente.TelefonoRiferimento != null)
                    richiedenteOrig.TelefonoRiferimento = location.Richiedente.TelefonoRiferimento;
                if (location.Richiedente.FatturatoMedioBimestrale != null)
                    richiedenteOrig.FatturatoMedioBimestrale = location.Richiedente.FatturatoMedioBimestrale;
                if (location.Richiedente.NumeroSIM != null)
                    richiedenteOrig.NumeroSIM = location.Richiedente.NumeroSIM;
                if (location.Richiedente.NumeroInterniVRUC != null)
                    richiedenteOrig.NumeroInterniVRUC = location.Richiedente.NumeroInterniVRUC;
                if (location.Richiedente.IdArea != null)
                    richiedenteOrig.IdArea = location.Richiedente.IdArea;
                if (location.Richiedente.IdAreaVendite != null)
                    richiedenteOrig.IdAreaVendite = location.Richiedente.IdAreaVendite;
                if (location.Richiedente.IdDistretto != null)
                    richiedenteOrig.IdDistretto = location.Richiedente.IdDistretto;
                if (location.Richiedente.IdCanaleVendita != null)
                    richiedenteOrig.IdCanaleVendita = location.Richiedente.IdCanaleVendita;
                if (location.Richiedente.IdCanaleVenditeDettaglio != null)
                    richiedenteOrig.IdCanaleVendita = location.Richiedente.IdCanaleVenditeDettaglio;
                if (location.Richiedente.IdTipologiaCliente != null)
                    richiedenteOrig.IdTipologiaCliente = location.Richiedente.IdTipologiaCliente;



                _RCDDbContext.Update(richiedenteOrig);
                location.Richiedente = null;
            }
            _RCDDbContext.Add(location);
            _RCDDbContext.SaveChanges();
        }

        /// <summary>
        /// Genera il codice office fittizio dell'anagrafica di Co.De.
        /// </summary>
        /// <param name="location">Location da elaborare</param>
        /// <param name="ctx">Il contesto</param>
        private void GenerateOffice(ref EntityLocation location)
        {
            if (string.IsNullOrWhiteSpace(location.Office))
            {
                Int64? idComune = location.IdComune;
                EntityStsComune? stsComune = _RCDDbContext.StsComune.Where(x => x.Id == idComune)
                                .Include("ProvinciaSts.Provincia.RegioneVF") 
                                .FirstOrDefault();

                List<EntityLocation> loLo = GetLocationForProgressivo(stsComune.ProvinciaSts.Provincia.RegioneVF.IdZona.GetValueOrDefault()).ToList();
               
                        long? maxProgressiveOffice = (from l in loLo
                                                      select l.ProgressivoOffice).Max();
                        if (!maxProgressiveOffice.HasValue)
                        {
                            maxProgressiveOffice = 0;
                        }
                        long newProgressivoOffice = maxProgressiveOffice.Value + 1;



                        List<EntityProvincia> loProv = GetProvinciaById((long)stsComune.ProvinciaSts.IdProvincia).ToList();
                       
                        EntityProvincia p = loProv.FirstOrDefault<EntityProvincia>();
                        string newOffice = p.RegioneVF.Zona.ProgressivoZona.ToString() + "CD" + newProgressivoOffice.ToString().PadLeft(5, '0');
                        location.ProgressivoOffice = newProgressivoOffice;
                        location.Office = newOffice;
                        ConvertiCoordinate(ref location);
                        
             
            }
            else
            {
                ConvertiCoordinate(ref location);
            }
        }

        /// <summary>
        /// Ritorna le location in base all'id della zona passato per calcolare il progressivo
        /// </summary>
        /// <param name="IdZona">Id della zona</param>
        /// <returns></returns>
        public IQueryable<EntityLocation> GetLocationForProgressivo(long IdZona)
        {
            return (from l in _RCDDbContext.Location
                    where l.StsComune.ProvinciaSts.Provincia.RegioneVF.Zona.Id == IdZona
                    orderby l.ProgressivoOffice descending
                    select l).Take<EntityLocation>(1);
        }
        /// <summary>
        /// Ritorna la provincia passata per Id
        /// </summary>
        /// <param name="idProvincia">Id della provincia</param>
        public IQueryable<EntityProvincia> GetProvinciaById(long idProvincia)
        {
            return from p in _RCDDbContext.Provincia
                       .Include("RegioneVF").Include("RegioneVF.Zona")
                   where p.Id == idProvincia
                   select p;
        }

        /// <summary>
        /// Esegue la conversione delle coordinate
        /// </summary>
        /// <param name="location">Location da gestire</param>
        /// <param name="ctx">Contesto</param>
        private void ConvertiCoordinate(ref EntityLocation location)
        {
            try
            {
                ConverterManager.Coordinate latitudine = null;
                ConverterManager.Coordinate longitudine = null;
                if (location.LatitudineGradi.HasValue && location.LatitudinePrimi.HasValue && location.LatitudineSecondi.HasValue)
                {
                    latitudine = new ConverterManager.Coordinate(location.LatitudineGradi.Value, location.LatitudinePrimi.Value, decimal.Parse(location.LatitudineSecondi.Value.ToString()), ConverterManager.CardinalDirection.North);
                }
                if (location.LongitudineGradi.HasValue && location.LongitudinePrimi.HasValue && location.LongitudineSecondi.HasValue)
                {
                    longitudine = new ConverterManager.Coordinate(location.LongitudineGradi.Value, location.LongitudinePrimi.Value, decimal.Parse(location.LongitudineSecondi.Value.ToString()), ConverterManager.CardinalDirection.East);
                }
                if (latitudine != null && longitudine != null)
                {
                    ConverterManager.UTM utm = new ConverterManager.UTM(latitudine, longitudine);
                    location.LatitudineUTM = utm.Northing;
                    location.LongitudineUTM = utm.Easting;
                }
               // GenerateCodiciApparati(location);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

    }
}
