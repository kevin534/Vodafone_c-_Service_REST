﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Request;
using RCDEngine.Entities;
using RCDContracts.Data;

namespace RCD.Code.Installazione
{
    public class TipologieInstallazioneManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public TipologieInstallazioneManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
        public async Task<List<ContractTipologiaStabile>> GetTipologiaStabilea()
        {
            List<EntityTipologiaStabile> stabile;
            stabile = await _RCDDbContext.TipologiaStabile
                                 .OrderBy(x => x.Id)
                                 .ToListAsync();
            List<ContractTipologiaStabile> stabileElenco = new List<ContractTipologiaStabile>();
            foreach (EntityTipologiaStabile varStabile in stabile)
            {
                ContractTipologiaStabile areaVendite = new ContractTipologiaStabile();
                UtilityManager.MapProp(varStabile, areaVendite);
                stabileElenco.Add(areaVendite);
            }
            return stabileElenco;
        }

        public async Task<List<ContractAccessibilitaTetto>> GetAccessibilitaTetto()
        {
            List<EntityAccessibilitaTetto> tetto;
            tetto = await _RCDDbContext.AccessibilitaTetto
                                 .OrderBy(x => x.Id)
                                 .ToListAsync();
            List<ContractAccessibilitaTetto> tettoElenco = new List<ContractAccessibilitaTetto>();
            foreach (EntityAccessibilitaTetto varTetto in tetto)
            {
                ContractAccessibilitaTetto AccTetto = new ContractAccessibilitaTetto();
                UtilityManager.MapProp(varTetto, AccTetto);
                tettoElenco.Add(AccTetto);
            }
            return tettoElenco;
        }

        public async Task<List<ContractGestori>> GetGestori()
        {
            List<EntityGestori> gestore;
            gestore = await _RCDDbContext.Gestori
                                 .OrderBy(x => x.Id)
                                 .ToListAsync();
            List<ContractGestori> gestoreElenco = new List<ContractGestori>();
            foreach (EntityGestori varGestore in gestore)
            {
                ContractGestori gest1 = new ContractGestori();
                UtilityManager.MapProp(varGestore, gest1);
                gestoreElenco.Add(gest1);
            }
            return gestoreElenco;
        }
    }
}
