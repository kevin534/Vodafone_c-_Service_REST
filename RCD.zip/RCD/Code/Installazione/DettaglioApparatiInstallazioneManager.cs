﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;

namespace RCD.Code.Installazione
{
    public class DettaglioApparatiInstallazioneManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;

        public DettaglioApparatiInstallazioneManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

        #region TARGHE TECNICHE
        public async Task<List<EntityElement>> GetTargheTecnicheByIdOffice(DettaglioApparatiInstallazioneRequestFull elemento)
        {
            List<string> listTT = elemento.ListTT;
            List<EntityElement> elementi;
            String sortParam = String.Concat(String.Concat(elemento.CampoOrdinamento, " "), elemento.Ordinamento.ToUpper());

            if (elemento.Pageable)
            {
                if (listTT != null)
                {

                    elementi = await _RCDDbContext.Elementi
                         .WhereIf(!String.IsNullOrEmpty(elemento.Filter.IdOffice.ToString()), q => q.IdOffice.Equals(elemento.Filter.IdOffice))
                         .Where(q => listTT.Contains(q.SiglaDiRete))
                         .OrderBy(sortParam).Skip(elemento.NumeroElementi * elemento.Page).Take(elemento.NumeroElementi)
                         .ToListAsync();
                }
                else
                {

                    elementi = await _RCDDbContext.Elementi
                        .WhereIf(!String.IsNullOrEmpty(elemento.Filter.IdOffice.ToString()), q => q.IdOffice.Equals(elemento.Filter.IdOffice))
                          .WhereIf(!String.IsNullOrEmpty(elemento.Filter.TargaTecnicaSap), q => q.TargaTecnicaSap.Contains(elemento.Filter.TargaTecnicaSap))
                        .OrderBy(sortParam).Skip(elemento.NumeroElementi * elemento.Page).Take(elemento.NumeroElementi)
                        .ToListAsync();
                }

            }
            else
            {
                if (listTT != null)
                {

                    elementi = await _RCDDbContext.Elementi
                         .WhereIf(!String.IsNullOrEmpty(elemento.Filter.IdOffice.ToString()), q => q.IdOffice.Equals(elemento.Filter.IdOffice))
                         .Where(q => listTT.Contains(q.SiglaDiRete))
                         .OrderBy(sortParam)
                         .ToListAsync();
                }
                else
                {

                    elementi = await _RCDDbContext.Elementi
                        .WhereIf(!String.IsNullOrEmpty(elemento.Filter.IdOffice.ToString()), q => q.IdOffice.Equals(elemento.Filter.IdOffice))
                          .WhereIf(!String.IsNullOrEmpty(elemento.Filter.TargaTecnicaSap), q => q.TargaTecnicaSap.Contains(elemento.Filter.TargaTecnicaSap))
                        .OrderBy(sortParam)
                        .ToListAsync();
                }
            }

            return elementi;
        }
        #endregion TARGHE TECNICHE

        #region DETTAGLIO APPARATI 
        public async Task<List<ContractInstallazioneApparati>> GetApparatiInstallazione(ApparatiInstallazioneRequestFull apparatoInstallazione)
        {
            List<EntityInstallazioneApparati> installazioniApparati;

            String sortParam = String.Concat(String.Concat(apparatoInstallazione.CampoOrdinamento, " "), apparatoInstallazione.Ordinamento.ToUpper());

            if (apparatoInstallazione.Pageable)
            {
                installazioniApparati = await _RCDDbContext.InstallazioneApparati.Where(x => x.IdInstallazione.Equals(apparatoInstallazione.Filter.IdInstallazione))
                .Include("Apparati")
                .Include("Apparati.TipologiaApparato")
                .Include("Apparati.Sistema")
                .Include("Apparati.Fornitore")
                .Include("RaggiungibilitaApparato")
                .Include("InstallazioneApparato")
                .Include("PosizioneApparati")
                .OrderBy(sortParam)
                .Skip(apparatoInstallazione.NumeroElementi * apparatoInstallazione.Page).Take(apparatoInstallazione.NumeroElementi)
                .ToListAsync();

            }
            else
            {
                installazioniApparati = await _RCDDbContext.InstallazioneApparati.Where(x => x.IdInstallazione.Equals(apparatoInstallazione.Filter.IdInstallazione))
                .Include("Apparati")
                .Include("Apparati.TipologiaApparato")
                .Include("Apparati.Sistema")
                .Include("Apparati.Fornitore")
                .Include("RaggiungibilitaApparato")
                .Include("InstallazioneApparato")
                .Include("PosizioneApparati")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractInstallazioneApparati> installazioneApparatiElenco = new List<ContractInstallazioneApparati>();
            foreach (EntityInstallazioneApparati varInstallazioniApparato in installazioniApparati)
            {
                ContractInstallazioneApparati installazioniApparati1 = new ContractInstallazioneApparati();
                UtilityManager.MapProp(varInstallazioniApparato, installazioniApparati1);
                installazioneApparatiElenco.Add(installazioniApparati1);
            }
            return installazioneApparatiElenco;
        }
        public async Task<Int32> GetApparatiInstallazioneTot(ApparatiInstallazioneRequestFull apparatoInstallazione)
        {

            Int32 count = _RCDDbContext.InstallazioneApparati.Where(x => x.IdInstallazione.Equals(apparatoInstallazione.Filter.IdInstallazione))
            .Include("Apparati")
            .Include("Apparati.TipologiaApparato")
            .Include("Apparati.Sistema")
            .Include("Apparati.Fornitore")
            .Include("RaggiungibilitaApparato")
            .Include("InstallazioneApparato")
            .Include("PosizioneApparati")
            .Count();

            return count;
        }

        public void AddApparatiInstallazione(ApparatiInstalazioneRequest apparatoInstallazione)
        {
            try
            {
                EntityInstallazioneApparati apparatoInstallazioneToAdd = new EntityInstallazioneApparati();
                UtilityManager.MapProp(apparatoInstallazione, apparatoInstallazioneToAdd);
                apparatoInstallazioneToAdd.Recuperato = false;
                apparatoInstallazioneToAdd.InRecupero = false;
                var result = _RCDDbContext.Add(apparatoInstallazioneToAdd);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(apparatoInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void UpdateApparatiInstallazione(ApparatiInstalazioneRequest apparatoInstallazione)
        {
            try
            {
                EntityInstallazioneApparati apparatoInstallazioneToEdit = new EntityInstallazioneApparati();
                UtilityManager.MapProp(apparatoInstallazione, apparatoInstallazioneToEdit);
                apparatoInstallazioneToEdit.Recuperato = false;
                apparatoInstallazioneToEdit.InRecupero = false;
                var result = _RCDDbContext.Update(apparatoInstallazioneToEdit);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(apparatoInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteApparatiInstallazione(ApparatiInstalazioneRequest apparatoInstallazione)
        {
            try
            {
                EntityInstallazioneApparati apparatoInstallazioneToRemove = new EntityInstallazioneApparati();
                UtilityManager.MapProp(apparatoInstallazione, apparatoInstallazioneToRemove);
                var result = _RCDDbContext.Remove(apparatoInstallazioneToRemove);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(apparatoInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion DETTAGLIO APPARATI 

        #region DETTAGLIO ANTENNE

        public async Task<List<ContractInstallazioneAntenne>> GetAntenneInstallazione(AntennaInstallazioneRequestFull antennaInstallazione)
        {
            List<EntityInstallazioneAntenne> installazioneAntenne;

            String sortParam = String.Concat(String.Concat(antennaInstallazione.CampoOrdinamento, " "), antennaInstallazione.Ordinamento.ToUpper());

            if (antennaInstallazione.Pageable)
            {
                installazioneAntenne = await _RCDDbContext.InstallazioneAntenne.Where(x => x.IdInstallazione.Equals(antennaInstallazione.Filter.IdInstallazione))
                .Include("Antenna")
                .Include("Antenna.Sistema")
                .Include("Antenna.Fornitore")
                .Include("Antenna.TipologiaAntenna")
                .Include("TipologiaSegnaleAntenna")
                .Include("TTAccessibilitaAntenna")
                .Include("TTLocalizzazioneAntenna")
                .Include("TTInstallazioneAntenna")
                .OrderBy(sortParam)
                .Skip(antennaInstallazione.NumeroElementi * antennaInstallazione.Page).Take(antennaInstallazione.NumeroElementi)
                .ToListAsync();
            }
            else
            {
                installazioneAntenne = await _RCDDbContext.InstallazioneAntenne.Where(x => x.IdInstallazione.Equals(antennaInstallazione.Filter.IdInstallazione))
                .Include("Antenna")
                .Include("Antenna.Sistema")
                .Include("Antenna.Fornitore")
                .Include("Antenna.TipologiaAntenna")
                .Include("TipologiaSegnaleAntenna")
                .Include("TTAccessibilitaAntenna")
                .Include("TTLocalizzazioneAntenna")
                .Include("TTInstallazioneAntenna")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractInstallazioneAntenne> installazioniAntenneElenco = new List<ContractInstallazioneAntenne>();
            foreach (EntityInstallazioneAntenne varInstallazioniAntenne in installazioneAntenne)
            {
                ContractInstallazioneAntenne installazioniAntenne1 = new ContractInstallazioneAntenne();
                UtilityManager.MapProp(varInstallazioniAntenne, installazioniAntenne1);
                installazioniAntenneElenco.Add(installazioniAntenne1);
            }
            return installazioniAntenneElenco;
        }

        public async Task<Int32> GetAntenneInstallazioneTot(AntennaInstallazioneRequestFull antennaInstallazione)
        {

            Int32 count = _RCDDbContext.InstallazioneAntenne.Where(x => x.IdInstallazione.Equals(antennaInstallazione.Filter.IdInstallazione))
                .Include("Antenna")
                .Include("Antenna.Sistema")
                .Include("Antenna.Fornitore")
                .Include("Antenna.TipologiaAntenna")
                .Include("TipologiaSegnaleAntenna")
                .Include("TTAccessibilitaAntenna")
                .Include("TTLocalizzazioneAntenna")
                .Include("TTInstallazioneAntenna")
            .Count();

            return count;

        }

        public void AddAntenneInstallazione(AntennaInstallazioneRequest antennaInstallazione)
        {
            try
            {
                EntityInstallazioneAntenne antennaInstallazioneToAdd = new EntityInstallazioneAntenne();
                UtilityManager.MapProp(antennaInstallazione, antennaInstallazioneToAdd);
                antennaInstallazioneToAdd.Recuperato = false;
                antennaInstallazioneToAdd.InRecupero = false;
                var result = _RCDDbContext.Add(antennaInstallazioneToAdd);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(antennaInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateAntenneInstallazione(AntennaInstallazioneRequest antennaInstallazione)
        {
            try
            {
                EntityInstallazioneAntenne antennaInstallazioneToEdit = new EntityInstallazioneAntenne();
                UtilityManager.MapProp(antennaInstallazione, antennaInstallazioneToEdit);
                antennaInstallazioneToEdit.Recuperato = false;
                antennaInstallazioneToEdit.InRecupero = false;
                var result = _RCDDbContext.Update(antennaInstallazioneToEdit);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(antennaInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteAntenneInstallazione(AntennaInstallazioneRequest antennaInstallazione)
        {
            try
            {
                EntityInstallazioneAntenne antennaInstallazioneToRemove = new EntityInstallazioneAntenne();
                UtilityManager.MapProp(antennaInstallazione, antennaInstallazioneToRemove);
                var result = _RCDDbContext.Remove(antennaInstallazioneToRemove);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(antennaInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion DETTAGLIO ANTENNE 

        #region DETTAGLIO ACCESSORI

        public async Task<List<ContractInstallazioniAccessori>> GetAccessoriInstallazione(AccessorioInstallazioneRequestFull accessorioInstallazione)
        {
            List<EntityInstallazioneAccessori> sopralluoghiAccessori;

            String sortParam = String.Concat(String.Concat(accessorioInstallazione.CampoOrdinamento, " "), accessorioInstallazione.Ordinamento.ToUpper());

            if (accessorioInstallazione.Pageable)
            {
                sopralluoghiAccessori = await _RCDDbContext.InstallazioneAccessori.Where(x => x.IdInstallazione.Equals(accessorioInstallazione.Filter.IdInstallazione))
                .Include("Accessorio")
                .Include("Accessorio.Sistema")
                .Include("Accessorio.Fornitore")
                .Include("Accessorio.TipologiaAccessorio")
                .OrderBy(sortParam)
                .Skip(accessorioInstallazione.NumeroElementi * accessorioInstallazione.Page).Take(accessorioInstallazione.NumeroElementi)
                .ToListAsync();
            }
            else
            {
                sopralluoghiAccessori = await _RCDDbContext.InstallazioneAccessori.Where(x => x.IdInstallazione.Equals(accessorioInstallazione.Filter.IdInstallazione))
                .Include("Accessorio")
                .Include("Accessorio.Sistema")
                .Include("Accessorio.Fornitore")
                .Include("Accessorio.TipologiaAccessorio")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractInstallazioniAccessori> sopralluoghiAccessoriElenco = new List<ContractInstallazioniAccessori>();
            foreach (EntityInstallazioneAccessori varSopralluoghiAccessori in sopralluoghiAccessori)
            {
                ContractInstallazioniAccessori sopralluoghiAccessori1 = new ContractInstallazioniAccessori();
                UtilityManager.MapProp(varSopralluoghiAccessori, sopralluoghiAccessori1);
                sopralluoghiAccessoriElenco.Add(sopralluoghiAccessori1);
            }
            return sopralluoghiAccessoriElenco;
        }
        public async Task<Int32> GetAccessoriInstallazioneTot(AccessorioInstallazioneRequestFull accessorioInstallazione)
        {

            Int32 count = _RCDDbContext.InstallazioneAccessori.Where(x => x.IdInstallazione.Equals(accessorioInstallazione.Filter.IdInstallazione))
                .Include("Accessorio")
                .Include("Accessorio.Sistema")
                .Include("Accessorio.Fornitore")
                .Include("Accessorio.TipologiaAccessorio")
            .Count();

            return count;

        }

        public void AddAccessoriInstallazione(AccessorioInstallazioneRequest accessorioInstallazione)
        {
            try
            {
                EntityInstallazioneAccessori accessorioInstallazioneToAdd = new EntityInstallazioneAccessori();
                UtilityManager.MapProp(accessorioInstallazione, accessorioInstallazioneToAdd);
                accessorioInstallazioneToAdd.InRecupero = false;
                accessorioInstallazioneToAdd.Recuperato = false;
                var result = _RCDDbContext.Add(accessorioInstallazioneToAdd);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(accessorioInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateAccessoriInstallazione(AccessorioInstallazioneRequest accessorioInstallazione)
        {
            try
            {
                EntityInstallazioneAccessori accessorioInstallazioneToEdit = new EntityInstallazioneAccessori();
                UtilityManager.MapProp(accessorioInstallazione, accessorioInstallazioneToEdit);
                accessorioInstallazioneToEdit.InRecupero = false;
                accessorioInstallazioneToEdit.Recuperato = false;
                var result = _RCDDbContext.Update(accessorioInstallazioneToEdit);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(accessorioInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteAccessoriInstallazione(AccessorioInstallazioneRequest accessorioInstallazione)
        {
            try
            {
                EntityInstallazioneAccessori accessorioInstallazioneToRemove = new EntityInstallazioneAccessori();
                UtilityManager.MapProp(accessorioInstallazione, accessorioInstallazioneToRemove);
                var result = _RCDDbContext.Remove(accessorioInstallazioneToRemove);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(accessorioInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion DETTAGLIO ACCESSORI 

        #region DETTAGLIO MISURE

        public async Task<List<ContractInstallazioneMisure>> GetMisureInstallazione(MisuraInstallazioneRequestFull misuraInstallazione)
        {
            List<EntityInstallazioneMisure> installazioneMisure;

            String sortParam = String.Concat(String.Concat(misuraInstallazione.CampoOrdinamento, " "), misuraInstallazione.Ordinamento.ToUpper());

            if (misuraInstallazione.Pageable)
            {
                installazioneMisure = await _RCDDbContext.InstallazioneMisure.Where(x => x.IdInstallazione.Equals(misuraInstallazione.Filter.IdInstallazione))
                .Include("SistemaMisure")
                .Include("TipologiaMisure")
                .OrderBy(sortParam)
                .Skip(misuraInstallazione.NumeroElementi * misuraInstallazione.Page).Take(misuraInstallazione.NumeroElementi)
                .ToListAsync();
            }
            else
            {
                installazioneMisure = await _RCDDbContext.InstallazioneMisure.Where(x => x.IdInstallazione.Equals(misuraInstallazione.Filter.IdInstallazione))
                .Include("SistemaMisure")
                .Include("TipologiaMisure")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractInstallazioneMisure> installazioneMisureElenco = new List<ContractInstallazioneMisure>();
            foreach (EntityInstallazioneMisure varInstallazioneMisure in installazioneMisure)
            {
                ContractInstallazioneMisure installazioniMisure1 = new ContractInstallazioneMisure();
                UtilityManager.MapProp(varInstallazioneMisure, installazioniMisure1);
                installazioneMisureElenco.Add(installazioniMisure1);
            }
            return installazioneMisureElenco;
        }
        public async Task<Int32> GetMisureInstallazioneTot(MisuraInstallazioneRequestFull misuraInstallazione)
        {

            Int32 count = _RCDDbContext.InstallazioneMisure.Where(x => x.IdInstallazione.Equals(misuraInstallazione.Filter.IdInstallazione))
                .Include("SistemaMisure")
                .Include("TipologiaMisure")
            .Count();

            return count;

        }

        public void AddMisureInstallazione(MisuraInstallazioneRequest misuraInstallazione)
        {
            try
            {
                EntityInstallazioneMisure misuraInstallazioneToAdd = new EntityInstallazioneMisure();
                UtilityManager.MapProp(misuraInstallazione, misuraInstallazioneToAdd);
                var result = _RCDDbContext.Add(misuraInstallazioneToAdd);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(misuraInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void UpdateMisureInstallazione(MisuraInstallazioneRequest misuraInstallazione)
        {
            try
            {
                EntityInstallazioneMisure misuraInstallazioneToEdit = new EntityInstallazioneMisure();
                UtilityManager.MapProp(misuraInstallazione, misuraInstallazioneToEdit);

                var result = _RCDDbContext.Update(misuraInstallazioneToEdit);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(misuraInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        public void DeleteMisureInstallazione(MisuraInstallazioneRequest misuraInstallazione)
        {
            try
            {
                EntityInstallazioneMisure misuraInstallazioneToRemove = new EntityInstallazioneMisure();
                UtilityManager.MapProp(misuraInstallazione, misuraInstallazioneToRemove);
                var result = _RCDDbContext.Remove(misuraInstallazioneToRemove);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(misuraInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        #endregion DETTAGLIO MISURE 

        #region DETTAGLIO CROWDCELL

        public async Task<List<ContractInstallazioneCrowdcell>> GetCrowdcellInstallazione(CrowdcellInstallazioneRequestFull crowdcellInstallazione)
        {
            List<EntityInstallazioneCrowdcell> installazioneCrowdcell;

            String sortParam = String.Concat(String.Concat(crowdcellInstallazione.CampoOrdinamento, " "), crowdcellInstallazione.Ordinamento.ToUpper());

            if (crowdcellInstallazione.Pageable)
            {
                installazioneCrowdcell = await _RCDDbContext.InstallazioneCrowdcell.Where(x => x.IdInstallazione.Equals(crowdcellInstallazione.Filter.IdInstallazione))
                .Include("TTFrequenzaLTE")
                .Include("TTFrequenzaLTE2")
                .Include("TTLocalizzazioneAntenna")
                .Include("TTInstallazioneAntenna")
                .Include("TTRaggiungibilitaApparato")
                .Include("TTCriticitaEMF")
                .OrderBy(sortParam)
                .Skip(crowdcellInstallazione.NumeroElementi * crowdcellInstallazione.Page).Take(crowdcellInstallazione.NumeroElementi)
                .ToListAsync();
            }
            else
            {
                installazioneCrowdcell = await _RCDDbContext.InstallazioneCrowdcell.Where(x => x.IdInstallazione.Equals(crowdcellInstallazione.Filter.IdInstallazione))
                .Include("TTFrequenzaLTE")
                .Include("TTFrequenzaLTE2")
                .Include("TTLocalizzazioneAntenna")
                .Include("TTInstallazioneAntenna")
                .Include("TTRaggiungibilitaApparato")
                .Include("TTCriticitaEMF")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractInstallazioneCrowdcell> installazioneCrowdcellElenco = new List<ContractInstallazioneCrowdcell>();
            foreach (EntityInstallazioneCrowdcell varInstallazioneCrowdcell in installazioneCrowdcell)
            {
                ContractInstallazioneCrowdcell installazioniCrowdcell1 = new ContractInstallazioneCrowdcell();
                UtilityManager.MapProp(varInstallazioneCrowdcell, installazioniCrowdcell1);
                installazioneCrowdcellElenco.Add(installazioniCrowdcell1);
            }
            return installazioneCrowdcellElenco;
        }
        public async Task<Int32> GetCrowdcellInstallazioneTot(CrowdcellInstallazioneRequestFull crowdcellInstallazione)
        {

            Int32 count = _RCDDbContext.InstallazioneCrowdcell.Where(x => x.IdInstallazione.Equals(crowdcellInstallazione.Filter.IdInstallazione))
                .Include("TTFrequenzaLTE")
                .Include("TTFrequenzaLTE2")
                .Include("TTLocalizzazioneAntenna")
                .Include("TTInstallazioneAntenna")
                .Include("TTRaggiungibilitaApparato")
                .Include("TTCriticitaEMF")
            .Count();

            return count;

        }

        public void AddCrowdcellInstallazione(CrowdcellInstallazioneRequest crowdcellInstallazione)
        {
            try
            {
                EntityInstallazioneCrowdcell crowdcellInstallazioneToAdd = new EntityInstallazioneCrowdcell();
                UtilityManager.MapProp(crowdcellInstallazione, crowdcellInstallazioneToAdd);
                var result = _RCDDbContext.Add(crowdcellInstallazioneToAdd);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(crowdcellInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateCrowdcellInstallazione(CrowdcellInstallazioneRequest crowdcellInstallazione)
        {
            try
            {
                EntityInstallazioneCrowdcell crowdcellInstallazioneToEdit = new EntityInstallazioneCrowdcell();
                UtilityManager.MapProp(crowdcellInstallazione, crowdcellInstallazioneToEdit);

                var result = _RCDDbContext.Update(crowdcellInstallazioneToEdit);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(crowdcellInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteCrowdcellInstallazione(CrowdcellInstallazioneRequest crowdcellInstallazione)
        {
            try
            {
                EntityInstallazioneCrowdcell crowdcellInstallazioneToRemove = new EntityInstallazioneCrowdcell();
                UtilityManager.MapProp(crowdcellInstallazione, crowdcellInstallazioneToRemove);
                var result = _RCDDbContext.Remove(crowdcellInstallazioneToRemove);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(crowdcellInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion DETTAGLIO CROWDCELL 

        #region DETTAGLIO FEMTOCELLE

        public async Task<List<ContractInstallazioneFemto>> GetFemtoCelleInstallazione(FemtoInstallazioneRequestFull femtoCelleInstallazione)
        {
            List<EntityInstallazioneFemto> installazioneFemtoCelle;

            String sortParam = String.Concat(String.Concat(femtoCelleInstallazione.CampoOrdinamento, " "), femtoCelleInstallazione.Ordinamento.ToUpper());

            if (femtoCelleInstallazione.Pageable)
            {
                installazioneFemtoCelle = await _RCDDbContext.InstallazioneFemto.Where(x => x.IdInstallazione.Equals(femtoCelleInstallazione.Filter.IdInstallazione))
                .Include("TipologiaCopertura")
                .Include("TipologiaLan")
                .OrderBy(sortParam)
                .Skip(femtoCelleInstallazione.NumeroElementi * femtoCelleInstallazione.Page).Take(femtoCelleInstallazione.NumeroElementi)
                .ToListAsync();
            }
            else
            {
                installazioneFemtoCelle = await _RCDDbContext.InstallazioneFemto.Where(x => x.IdInstallazione.Equals(femtoCelleInstallazione.Filter.IdInstallazione))
                .Include("TipologiaCopertura")
                .Include("TipologiaLan")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractInstallazioneFemto> installazioneFemtoCelleElenco = new List<ContractInstallazioneFemto>();
            foreach (EntityInstallazioneFemto varInstallazioneFemtoCelle in installazioneFemtoCelle)
            {
                ContractInstallazioneFemto installazioniFemtoCellel1 = new ContractInstallazioneFemto();
                UtilityManager.MapProp(varInstallazioneFemtoCelle, installazioniFemtoCellel1);
                installazioneFemtoCelleElenco.Add(installazioniFemtoCellel1);
            }
            return installazioneFemtoCelleElenco;
        }
        public async Task<Int32> GetFemtoInstallazioneTot(FemtoInstallazioneRequestFull femtoInstallazione)
        {

            Int32 count = _RCDDbContext.InstallazioneFemto.Where(x => x.IdInstallazione.Equals(femtoInstallazione.Filter.IdInstallazione))
                .Include("TipologiaCopertura")
                .Include("TipologiaLan")
            .Count();

            return count;

        }

        public void AddFemtoInstallazione(FemtoInstallazioneRequest femtoInstallazione)
        {
            try
            {
                EntityInstallazioneFemto femtoInstallazioneToAdd = new EntityInstallazioneFemto();
                UtilityManager.MapProp(femtoInstallazione, femtoInstallazioneToAdd);
                var result = _RCDDbContext.Add(femtoInstallazioneToAdd);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(femtoInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateFemtoInstallazione(FemtoInstallazioneRequest femtoInstallazione)
        {
            try
            {
                EntityInstallazioneFemto femtoInstallazioneToEdit = new EntityInstallazioneFemto();
                UtilityManager.MapProp(femtoInstallazione, femtoInstallazioneToEdit);

                var result = _RCDDbContext.Update(femtoInstallazioneToEdit);
                _RCDDbContext.SaveChanges();
                RecalculateCosti(femtoInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteFemtoInstallazione(FemtoInstallazioneRequest femtoInstallazione)
        {
            try
            {
                EntityInstallazioneFemto femtoInstallazioneToRemove = new EntityInstallazioneFemto();
                UtilityManager.MapProp(femtoInstallazione, femtoInstallazioneToRemove);
                var result = _RCDDbContext.Remove(femtoInstallazioneToRemove);
                _RCDDbContext.SaveChanges();

                RecalculateCosti(femtoInstallazione.IdInstallazione);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion DETTAGLIO FEMTOCELLE 

        private void RecalculateCosti(Int64? idInstallazione)
        {

            EntityInstallazione? installazione = _RCDDbContext.Installazione
                                       .Where(x => x.Id == idInstallazione)
                                       .Include("InstallazioneCme")
                                       .Include("InstallazioneApparati")
                                       .Include("InstallazioneApparati.Apparati.TipologiaApparato")
                                       .Include("InstallazioneApparati.Apparati.Sistema")
                                       .Include("InstallazioneAntenne")
                                       .Include("InstallazioneAccessori")
                                       .FirstOrDefault();
            EntityRichiesta? richiesta = _RCDDbContext.Richieste
                .Where(x => x.IdInstallazione == idInstallazione)
                .Include("Sopralluogo")
                .AsNoTracking()
                .FirstOrDefault();

            decimal? TotaleCosti = 0;
            decimal? TotaleCostiApparatiAccessori = 0;
            int? TotaleRiuso = 0;
            int? TotaleNuovo = 0;
            int? TotaleRighe = 0;

            decimal? TotaleCostiCME = 0;
            decimal? TotaleCostiApparati = 0;
            decimal? TotaleCostiAccessori = 0;
            decimal? TotaleCostiAntenne = 0;
            int? TotaleApparatiNuovi = 0;
            int? TotaleApparatiRiuso = 0;
            int? TotaleAccessoriNuovi = 0;
            int? TotaleAccessoriRiuso = 0;
            int? TotaleAntenneNuovi = 0;
            int? TotaleAntenneRiuso = 0;

            TotaleCostiCME = installazione.InstallazioneCme.Sum(cme => cme.PrezzoTotale);
            TotaleRighe += installazione.InstallazioneCme.Count();

            TotaleCostiApparati = installazione.InstallazioneApparati.Where(sApp => sApp.Riuso == false).Sum(sApp => sApp.PrezzoTotale);
            TotaleApparatiNuovi = installazione.InstallazioneApparati.Where(sApp => sApp.Riuso == false).Sum(sApp => sApp.Quantita);
            TotaleApparatiRiuso = installazione.InstallazioneApparati.Where(sApp => sApp.Riuso == true).Sum(sApp => sApp.Quantita);
            TotaleRighe += installazione.InstallazioneApparati.Count();

            TotaleCostiAntenne = installazione.InstallazioneAntenne.Where(sAnt => sAnt.Riuso == false).Sum(sAnt => sAnt.PrezzoTotale);
            TotaleAntenneNuovi = installazione.InstallazioneAntenne.Where(sAnt => sAnt.Riuso == false).Sum(sAnt => sAnt.Quantita);
            TotaleAntenneRiuso = installazione.InstallazioneAntenne.Where(sAnt => sAnt.Riuso == true).Sum(sAnt => sAnt.Quantita);
            TotaleRighe += installazione.InstallazioneAntenne.Count();

            TotaleCostiAccessori = installazione.InstallazioneAccessori.Where(sAcc => sAcc.Riuso == false).Sum(sAcc => sAcc.PrezzoTotale);
            TotaleAccessoriNuovi = installazione.InstallazioneAccessori.Where(sAcc => sAcc.Riuso == false).Sum(sAcc => sAcc.Quantita);
            TotaleAccessoriRiuso = installazione.InstallazioneAccessori.Where(sAcc => sAcc.Riuso == true).Sum(sAcc => sAcc.Quantita);
            TotaleRighe += installazione.InstallazioneAccessori.Count();

            // Calcolo totali
            if (TotaleRighe > 0)
            {
                TotaleCosti = TotaleCostiCME + TotaleCostiApparati + TotaleCostiAntenne + TotaleCostiAccessori;
                installazione.CostoTotaleConsuntivato = (double)TotaleCosti;
                installazione.DeltaStimatoConsuntivato = richiesta.Sopralluogo.StimaIntervento - installazione.CostoTotaleConsuntivato;
                TotaleCostiApparatiAccessori = TotaleCostiApparati + TotaleCostiAntenne + TotaleCostiAccessori;
                installazione.CostoApparatiAccessoriConsuntivato = (double)TotaleCostiApparatiAccessori;
                TotaleNuovo = TotaleApparatiNuovi + TotaleAntenneNuovi + TotaleAccessoriNuovi;
                installazione.TotaleApparatiNuovi = TotaleApparatiNuovi;
                TotaleRiuso = TotaleApparatiRiuso + TotaleAntenneRiuso + TotaleAccessoriRiuso;
                installazione.TotaleApparatiRiuso = TotaleApparatiRiuso;
            }
            var result = _RCDDbContext.Update(installazione);
            _RCDDbContext.SaveChanges();
        }
    }
}
