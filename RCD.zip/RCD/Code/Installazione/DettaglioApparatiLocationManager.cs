﻿using Microsoft.EntityFrameworkCore;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;

namespace RCD.Code.Installazione
{
    public class DettaglioApparatiLocationManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;


        public DettaglioApparatiLocationManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }

 

        #region LOCATION ACCESSORIO

        public async Task<List<ContractLocationAccessori>> GetLocationAccessori(LocationAccessorioRequestFull accessorio)
        {
            List<EntityLocationAccessori> accessori;

            String sortParam = String.Concat(String.Concat(accessorio.CampoOrdinamento, " "), accessorio.Ordinamento.ToUpper());

            if (accessorio.Pageable)
            {
                accessori = await _RCDDbContext.LocationAccessori.Where(x => x.IdLocation.Equals(accessorio.Filter.IdLocation))
                    .Include("Location")
                    .Include("Accessorio")
                .OrderBy(sortParam)
                .Skip(accessorio.NumeroElementi * accessorio.Page).Take(accessorio.NumeroElementi)
                .ToListAsync();

            }
            else
            {
                accessori = await _RCDDbContext.LocationAccessori.Where(x => x.IdLocation.Equals(accessorio.Filter.IdLocation))
                     .Include("Location")
                    .Include("Accessorio")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractLocationAccessori> locationElenco = new List<ContractLocationAccessori>();
            foreach (EntityLocationAccessori varLocation in accessori)
            {
                ContractLocationAccessori location1 = new ContractLocationAccessori();
                UtilityManager.MapProp(varLocation, location1);
                locationElenco.Add(location1);
            }
            return locationElenco;
        }

        public async Task<Int32> GetLocationAccessoriTot(LocationAccessorioRequestFull accessorio)
        {

            Int32 count =  _RCDDbContext.LocationAccessori.Where(x => x.IdLocation.Equals(accessorio.Filter.IdLocation))
                 .Include("Location")
                    .Include("Accessorio")
                           .Count();

            return count;

        }

        public void AddLocationAccessori(LocationAccessorioRequest accessorio)
        {
            try
            {
                EntityLocationAccessori locationToAdd = new EntityLocationAccessori();
                UtilityManager.MapProp(accessorio, locationToAdd);
                var result = _RCDDbContext.Add(locationToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateLocationAccessori(LocationAccessorioRequest accessorio)
        {
            try
            {
                EntityLocationAccessori locationToAEdit = new EntityLocationAccessori();
                UtilityManager.MapProp(accessorio, locationToAEdit);
                var result = _RCDDbContext.Update(locationToAEdit);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteLocationAccessori(LocationAccessorioRequest accessorio)
        {
            try
            {
                EntityLocationAccessori locationToARemove = new EntityLocationAccessori();
                UtilityManager.MapProp(accessorio, locationToARemove);
                var result = _RCDDbContext.Remove(locationToARemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion LOCATION ACCESSORIO

        #region LOCATION ANTENNE

        public async Task<List<ContractLocationAntenna>> GetLocationAntenne(LocationAntenneRequestFull antenna)
        {
            List<EntityLocationAntenna> antenne;

            String sortParam = String.Concat(String.Concat(antenna.CampoOrdinamento, " "), antenna.Ordinamento.ToUpper());

            if (antenna.Pageable)
            {
                antenne = await _RCDDbContext.LocationAntenna.Where(x => x.IdLocation.Equals(antenna.Filter.IdLocation))
                    .Include("Location")
                  .Include("Antenna")
                    .Include("TipologiaSegnaleAntenna")
                    .Include("AccessibilitaAntenna")
                    .Include("LocalizzazioneAntenna")
                    .Include("InstallazioneAntenna")

                .OrderBy(sortParam)
                .Skip(antenna.NumeroElementi * antenna.Page).Take(antenna.NumeroElementi)
                .ToListAsync();

            }
            else
            {
                antenne = await _RCDDbContext.LocationAntenna.Where(x => x.IdLocation.Equals(antenna.Filter.IdLocation))
                    .Include("Location")
                  .Include("Antenna")
                    .Include("TipologiaSegnaleAntenna")
                    .Include("AccessibilitaAntenna")
                    .Include("LocalizzazioneAntenna")
                    .Include("InstallazioneAntenna")
                    .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractLocationAntenna> locationElenco = new List<ContractLocationAntenna>();
            foreach (EntityLocationAntenna varLocation in antenne)
            {
                ContractLocationAntenna location1 = new ContractLocationAntenna();
                UtilityManager.MapProp(varLocation, location1);
                locationElenco.Add(location1);
            }
            return locationElenco;
        }

        public async Task<Int32> GetLocationAntenneTot(LocationAntenneRequestFull antenna)
        {

            Int32 count = _RCDDbContext.LocationAntenna.Where(x => x.IdLocation.Equals(antenna.Filter.IdLocation))
                 .Include("Location")
                    .Include("Antenna")
                    .Include("TipologiaSegnaleAntenna")
                    .Include("AccessibilitaAntenna")
                    .Include("LocalizzazioneAntenna")
                    .Include("InstallazioneAntenna")
                .Count();

            return count;

        }

        public void AddLocationAntenne(LocationAntenneRequest antenna)
        {
            try
            {
                EntityLocationAntenna locationToAdd = new EntityLocationAntenna();
                UtilityManager.MapProp(antenna, locationToAdd);
                var result = _RCDDbContext.Add(locationToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateLocationAntenne(LocationAntenneRequest antenna)
        {
            try
            {
                EntityLocationAntenna locationToEdit = new EntityLocationAntenna();
                UtilityManager.MapProp(antenna, locationToEdit);
                var result = _RCDDbContext.Update(locationToEdit);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteLocationAntenne(LocationAntenneRequest antenna)
        {
            try
            {
                EntityLocationAntenna locationToRemove = new EntityLocationAntenna();
                UtilityManager.MapProp(antenna, locationToRemove);
                var result = _RCDDbContext.Remove(locationToRemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion LOCATION ANTENNE

        #region LOCATION APPARATI

        public async Task<List<ContractLocationApparato>> GetLocationApparati(LocationApparatiRequestFull apparato)
        {
            List<EntityLocationApparato> apparati;

            String sortParam = String.Concat(String.Concat(apparato.CampoOrdinamento, " "), apparato.Ordinamento.ToUpper());

            if (apparato.Pageable)
            {
                apparati = await _RCDDbContext.LocationApparato.Where(x => x.IdLocation.Equals(apparato.Filter.IdLocation))
                    .Include("Location")
                    .Include("Apparato")
                    .Include("StatoApparato")
                   .Include("PosizioneApparatoEntity")
                    .Include("RaggiungibilitaEntity")
                .OrderBy(sortParam)
                .Skip(apparato.NumeroElementi * apparato.Page).Take(apparato.NumeroElementi)
                .ToListAsync();

            }
            else
            {
                apparati = await _RCDDbContext.LocationApparato.Where(x => x.IdLocation.Equals(apparato.Filter.IdLocation))
                     .Include("Location")
                    .Include("Apparato")
                    .Include("StatoApparato")
                    .Include("PosizioneApparatoEntity")
                    .Include("RaggiungibilitaEntity")
               .OrderBy(sortParam)
               .ToListAsync();
            }

            List<ContractLocationApparato> locationElenco = new List<ContractLocationApparato>();
            foreach (EntityLocationApparato varLocation in apparati)
            {
                ContractLocationApparato location1 = new ContractLocationApparato();
                UtilityManager.MapProp(varLocation, location1);
                locationElenco.Add(location1);
            }
            return locationElenco;
        }

        public async Task<Int32> GetLocationApparatiTot(LocationApparatiRequestFull apparato)
        {

            Int32 count = _RCDDbContext.LocationApparato.Where(x => x.IdLocation.Equals(apparato.Filter.IdLocation))
                 .Include("Location")
                    .Include("Apparato")
                    .Include("StatoApparato")
                   .Include("PosizioneApparatoEntity")
                    .Include("RaggiungibilitaEntity")
                .Count();

            return count;

        }

        public void AddLocationApparati(LocationApparatiRequest apparato)
        {
            try
            {
                EntityLocationApparato locationToAdd = new EntityLocationApparato();
                UtilityManager.MapProp(apparato, locationToAdd);
                var result = _RCDDbContext.Add(locationToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateLocationApparati(LocationApparatiRequest apparato)
        {
            try
            {
                EntityLocationApparato locationToEdit = new EntityLocationApparato();
                UtilityManager.MapProp(apparato, locationToEdit);
                var result = _RCDDbContext.Update(locationToEdit);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteLocationApparati(LocationApparatiRequest apparato)
        {
            try
            {
                EntityLocationApparato locationToDelete = new EntityLocationApparato();
                UtilityManager.MapProp(apparato, locationToDelete);
                var result = _RCDDbContext.Remove(locationToDelete);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion LOCATION APPARATI

        #region LOCATION FEMTO

        public async Task<List<ContractLocationFemTo>> GetLocationFemto(LocationFemtoRequestFull femto)
        {
            List<EntityLocationFemTo> femti;

            String sortParam = String.Concat(String.Concat(femto.CampoOrdinamento, " "), femto.Ordinamento.ToUpper());

            if (femto.Pageable)
            {
                femti = await _RCDDbContext.LocationFemTo.Where(x => x.IdLocation.Equals(femto.Filter.IdLocation))
                    .Include("Location")
                    .Include("TipologiaLan")
                    .Include("Copertura")
                .OrderBy(sortParam)
                .Skip(femto.NumeroElementi * femto.Page).Take(femto.NumeroElementi)
                .ToListAsync();

            }
            else
            {
                femti = await _RCDDbContext.LocationFemTo.Where(x => x.IdLocation.Equals(femto.Filter.IdLocation))
                    .Include("Location")
                    .Include("TipologiaLan")
                    .Include("Copertura")
               .OrderBy(sortParam)
               .ToListAsync();
            }

            List<ContractLocationFemTo> locationElenco = new List<ContractLocationFemTo>();
            foreach (EntityLocationFemTo varLocation in femti)
            {
                ContractLocationFemTo location1 = new ContractLocationFemTo();
                UtilityManager.MapProp(varLocation, location1);
                locationElenco.Add(location1);
            }
            return locationElenco;
        }

        public async Task<Int32> GetLocationFemtoTot(LocationFemtoRequestFull femto)
        {

            Int32 count = _RCDDbContext.LocationFemTo.Where(x => x.IdLocation.Equals(femto.Filter.IdLocation))
                .Include("Location")
                    .Include("TipologiaLan")
                    .Include("Copertura")
                .Count();

            return count;

        }

        public void AddLocationFemto(LocationFemtoRequest femto)
        {
            try
            {
                EntityLocationFemTo locationToAdd = new EntityLocationFemTo();
                UtilityManager.MapProp(femto, locationToAdd);
                var result = _RCDDbContext.Add(locationToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateLocationFemto(LocationFemtoRequest femto)
        {
            try
            {
                EntityLocationFemTo locationToAEdit = new EntityLocationFemTo();
                UtilityManager.MapProp(femto, locationToAEdit);
                var result = _RCDDbContext.Update(locationToAEdit);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteLocationFemto(LocationFemtoRequest femto)
        {
            try
            {
                EntityLocationFemTo locationToARemove = new EntityLocationFemTo();
                UtilityManager.MapProp(femto, locationToARemove);
                var result = _RCDDbContext.Remove(locationToARemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion LOCATION FEMTO

        #region LOCATION MISURE

        public async Task<List<ContractLocationMisure>> GetLocationMisure(LocationMisureRequestFull misure)
        {
            List<EntityLocationMisure> misuri;

            String sortParam = String.Concat(String.Concat(misure.CampoOrdinamento, " "), misure.Ordinamento.ToUpper());

            if (misure.Pageable)
            {
                misuri = await _RCDDbContext.LocationMisure.Where(x => x.IdLocation.Equals(misure.Filter.IdLocation))
                    .Include("Location")
                    .Include("Sistema")
                    .Include("TipologiaMisura")
                .OrderBy(sortParam)
                .Skip(misure.NumeroElementi * misure.Page).Take(misure.NumeroElementi)
                .ToListAsync();

            }
            else
            {
                misuri = await _RCDDbContext.LocationMisure.Where(x => x.IdLocation.Equals(misure.Filter.IdLocation))
                     .Include("Location")
                    .Include("Sistema")
                    .Include("TipologiaMisura")
                .OrderBy(sortParam)
                .ToListAsync();
            }

            List<ContractLocationMisure> locationElenco = new List<ContractLocationMisure>();
            foreach (EntityLocationMisure varLocation in misuri)
            {
                ContractLocationMisure location1 = new ContractLocationMisure();
                UtilityManager.MapProp(varLocation, location1);
                locationElenco.Add(location1);
            }
            return locationElenco;
        }

        public async Task<Int32> GetLocationMisureTot(LocationMisureRequestFull misure)
        {

            Int32 count = _RCDDbContext.LocationMisure.Where(x => x.IdLocation.Equals(misure.Filter.IdLocation))
                 .Include("Location")
                    .Include("Sistema")
                    .Include("TipologiaMisura")
                .Count();

            return count;

        }

        public void AddLocationMisure(LocationMisureRequest misure)
        {
            try
            {
                EntityLocationMisure locationToAdd = new EntityLocationMisure();
                UtilityManager.MapProp(misure, locationToAdd);
                var result = _RCDDbContext.Add(locationToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateLocationMisure(LocationMisureRequest misure)
        {
            try
            {
                EntityLocationMisure locationToEdit = new EntityLocationMisure();
                UtilityManager.MapProp(misure, locationToEdit);
                var result = _RCDDbContext.Update(locationToEdit);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteLocationMisure(LocationMisureRequest misure)
        {
            try
            {
                EntityLocationMisure locationToRemove = new EntityLocationMisure();
                UtilityManager.MapProp(misure, locationToRemove);
                var result = _RCDDbContext.Remove(locationToRemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion LOCATION MISURE

        #region LOCATION CROWDCELL

        public async Task<List<ContractLocationCrowdcell>> GetLocationCrowdcell(LocationCrowdcellRequestFull crowdcell)
        {
            List<EntityLocationCrowdcell> crowdcells;

            String sortParam = String.Concat(String.Concat(crowdcell.CampoOrdinamento, " "), crowdcell.Ordinamento.ToUpper());

            if (crowdcell.Pageable)
            {
                crowdcells = await _RCDDbContext.LocationCrowdcell.Where(x => x.IdLocation.Equals(crowdcell.Filter.IdLocation))
                .OrderBy(sortParam)
                .Include("Location")
                .Include("LocalizzazioneAntenna")
                .Include("InstallazioneAntenna")
                .Include("Raggiungibilita")
                .Include("CriticitaEmf")
                .Include("FrequenzaDonor")
                .Include("FrequenzaCoverage")
                .Skip(crowdcell.NumeroElementi * crowdcell.Page).Take(crowdcell.NumeroElementi)
                .ToListAsync();

            }
            else
            {
                crowdcells = await _RCDDbContext.LocationCrowdcell.Where(x => x.IdLocation.Equals(crowdcell.Filter.IdLocation))                
                .OrderBy(sortParam)
                .Include("Location")
                .Include("LocalizzazioneAntenna")
                .Include("InstallazioneAntenna")
                .Include("Raggiungibilita")
                .Include("CriticitaEmf")
                .Include("FrequenzaDonor")
                .Include("FrequenzaCoverage")
                .ToListAsync();
            }

            List<ContractLocationCrowdcell> locationElenco = new List<ContractLocationCrowdcell>();
            foreach (EntityLocationCrowdcell varLocation in crowdcells)
            {
                ContractLocationCrowdcell location1 = new ContractLocationCrowdcell();
                UtilityManager.MapProp(varLocation, location1);
                locationElenco.Add(location1);
            }
            return locationElenco;
        }

        public async Task<Int32> GetLocationCrowdcellTot(LocationCrowdcellRequestFull crowdcell)
        {

            Int32 count = _RCDDbContext.LocationCrowdcell.Where(x => x.IdLocation.Equals(crowdcell.Filter.IdLocation))
                        .Include("Location")
                        .Include("LocalizzazioneAntenna")
                        .Include("InstallazioneAntenna")
                        .Include("Raggiungibilita")
                        .Include("CriticitaEmf")
                        .Include("FrequenzaDonor")
                        .Include("FrequenzaCoverage")
                        .Count();

            return count;

        }

        public void AddLocationCrowdcell(LocationCrowdcellRequest crowdcell)
        {
            try
            {
                EntityLocationCrowdcell locationToAdd = new EntityLocationCrowdcell();
                UtilityManager.MapProp(crowdcell, locationToAdd);
                var result = _RCDDbContext.Add(locationToAdd);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void UpdateLocationCrowdcell(LocationCrowdcellRequest crowdcell)
        {
            try
            {
                EntityLocationCrowdcell locationToEdit = new EntityLocationCrowdcell();
                UtilityManager.MapProp(crowdcell, locationToEdit);
                var result = _RCDDbContext.Update(locationToEdit);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }
        public void DeleteLocationCrowdcell(LocationCrowdcellRequest crowdcell)
        {
            try
            {
                EntityLocationCrowdcell locationToRemove = new EntityLocationCrowdcell();
                UtilityManager.MapProp(crowdcell, locationToRemove);
                var result = _RCDDbContext.Remove(locationToRemove);
                _RCDDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

        }

        #endregion LOCATION CROWDCELL

    }
}

