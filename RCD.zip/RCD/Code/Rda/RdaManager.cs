﻿using Microsoft.EntityFrameworkCore;
using RCD.Code.Amministrazione;
using RCDContracts;
using RCDContracts.Data;
using RCDContracts.Request;
using RCDEngine;
using RCDEngine.Entities;
using System.Data;
namespace RCD.Code.Rda
{
    public class RdaManager
    {
        private readonly RCDEngine.RCDDbContext _RCDDbContext;


        public RdaManager(RCDEngine.RCDDbContext RCDDbContext)
        {
            _RCDDbContext = RCDDbContext;
        }
        public async Task<List<EntityDitta>> GetDitteAbilitateByIdUtente(DittaRequestFull ditta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(ditta.CampoOrdinamento, " "),
                              ditta.Ordinamento.ToUpper());

            List<EntityDitta> ditte = new List<EntityDitta>();

            List<Int64?> idDittaFittizia = new List<Int64?> { 1, 2, 3, 4 };

            List<Int64?> idZonas = new List<Int64?>();

            if (ditta.Pageable)
            {

                if (utente.Zona != null)
                {

                    ditte = _RCDDbContext.Ditta.Where(x => x.IdZona.Equals(utente.IdZona) && x.Abilitato == true && !idDittaFittizia.Contains(x.Id))
                       .Select(x => x)
                       .Skip(ditta.NumeroElementi * ditta.Page).Take(ditta.NumeroElementi)
                       .ToList();
                }
                else
                {
                    idZonas = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente.Equals(utente.Id))
                        .Include("StsProvincia")
                        .Include("StsProvincia.Provincia")
                        .Include("StsProvincia.Provincia.RegioneVF")
                        .Include("StsProvincia.Provincia.RegioneVF.Zona")
                        .Select(x => x.StsProvincia.Provincia.RegioneVF.IdZona).Distinct()               
                        .ToList();


                    ditte = _RCDDbContext.Ditta.Where(x => x.Abilitato == true && idZonas.Contains(x.IdZona) && !idDittaFittizia.Contains(x.Id))
                     .Select(x => x)
                     .Skip(ditta.NumeroElementi * ditta.Page).Take(ditta.NumeroElementi)
                     .ToList();

                }
            }
            else
            {
                if (utente.Zona != null)
                {

                    ditte = _RCDDbContext.Ditta.Where(x => x.IdZona.Equals(utente.IdZona) && x.Abilitato == true && !idDittaFittizia.Contains(x.Id))
                       .Select(x => x)
                       .ToList();

                }
                else
                {

                    idZonas = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente.Equals(utente.Id))
                         .Include("StsProvincia")
                         .Include("StsProvincia.Provincia")
                         .Include("StsProvincia.Provincia.RegioneVF")
                         .Include("StsProvincia.Provincia.RegioneVF.Zona")
                         .Select(x => x.StsProvincia.Provincia.RegioneVF.IdZona).Distinct()
                         .ToList();

                    ditte = _RCDDbContext.Ditta.Where(x => x.Abilitato == true && idZonas.Contains(x.IdZona) && !idDittaFittizia.Contains(x.Id))
                     .Select(x => x)
                     .ToList();

                }
            }

            return ditte;
        }

        public async Task<Int32> GetDitteAbilitateByIdUtenteTot(DittaRequestFull ditta, Int64 idUtente)
        {
            EntityUtente utente;
            UtentiManager utentiManager;
            utentiManager = new UtentiManager(_RCDDbContext);
            utente = await utentiManager.GetUtenteById(idUtente);

            String sortParam = String.Concat(String.Concat(ditta.CampoOrdinamento, " "),
                              ditta.Ordinamento.ToUpper());


            List<Int64?> idDittaFittizia = new List<Int64?> { 1, 2, 3, 4 };

            List<Int64?> idZonas = new List<Int64?>();

            Int32 ditteCount;

            if (utente.Zona != null)
            {

                ditteCount = _RCDDbContext.Ditta.Where(x => x.IdZona.Equals(utente.IdZona) && x.Abilitato == true && !idDittaFittizia.Contains(x.Id))
                      .Select(x => x)
                      .Count();
            }
            else
            {
                idZonas = _RCDDbContext.UtentiProvince.Where(x => x.IdUtente.Equals(utente.Id))
                    .Select(x => x.StsProvincia.Id)
                    .ToList();

                ditteCount = _RCDDbContext.Ditta.Where(x => x.Abilitato == true && idZonas.Contains(x.IdZona) && !idDittaFittizia.Contains(x.Id))
                     .Select(x => x)
                     .Count();

            }
            return ditteCount;
        }
    }
}