﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class ApparatiSopralluogoRequestFull : BaseRequest
    {
        public ContractSopralluogoApparati? Filter { get; set; }
    }
    public class ApparatiSopralluogoRequest : ContractSopralluogoApparati
    {

    }
}