﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class AnagraficaFornitoriRequestFull : BaseRequest
    {
        public ContractAnagraficaFornitori? Filter { get; set; }

    }

    public class AnagraficaFornitoriRequest : ContractAnagraficaFornitori
    {

    }
}
