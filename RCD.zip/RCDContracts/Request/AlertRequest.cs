﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class AlertRequestFull : BaseRequest
    {
        
        public ContractEventoZona? Filter { get; set; }
        public ContractEventi? FilterEvento { get; set; }
        public long? IdZona { get; set; }

    }

    public class AlertRequestEventoZona : ContractEventoZona
    {

    }
}
