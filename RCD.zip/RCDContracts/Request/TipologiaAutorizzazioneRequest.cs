﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class TipologiaAutorizzazioneRequestFull : BaseRequest
    {
        public ContractTipologiaAutorizzazione? Filter { get; set; }
    }
    public class TipologiaAutorizzazioneRequest : ContractTipologiaAutorizzazione
    { 

    }
}