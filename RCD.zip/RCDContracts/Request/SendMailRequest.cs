﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class SendMailRequest 
    {
        public Boolean? Flag { get; set; } = true;
        public List<Int32>? ListRuoli { get; set; } 
        public String? Oggetto { get; set; } = String.Empty;
        [Column(TypeName = "ntext")]
        public String? CorpoMail { get; set; }
    }
}
