﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    
    public class UtenteRequestFull : BaseRequest
    {
       public ContractUtente? Filter { get; set; }
    }
    public class UtenteRequest : ContractUtente
    {
        
    }
}
