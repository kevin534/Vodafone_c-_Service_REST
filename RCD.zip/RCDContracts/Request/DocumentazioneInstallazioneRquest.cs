﻿using System;
using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class DocumentazioneInstallazioneRequestFull : BaseRequest
    {
        public ContractDocumentazioneInstallazione? Filter { get; set; }
    }
    public class DocumentazioneInstallazioneRquest : ContractDocumentazioneInstallazione
    {

    }
}
