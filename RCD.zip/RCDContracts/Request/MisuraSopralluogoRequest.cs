﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class MisuraSopralluogoRequestFull : BaseRequest
    {
        public ContractSopralluogoMisure? Filter { get; set; }
    }
    public class MisuraSopralluogoRequest : ContractSopralluogoMisure
    {

    }
}
