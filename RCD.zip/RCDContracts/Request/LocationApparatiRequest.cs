﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class LocationApparatiRequestFull : BaseRequest
    {
        public ContractLocationApparato? Filter { get; set; }
    }
    public class LocationApparatiRequest : ContractLocationApparato
    {

    }
}