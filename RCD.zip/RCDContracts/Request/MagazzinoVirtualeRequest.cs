﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RCDContracts.Data;

namespace RCDContracts.Request
{ 
    public class MagazzinoVirtualeRequestFull : BaseRequest
    {
        public ContractMagazzino? Filter { get; set; }
    }

    public class MagazzinoVirtualeRequest : ContractMagazzino
    {

    }
}