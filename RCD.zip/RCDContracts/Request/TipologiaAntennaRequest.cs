﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace RCDContracts.Request
{
    public class TipologiaAntennaRequestFull : BaseRequest
    {
        public ContractTipologiaAntenna? Filter { get; set; }
    }
    public class TipologiaAntennaRequest : ContractTipologiaAntenna
    {

    }
}
