﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class TipologiaAntennaSogliaRequestFull : BaseRequest
    {
        public ContractTipologiaAntennaSoglia? Filter { get; set; }


    }

    public class TipologiaAntennaSogliaRequest : ContractTipologiaAntennaSoglia
    {

    }
}
