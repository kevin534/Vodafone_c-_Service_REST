﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class ViewRichiesteRequestFull : BaseRequest
    {
        public ContractViewReportRichieste? Filter { get; set; }
        public List<long?>? StatiKo { get; set; }
        public List<long?>? IdRegioni { get; set; }
        public List<long?>? IdProvince { get; set; }


    }

    public class ViewRichiesteRequest : ContractViewReportRichieste
    {

    }
}
