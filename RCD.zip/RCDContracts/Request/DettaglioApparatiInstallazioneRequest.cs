﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{

    public class DettaglioApparatiInstallazioneRequestFull : BaseRequest
    {
        public ContractElement? Filter { get; set; }
        public List<string?> ListTT { get; set; }
    }

    public class DettaglioApparatiInstallazioneRequest : ContractElement
    {
    }
}
