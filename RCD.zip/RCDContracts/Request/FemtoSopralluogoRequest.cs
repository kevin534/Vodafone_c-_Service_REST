﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class FemtoSopralluogoRequestFull : BaseRequest
    {
        public ContractSopralluogoFemto? Filter { get; set; }
    }
    public class FemtoSopralluogoRequest : ContractSopralluogoFemto
    {

    }
}