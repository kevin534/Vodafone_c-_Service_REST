﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class DittaRequestFull : BaseRequest
    {
        public ContractDitta? Filter { get; set; }

    }

    public class DittaRequest : ContractDitta
    {

    }
}
