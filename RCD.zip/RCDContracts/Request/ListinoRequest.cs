﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class ListinoRequestFull : BaseRequest
    {
        public ContractListino? Filter { get; set; }
        public Int64? IdDitta { get; set; }
    }
    public class ListinoRequest : ContractListino
    { 

    }
}




