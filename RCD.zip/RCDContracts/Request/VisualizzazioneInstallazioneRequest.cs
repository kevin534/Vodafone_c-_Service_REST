﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class VisualizzazioneInstallazioneRequestFull : BaseRequest
    {
        public ContractUtente? Filter { get; set; }

    }
    public class VisualizzazioneInstallazioneRequest : ContractUtente
    {
    }
}
