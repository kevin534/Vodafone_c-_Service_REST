﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class LocationCmeRequestFull : BaseRequest
    {
        public ContractLocationCme? Filter { get; set; }
    }
    public class LocationCmeRequest : ContractLocationCme
    {

    }
}