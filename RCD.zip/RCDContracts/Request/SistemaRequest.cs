﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class SistemaRequestFull : BaseRequest
    {
        public ContractSistema? Filter { get; set; }

    }

    public class SistemaRequest : ContractSistema
    {

    }
}
