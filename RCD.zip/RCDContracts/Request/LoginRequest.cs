﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Request
{
    public class LoginRequest
    {
        public String Username { get; set; }
        public String Password { get; set; }
        public String Application { get; set; }
    }
}
