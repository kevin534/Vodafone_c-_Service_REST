﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractDittaVerificaAccessi
    {
        public Int32? Id { get; set; }
        public Int64? IdDitta { get; set; }
        public Int32? LoginFailedTentatives { get; set; } 
        public DateTime? LastLoginFailedTime { get; set; } 
    }
}
