﻿using RCDContracts.Data;

namespace RCDContracts
{
	public class ContractUtente
	{
		public Int64? Id { get; set; }
		public Int64? IdZona { get; set; }
		public Int64? IdCanaleVendita { get; set; }
		public Int64? IdCanaleVenditaDettaglio { get; set; }
		public Int64? IdAreaVendita { get; set; }
		public Int64? IdRuolo { get; set; }
		public Int64? IdTipologiaUtente { get; set; }
		public String? Username { get; set; } = String.Empty;
		public String? Cognome { get; set; } = String.Empty;
		public String? Nome { get; set; } = String.Empty;
		public String? FullName { get; set; } = String.Empty;
		public String? Telefono { get; set; } = String.Empty;
		public String? Mail { get; set; } = String.Empty;
		public String? Note { get; set; } = String.Empty;
		public Boolean? Abilitato { get; set; } = true;
		public ContractZona? Zona { get; set; }
		public ContractCanaleVendita? CanaleVendita { get; set; }
		public ContractCanaleVenditaDettaglio? CanaleVenditaDettaglio { get; set; }
		public ContractAreaVendite? AreaVendita { get; set; }
		public ContractRuolo? Ruolo { get; set; }
		public ContractTipologiaUtente? TipologiaUtente { get; set; }

		public List<ContractUtentiProvincie>? ListProvinceUtente { get; set; }
	}
}