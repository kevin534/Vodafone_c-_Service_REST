﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractOffice
    {
        public Decimal? IdZona { get; set; }
        public Decimal? IdOffice { get; set; }
		public Int64? IdComune { get; set; }
		public String? OfficeSigla { get; set; }
		public String? Nome { get; set; }
		public String? IndirizzoLegale { get; set; }
		public String? IndirizzoOperativo { get; set; }
		public String? Latitudine { get; set; }
		public String? Longitudine { get; set; }
		public String? ParticellaCatastale { get; set; }
		public Decimal? IdZonaRes { get; set; }
		public Decimal? IdComuneOperativo { get; set; }
		public String? CapOperativo { get; set; }
		public String? CapLegale { get; set; }
		public String? Proprietario { get; set; }
		public Decimal? IdTipoOffice { get; set; }
		public String? CodiceIstat { get; set; }
		public Decimal? OfficeIinsert { get; set; }
		public Decimal? OfficeUpdate { get; set; }
		public DateTime? DataIinserimento { get; set; }
		public DateTime? DataVariazione { get; set; }
		public Decimal? SistemaPorprietario { get; set; }
		public Decimal? Larghezza { get; set; }
		public Decimal? Altezza { get; set; }
		public Decimal? Profondita { get; set; }
		public Decimal? NumeroMaxApparati { get; set; }
		public Decimal? NumeroApparati { get; set; }
		public Decimal? NumeroMaxApparatiOpCiv { get; set; }
		public Decimal? NumeroMaxCavi { get; set; }
		public Decimal? NumeroCaviIinstallati { get; set; }
		public Decimal? NumeroCaviUtilizzati { get; set; }
		public Decimal? NumeroCaviCondivisi { get; set; }
		public Decimal? IdProvinciaApp { get; set; }
		public Decimal? IdTipologiaOffice { get; set; }
		public Decimal? IdCategoria { get; set; }
		public Decimal? IdTipoPosizione { get; set; }
		public Decimal? IdTipologiaSsi { get; set; }
		public Decimal? IdTipoAccesso { get; set; }
		public String? CodiceTim { get; set; }
		public Decimal? IdOfficeLink { get; set; }
		public ContractStsComune? StsComune { get; set; }


	}
}
