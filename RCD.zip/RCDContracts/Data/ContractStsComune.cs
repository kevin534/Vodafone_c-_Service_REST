﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractStsComune
    {
        public Int64? Id { get; set; }
        public Int64? IdProvinciaSts { get; set; }
        public String? Descrizione { get; set; }
        public String? Cap { get; set; } = String.Empty;
        public String? CodiceIstat { get; set; }
        public DateTime? DataInserimento { get; set; }
        public DateTime? DataModifica { get; set; }
        public Boolean Abilitato { get; set; }

        public ContractStsProvincia? ProvinciaSts { get; set; }
    }
}
