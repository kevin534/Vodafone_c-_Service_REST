﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractUtentiProvincie
    {
        public Int64? Id { get; set; }
        
        public Int64? IdUtente { get; set; }
        
        public Int64? IdProvincia { get; set; }

        public ContractUtente? Utente { get; set; }
        public ContractStsProvincia? StsProvincia { get; set; }

    }
}
