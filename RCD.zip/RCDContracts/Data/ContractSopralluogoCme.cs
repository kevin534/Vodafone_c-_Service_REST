﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDContracts.Data
{
    public class ContractSopralluogoCme
    {
        public Int64? Id { get; set; }
        public Int64? IdSopralluogo { get; set; }
        public Int64? IdListino { get; set; }

        [Column("Quantità")]
        public Decimal? Quantita { get; set; }   //o Quantita ? [Column(TypeName = "decimal(18, 2)")]
        public Decimal? PrezzoTotale { get; set; }   //    [Column(TypeName = "decimal(18, 2)")]
        public Boolean? CostoSostenuto { get; set; }
        public Int64? IdApparato { get; set; }

        public ContractSopralluogo? Sopralluogo { get; set; }
        public ContractListino? Listino { get; set; }
        //public ContractApparati? Apparato { get; set; }
        public ContractSopralluogoApparati? SopralluogoApparati { get; set; }
    }
}
