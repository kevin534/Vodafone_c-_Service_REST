﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractStsProvincia
    {
        public Int64? Id { get; set; }
        public Int64? IdProvincia { get; set; }
        public Int64? IdRegioneSts { get; set; }
        public String? Descrizione { get; set; }
        public String? Sigla { get; set; }
        public DateTime DataInserimento { get; set; }
        public DateTime DataModifica { get; set; }
        public Boolean Abilitato { get; set; }
        public ContractProvincia? Provincia { get; set; }
        public ContractStsRegione? RegioneSts { get; set; }
        //campi non in db
        public Boolean? IsProvinciaUtente { get; set; }
    }
}
