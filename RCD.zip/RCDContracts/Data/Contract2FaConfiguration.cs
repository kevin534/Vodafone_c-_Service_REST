﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class Contract2FaConfiguration
    {
        public Int64? Id { get; set; }
        public Int64? TOTP_INTERVAL_2FA { get; set; }
        public Int64? TOTP_DELAY_OFFSET_2FA { get; set; }
        public Boolean? TOTP_RESET_COUNTER { get; set; }
        public Boolean? IS_2FA_ENABLED { get; set; }
    }
}
