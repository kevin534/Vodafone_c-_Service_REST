﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractTTInstallazioneAntenna
    {
        public Int64? Id { get; set; }
        public String? descrizione { get; set; } = String.Empty;
    }
}

