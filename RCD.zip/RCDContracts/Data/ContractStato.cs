﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractStato
    {
		public Int64? Id { get; set; }
		public String? Stato { get; set; } = String.Empty;
		public Boolean? FollowGovernanceRule { get; set; }
		public Boolean? IsAutomaticChange { get; set; }
		public Boolean? IsConfigurable { get; set; }
		public Boolean? IsKoState { get; set; }
		public Boolean? IsFinalState { get; set; }
		public Boolean? CanEmitRdASopralluogo { get; set; }
		public Boolean? CanEmitRdAInstallazione { get; set; }

	}
}
