﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDContracts.Data
{
    public class ContractLocation
    {
        public Int64? Id { get; set; }
        public Int64? IdRichiedente { get; set; }
        public Int64? IdComune { get; set; }
        public Int64? IdTipologiaStabile { get; set; }
        public Int64? IdDisponibilitaAccessoAlTetto { get; set; }
        public Int64? IdCoperturaIndoorAltriGestori { get; set; }
        public String? CodiceRepeater { get; set; }
        public String? NomeInstallazione { get; set; }
        public String? Indirizzo { get; set; }
        public String? CAP { get; set; }
        public String? ProprietaEdificio { get; set; }
        public String? ParticellaCatastale { get; set; }
        public Boolean? Vincolo { get; set; }
        public String? Office { get; set; }
        public Int64? ProgressivoOffice { get; set; }
        public Int32? LatitudineGradi { get; set; }
        public Int32? LatitudinePrimi { get; set; }
        public Double? LatitudineSecondi { get; set; }
        public Double? LatitudineUTM { get; set; }
        public Int32? LongitudineGradi { get; set; }
        public Int32? LongitudinePrimi { get; set; }
        public Double? LongitudineSecondi { get; set; }
        public Double? LongitudineUTM { get; set; }
        public Int32? SLM { get; set; }
        public DateTime? DataOnAir { get; set; }       
        public String? NoteLocation { get; set; }
        public Boolean? DismissioneImpianti { get; set; }
        public Boolean? IsDismesso { get; set; }
        public DateTime? DataDismissioneImpianti { get; set; }
        [Column("StabileDiProprietà")]
        public Boolean? StabileDiProprieta { get; set; }    
        public String? MotivoDismissione { get; set; }   
        public String? Note { get; set; }
        public Decimal? IdOffice { get; set; }
        public String? FullNameReferenteLocale { get; set; }
        public String? TelefonoReferenteLocale { get; set; }
        public String? EmailReferenteLocale { get; set; }

        public ContractRichiedente? Richiedente { get; set; }
        public ContractStsComune? StsComune { get; set; }
        public ContractTipologiaStabile? TipologiaStabile { get; set; }
        public ContractAccessibilitaTetto? AccessibilitaTetto { get; set; }
        public ContractGestori? Gestori { get; set; }

        public List<ContractLocationAccessori>? LocationAccessori { get; set; }
        public List<ContractLocationAntenna>? LocationAntenne { get; set; }
        public List<ContractLocationApparato>? LocationApparati { get; set; }
        public List<ContractLocationCme>? LocationCme { get; set; }
        public List<ContractLocationFemTo>? LocationFemTo { get; set; }
        public List<ContractLocationMisure>? LocationMisure { get; set; }
        public List<ContractLocationCrowdcell>? LocationCrowdcell { get; set; }

        public Int32 NumeriApparatiGsm { get; set; }
        public Int32 NumeriApparatiUmts { get; set; }
        public Int32 NumeriApparatiLTE { get; set; }
        public Int32 NumeriApparatiGsmUmts { get; set; }
        public Int32 NumeriApparatiGsmLTE { get; set; }
    }
}
