﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractMenu
    {
        public Int64? Id { get; set; }
        public Int64? IdPadre { get; set; }
        public String? Header { get; set; } = String.Empty;
        public String? PageName { get; set; } = String.Empty;
		public String? Path { get; set; } = String.Empty;
		public Int64? Position { get; set; }
		public Boolean? IsReporting { get; set; }
		public Boolean? Abilitato { get; set; }
		public String? Tooltip { get; set; } = String.Empty;
		public String? ForeGroundColor { get; set; } = String.Empty;
		public String? BackGroundColor { get; set; } = String.Empty;

	}
}
