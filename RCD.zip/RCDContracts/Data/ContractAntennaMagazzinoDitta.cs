﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractAntennaMagazzinoDitta
    {
        public Int64? Id { get; set; }
        public Int64? IdStatoMateriale { get; set; }
        public Int64? IdDitta { get; set; }
        public Int64? IdAntenna { get; set; }
        public DateTime? DataArrivo { get; set; }
        public String? OdA { get; set; } = String.Empty;
        [Column("Quantità")]
        public Int32? Quantita { get; set; }
        [Column(TypeName = "ntext")]
        public String? Note { get; set; }

        public ContractStatoMateriale? StatoMateriale { get; set; }
        // da DB [T_DITTA_old]  ??
        public ContractDitta? Ditta { get; set; }
        public ContractAntenna? Antenna { get; set; }
    }
}
