﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDContracts.Data
{
    public class ContractViewRichiestaStatoProvincia
    {
        public Int64? IdRichiesta { get; set; }
        public Int64? IdStatoRichiesta { get; set; }
        public Int64? IdProvinciaSts { get; set; }

        public ContractRichiesta? Richiesta { get; set; }
    }
}
