﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractInstallazioneApparato
    {
        public Int64? id { get; set; }

        public String? descrizione { get; set; } = String.Empty;
    }
}
