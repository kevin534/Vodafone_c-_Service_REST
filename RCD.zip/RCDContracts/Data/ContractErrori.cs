﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace RCDContracts.Data
{
    public class ContractErrori
    {
        public Int64? Id { get; set; }
        public DateTime? DataInizio { get; set; }
        public DateTime? DataFine { get; set; }
        public Int32? Conteggio { get; set; }
        public String? Progetto { get; set; } = String.Empty;
        public String? Sorgente { get; set; } = String.Empty;
        public String? NomeMacchina { get; set; } = String.Empty;
        public String? Descrizione { get; set; } = String.Empty;
        public Byte[]? Eccezione { get; set; }  //Image
        public Byte[]? Oggetto { get; set; }
        public String? HashEccezione { get; set; } = String.Empty;   //	[char]
        public String? HashOggetto { get; set; } = String.Empty;     // [char]
      
    }
}
