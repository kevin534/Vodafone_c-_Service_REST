﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractListino
    {
        public Int64? Id { get; set; }
        public String? CodiceMateriale { get; set; } = String.Empty;
        public String? CodiceInforecord { get; set; } = String.Empty;
        public String? DescrizioneInforecord { get; set; } = String.Empty;
        public Decimal? PrezzoUnitario { get; set; }
        public String? MaterialGroup { get; set; } = String.Empty;
        public String? CodiceFornitore { get; set; } = String.Empty;
        public String? MaterialGroupFornitore { get; set; } = String.Empty;
        public String? CodiceProduttore { get; set; } = String.Empty;
        public String? CodiceMaterialeFornitore { get; set; } = String.Empty;
        public String? PurchaseOrg { get; set; } = String.Empty;
        public String? InforecordCategory { get; set; } = String.Empty;
        public String? Divisione { get; set; } = String.Empty;
        public String? PurchaseGroup { get; set; } = String.Empty;
        public String? UnitaMisPo { get; set; } = String.Empty;
        public String? UnitaMisMag { get; set; } = String.Empty;
        public Int32? UnitaPrezzo { get; set; }
        public Decimal? QuantitaMinima { get; set; }
        public Decimal? QuantitaStandard { get; set; }
        public Decimal? PrezzoStandard { get; set; }
        public DateTime? DataCreazioneInforecord { get; set; }
        public DateTime? DataFineValidita { get; set; }
        public String? IsCancellato { get; set; } = String.Empty;
        public String? Valuta { get; set; } = String.Empty;
        public Int64? IdIr { get; set; }
        public Int64? IdIrPos { get; set; }
        public Int64? IdVendor { get; set; }
        public Int64? IdZona { get; set; }
        public Int64? CategoriaCsc { get; set; }
        public Int64? IdVendorPurchaseOrg { get; set; }
        public Int64? MaterialeCsc { get; set; }
        public Boolean? Attivo { get; set; } = true;
        public String? FiscalYear { get; set; } = String.Empty;
        public Boolean? FyAttuale { get; set; } = true;

        public ContractZona? Zona { get; set; }
    }
}
