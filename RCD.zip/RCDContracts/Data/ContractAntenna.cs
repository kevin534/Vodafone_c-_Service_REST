﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace RCDContracts.Data
{
    public class ContractAntenna
    {
        public Int64? Id { get; set; }
        public Int64? IdSistema { get; set; }
        public Int64? IdFornitore { get; set; }
        public Int64? IdTipologiaAntenna { get; set; }
        public String? Modello { get; set; } = String.Empty;
        public String? Guadagno { get; set; } = String.Empty;
        public String? Lobo3dbOrizzontale { get; set; } = String.Empty;
        public String? Lobo3dbVerticale { get; set; } = String.Empty;
        public String? Dimensioni { get; set; } = String.Empty;
        public Double? Costo { get; set; } 
        public Boolean? Abilitato { get; set; } 

        public ContractSistema? Sistema { get; set; }
        public ContractFornitore? Fornitore { get; set; }
        public ContractTipologiaAntenna? TipologiaAntenna { get; set; }

    }
}
