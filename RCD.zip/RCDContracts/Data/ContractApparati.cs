﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractApparati
    {
        public Int64? Id { get; set; }
        public Int64? IdFornitore { get; set; }
        public Int64? IdSistema { get; set; }
        public Int64? IdTipoApparato { get; set; }
        public String? Modello { get; set; } = String.Empty;
        public String? RfOutputPowerDlUl { get; set; } = String.Empty;
        public Int32? NumeroCanali { get; set; }
        public Boolean? Modem { get; set; }
        public Double? Costo { get; set; }
        public Boolean? Abilitato { get; set; } = true;

       public ContractFornitore? Fornitore { get; set; }
       public ContractSistema? Sistema { get; set; }
        public ContractTipologiaApparato? TipologiaApparato { get; set; }
    }
}
