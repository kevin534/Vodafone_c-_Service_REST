﻿using System.ComponentModel.DataAnnotations.Schema;

namespace RCDContracts
{
    public class ContractFornitore
    {
        public Int64? Id { get; set; }

        [Column("Fornitore")]
        public String? RagioneSociale { get; set; } = String.Empty;

        public Boolean? Abilitato { get; set; } 
    }
}
