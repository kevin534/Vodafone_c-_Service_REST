﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractTipologiaCopertura
    {
        public Int64? Id { get; set; }
        public String? TipologiaCopertura { get; set; } = String.Empty;
    }
}
