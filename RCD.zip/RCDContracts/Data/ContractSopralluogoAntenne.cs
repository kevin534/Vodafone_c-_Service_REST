﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDContracts.Data
{
    public class ContractSopralluogoAntenne
    {
        public Int64? Id { get; set; }
        public Int64? IdSopralluogo { get; set; }
        public Int64? IdAntenna { get; set; }
		public Int64? IdTipologiaSegnaleAntenna { get; set; }
		public String? Codice { get; set; } = String.Empty;
        public String? PotenzaAlConnettore { get; set; } //= String.Empty;
        public Double? AltezzaBaseAntenna { get; set; }
		public Double? AltezzaCentroElettrico { get; set; }
		public Int32? Azimuth { get; set; }
		public String? Localizzazione { get; set; } //= String.Empty;
		public String? Accessibilita { get; set; } //= String.Empty;
		public Boolean? Piattaforma { get; set; }
		public String? ObiettiviCopertura { get; set; } //= String.Empty;

		[Column(TypeName = "ntext")]
        public String? Note { get; set; }
		public Boolean? Riuso { get; set; }
		public Int32? Quantita { get; set; }

        [Column(TypeName = "decimal(18, 2)")]
        public Decimal? PrezzoTotale { get; set; }
		public Int64? IdAccessibilitaAntenna { get; set; }
		public Int64? IdLocalizzazioneAntenna { get; set; }
		public Int64? IdInstallazioneAntenna { get; set; }

		public ContractSopralluogo? Sopralluogo { get; set; }
		public ContractAntenna? Antenna { get; set; }
		public ContractTipologiaSegnaleAntenna? TipologiaSegnaleAntenna { get; set; }
		public ContractAccessibilitaAntenna? TTAccessibilitaAntenna { get; set; }
		public ContractLocalizzazioneAntenna? TTLocalizzazioneAntenna { get; set; }
		public ContractTTInstallazioneAntenna? TTInstallazioneAntenna { get; set; }

	}
}
