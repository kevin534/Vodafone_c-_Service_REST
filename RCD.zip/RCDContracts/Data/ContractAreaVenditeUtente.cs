﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
   
    public class ContractAreaVenditaUtente
    {
        public Int64? Id { get; set; }
        public Int64? IdDirezione { get; set; }
        public Int64? IdDivisione { get; set; }
        public Int64? IdAreaVendita { get; set; }
        public Int64? IdUtenteAM { get; set; }
        public Int64? IdUtenteCRD { get; set; }
        public ContractCanaleVendita? CanaleVendita { get; set; }
        public ContractCanaleVenditaDettaglio? CanaleVenditaDettaglio { get; set; }
        public ContractAreaVendite? AreaVendite { get; set; }
        public ContractUtente? Utente { get; set; }


        public List<ContractUtente>? ListUtentiAreaVendita { get; set; }
    }
}
