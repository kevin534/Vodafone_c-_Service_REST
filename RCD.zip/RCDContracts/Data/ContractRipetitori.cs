﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractRipetitori
    {
        public Decimal? IdElement { get; set; }
        public Decimal? IdUsoRipetitore { get; set; }
        public Decimal? IdAlimentazione { get; set; }
        public Decimal? IdStato { get; set; }
        public Decimal? IdNe { get; set; }
        public Decimal? IdZona { get; set; }
        public Decimal? IdOffice { get; set; }
        public Decimal? IdComune { get; set; }
        public Decimal? IdClasse { get; set; }
        public Decimal? IdFase { get; set; }
        public String? RipNumber { get; set; }
        public String? Suffisso { get; set; }
        public Decimal? Altezza { get; set; }
        public String? Nome { get; set; }
        public String? Indirizzo { get; set; }
        public String? Latitudine { get; set; }
        public String? Longitudine { get; set; }
        public String? TempDef { get; set; }
        public String? BatteriaBackup { get; set; }
        public Decimal? IdVersione { get; set; }
        public Decimal? IdProgetto { get; set; }
        public Decimal? BtsDonatrice { get; set; }
        public Decimal? CellId { get; set; }
        public String? ObiettiviCopertura { get; set; }
        public DateTime? DataPrevistaOnAir { get; set; }
        public String? Cpa { get; set; }
        public Decimal? IdProgettoAziendale { get; set; }
        public Decimal? IdStatoRipetitore { get; set; }
        public Decimal? UmtsDonatrice { get; set; }
        public Decimal? UmtsCellId { get; set; }
        public Decimal? IdTipoUtilizzo { get; set; }
    }
}
