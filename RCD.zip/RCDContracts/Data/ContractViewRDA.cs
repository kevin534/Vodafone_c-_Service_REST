﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractViewRDA
    {
        public Int64? IdRdA { get; set; }
        public String? StatoRichiesta { get; set; }
        public String? CreatoDa { get; set; }
        public DateTime? DataInvio { get; set; }
        public DateTime? DataChiusuraLavori { get; set; }
        public String? CodiceNazionale { get; set; }
        public String? Office { get; set; }
        public String? Zona { get; set; }
        public String? CodiceCliente { get; set; }
        public String? RagioneSocialeCliente { get; set; }
        public String? NomeInstallazione { get; set; }
        public String? Indirizzo { get; set; }
        public String? Comune { get; set; }
        public String? Provincia { get; set; }
        public String? Fornitore { get; set; }
        public String? StatoAmministrativo { get; set; }
        public String? StatoRda { get; set; }
        public String? IdRdaCsc { get; set; }
        public String? IdOdaCsc { get; set; }
        public Decimal? TotaleRDA { get; set; }
        public String? IdEntry { get; set; }
        public DateTime? DataSopralluogoStimata { get; set; }
        public DateTime? DataSopralluogoConsuntivata { get; set; }
        public DateTime? DataInstallazioneStimata { get; set; }
        public DateTime? DataOnAirConsuntivata { get; set; }
        public DateTime? DataRichiesta { get; set; }
        public DateTime? DataChiusuraAttivitaDitta { get; set; }
        public String? DeliveryManager { get; set; }
        public String? RAN { get; set; }
        public String? NI { get; set; }
        public Int64? IdFornitore { get; set; }
        public String? TipologiaRichiesta { get; set; }
        public Int64? IdIntervento { get; set; }
    }
}
