﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractAccessorio
    {
        public Int64? Id { get; set; }
        public Int64? IdTipologiaAccessorio { get; set; }
        public Int64? IdSistema { get; set; }
        public Int64? IdFornitore { get; set; }
        public String? Modello { get; set; } = String.Empty;
        public Double? Costo { get; set; }
        public Boolean? Abilitato { get; set; }

        public ContractTipologiaAccessorio? TipologiaAccessorio { get; set; }
        public ContractSistema? Sistema { get; set; }
        public ContractFornitore? Fornitore { get; set; }

    }
}
