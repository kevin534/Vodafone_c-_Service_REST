﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDContracts.Data
{
    public class ContractSopralluogo
    {
		public Int64? Id { get; set; }
		public Int64? IdTipoCantiere { get; set; }
        public Int64? IdDittaIncaricata { get; set; }
        public Int64? IdDeliveryManager { get; set; }
        public String? SiglaCodiceInstallazione { get; set; } = String.Empty;
        public Int32? ProgressivoCodiceInstallazione { get; set; }
        public String? CodiceInstallazione { get; set; } = String.Empty;
        public DateTime? DataSopralluogoStimata { get; set; }
        public DateTime? DataSopralluogoConsuntivata { get; set; }
        public DateTime? DataRichiestaSopralluogo { get; set; }
        public DateTime? DataInstallazioneStimata { get; set; }
        public DateTime? DataInvioStima { get; set; }

        [Column(TypeName = "ntext")]
        public String? DescrizioneSopralluogo { get; set; }
        public Int32? NumeroMiniGsmRichiesti { get; set; }
        public Int32? NumeroMiniUmtsRichiesti { get; set; }
        public Int32? NumeroMiniLteRichiesti { get; set; }
        public Int32? NumeroCompactGsmRichiesti { get; set; }
        public Int32? NumeroCompactUmtsRichiesti { get; set; }
        public Int32? NumeroCompactLteRichiesti { get; set; }
        public Int32? NumeroApparatiFemto { get; set; }
        public Int32? NumeroApparatiFemtoLte { get; set; }
        public Int32? NumeroPicoUmts { get; set; }
        public Int32? NumeroPicoLte { get; set; }
        public Int32? NumeroApparatiDualBand { get; set; }
        public Int32? NumeroSimNecessarie { get; set; }
        public Boolean? VincoliAreaPresenti { get; set; }

        [Column(TypeName = "ntext")]
        public String? TipologiaVincolo { get; set; }
        public Double? StimaIntervento { get; set; }
        public Boolean? MicrocelleMacrosito { get; set; }
        public Int32? TotaleApparatiNuovi { get; set; }
        public Int32? TotaleApparatiRiuso { get; set; }
        public Double? CostoAccessoriApparatiStimato { get; set; }
        public Boolean? AutorizzazioneCliente { get; set; }
        public Boolean? Preventivo { get; set; }
        public String? StudioProgettazione { get; set; } = String.Empty;
        public Double? TotaleCostiSostenuti { get; set; }
        public Boolean? Piattaforma { get; set; }
        public Boolean? PermessoNecessario { get; set; }
        public Boolean? RdAEmessa { get; set; }
        public Boolean? OdAEmessa { get; set; }
        public Boolean? NclEmessa { get; set; }
        public DateTime? DataChiusuraSopralluogoDitta { get; set; }
        public String? NumeroNCL { get; set; } = String.Empty;
        public String? NumeroODA { get; set; } = String.Empty;
        public String? IdEntry { get; set; } = String.Empty;
        public String? NumeroRDA { get; set; } = String.Empty;
        public Boolean? NecessitaRelazione { get; set; } 
        public DateTime? DataPresentazionePermesso { get; set; }
        public String? NumeroProtocolloRichiesta { get; set; } = String.Empty;
        public String? StimaOttenimentoPermesso { get; set; } = String.Empty;
        public DateTime? DataPresaInCaricoDitta { get; set; }
        public String? NoteRANVO { get; set; } = String.Empty;


        public ContractTipologiaCantiere? TipologiaCantiere { get; set; }
        public ContractDitta? Ditta { get; set; }
        public ContractUtente? DeliveryManager { get; set; }
   
        public ContractSopralluogoAccessori? SopralluogoAccessori { get; set; }
        public ContractSopralluogoAntenne? SopralluogoAntenne { get; set; }
        public ContractSopralluogoApparati? SopralluogoApparati { get; set; }
        public ContractSopralluogoCme? SopralluogoCme { get; set; }
        public ContractSopralluogoCrowdcell? SopralluogoCrowdcell { get; set; }
        public ContractSopralluogoFemto? SopralluogoFemto { get; set; }
        public ContractSopralluogoMisure? SopralluogoMisure { get; set; }
    }
}
