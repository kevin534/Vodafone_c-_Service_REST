﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDContracts.Data
{
    public class ContractViewReportRichieste
    {
		public Int64? Id { get; set; }
		public String? RagioneSociale { get; set; }
		public String? PartitaIVA { get; set; }
		public String? CodiceCliente { get; set; }
		public String? Richiedente { get; set; }
		public String? NomeInstallazione { get; set; }
		public String? Indirizzo { get; set; }
		public String? Comune { get; set; }
		public String? Provincia { get; set; }
		public String? TipologiaCopertura { get; set; }
		public String? SistemaRichiesto { get; set; }
		public String? ServizioRichiesto { get; set; }
		public Boolean? PrevistaVruVruc { get; set; }
		public String? MancanzaSegnaleEsterno { get; set; }
		public String? MancanzaSegnaleInterno { get; set; }

		[Column("StabileDiProprietà")]
		public Boolean? StabileDiProprieta { get; set; }
		public String? TipologiaStabile { get; set; }
		public Int32? MetriQuadriDaCoprire { get; set; }
		public Int32? PianiDaCoprire { get; set; }
		public String? AccessibilitaTetto { get; set; }

		[Column("DisponibilitàOspitareRepeater")]
		public Boolean? DisponibilitaOspitareRepeater { get; set; }
		public String? CoperturaIndoorAltriGestori { get; set; }
		public String? InseritoDa { get; set; }
		public DateTime? DataRichiesta { get; set; }
		public String? CanaleVendita { get; set; }
		public String? CanaleVenditaDettaglio { get; set; }
		public String? AreaVendite { get; set; }
		public String? DistrettoVendite { get; set; }
		public String? Distretto { get; set; }
		public String? MotivoRichiesta { get; set; }
		public String? RiferimentoVendite { get; set; }
		public String? RiferimentoAM { get; set; }
		public String? RiferimentoDce { get; set; }
		public String? RAN { get; set; }
		public String? NI { get; set; }
		public String? TipologiaCliente { get; set; }

		[Column("PrioritàVendite")]
		public String? PrioritaVendite { get; set; }
		public Double? FatturatoMedioBimestrale { get; set; }
		public Int32? NumeroSIM { get; set; }
		public Int32? NumeroInterniVRUC { get; set; }
		public String? UltimoStato { get; set; }
		public Int64? IdUltimoStato { get; set; }
		public Int64? IdProvincia { get; set; }
		public String? Zona { get; set; }
		public Int64? IdUtente { get; set; }
		public Int64? IdRegioneVF { get; set; }
		public String? CodiceNazionale { get; set; }
		public String? Regione { get; set; }
		public String? AgenziaRiferimento { get; set; }
		public DateTime? DataSopralluogoStimata { get; set; }
		public DateTime? DataSopralluogoConsuntivata { get; set; }
		public DateTime? DataOnAirStimata { get; set; }
		public DateTime? DataOnAirConsuntivata { get; set; }
		public DateTime? DataInvioIncaricoVersoDitta { get; set; }
		public Int32? TotaleApparatiNuovi { get; set; }
		public Int32? TotaleApparatiRiuso { get; set; }
		public Double? CostoPreventivo { get; set; }
		public Double? CostoConsuntivo { get; set; }
		public String? TelefonoRiferimento { get; set; }
		public DateTime? DataUltimaModifica { get; set; }
		public String? DittaInstallatrice { get; set; }
		public String? StudioProgettazione { get; set; }
		public String? TipologiaCantiere { get; set; }
		public Boolean? VincoliAreaPresenti { get; set; }
		public Boolean? PermessoNecessario { get; set; }
		public Boolean? RDAEmessa { get; set; }
		public String? NumeroODA { get; set; }
		public Boolean? NCLEmessa { get; set; }
		public String? NumeroNCL { get; set; }
		public Int32? TotaleMini { get; set; }
		public Int32? TotaleCompact { get; set; }
		public Int32? TotaleFemTo { get; set; }
		public Int32? SistemaLTE { get; set; }
		public Int32? SistemaGSM { get; set; }
		public Int32? SistemaUMTS { get; set; }
		public Int32? SistemaUMTSLTE { get; set; }
		public Int32? SistemaGsmUmts { get; set; }
		public Int32? SistemaGsmLTE { get; set; }
		public Int32? TotaleMaxi { get; set; }


		public ContractRichiesta? Richiesta { get; set; }
	}
}
