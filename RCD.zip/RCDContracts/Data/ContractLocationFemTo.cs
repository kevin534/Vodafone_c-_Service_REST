﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{

    public class ContractLocationFemTo
    {
        public Int64? Id { get; set; }
        public Int64? IdLocation { get; set; }
        public String? SerialVfBooster { get; set; } = String.Empty;
        public String? NumeroFemtoGroupAppartenenza { get; set; } = String.Empty;
        public Boolean? IsOpen { get; set; }
        public Int64? AmbitoCopertura { get; set; }
        public Int32? TipoLan { get; set; }
        public String? GestoreLan { get; set; } = String.Empty;
        public Int32? NumeroSimGestite { get; set; }
        public ContractLocation? Location { get; set; }
        public ContractTipologiaLan? TipologiaLan { get; set; }
        public ContractTipologiaCopertura? Copertura { get; set; }
    }
}
