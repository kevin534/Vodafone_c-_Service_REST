﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractInstallazioneMisure
    {
        public Int64? Id { get; set; }
        public Int64? IdInstallazione { get; set; }
        public Int64? IdSistema { get; set; }
        public Int64? IdTipologiaMisura { get; set; }
        public String? Descrizione { get; set; } = String.Empty;
        public Double? LivelloAccesso { get; set; }
        public Double? LivelloSpento { get; set; }
        [Column("QualitàEcIoRxQ")]
        public Int32? QualitaEcIoRxQ { get; set; }
        public Int64? CellId { get; set; }
        public Int32? BcchSc { get; set; }
        [Column(TypeName = "ntext")]
        public String? Note { get; set; }

        public ContractInstallazione? Installazione { get; set; }
        public ContractSistemaMisure? SistemaMisure { get; set; }
        public ContractTipologiaMisura? TipologiaMisure { get; set; }
    }
}
