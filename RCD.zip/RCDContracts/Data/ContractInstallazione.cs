﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractInstallazione
    {
        public Int64? Id { get; set; }
        public Int64? IdDittaInstallazione { get; set; }
        public Int64? IdTipoCosto { get; set; }
        public Int64? IdStatoConsegnaLetteraEmf { get; set; }
        public Int64? IdStatoConsegnaLetteraComodatoUso { get; set; }
        [Column(TypeName = "ntext")]
        public String? DescrizioneInstallazione { get; set; }        
        public Int32? NumeroMiniGsmInstallati { get; set; }
        public Int32? NumeroMiniUmtsInstallati { get; set; }
        public Int32? NumeroMiniLteInstallati { get; set; }
        public Int32? NumeroCompactGsmInstallati { get; set; }
        public Int32? NumeroCompactUmtsInstallati { get; set; }
        public Int32? NumeroCompactLteInstallati { get; set; }
        public Int32? NumeroApparatiFemto { get; set; }
        public Int32? NumeroApparatiFemtoLte { get; set; }
        public Int32? NumeroPicoUmts { get; set; }
        public Int32? NumeroPicoLte { get; set; }
        public Int32? NumeroApparatiDualBand { get; set; }
        public Int32? TotaleApparatiNuovi { get; set; }
        public Int32? TotaleApparatiRiuso { get; set; }
        public DateTime? DataPermessoPresentato { get; set; }
        public DateTime? DataOnAirStimata { get; set; }
        public DateTime? DataApprovazioneCancellazioneInstallazione { get; set; }
        public DateTime? DataOnAirConsuntivata { get; set; }
        public DateTime? DataInvioIncaricoVersoDitta { get; set; }
        public Boolean? SimNecessarie { get; set; }
        public Boolean? RarfStsAperta { get; set; }
        public Boolean? NominaRLInviataAllaDitta { get; set; }
        public String? CognomeRL { get; set; } = String.Empty;
        public String? NomeRL { get; set; } = String.Empty;
        public Boolean? RdAEmessa { get; set; }
        public String? NumeroRdA { get; set; } = String.Empty;
        public Boolean? NcLEmessa { get; set; }
        public Boolean? CtaConsegnatoVo { get; set; }

        [Column(TypeName = "ntext")]
        public String? NoteInstallazione { get; set; }
        public Double? CostoApparatiAccessoriConsuntivato { get; set; }
        public Double? CostoTotaleConsuntivato { get; set; }
        public Double? DeltaStimatoConsuntivato { get; set; }
        public DateTime? DataNominaRL { get; set; }
        public Boolean? OdAEmessa { get; set; }
        public String? NumeroNCL { get; set; }
        public String? NumeroODA { get; set; }
        public String? IdEntry { get; set; }


        public ContractDitta? Ditta { get; set; }
        public ContractTipologiaCosto? TipologiaCosto { get; set; }
        public ContractConsegnaLettere? ConsegnaLettere1 { get; set; }
        public ContractConsegnaLettere? ConsegnaLettere2 { get; set; }


    }
}
