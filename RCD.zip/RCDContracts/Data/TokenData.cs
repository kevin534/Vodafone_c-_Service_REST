﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
   
	public class TokenData 
	{
	
		public String CodiceUtente { get; set; }
		public Int64 IndiceRuolo { get; set; } = 0;
	
		public DateTime DateToken { get; set; }
		//public String SessionCookie { get; set; }
	}
}
