﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractStatiRichiesta
    {
		public Int64? Id { get; set; }
		public Int64? IdRichiesta { get; set; }
		public Int64? IdStato { get; set; }
		public String? Note { get; set; }
		public Int64? IdUtente { get; set; }
		public DateTime? InsertDate { get; set; }

		public ContractUtente? Utente { get; set; }
		public ContractStato? Stato { get; set; }
		public ContractRichiesta? Richiesta { get; set; }
	}
}
