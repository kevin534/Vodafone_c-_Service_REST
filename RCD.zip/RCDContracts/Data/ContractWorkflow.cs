﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractWorkflow
    {
        public Int64 Id { get; set; }
        public Int64 IdInitialState { get; set; }
        public Int64 IdFinalState { get; set; }
        public Int32 ConditionValue { get; set; }

        public ContractStato? InitialState { get; set; }
        public ContractStato? FinalState { get; set; }
    }
}
