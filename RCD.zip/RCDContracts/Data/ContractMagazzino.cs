﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractMagazzino
    {
        public Int64? Id { get; set; }
        public Int64? IdZona { get; set; }
        public String? Magazzino { get; set; } = String.Empty;

        public ContractZona? Zona { get; set; }

        public List<ContractTipologiaApparatoSoglia>? listTipologiaApparatoSoglia { get; set; }
        public List<ContractTipologiaAntennaSoglia>? listTipologiaAntennaSoglia { get; set; }
        public List<ContractTipologiaAccessorioSoglia>? listTipologiaAccessorioSoglia { get; set; }

        //public ContractAccessorioMagazzino? AccessorioMagazzino { get; set; }
        //public ContractAntennaMagazzino? AntennaMagazzino { get; set; }
        //public ContractApparatoMagazzino? ApparatoMagazzino { get; set; }
        //public ContractTipologiaAccessorioSoglia? TipologiaAccessorioSoglia { get; set; }
        //public ContractTipologiaAntennaSoglia? TipologiaAntennaSoglia { get; set; }
        //public ContractTipologiaApparatoSoglia? TipologiaApparatoSoglia { get; set; }
    }
}
