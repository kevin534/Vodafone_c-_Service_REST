﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDContracts.Data
{
    public class ContractBudget
    {
        public Int64? Id { get; set; }
        public Int64? IdAreaVendita { get; set; }
        public Int64? IdBudgetAlert { get; set; }
        public Double? Assegnato { get; set; }
        public Int64? AnnoFiscale { get; set; }
        public Double? Soglia { get; set; }
        [Column("DataInizialeValidità")]
        public DateTime DataInizialeValidita { get; set; }
        [Column("DataFinaleValidità")]
        public DateTime DataFinaleValidita { get; set; }
        public Double InstallatoCancellato { get; set; }
        public Double Approvato { get; set; }
        public Double Pending { get; set; }
        public Int64? FyAttuale { get; set; }
        public Boolean? BloccoRichiesta { get; set; }
        public Int64? SogliaMinima { get; set; }
        public Int64? SogliaMassima { get; set; }

        public ContractAreaVendite? AreaVendita { get; set; }
        public ContractBudgetAlert? BudgetAlert { get; set; }
    }
}
