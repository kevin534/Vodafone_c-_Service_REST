﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDContracts.Data
{
    public class ContractRdaRiga
    {
		public Int64? Id { get; set; }
		public Int64? IdRda { get; set; }
		public Int64? IdListino { get; set; }
		public Int64? IdIntervento { get; set; }
		public Int64? IdElement { get; set; }
		public Int64? IdFornitore { get; set; }
		public Int64? IdCategoriaCsc { get; set; }
		public Int64? IdTipoRichiesta { get; set; }
		public Int64? IdUtente { get; set; }
		public Int64? IdRdaFittizia { get; set; }
		public Int64? IdRdaCsc { get; set; }
		public Int64? IdOdaCsc { get; set; }
		public Int64? IdNclCsc { get; set; }
		public Int32? IdStatoRda { get; set; }
		public Int32? IdStatoOda { get; set; }
		public Int32? IdStatoNcl { get; set; }
		public Int32? IdPosizioneRdaCsc { get; set; }
		public Int32? IdPosizioneOdaCsc { get; set; }
		public Int32? IdPosizioneNclCsc { get; set; }
		public String? TargaTecnicaRdA { get; set; } = String.Empty;
		public String? TargaTecnicaNcl { get; set; } = String.Empty;
		public Boolean? IsInCatalogo { get; set; }

		[Column(TypeName = "decimal(14,3)")]
		public Decimal? QuantitaRichiesta { get; set; }

		[Column(TypeName = "decimal(14,3)")]
		public Decimal? QuantitaChiusura { get; set; }

		public DateTime? DataInserimento { get; set; }
		public DateTime? DataAggiornamento { get; set; }
		public String? NoteAggiornamento { get; set; } = String.Empty;
		public String? NotePiBudget { get; set; } = String.Empty;
		public String? NoteCsc { get; set; } = String.Empty;
		public Decimal? PrezzoRdA { get; set; }   //money type
		public Decimal? PrezzoNcl { get; set; }   //money type
		public Boolean? ToSendRdA { get; set; }
		public Boolean? ToSendNcl { get; set; }
		public Boolean? SendedCsc { get; set; }
		public Boolean? SendedCscNcl { get; set; }
		public String? Apparato { get; set; } = String.Empty;
		public String? OdaNum { get; set; } = String.Empty;
		public Int32? PosizioneOdaNum { get; set; }
		public Boolean? IsIntegrativa { get; set; }
		public Int64? IdRDAintegrativaFittiza { get; set; }
		public Int64? IdEntryNplus { get; set; }
		public Int64? IdApparato { get; set; }
		
	}
}
