﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractOdaSmvs
    {
		public Int64? IDPO { get; set; }
		public Int64? IDPOPOS { get; set; }
		public Int64? FKIDVENDOR { get; set; }
		public Int64? FKIDVCOMPCODE { get; set; }
		public Int64? FKIDVPURCHORG { get; set; }
		public String? PONUM { get; set; }
		public String? CODTIPOPO { get; set; }
		public String? CODVALUTA { get; set; }
		public String? COMPCODE { get; set; }
		public String? PURCHORG { get; set; }
		public String? PURCHGROUP { get; set; }
		public DateTime? DATAMODIFICAPO { get; set; }
		public DateTime? DATACREAZIONEPO { get; set; }
		public TimeSpan? ORACREAZIONEPO { get; set; }
		public String? ANNOSOLAREPO { get; set; }
		public String? CODFORNITORE { get; set; }
		public String? PONUMSAPLEGACY { get; set; }
		public String? GRUPPORILASCIO { get; set; }
		public String? STRATEGIARILASCIO { get; set; }
		public String? INDICATORERILASCIO { get; set; }  //[nchar]
		public String? STATORILASCIO { get; set; }
		public String? FLAGSOTTOPOSTORIL { get; set; } //[nchar]
		public String? USEREVO { get; set; }
		public String? SHOPPINGCARTNUM { get; set; }
		public String? TESTOTESTATADESCR { get; set; }
		public String? TESTOTESTATADEADLINE { get; set; }
		public Int32? POSPONUM { get; set; }
		public String? TIPOOPERAZIONE { get; set; }
		public String? TIPOITEM { get; set; } //[nchar]
		public DateTime? DATAMODIFICAPOSPO { get; set; }
		public TimeSpan? ORAMODIFICAPOSPO { get; set; }
		public Decimal? QUANTITA { get; set; }
		public String? UMQUANTITA { get; set; }
		public Decimal? QUANTITAINUP { get; set; }
		public String? UMPREZZO { get; set; }
		public Int32? UNITAPREZZO { get; set; }
		public String? MATGROUP { get; set; }
		public String? DIVISIONE { get; set; }
		public Decimal? PREZZOUNITARIO { get; set; }
		public Decimal? PREZZOTOTPOSPO { get; set; }
		public String? NUMCONTRATTO { get; set; }
		public String? POSCONTRATTO { get; set; }
		public String? PRNUM { get; set; }
		public Int32? POSPRNUM { get; set; }
		public String? IDPRATICALEGACY { get; set; }
		public DateTime? DATACONSEGNA { get; set; }
		public String? VIA { get; set; }
		public String? CITTA { get; set; }
		public String? CODPOSTALE { get; set; }
		public String? PROVINCIA { get; set; }
		public String? REGIONE { get; set; }
		public String? CODMAT { get; set; }
		public String? DESCMAT { get; set; }
		public String? ACCOUNTASSIGNMENT { get; set; } //[nchar]
		public String? GLACCOUNT { get; set; }
		public String? CDCCODE { get; set; }
		public String? ASSETNUM { get; set; }
		public String? ASSETSUBNUM { get; set; }
		public String? INTERNALORDERNUM { get; set; }
		public String? GOODRECIPIENT { get; set; }
		public String? CODPUNTOSCARICO { get; set; }
		public String? CONTROLLINGAREA { get; set; }
		public String? PROFITSEGMENT { get; set; }
		public String? CDPCODE { get; set; }
		public String? WBSELEMENT { get; set; }
		public String? TESTOPOSDESCR { get; set; }
		public String? TESTOPOSREQUISITIONER { get; set; }
		public String? PO2NUM { get; set; }
		public Int32? POSPO2NUM { get; set; }
		public String? CODCOSTRUTTORE { get; set; }
		public DateTime? DATACREAZIONEPO2 { get; set; }
		public DateTime? DATACONSEGNAPO2 { get; set; }
		public Decimal? QUANTITAPO2 { get; set; }
		public Int64? FKIDPR { get; set; }
	
	}
}
