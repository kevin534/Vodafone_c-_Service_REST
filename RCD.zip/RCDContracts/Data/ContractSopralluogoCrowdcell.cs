﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDContracts.Data
{
    public class ContractSopralluogoCrowdcell
    {
        public Int64? Id { get; set; }
        public Int64? IdSopralluogo { get; set; }
        public String? TargaTecnica { get; set; } 
        public String? Nome { get; set; }
        public DateTime? DataAttivazione { get; set; }
		public Int64? CodiceCellaDonor { get; set; }
		public Int32? PCIDonor { get; set; }
		public Int32? IDFrequenzaDonor { get; set; }
		public Decimal? LivelloDonor { get; set; }
		public Decimal? SpeedTestDownDonor { get; set; }
		public Decimal? SpeedTestUpDonor { get; set; }
		public Decimal? LatenzaDonor { get; set; }
		public Decimal? SNRDonor { get; set; }

		[Column(TypeName = "ntext")]
		public String? NoteDonor { get; set; } 
		public Int64? CodiceCellaCoverage { get; set; }
		public Int32? PCICoverage { get; set; }
		public Int32? IDFrequenzaCoverage { get; set; }
		public Decimal? AttenuazioneCoverage { get; set; }
		public Decimal? AccessoDACoverage { get; set; }
		public Decimal? SpeedTestDownCoverage { get; set; }
		public Decimal? SpeedTestUpCoverage { get; set; }
		public Decimal? LatenzaCoverage { get; set; }
		public Decimal? SNRCoverage { get; set; }

		[Column(TypeName = "ntext")]
		public String? NoteCoverage { get; set; } 
		public String? SerialeSim { get; set; }
		public String? SerialeApparato { get; set; } 
		public String? MsIsdn { get; set; } 
		public String? Puk { get; set; } 
		public Int64? IdLocalizzazioneAntenna { get; set; }
		public Int64? IdInstallazioneAntenna { get; set; }
		public Int64? IdRaggiungibilita { get; set; }
		public Decimal? Altezza { get; set; }
		public Int32? IdCriticitaEmf { get; set; }
		
		[Column(TypeName = "ntext")]
		public String? NotePosizione { get; set; } 

		public ContractSopralluogo? Sopralluogo { get; set; }
		public ContractFrequenzaLTE? TTFrequenzaLte { get; set; }
		public ContractFrequenzaLTE? TTFrequenzaLte1 { get; set; }
		public ContractLocalizzazioneAntenna? TTLocalizzazioneAntenna { get; set; }
		public ContractTTInstallazioneAntenna? TTInstallazioneAntenna { get; set; }
		public ContractRaggiungibilitaApparato? TTRaggiungibilitaApparato { get; set; }
		public ContractCriticitaEMF? TTCriticitaEmf { get; set; }

	}
}
