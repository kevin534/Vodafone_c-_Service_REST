﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractBudgetAlert
    {
        public Int64? Id { get; set; }
        public Int64? DayBetweenMail { get; set; }
        public Int64? MaxMail { get; set; }
        public Int64? MailSended { get; set; }
        public DateTime? LastMailSendedOn { get; set; }
    }
}
