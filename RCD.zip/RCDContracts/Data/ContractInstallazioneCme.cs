﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDContracts.Data
{
    public class ContractInstallazioneCme
    {
        public Int64? Id { get; set; }
        public Int64? IdInstallazione { get; set; }
        public Int64? IdListino { get; set; }
        [Column("Quantità")]
        public Decimal? Quantita { get; set; }
        public Decimal PrezzoTotale { get; set; }
        public String? TargaTecnica { get; set; } = String.Empty;
        public Int64? IdApparato { get; set; }

        public ContractInstallazione? Installazione { get; set; }
        public ContractListino? Listino { get; set; }
        public ContractInstallazioneApparati? InstallazioneApparati { get; set; }
    }
}
