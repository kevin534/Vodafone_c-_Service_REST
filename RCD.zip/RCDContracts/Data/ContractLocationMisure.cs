﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDContracts.Data
{
    public class ContractLocationMisure
    {
        public Int64? Id { get; set; }
        public Int64? IdLocation { get; set; }
        public Int64? IdSistema { get; set; }
        public Int64? IdTipologiaMisura { get; set; }
        public String? Descrizione { get; set; } = String.Empty;
        public Double? LivelloAccesso { get; set; }
        public Double? LivelloSpento { get; set; }
        [Column("QualitàEcIoRxQ")]
        public Int32? QualitaEcIoRxQ { get; set; }
        public Int64? CellId { get; set; }
        public Int32? BcchSc { get; set; }

        [Column(TypeName = "ntext")]
        public String? Note { get; set; } = String.Empty;
        public ContractLocation? Location { get; set; }
        public ContractSistema? Sistema { get; set; }
        public ContractTipologiaMisura? TipologiaMisura { get; set; }
    }
}
