﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractRuoloPrivilegio
    {
        public Int64? Id { get; set; }
        public Int64? IdRuolo { get; set; }
        public Int64? IdPrivilegio { get; set; }
        public ContractRuolo? Ruolo { get; set; }
        public ContractPrivilegio? Privilegio { get; set; }
    }
}
