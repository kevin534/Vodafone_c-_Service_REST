﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractTipologiaApparatoSoglia
    {
        public Int64? Id { get; set; }
        public Int64? IdMagazzino { get; set; }
        public Int64? IdTipologiaApparato { get; set; }
        public Double? Soglia { get; set; }

        public ContractMagazzino? Magazzino { get; set; }
        public ContractTipologiaApparato? TipologiaApparato { get; set; }
    }
}
