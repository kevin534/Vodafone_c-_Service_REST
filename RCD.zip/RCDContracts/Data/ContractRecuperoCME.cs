﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractRecuperoCME
    {
        public Int64? Id { get; set; }
        public Int64? IdRecupero { get; set; }
        public Int64? IdListino { get; set; }
        public Decimal? Quantità { get; set; }
        public Decimal? PrezzoTotale { get; set; }
        public String? TargaTecnica { get; set; } = String.Empty;
        public Int64? IdApparato { get; set; }
        public ContractListino? Listino { get; set; }
        public ContractRecuperi? Recupero { get; set; }
    }
}
