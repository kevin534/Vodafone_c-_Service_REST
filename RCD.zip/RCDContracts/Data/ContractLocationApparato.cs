﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractLocationApparato
    {
        public Int64? Id { get; set; }
        public Int64? IdLocation { get; set; }
        public Int64? IdApparato { get; set; }
        public Int64? IdStatoApparato { get; set; }
        public Int32? IdClasse { get; set; }
        public Int64? IdZona { get; set; }
        public String? SiglaCodice { get; set; } = String.Empty;
        public String? SiglaProvincia { get; set; } = String.Empty;
        public String? Codice { get; set; } = String.Empty;
        public Int32? ProgressivoCodiceApparato { get; set; }
        public String? OldCode { get; set; }
        public DateTime? DataOnAir { get; set; }
        public String? NomeApparato { get; set; } = String.Empty;
        public String? PosizioneApparato { get; set; } = String.Empty;
        public Double? AltezzaApparato { get; set; }
        public String? Raggiungibilita { get; set; } = String.Empty;
        public String? SerialeApparato { get; set; } = String.Empty;
        public String? MatricolaApparato { get; set; } = String.Empty;
        public String? NumeroSim { get; set; } = String.Empty;
        public String? SerialeSim { get; set; } = String.Empty;
        public String? CellaRipetuta { get; set; } = String.Empty;
        public String? CellaRipetutaLte { get; set; } = String.Empty;
        public String? BcchSc { get; set; } = String.Empty;
        public DateTime? Refarming { get; set; }
        public Boolean? CheckFrequenze { get; set; }
        public String? Frequenze { get; set; } = String.Empty;
        [Column(TypeName = "ntext")]
        public String? Note { get; set; }
        public Boolean? Riuso { get; set; }
        public Int32? Quantita { get; set; }
        public Decimal? PrezzoTotale { get; set; }
        public Boolean? InRecupero { get; set; }
        public Boolean? Recuperato { get; set; }
        public Int64? IdPosizioneInstallazioneApparato { get; set; }
        public Int64? IdPosizioneApparato { get; set; }
        public Int64? IdRaggiungibilita { get; set; }
        public DateTime? DataAttivazioneApparato { get; set; }
        public Boolean? ProprietaCliente { get; set; }
        public ContractLocation? Location { get; set; }
        public ContractApparati? Apparato { get; set; }
        public ContractStatoApparati? StatoApparato { get; set; }
        public ContractPosizioneApparato? PosizioneApparatoEntity { get; set; }
        public ContractRaggiungibilitaApparato? RaggiungibilitaEntity { get; set; }
    }
}
