﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractTipologiaAutorizzazione
    {
        public Int64? Id { get; set; }
        public Int64? IdStatoAssociato { get; set; }
        public String? TipologiaAutorizzazione { get; set; }

        public ContractStato? Stato { get; set; }
    }
}
