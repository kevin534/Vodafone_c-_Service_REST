﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractAccessorioMagazzino
    {
        public Int64? Id { get; set; }
        public Int64? IdStatoMateriale { get; set; }
        public Int64? IdMagazzino { get; set; }
        public Int64? IdAccessorio { get; set; }
        public DateTime? DataArrivo { get; set; }
        public String? OdA { get; set; } = String.Empty;
        [Column("Quantità")]
        public Int32? Quantita { get; set; }
        [Column(TypeName = "ntext")]
        public String? Note { get; set; }

        public ContractAccessorioMagazzino? AccessorioMagazzino { get; set; }
        public ContractMagazzino? Magazzino { get; set; }
        public ContractAccessorio? Accessorio { get; set; }
    }
}
