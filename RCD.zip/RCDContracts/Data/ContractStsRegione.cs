﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractStsRegione
    {
        public Int64? Id { get; set; }
        public String? Descrizione { get; set; }
        public Boolean? Abilitato { get; set; }
    }
}
