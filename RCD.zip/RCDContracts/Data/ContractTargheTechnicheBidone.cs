﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractTargheTechnicheBidone
    {
        public Int64? Id { get; set; }
        public String? TargaTecnica { get; set; }
        public Int64? IdZona { get; set; }
        public ContractZona? Zona { get; set; }
    }
}
