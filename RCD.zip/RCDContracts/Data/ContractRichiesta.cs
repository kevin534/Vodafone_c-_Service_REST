﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractRichiesta
    {
        public Int64? Id { get; set; }
        public Int64? IdDitta { get; set; }
        public Int64? IdUserInsert{ get; set; }
        public Int64? IdRiferimentoVendite { get; set; }
        public Int64? IdRiferimentoAreaManager { get; set; }
        public Int64? IdRiferimentoDce { get; set; }
        public Int64? IdRichiedente { get; set; }
        public Int64? IdLocation { get; set; }
        public Int64? IdSopralluogo { get; set; }
        public Int64? IdInstallazione { get; set; }
        public Int64? IdPrioritaVendite { get; set; }
        public Int64? IdProgettistaRan { get; set; }
        public Int64? IdSiteManagerNI { get; set; }
        public Int64? IdMotivoRichiesta { get; set; }
        public Int64? IdTipologiaCoperturaRichiesta { get; set; }
        public Int64? IdSistemaRichiesto { get; set; }
        public Int64? IdServizioRichiesto { get; set; }
        public Int64? IdMancanzaSegnaleEsternoAzienda { get; set; }
        public Int64? IdMancanzaSegnaleInternoAzienda { get; set; }

        [Column(TypeName = "ntext")]
        public String? DescrizioneProblema { get; set; }

        public Boolean? PrevistaVruVruc { get; set; }
        [Column(TypeName = "ntext")]
        public String? DescrizioneZonaDaCoprire { get; set; }
        public Int32? MetriQuadriDaCoprire { get; set; }

        public Int32? PianiDaCoprire { get; set; }
        [Column("DisponibilitàOspitareRepeater")]
        public Boolean? DisponibilitaOspitareRepeater { get; set; }
        [Column(TypeName = "ntext")]
        public String? NoteRichiestaSopralluogo { get; set; }
        public Boolean? EventoTemporaneo { get; set; }

        public DateTime? DataRichiesta { get; set; }
        [Column(TypeName = "ntext")]
        public String? NoteRanNi { get; set; }
        [Column(TypeName = "ntext")]
        public String? NoteDeliveryManager { get; set; }
        public String? LastStatus { get; set; }

        public Int64? LastStatusId { get; set; }
        public DateTime? DataUltimaModifica { get; set; }
        public Boolean? SAC_RDA { get; set; }
        public DateTime? SAC_DATA_RDA { get; set; }
        public Boolean? SAC_NCL { get; set; }
        public DateTime? SAC_DATA_NCL { get; set; }


        public ContractUtente? Utente { get; set; }
        public ContractUtente? RiferimentoVendite { get; set; }
        public ContractUtente? RiferimentoAreaManager { get; set; }
        public ContractUtente? RiferimentoDce { get; set; }
        public ContractUtente? ProgettistaRan { get; set; }
        public ContractUtente? SiteManagerNI { get; set; }
        public ContractRichiedente? Richiedente { get; set; }
        public ContractLocation? Location { get; set; }
        public ContractSopralluogo? Sopralluogo { get; set; }
        public ContractInstallazione? Installazione { get; set; }
        public ContractPrioritaVendite? PrioritaVendite { get; set; }
        public ContractMotivoRichiesta? MotivoRichiesta { get; set; }
        public ContractTipologiaCopertura? TipologiaCopertura { get; set; }
        public ContractSistemaRichiesto? SistemaRichiesto { get; set; }
        public ContractServizio? Servizio { get; set; }
        public ContractMancanzaSegnale? MancanzaSegnaleEsterno { get; set; }
        public ContractMancanzaSegnale? MancanzaSegnaleInterno { get; set; }
    }
}
