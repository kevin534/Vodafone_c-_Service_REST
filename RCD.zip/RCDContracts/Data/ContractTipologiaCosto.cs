﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractTipologiaCosto
    {
        public Int64? Id { get; set; }
        public String? TipologiaCosto { get; set; } = String.Empty;
    }
}
