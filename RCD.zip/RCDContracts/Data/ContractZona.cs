﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractZona
    {
        public Int64 Id { get; set; }
        public String Zona { get; set; } = String.Empty;
        public Int32 ProgressivoZona { get; set; }
        public Boolean Blocco { get; set; }
        //public ContractRegioneVF? RegioniVF { get; set; }
    }
}
