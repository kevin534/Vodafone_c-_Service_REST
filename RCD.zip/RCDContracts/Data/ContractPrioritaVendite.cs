﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractPrioritaVendite
    {
		public Int64? Id { get; set; }
		public String? DescrizionePriorita { get; set; } = String.Empty;
		
	}
}
