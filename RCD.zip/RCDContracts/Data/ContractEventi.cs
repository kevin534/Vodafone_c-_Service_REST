﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractEventi
    {
        public Int64? Id { get; set; }
        public String? DescrizioneEvento { get; set; } = String.Empty;
        public Int64? IdStatoCorrelato { get; set; }
        public Boolean? HasSoglia { get; set; }
        public String? ProcedureName { get; set; } = String.Empty;

        public ContractStato? Stato { get; set; }
    }
}
