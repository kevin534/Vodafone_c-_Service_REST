﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractView_TipologiaApparatoProgressivo
    {
        public Int64? IdZona { get; set; }
        public String? SiglaCodice { get; set; }
        public Int32? Progressivo { get; set; }
    }
}
