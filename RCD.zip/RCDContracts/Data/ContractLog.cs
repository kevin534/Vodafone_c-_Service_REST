﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractLog
    {
        public Int64? Id { get; set; }
        public DateTime? Date { get; set; }
        public String? Thread { get; set; } = String.Empty;
        public String? Level { get; set; } = String.Empty;
        public String? Logger { get; set; } = String.Empty;
        public String? Message { get; set; } = String.Empty;
        public String? Exception { get; set; } = String.Empty;

     }
}
