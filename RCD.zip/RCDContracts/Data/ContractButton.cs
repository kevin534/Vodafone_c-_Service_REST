﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractButton
    {
        public Int64 IdRichiesta { get; set; }
        public Boolean CmbDitta { get; set; }
        public Boolean BtnInviaMail { get; set; }
        public Boolean BtnDettaglioCosti { get; set; }
        public Boolean BtnDettaglioApparati { get; set; }
        public Boolean BtnDocumentazione { get; set; }
        public Boolean CtpDatiSopralluogo { get; set; }
        public Boolean TxtCostoStimato { get; set; }
        public Boolean DpDataInvioStima { get; set; }
      
    }
}
