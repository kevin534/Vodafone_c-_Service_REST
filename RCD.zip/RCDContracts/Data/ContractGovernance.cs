﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractGovernance
    {
		public Int64? Id { get; set; }
		public Int64? IdCanaleCommerciale { get; set; }
		public Int64? IdTipologiaAutorizzazioneApplicata { get; set; }
		public Int32? NumeroSimVoce { get; set; }
		public Int32? NumeroInterniVruc { get; set; }
		public Double? FatturatoBimestrale { get; set; }
		public Double? CostoSopralluogo { get; set; }
		public ContractTipologiaAutorizzazione? TipologiaAutorizzazione { get; set; }
		public ContractCanaleVenditaDettaglio? CanaleVenditaDettaglio { get; set; }

	}
}
