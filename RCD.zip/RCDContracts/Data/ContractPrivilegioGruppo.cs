﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractPrivilegioGruppo
    {
        public String? PrivilegioPadre { get; set; } = String.Empty;
        public List<ContractPrivilegio> ElencoPrivilegio { get; set; } = new List<ContractPrivilegio>();
    }
}
