﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDContracts.Data
{
    public class ContractLocationCrowdcell
    {
		public Int64? Id { get; set; }
		public Int64? IdLocation { get; set; }
		public String? TargaTecnica { get; set; } = String.Empty;
		public DateTime? DataAttivazione { get; set; }
		public Int64? CodiceCellaDonor { get; set; }
		public Int32? PCIDonor { get; set; }
		public Int32? IDFrequenzaDonor { get; set; }
		public Decimal? LivelloDonor { get; set; }
		public Decimal? SpeedTestDownDonor { get; set; }
		public Decimal? SpeedTestUpDonor { get; set; }
		public Decimal? LatenzaDonor { get; set; }
		public Decimal? SNRDonor { get; set; }

		[Column(TypeName = "ntext")]
		public String? NoteDonor { get; set; } = String.Empty;
		public Int64? CodiceCellaCoverage { get; set; }
		public Int32? PCICoverage { get; set; }
		public Int32? IDFrequenzaCoverage { get; set; }
		public Decimal? AttenuazioneCoverage { get; set; }
		public Decimal? AccessoDACoverage { get; set; }
		public Decimal? SpeedTestDownCoverage { get; set; }
		public Decimal? SpeedTestUpCoverage { get; set; }
		public Decimal? LatenzaCoverage { get; set; }
		public Decimal? SNRCoverage { get; set; }

		[Column(TypeName = "ntext")]
		public String? NoteCoverage { get; set; } = String.Empty;
		public String? SerialeSim { get; set; } = String.Empty;
		public String? SerialeApparato { get; set; } = String.Empty;
		public String? MsIsdn { get; set; } = String.Empty;
		public String? Puk { get; set; } = String.Empty;
		public Int64? IdLocalizzazioneAntenna { get; set; }
		public Int64? IdInstallazioneAntenna { get; set; }
		public Int64? IdRaggiungibilita { get; set; }
		public Decimal? Altezza { get; set; }
		public Int32? IdCriticitaEmf { get; set; }

		[Column(TypeName = "ntext")]
		public String? NotePosizione { get; set; } = String.Empty;
		public String? Nome { get; set; } = String.Empty;
		public ContractLocation? Location { get; set; }
		public ContractLocalizzazioneAntenna? LocalizzazioneAntenna { get; set; }
		public ContractInstallazioneAntenne? InstallazioneAntenna { get; set; }
		public ContractRaggiungibilitaApparato? Raggiungibilita { get; set; }
		public ContractCriticitaEMF? CriticitaEmf { get; set; }
		public ContractFrequenzaLTE? FrequenzaDonor { get; set; }
		public ContractFrequenzaLTE? FrequenzaCoverage{ get; set; }
	}
}
