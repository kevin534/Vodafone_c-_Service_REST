﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class Contract2FaOtpValidated
    {
        public Int64? Id { get; set; }
        public Int64? IdDitta { get; set; }
        public String? OTP { get; set; } = String.Empty;
        public DateTime? DataAutenticazione { get; set; }
    }
}
