﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractRDAnclLog
    {
		public Int64? Id { get; set; }
		public Int64? IdRdaRiga { get; set; }
		public Int64? IdRdaFittizio { get; set; }
		public Int64? IdRda { get; set; }
		public DateTime? Dt_invio { get; set; }
		public Boolean? Esito { get; set; }
		public String? DescrizioneErrore { get; set; } = String.Empty;
		public String? TipoErrore { get; set; } = String.Empty;
		public String? TargaTecnica { get; set; } = String.Empty;
		public Boolean? IsIntegrativa { get; set; }
		public Boolean? IsRda { get; set; }
	
	}
}
