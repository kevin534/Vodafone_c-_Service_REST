﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractRecuperi
    {
		public Int64? Id { get; set; }
		public Int64? IdLocation { get; set; }
		public Int64? IdUserInsert { get; set; }
		public Int64? IdDittaInstallazione { get; set; }
		public Int64? IdTipoCantiere { get; set; }
		public Int64? IdSiteManagerNI { get; set; }
		public Int64? IdProvenienzaRichiesta { get; set; }
		public Int64? IdProgettistaRan { get; set; }
		public DateTime? DataRichiesta { get; set; }
		public DateTime? DataInvioRichiestaDisinstallazioneVersoDitta { get; set; }
		public DateTime? DataRecuperoStimata { get; set; }
		public DateTime? DataRecuperoConsuntivata { get; set; }
		[Column(TypeName = "ntext")]
		public String? NoteRanNi { get; set; }
		[Column(TypeName = "ntext")]
		public String? NoteDeliveryManager { get; set; }
		public String? StudioProgettazione { get; set; }
		public String? CognomeRL { get; set; }
		public String? NomeRL { get; set; }
		public Int32? NumeroMiniGsm { get; set; }
		public Int32? NumeroMiniUmts { get; set; }
		public Int32? NumeroCompactGsm { get; set; }
		public Int32? NumeroCompactUmts { get; set; }
		public Int32? NumeroApparatiFemto { get; set; }
		public Int32? NumeroApparatiDualBand { get; set; }
		public Int32? TotaleApparatiDaRecuperare { get; set; }
		public Int32? TotaleSimDaRecuperare { get; set; }
		public Double? CostoApparatiRecuperati { get; set; }
		public Double? CostoStimatoRecupero { get; set; }
		public Boolean? RdAEmessa { get; set; }
		public Boolean? NcLEmessa { get; set; }
		public Boolean? NominaRLInviataDitta { get; set; }
		public Boolean? ApparatiInviatiMagazzino { get; set; }
		public Boolean? Vincolo { get; set; }
		public String? NumeroRda { get; set; }
		public Boolean? IsChiuso { get; set; }
		public Boolean? DismettiImpianto { get; set; }
		public Boolean? OdAEmessa { get; set; }
		public Boolean? IsManutenzione { get; set; }
		public DateTime? DataChiusuraAttivitaDitta { get; set; }
		public String? NumeroODA { get; set; }
		public String? NumeroNCL { get; set; }
		public String? IdEntry { get; set; }

		public ContractTipologiaCantiere? TipologiaCantiere { get; set; }
		public ContractLocation? Location { get; set; }
		public ContractDitta? Ditta { get; set; }
		public ContractUtente? UserInsert { get; set; }
		public ContractUtente? SiteManagerNI { get; set; }
		public ContractUtente? ProgettistaRan { get; set; }
		public ContractProvenienzaRichiesta? ProvenienzaRichiesta { get; set; }

	
	}
}
