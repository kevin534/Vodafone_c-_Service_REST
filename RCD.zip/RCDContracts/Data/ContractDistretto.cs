﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractDistretto
    {
        public Int64? Id { get; set; }
        public Int64? IdCanaleVenditeDettaglio { get; set; }
        public String? NomeDistretti { get; set; } = String.Empty;
        public ContractCanaleVenditaDettaglio? CanaleVenditaDettaglio { get; set; }
    }
}
