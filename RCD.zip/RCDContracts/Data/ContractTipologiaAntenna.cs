﻿using System.ComponentModel.DataAnnotations.Schema;

namespace RCDContracts.Data
{
    public class ContractTipologiaAntenna
    {
        public Int64? Id { get; set; }
        public String? TipologiaAntenna { get; set; } = String.Empty;
        public Boolean? Abilitato { get; set; } = true;
    }
}
