﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractRegioneVF
    {
        public Int64? Id { get; set; }
       
        public Int64? IdZona { get; set; }
        public String? Region { get; set; }
        public String? SiglaCodiceInstallazione { get; set; }
        public ContractZona? Zona { get; set; }
    }
}
