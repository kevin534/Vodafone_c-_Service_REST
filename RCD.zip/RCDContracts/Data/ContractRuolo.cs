﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractRuolo
    {
        public Int64? Id { get; set; }
        public String? DescrizioneRuolo { get; set; } = String.Empty;
       
        public String? NoteRuolo { get; set; }

        public List<ContractRuoloPrivilegio>? listRuoloPrivilegio { get; set; }
    }
}
