﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractGestori
    {
        public Int64? Id { get; set; }
        public String? Gestore { get; set; } = String.Empty;
    }
}
