﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace RCDContracts.Data
{
    public class ContractAnagraficaFornitori
    {
        [Key]
        public Int64 IdVendor { get; set; }
        public Int64? IdVendorCompCode { get; set; }
        public Int64? IdVendorPurchaseOrg { get; set; }
        public String? CodiceFornitore { get; set; } = String.Empty;
        public String? DescrizioneFornitore { get; set; } = String.Empty;
        public String? PartitaIva { get; set; } = String.Empty;
        public String? CompanyId { get; set; } = String.Empty;
        public String? IsOneTime { get; set; } = String.Empty;
        public String? Country { get; set; } = String.Empty;
        public String? Localita { get; set; } = String.Empty;
        public String? CodicePostale { get; set; } = String.Empty;
        public String? Provincia { get; set; } = String.Empty;
        public String? Via { get; set; } = String.Empty;
        public String? AccountGroup { get; set; } = String.Empty;
        public String? AccountGroupOneTime { get; set; } = String.Empty;
        public String? CompCode { get; set; } = String.Empty;
        public String? CondizioniPagamento { get; set; } = String.Empty;
        public String? NumeroTelefono { get; set; } = String.Empty;
        public String? BloccoPagamenti { get; set; } = String.Empty;
        public String? IsCancellato { get; set; } = String.Empty;
        public String? PurchaseOrg { get; set; } = String.Empty;

        String? _zona;
        public Int32? IdZona { get; set; }
        public String? Zona
        {
            get
            {
                return _zona;
            }
            set
            {
                _zona = value;
                if (!String.IsNullOrEmpty(value))
                {
                    IdZona = Convert.ToInt32(value);
                }
            }
        }
  

    }
}
