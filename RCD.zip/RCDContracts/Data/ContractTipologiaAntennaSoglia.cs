﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Data
{
    public class ContractTipologiaAntennaSoglia
    {

        public Int64? Id { get; set; }
        public Int64? IdMagazzino { get; set; }
        public Int64? IdTipologiaAntenna { get; set; }
        public Double? Soglia { get; set; }

        public ContractMagazzino? Magazzino { get; set; }
        public ContractTipologiaAntenna? TipologiaAntenna { get; set; }
    }
}
