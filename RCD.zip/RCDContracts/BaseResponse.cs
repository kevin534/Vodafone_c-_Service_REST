﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts
{
    public class BaseResponse
    {
        public String Result { get; set; } = String.Empty;

        public Payload Payload { get; set; } = new Payload();
        public String Message { get; set; } = String.Empty;
    }
    public class Payload
    {
        public Int32 TotaleElementi { get; set; }
        public Object List { get; set; }
    }
}

