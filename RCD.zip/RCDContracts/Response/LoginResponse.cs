﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Response
{
    public class LoginResponse
    {
        public String Result { get; set; } = String.Empty;

       public Boolean IsAuthenticateOnLDAP { get; set; }
        public String Message { get; set; } = String.Empty;
    }
}
