﻿using RCDContracts.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDContracts.Response
{
    public class LoginResultData
    {
        public String Result { get; set; }
        public LoginPayload Payload { get; set; }
    }

    public class LoginPayload
    {
        public LoginPayloadAccount Account { get; set; }
        public LoginPayloadAuthUserDetails AuthUserDetails { get; set; }
        public String AuthorizationHeader { get; set; }
        public Int32 Error_code { get; set; }
        public String Error_message { get; set; }
    }

    public class LoginPayloadAccount
    {
        public String Username { get; set; }
    }

    public class LoginPayloadAuthUserDetails
    {
        public Int64? UserId { get; set; }
        public String Username { get; set; }
        public String Nome { get; set; }
        public String Cognome { get; set; }
        public String Mail { get; set; }
        public String Dipartimento { get; set; }
        public String Direzione { get; set; }
        public String Divisione { get; set; }
        public String AreaVendita { get; set; }
        public Boolean CheckIdentity { get; set; }
        public List<String> Ruoli { get; set; }
        public List<String> Applicazioni { get; set; }
        public List<ContractMenuUtente> ListaFunzioni { get; set; }
        public String SessionId { get; set; }
        public bool Enabled { get; set; }
        public List<LoginPyloadAuthorities> Authorities { get; set; }
        public bool AccountNonExpired { get; set; }
        public bool AccountNonLocked { get; set; }
        public bool CredentialsNonExpired { get; set; }
    }

    public class LoginPyloadAuthorities
    {
        public String Authority { get; set; }
    }

}
