﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

using RCDEngine.Entities;

namespace RCDEngine
{
	public class RCDDbContext : DbContext
	{
        

        public String ConnectionString { get; set; } = String.Empty;


		public RCDDbContext(DbContextOptions<RCDDbContext> options) : base(options)
		{

		}

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			optionsBuilder.UseSqlServer(ConnectionString);
		}

		private String SqlConnectionString()
		{
			SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder();
			builder.DataSource = "PAOLOW10\\PAOLOSQL19,1533";
			builder.UserID = "vodafone_code_admin";
			builder.Password = "Pallo100100!";
			builder.InitialCatalog = "Vodafone_Code_Svil";
			builder.ApplicationIntent = ApplicationIntent.ReadWrite;
			builder.ConnectTimeout = 300;
			builder.PersistSecurityInfo = true;

			//if (environmentType != UtilityManager.ENVIRONMENT_TYPE.LOCALHOST)
			//{
			builder.Encrypt = false;
			builder.TrustServerCertificate = false;
			builder.MultiSubnetFailover = false;
			//}

			return builder.ConnectionString;
		}


		public DbSet<EntityUtente>? Utente { get; set; }


		public DbSet<EntityRuolo>? Ruolo { get; set; }


		public DbSet<EntityTipologiaApparato>? TipologiaApparato { get; set; }
		public DbSet<EntityTipologiaAccessorio>? TipologiaAccessorio { get; set; }


		public DbSet<EntityZona>? Zona { get; set; }
		public DbSet<EntityEventoZona>? EventoZona { get; set; }
		public DbSet<EntityEventi>? Evento { get; set; }
		public DbSet<EntityStato>? Stato { get; set; }
		public DbSet<EntityStatiRichiesta>? StatiRichiesta { get; set; }
		public DbSet<EntityStatoMateriale>? StatoMateriale { get; set; }

		public DbSet<EntityTipologiaUtente>? TipologiaUtente { get; set; }
		public DbSet<EntityAreaVendite>? AreaVendita { get; set; }
		public DbSet<EntityAreaVenditeUtente>? AreaVenditaUtente { get; set; }
		public DbSet<EntityStsProvincia>? StsProvincia{ get; set; }
		public DbSet<EntityProvincia>? Provincia { get; set; }
		public DbSet<EntityUtentiProvince>? UtentiProvince { get; set; }
		public DbSet<EntityFornitore>? Fornitore { get; set; }
		
		public DbSet<EntityTipologiaAntenna>? TipologiaAntenna { get; set; }

		public DbSet<EntityAntenna>? Antenna { get; set; }

		public DbSet<EntityAccessorio>? Accessorio { get; set; }

		public DbSet<EntitySistema>? Sistema { get; set; }

		public DbSet<EntityMagazzino>? Magazzino { get; set; }

		public DbSet<EntityDitta>? Ditta { get; set; }
		public DbSet<EntityAnagraficaFornitori>? AnagraficaFornitore { get; set; }

		public DbSet<EntityApparati>? Apparati { get; set; }
		public DbSet<EntityListino>? Listino { get; set; }

		public DbSet<EntityGovernance>? Governances { get; set; }
		public DbSet<EntityTipologiaApparatoSoglia>? TipologiaApparatoSoglia { get; set; }
		public DbSet<EntityTipologiaAntennaSoglia>? TipologiaAntennaSoglia { get; set; }
		public DbSet<EntityTipologiaAccessorioSoglia>? TipologiaAccessorioSoglia { get; set; }
		public DbSet<EntityCanaleVenditaDettaglio>? CanaleVenditaDettaglio { get; set; }
		public DbSet<EntityTipologiaAutorizzazione>? TipologiaAutorizzazione { get; set; }
		public DbSet<EntityPrivilegio>? Privilegio { get; set; }
		public DbSet<EntityRuoloPrivilegio>? RuoloPrivilegio { get; set; }
		public DbSet<EntityMail>? Mail { get; set; }
		public DbSet<EntityInstallazione>? Installazione { get; set; }
		public DbSet<EntityListinoPreconfigurato>? ListinoPreconfigurato { get; set; }


		//RICHIESTE E SOPRALLUOGO
		public DbSet<EntityViewReportRichieste>? ViewReportRichieste { get; set; }
		public DbSet<EntityViewRichiestaStatoProvincia>? ViewRichiestaStatoProvincia { get; set; }
		public DbSet<EntityRichiesta>? Richieste { get; set; }
		public DbSet<EntityDocumentazioneSopralluogo>? DocSopralluogo { get; set; }
		public DbSet<EntitySopralluogoCme>? SopralluogoCme { get; set; }
		public DbSet<EntitySopralluogoApparati>? SopralluogoApparati { get; set; }
		public DbSet<EntitySopralluogoFemto>? SopralluogoFemto { get; set; }
		public DbSet<EntitySopralluogoMisure>? SopralluogoMisure { get; set; }
		public DbSet<EntitySopralluogoAntenne>? SopralluogoAntenne { get; set; }
		public DbSet<EntitySopralluogoAccessori>? SopralluogoAccessori { get; set; }
		public DbSet<EntitySopralluogoCrowdcell>? SopralluogoCrowdcell { get; set; }
		public DbSet<EntitySopralluogo>? Sopralluogo { get; set; }
		public DbSet<EntityRegioneVF>? RegioneVF { get; set; }

		public DbSet<EntityWorkflow>? Workflow { get; set; }

		public DbSet<EntityBudget>? Budget { get; set; }


		//INSTALLAZIONI
		public DbSet<EntityInstallazioneCme>? InstallazioneCme { get; set; }
		public DbSet<EntityInstallazioneApparati>? InstallazioneApparati { get; set; }
		public DbSet<EntityInstallazioneAntenne>? InstallazioneAntenne { get; set; }
		public DbSet<EntityInstallazioneAccessori>? InstallazioneAccessori { get; set; }
		public DbSet<EntityInstallazioneMisure>? InstallazioneMisure { get; set; }
		public DbSet<EntityInstallazioneCrowdcell>? InstallazioneCrowdcell { get; set; }
		public DbSet<EntityInstallazioneFemto>? InstallazioneFemto { get; set; }
		public DbSet<EntityDocumentazioneInstallazione>? DocInstallazione { get; set; }


		public DbSet<EntityElement>? Elementi { get; set; }
		public DbSet<EntityAccessibilitaAntenna>? AccessAntenna { get; set; }
		public DbSet<EntityCriticitaEMF>? CriticitaE { get; set; }
		public DbSet<EntityInstallazioneApparato>? InstallazioneAp { get; set; }
		public DbSet<EntityRaggiungibilitaApparato>? RaggiungibilitaAP { get; set; }
		public DbSet<EntityPosizioneApparato>? PosizioneAp { get; set; }
		public DbSet<EntityCanaleVendita>? CanaleVendita { get; set; }
		public DbSet<EntityDistretto>? Distretto { get; set; }
		public DbSet<EntityArea>? Area { get; set; }
		public DbSet<EntityTipologiaCliente>? TipologiaClient { get; set; }
		public DbSet<EntityFrequenzaLTE>? FrequenzaLTE { get; set; }
		public DbSet<EntityLocalizzazioneAntenna>? LocalizzazioneAntenna1 { get; set; }
		public DbSet<EntityTTInstallazioneAntenna>? TTInstallazioneAntenna { get; set; }
		public DbSet<EntityTipologiaCopertura>? TipologiaCopertura { get; set; }
		public DbSet<EntityTipologiaLan>? TipologiaLan { get; set; }
		public DbSet<EntityTipologiaSegnaleAntenna>? TipologiaSegnaleAntenna { get; set; }
		public DbSet<EntitySistemaMisure>? SistemaMisure { get; set; }
		public DbSet<EntityTipologiaMisura>? TipologiaMisura { get; set; }
		public DbSet<EntityStsRegione>? StsRegione { get; set; }
		public DbSet<EntityStsComune>? StsComune { get; set; }
		public DbSet<EntityTipologiaStabile>? TipologiaStabile { get; set; }
		public DbSet<EntityAccessibilitaTetto>? AccessibilitaTetto { get; set; }
		public DbSet<EntityGestori>? Gestori { get; set; }
		public DbSet<EntityOffice>? Office { get; set; }
		public DbSet<EntityRichiedente>? Richiedente { get; set; }
		public DbSet<EntityViewRecuperi>? ViewRecuperi { get; set; }
		public DbSet<EntityRecuperi>? Recuperi { get; set; }
		public DbSet<EntityRecuperoCME>? RecuperiCME { get; set; }
		public DbSet<EntityDocumentazioneRecupero>? DocumentazioneRecupero { get; set; }
		public DbSet<EntitySistemaRichiesto>? SistemaRichiesto { get; set; }
		public DbSet<EntityServizio>? Servizio { get; set; }
		public DbSet<EntityMancanzaSegnale>? MancanzaSegnale { get; set; }
		public DbSet<EntityPrioritaVendite>? PrioritaVendite { get; set; }
		public DbSet<EntityMotivoRichiesta>? MotivoRichiesta { get; set; }
		public DbSet<EntityLocation>? Location { get; set; }
		public DbSet<EntityTipologiaCantiere>? TipologiaCantiere { get; set; }
		public DbSet<EntityLocationAccessori>? LocationAccessori { get; set; }
		public DbSet<EntityLocationAntenna>? LocationAntenna { get; set; }
		public DbSet<EntityLocationApparato>? LocationApparato { get; set; }
		public DbSet<EntityLocationCme>? LocationCme { get; set; }
		public DbSet<EntityLocationCrowdcell>? LocationCrowdcell { get; set; }
		public DbSet<EntityLocationFemTo>? LocationFemTo { get; set; }
		public DbSet<EntityLocationMisure>? LocationMisure { get; set; }
		public DbSet<EntityStatoApparati>? StatoApparati { get; set; }
		public DbSet<EntityElement>? Element { get; set; }
		public DbSet<EntityTargheTechnicheBidone>? TargheTechnicheBidone { get; set; }
		public DbSet<EntityPianificazione>? Pianificazione { get; set; }
		public DbSet<EntityProvenienzaRichiesta>? ProvenienzaRichiesta { get; set; }
		public DbSet<EntityRipetitori>? Ripetitori { get; set; }

		#region "MAGAZZINO"
		public DbSet<EntityApparatoMagazzinoDitta>? ApparatoMagazzinoDitta { get; set; }
		public DbSet<EntityApparatoMagazzino>? ApparatoMagazzino { get; set; }
		public DbSet<EntityAntennaMagazzinoDitta>? AntennaMagazzinoDitta { get; set; }
		public DbSet<EntityAntennaMagazzino>? AntennaMagazzino { get; set; }
		public DbSet<EntityAccessorioMagazzinoDitta>? AccessorioMagazzinoDitta { get; set; }
		public DbSet<EntityAccessorioMagazzino>? AccessorioMagazzino { get; set; }
		public DbSet<EntityView_TipologiaApparatoProgressivo>? VistaTipologiaApparatoProgressivo { get; set; }

		#endregion "MAGAZZINO"

		public DbSet<EntityViewRDA>? ViewRDA { get; set; }
		public DbSet<EntityViewReportCostiRichieste>? ViewReportCostiRichieste { get; set; }

	}
}
