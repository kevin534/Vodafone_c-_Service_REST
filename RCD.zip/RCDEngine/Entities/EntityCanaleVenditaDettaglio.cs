﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_CANALE_VENDITA_DETTAGLIO", Schema = "RCD")]
    public class EntityCanaleVenditaDettaglio
    {
        public Int64? Id { get; set; }
        [ForeignKey("CanaleVendita")]
        public Int64? IdCanaleVendita { get; set; }
        public String? Descrizione { get; set; } = String.Empty;
        public Boolean? HasDistrettoVendite { get; set; }
        public Boolean? Abilitato { get; set; }
        public EntityCanaleVendita? CanaleVendita { get; set; }
    }
}
