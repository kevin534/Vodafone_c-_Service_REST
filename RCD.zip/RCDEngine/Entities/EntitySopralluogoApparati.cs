﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_SOPRALLUOGO_APPARATI", Schema = "RCD")]
    public class EntitySopralluogoApparati
    {
		public Int64? Id { get; set; }
		[ForeignKey("Sopralluogo")]
		public Int64? IdSopralluogo { get; set; }
		[ForeignKey("Apparati")]
		public Int64? IdApparato { get; set; }
		public Int32? IdClasse { get; set; }
		[ForeignKey("StatoApparati")]
		public Int64? IdStatoApparato { get; set; }
		public String? Codice { get; set; } = String.Empty;
		public String? NomeApparato { get; set; } = String.Empty;

		public String? PosizioneApparato { get; set; } = String.Empty;
		public Double? AltezzaApparato { get; set; }
		public String? Raggiungibilita { get; set; } = String.Empty;
		public String? SerialeApparato { get; set; } = String.Empty;
		public String? MatricolaApparato { get; set; } = String.Empty;
		public String? NumeroSim { get; set; } = String.Empty;
		public String? SerialeSim { get; set; } = String.Empty;
		public String? CellaRipetuta { get; set; } = String.Empty;
		public String? CellaRipetutaLte { get; set; } = String.Empty;
		public String? BcchSc { get; set; } = String.Empty;
		public DateTime? Refarming { get; set; }
		public Boolean? CheckFrequenze { get; set; }
		public String? Frequenze { get; set; } = String.Empty;
		[Column(TypeName = "ntext")]
		public String? Note { get; set; }
		public Boolean? Riuso { get; set; }
		public Int32? Quantita { get; set; }

		[Column(TypeName = "decimal(18, 2)")]
		public Decimal? PrezzoTotale { get; set; }

		[ForeignKey("RaggiungibilitaApparato")]
		public Int64? IdRaggiungibilita { get; set; }
		[ForeignKey("InstallazioneApparato")]
		public Int64? IdPosizioneInstallazioneApparato { get; set; }
		[ForeignKey("PosizioneApparati")]
		public Int64? IdPosizioneApparato { get; set; }
		public DateTime? DataAttivazioneApparato { get; set; }
		public Boolean? ProprietaCliente { get; set; }

		public EntitySopralluogo? Sopralluogo { get; set; }
		public EntityApparati? Apparati { get; set; }
		public EntityRaggiungibilitaApparato? RaggiungibilitaApparato { get; set; }
		public EntityPosizioneApparato? PosizioneApparati { get; set; }
		public EntityInstallazioneApparato? InstallazioneApparato { get; set; }
		public EntityStatoApparati? StatoApparati { get; set; }
	}
}
