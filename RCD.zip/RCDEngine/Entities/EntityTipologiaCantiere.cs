﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_TIPOLOGIA_CANTIERE", Schema = "RCD")]
    public class EntityTipologiaCantiere
    {
        public Int64? Id { get; set; }
        public String? TipologiaCantiere { get; set; } = String.Empty;
        public Boolean? Abilitato { get; set; }

    }
}
