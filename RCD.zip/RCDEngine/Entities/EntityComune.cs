﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace RCDEngine.Entities
{
    [Table("T_COMUNE", Schema = "RCD")]
    [Keyless]
    public class EntityComune
    {
        public Decimal? Id_Comune { get; set; }
        public Decimal? Id_Provincia { get; set; }
        public String? Descrizione { get; set; } = String.Empty;
        public String? Cap { get; set; } = String.Empty;
        public String? Istat { get; set; } = String.Empty;
        public DateTime? Data_Inserimento { get; set; }
        public DateTime? Data_Variazione { get; set; }
    }
}
