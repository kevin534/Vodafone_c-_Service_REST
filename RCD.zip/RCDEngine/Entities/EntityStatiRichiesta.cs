﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace RCDEngine.Entities
{
    [Table("T_STATI_RICHIESTA", Schema = "RCD")]
	public class EntityStatiRichiesta
    {
		public Int64? Id { get; set; }

		//[Key, Column(Order = 0)]
		[ForeignKey("Richiesta")]
		public Int64? IdRichiesta { get; set; }

		//[Key, Column(Order = 1)]
		[ForeignKey("Stato")]
		public Int64? IdStato { get; set; }

		public String? Note { get; set; }

		[ForeignKey("Utente")]
		public Int64? IdUtente { get; set; }
		public DateTime? InsertDate { get; set; }

		public EntityUtente? Utente { get; set; }
		public EntityStato? Stato { get; set; }
		public EntityRichiesta? Richiesta { get; set; }
	}
}
