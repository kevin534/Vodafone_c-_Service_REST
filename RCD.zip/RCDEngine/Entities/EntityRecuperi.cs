﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace RCDEngine.Entities
{
	[Table("T_RECUPERO", Schema = "RCD")]
	public class EntityRecuperi
	{
		public Int64? Id { get; set; }
		[ForeignKey("Location")]
		public Int64? IdLocation { get; set; }
		[ForeignKey("UserInsert")]
		public Int64? IdUserInsert { get; set; }

		[ForeignKey("Ditta")]
		public Int64? IdDittaInstallazione { get; set; }
		[ForeignKey("TipologiaCantiere")]
		public Int64? IdTipoCantiere { get; set; }
		[ForeignKey("SiteManagerNI")]
		public Int64? IdSiteManagerNI { get; set; }
		[ForeignKey("ProvenienzaRichiesta")]
		public Int64? IdProvenienzaRichiesta { get; set; }
		[ForeignKey("ProgettistaRan")]
		public Int64? IdProgettistaRan { get; set; }
		public DateTime? DataRichiesta { get; set; }
		public DateTime? DataInvioRichiestaDisinstallazioneVersoDitta { get; set; }
		public DateTime? DataRecuperoStimata { get; set; }
		public DateTime? DataRecuperoConsuntivata { get; set; }	
		[Column(TypeName = "ntext")]
		public String? NoteRanNi { get; set; }
		[Column(TypeName = "ntext")]
		public String? NoteDeliveryManager { get; set; }
		public String? StudioProgettazione { get; set; }
		public String? CognomeRL { get; set; }
		public String? NomeRL { get; set; }
		public Int32? NumeroMiniGsm { get; set; }
		public Int32? NumeroMiniUmts { get; set; }
		public Int32? NumeroCompactGsm { get; set; }
		public Int32? NumeroCompactUmts { get; set; }
		public Int32? NumeroApparatiFemto { get; set; }
		public Int32? NumeroApparatiDualBand { get; set; }
		public Int32? TotaleApparatiDaRecuperare { get; set; }
		public Int32? TotaleSimDaRecuperare { get; set; }
		public Double? CostoApparatiRecuperati { get; set; }
		public Double? CostoStimatoRecupero { get; set; }
		public Boolean? RdAEmessa { get; set; }
		public Boolean? NcLEmessa { get; set; }
		public Boolean? NominaRLInviataDitta { get; set; }
		public Boolean? ApparatiInviatiMagazzino { get; set; }
		public Boolean? Vincolo { get; set; }
		public String? NumeroRda { get; set; }
		public Boolean? IsChiuso { get; set; }
		public Boolean? DismettiImpianto { get; set; }
		public Boolean? OdAEmessa { get; set; }
		public Boolean? IsManutenzione { get; set; }
		public DateTime? DataChiusuraAttivitaDitta { get; set; }
		public String? NumeroODA { get; set; }
		public String? NumeroNCL { get; set; }
		public String? IdEntry { get; set; }

		public EntityTipologiaCantiere? TipologiaCantiere { get; set; }
		public EntityLocation?Location { get; set; }
		public EntityDitta? Ditta { get; set; }
		public EntityUtente? UserInsert { get; set; }
		public EntityUtente? SiteManagerNI { get; set; }
		public EntityUtente? ProgettistaRan { get; set; }
		public EntityProvenienzaRichiesta? ProvenienzaRichiesta { get; set; }

		

	}
}

