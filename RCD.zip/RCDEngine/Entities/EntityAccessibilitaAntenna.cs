﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("TT_ACCESSIBILITA_ANTENNA", Schema = "RCD")]
    public class EntityAccessibilitaAntenna
    {
        public Int64? id { get; set; }
        
        public String? descrizione { get; set; } = String.Empty;
       

    }
}
