﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_REGION_VF", Schema = "RCD")]
    public class EntityRegioneVF
    {
        public Int64? Id { get; set; }
        [ForeignKey("Zona")]
        public Int64? IdZona { get; set; }
        public String? Region { get; set; }
        public String? SiglaCodiceInstallazione { get; set; }
        //[JsonIgnore]
        public EntityZona? Zona { get; set; }
    }
}
