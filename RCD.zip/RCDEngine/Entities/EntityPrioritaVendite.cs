﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_PRIORITA_VENDITE", Schema = "RCD")]
    public class EntityPrioritaVendite
    {
        public Int64? Id { get; set; }
        public String? DescrizionePriorita { get; set; } = String.Empty;
    }
}
