﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_STS_PROVINCIA", Schema = "RCD")]
    public class EntityStsProvincia
    {
        public Int64? Id { get; set; }
        [ForeignKey("Provincia")]
        public Int64? IdProvincia { get; set; }
        [ForeignKey("RegioneSts")]
        public Int64? IdRegioneSts { get; set; }
        public String? Descrizione { get; set; }
        public String? Sigla { get; set; }
        public DateTime DataInserimento { get; set; }
        public DateTime? DataModifica { get; set; }
        public Boolean Abilitato { get; set; }
        public EntityProvincia? Provincia { get; set; }
        public EntityStsRegione? RegioneSts { get; set; }

    }
}
