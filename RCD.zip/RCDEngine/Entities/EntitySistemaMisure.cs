﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_SISTEMA_MISURE", Schema = "RCD")]
    public class EntitySistemaMisure
    {
        public Int64? Id { get; set; }
        public String? Descrizione { get; set; } = String.Empty;
    }
}
