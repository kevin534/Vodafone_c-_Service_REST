﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("TT_INSTALLAZIONE_APPARATO", Schema = "RCD")]
    public class EntityInstallazioneApparato
    {
        public Int64? id { get; set; }

        public String? descrizione { get; set; } = String.Empty;
    }
}
