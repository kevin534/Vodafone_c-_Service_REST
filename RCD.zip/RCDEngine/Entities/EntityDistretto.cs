﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_DISTRETTO", Schema = "RCD")]
    public class EntityDistretto
    {
        public Int64? Id { get; set; }
        [ForeignKey("CanaleVenditaDettaglio")]
        public Int64? IdCanaleVenditeDettaglio { get; set; }
        public String? NomeDistretti { get; set; } = String.Empty;
        public EntityCanaleVenditaDettaglio? CanaleVenditaDettaglio { get; set; }
    }
}
