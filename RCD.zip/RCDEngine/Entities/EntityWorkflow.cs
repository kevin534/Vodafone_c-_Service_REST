﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace RCDEngine.Entities
{
    [Table("T_WORKFLOW", Schema = "RCD")]
    public class EntityWorkflow
    {
        public Int64 Id { get; set; }
        [ForeignKey("InitialState")]
        public Int64 IdInitialState { get; set; }
        [ForeignKey("FinalState")]
        public Int64 IdFinalState { get; set; }
        public Int32 ConditionValue { get; set; }

        public EntityStato? InitialState { get; set; }
        public EntityStato? FinalState { get; set; }
    }
}
