﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_TIPOLOGIA_AUTORIZZAZIONE", Schema = "RCD")]
    public class EntityTipologiaAutorizzazione
    {
        public Int64? Id { get; set; }
        [ForeignKey("Stato")]
        public Int64? IdStatoAssociato { get; set; }
        public String? TipologiaAutorizzazione { get; set; } 

        public EntityStato? Stato { get; set; }
    }
}
