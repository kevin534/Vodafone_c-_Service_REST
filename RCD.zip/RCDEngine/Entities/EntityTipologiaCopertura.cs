﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_TIPOLOGIA_COPERTURA", Schema = "RCD")]
    public class EntityTipologiaCopertura
    {
        public Int64? Id { get; set; }
        public String? TipologiaCopertura { get; set; } = String.Empty;
    }
}
