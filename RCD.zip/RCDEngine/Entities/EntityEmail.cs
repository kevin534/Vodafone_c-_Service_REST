﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_EMAIL", Schema = "RCD")]
    public class EntityEmail
    {
        public Int64? Id { get; set; }
        public Int64? IdEvento { get; set; }
        public String? Subject { get; set; } = String.Empty;
        public String? Body { get; set; } = String.Empty;
        public Boolean? IsForStateChange { get; set; }
        public Boolean? IsForEvent { get; set; }
    }
}
