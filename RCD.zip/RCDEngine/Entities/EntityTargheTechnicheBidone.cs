﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace RCDEngine.Entities
{
    [Table("T_TARGHE_TECNICHE_BIDONE", Schema = "RCD")]
    public class EntityTargheTechnicheBidone
    {
        public Int64? Id { get; set; }
        public String? TargaTecnica { get; set; }
        [ForeignKey("Zona")]
        public Int64? IdZona { get; set; }
        public EntityZona? Zona { get; set; }
       
    }
}
