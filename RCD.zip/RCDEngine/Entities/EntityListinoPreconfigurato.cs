﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_LISTINO_PRECONFIGURATO", Schema = "RCD")]
    public class EntityListinoPreconfigurato
    {
        public Int32? Id { get; set; }
        public String? Valore { get; set; } 
        public String? SiglaValore { get; set; } 
        public String? Descrizione { get; set; } 
        public Boolean? Attivo { get; set; }
    }
}
