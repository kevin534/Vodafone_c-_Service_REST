﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("TT_CRITICITA_EMF", Schema = "RCD")]
    public class EntityCriticitaEMF
    {
        public Int32? id { get; set; }

        public String? descrizione { get; set; } = String.Empty;


    }
}
