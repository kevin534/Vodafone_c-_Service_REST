﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_TIPOLOGIA_UTENTE", Schema = "RCD")]
    public class EntityTipologiaUtente
    {
        public Int64? Id { get; set; }
        public String? TipologiaUtente { get; set; } = String.Empty;
        public Boolean? IsVendita { get; set; }
    }
}
