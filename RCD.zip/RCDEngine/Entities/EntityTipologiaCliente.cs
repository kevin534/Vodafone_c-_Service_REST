﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_TIPOLOGIA_CLIENTE", Schema = "RCD")]
    public class EntityTipologiaCliente
    {
        public Int64? Id { get; set; }
        public String? TipologiaCliente { get; set; } = String.Empty;
    }

}
