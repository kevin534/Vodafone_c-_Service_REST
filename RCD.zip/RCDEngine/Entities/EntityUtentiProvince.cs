﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_UTENTI_PROVINCE", Schema = "RCD")]
    public class EntityUtentiProvince
    {
        public Int64? Id { get; set; }
        [ForeignKey("Utente")]
        public Int64? IdUtente { get; set; }
        [ForeignKey("StsProvincia")]
        public Int64? IdProvincia { get; set; }

        public EntityUtente? Utente { get; set; }
        public EntityStsProvincia? StsProvincia { get; set; }

    }
}
