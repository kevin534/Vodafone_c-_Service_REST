﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_AREAVENDITA_UTENTE", Schema = "RCD")]
    public class EntityAreaVenditeUtente
    {
        public Int64? Id { get; set; }
        [ForeignKey("CanaleVendita")]
        public Int64? IdDirezione { get; set; }
        [ForeignKey("CanaleVenditaDettaglio")]
        public Int64? IdDivisione { get; set; }
        [ForeignKey("AreaVendite")]
        public Int64? IdAreaVendita { get; set; }
        [ForeignKey("Utente")]
        public Int64? IdUtenteAM { get; set; }
        public Int64? IdUtenteCRD { get; set; }
        public EntityCanaleVendita? CanaleVendita { get; set; }
        public EntityCanaleVenditaDettaglio? CanaleVenditaDettaglio { get; set; }
        public EntityAreaVendite? AreaVendite { get; set; }
        public EntityUtente? Utente { get; set; }
    }
}
