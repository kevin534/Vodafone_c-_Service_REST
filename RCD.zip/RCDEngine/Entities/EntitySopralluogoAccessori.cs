﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_SOPRALLUOGO_ACCESSORI", Schema = "RCD")]
    public class EntitySopralluogoAccessori
    {
        public Int64? Id { get; set; }

        [ForeignKey("Sopralluogo")]
        public Int64? IdSopralluogo { get; set; }
        [ForeignKey("Accessorio")]
        public Int64? IdAccessorio { get; set; }
        public String? Codice { get; set; } = String.Empty;
        public String? Posizione { get; set; } = String.Empty;
        public Double? Metri { get; set; }

        [Column(TypeName = "ntext")]
        public String? Note { get; set; }
        public Boolean? Riuso { get; set; }
        public Int32? Quantita { get; set; }

        [Column(TypeName = "decimal(18, 2)")]
        public Decimal? PrezzoTotale { get; set; }

        public EntitySopralluogo? Sopralluogo { get; set; }
        public EntityAccessorio? Accessorio { get; set; }
    }
}
