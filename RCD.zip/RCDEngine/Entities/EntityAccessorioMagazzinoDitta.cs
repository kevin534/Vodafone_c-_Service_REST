﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_ACCESSORIO_MAGAZZINODITTA", Schema = "RCD")]
    public class EntityAccessorioMagazzinoDitta
    {
        public Int64? Id { get; set; }
        [ForeignKey("StatoMateriale")]
        public Int64? IdStatoMateriale { get; set; }
        [ForeignKey("Ditta")]
        public Int64? IdDitta { get; set; }
        [ForeignKey("Accessorio")]
        public Int64? IdAccessorio { get; set; }
        public DateTime? DataArrivo { get; set; }
        public String? OdA { get; set; } = String.Empty;
        [Column("Quantità")]
        public Int32? Quantita { get; set; }
        [Column(TypeName = "ntext")]
        public String? Note { get; set; }

        public EntityStatoMateriale? StatoMateriale { get; set; }
        public EntityDitta? Ditta { get; set; }
        public EntityAccessorio? Accessorio { get; set; }
    }
}
