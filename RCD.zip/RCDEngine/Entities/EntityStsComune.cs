﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_STS_COMUNE", Schema = "RCD")]
    public class EntityStsComune
    {
        public Int64? Id { get; set; }
        [ForeignKey("ProvinciaSts")]
        public Int64? IdProvinciaSts { get; set; }
        public String? Descrizione { get; set; } 
        public String? Cap { get; set; } = String.Empty;
        public String? CodiceIstat { get; set; }
        public DateTime? DataInserimento { get; set; }
        public DateTime? DataModifica { get; set; }
        public Boolean Abilitato { get; set; }

        public EntityStsProvincia? ProvinciaSts { get; set; }

    }
}
