﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_SISTEMA_RICHIESTO", Schema = "RCD")]
    public class EntitySistemaRichiesto
    {
        public Int64? Id { get; set; }
        public String? Sistema { get; set; } = String.Empty;
        public Boolean? SkipGovSopralluogo { get; set; }
        public Boolean? SkipGovInstallazione { get; set; }
    }
}
