﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_TIPOLOGIA_SEGNALE_ANTENNA", Schema = "RCD")]
    public class EntityTipologiaSegnaleAntenna
    {
        public Int64? Id { get; set; }
        public String? TipologiaSegnaleAntenna { get; set; } = String.Empty;
       
    }
}
