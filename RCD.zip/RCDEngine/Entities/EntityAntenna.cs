﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace RCDEngine.Entities
{
    [Table("T_ANTENNA", Schema = "RCD")]
    public  class EntityAntenna
    {
        public Int64? Id { get; set; }

        [ForeignKey("Sistema")]
        public Int64? IdSistema { get; set; }
        [ForeignKey("Fornitore")]
        public Int64? IdFornitore { get; set; }
        [ForeignKey("TipologiaAntenna")]
        public Int64? IdTipologiaAntenna { get; set; }
        public String? Modello { get; set; } = String.Empty;
        public String? Guadagno { get; set; } = String.Empty;
        public String? Lobo3dbOrizzontale { get; set; } = String.Empty;
        public String? Lobo3dbVerticale { get; set; } = String.Empty;
        public String? Dimensioni { get; set; } = String.Empty;
        public Double? Costo { get; set; } 
        public Boolean? Abilitato { get; set; } 

        public EntitySistema? Sistema { get; set; }
        public EntityFornitore? Fornitore { get; set; }
        public EntityTipologiaAntenna? TipologiaAntenna { get; set; }
    }
}
