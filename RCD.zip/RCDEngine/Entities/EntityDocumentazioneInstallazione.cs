﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_DOCUMENTAZIONE_INSTALLAZIONE", Schema = "RCD")]
    public class EntityDocumentazioneInstallazione
    {
        public Int64? Id { get; set; }
        [ForeignKey("Installazione")]
        public Int64? IdInstallazione { get; set; }
        public String? Nome { get; set; } = String.Empty;
        public String? Filename { get; set; } = String.Empty;
        public String? PortalFilename { get; set; } = String.Empty;
        public Int32? Version { get; set; }
        public DateTime DataInserimento { get; set; }
        public Boolean? Active { get; set; }
        public EntityInstallazione? Installazione { get; set; }
    }
}
