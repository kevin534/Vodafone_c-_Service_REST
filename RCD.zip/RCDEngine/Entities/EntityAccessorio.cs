﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_ACCESSORIO", Schema = "RCD")]
    public class EntityAccessorio
    {
        public Int64? Id { get; set; }

        [ForeignKey("TipologiaAccessorio")]
        public Int64? IdTipologiaAccessorio { get; set; }

        [ForeignKey("Sistema")]
        public Int64? IdSistema { get; set; }

        [ForeignKey("Fornitore")]
        public Int64? IdFornitore { get; set; }

        public String? Modello { get; set; } = String.Empty;
        public Double? Costo { get; set; }
        public Boolean? Abilitato { get; set; }

        public EntityTipologiaAccessorio? TipologiaAccessorio { get; set; }
        public EntitySistema? Sistema { get; set; }
        public EntityFornitore? Fornitore { get; set; }
    }
}
