﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("VW_PIANIFICAZIONI", Schema = "RCD")]
    public class EntityPianificazione
    {
        public Int64? Id { get; set; }
        public String? RagioneSociale { get; set; }
        public String? PartitaIVA { get; set; }
        public String? CodiceCliente { get; set; }
        public String? Richiedente { get; set; }
        public String? NomeInstallazione { get; set; }
        public String? Indirizzo { get; set; }
        public String? Comune { get; set; }
        public String? Provincia { get; set; }
        public String? TipologiaCopertura { get; set; }
        public String? SistemaRichiesto { get; set; }
        public String? ServizioRichiesto { get; set; }
        public Boolean? PrevistaVruVruc { get; set; }
        public String? MancanzaSegnaleEsterno { get; set; }
        public String? MancanzaSegnaleInterno { get; set; }
        public Boolean? StabileDiProprietà { get; set; }
        public String? TipologiaStabile { get; set; }
        public Int32? MetriQuadriDaCoprire { get; set; }
        public Int32? PianiDaCoprire { get; set; }
        public String? AccessibilitaTetto { get; set; }
        public Boolean? DisponibilitàOspitareRepeater { get; set; }
        public String? CoperturaIndoorAltriGestori { get; set; }
        public String? InseritoDa { get; set; }
        public DateTime? DataRichiesta { get; set; }
        public String? CanaleVendita { get; set; }
        public String? CanaleVenditaDettaglio { get; set; }
        public String? AreaVendite { get; set; }
        public String? DistrettoVendite { get; set; }
        public String? MotivoRichiesta { get; set; }
        public String? RiferimentoVendite { get; set; }
        public String? RiferimentoAM { get; set; }
        public String? RiferimentoDce { get; set; }
        public String? ProgettistaRan { get; set; }
        public String? SiteManagerNI { get; set; }
        public String? TipologiaCliente { get; set; }
        [Column("PrioritàVendite")]
        public String? PrioritaVendite { get; set; }
        public Double? FatturatoMedioBimestrale { get; set; }
        public Int32? NumeroSIM { get; set; }
        public Int32? NumeroInterniVRUC { get; set; }
        public String? UltimoStato { get; set; }
        public Int64? IdUltimoStato { get; set; }
        public Int64? IdProvincia { get; set; }
        public String? Zona { get; set; }
        public DateTime? DataInstallazioneStimata { get; set; }
        public DateTime? DataInvioStima { get; set; }
        public DateTime? DataRichiestaSopralluogo { get; set; }
        public DateTime? DataSopralluogoConsuntivata { get; set; }
        public DateTime? DataSopralluogoStimata { get; set; }
        public DateTime? DataInvioIncaricoVersoDitta { get; set; }
        public DateTime? DataOnAirConsuntivata { get; set; }
        public DateTime? DataOnAirStimata { get; set; }
        public DateTime? DataPermessoPresentato { get; set; }
        public String? DittaInstallatrice { get; set; }
        public Int64? IdZona { get; set; }
        public String? CodiceInstallazione { get; set; }
        public String? StudioProgettazione { get; set; }
        public Double? CostoAccessoriApparatiStimato { get; set; }
        public Double? StimaIntervento { get; set; }
        public Int32? NumeroCompactGsmRichiesti { get; set; }
        public Int32? NumeroCompactUmtsRichiesti { get; set; }
        public Int32? NumeroMiniUmtsRichiesti { get; set; }
        public Int32? NumeroApparatiFemto { get; set; }
        public Int32? NumeroApparatiDualBand { get; set; }
        public Boolean? MicrocelleMacrosito { get; set; }
        public Boolean? AutorizzazioneCliente { get; set; }
        public Boolean? Preventivo { get; set; }
        public Boolean? VincoliAreaPresenti { get; set; }
        public String? TipologiaCantiere { get; set; }
        public Boolean? SimNecessarie { get; set; }
        public Boolean? RarfStsAperta { get; set; }
        public Boolean? CtaConsegnatoVo { get; set; }
        public Boolean? NominaRLInviataAllaDitta { get; set; }
        public String? CognomeRL { get; set; }
        public String? NomeRL { get; set; }
        public Boolean? RdAEmessa { get; set; }
        public String? NumeroRdA { get; set; }
        public Boolean? NcLEmessa { get; set; }
        public Double? CostoApparatiAccessoriConsuntivato { get; set; }
        public Int32? NumeroCompactGsmInstallati { get; set; }
        public Int32? NumeroCompactUmtsInstallati { get; set; }
        public Int32? NumeroMiniGsmInstallati { get; set; }
        public Int32? NumeroMiniUmtsInstallati { get; set; }
        public Int32? NumeroApparatiFemtoInstallati { get; set; }
        public Int32? NumeroApparatiDualBandInstallati { get; set; }
        public Int32? TotaleApparatiNuovi { get; set; }
        public Int32? TotaleApparatiRiuso { get; set; }
        public String? TipologiaCosto { get; set; }
        public Double? DeltaStimatoConsuntivato { get; set; }
        public Double? CostoTotaleConsuntivato { get; set; }
        public String? RegioneVF { get; set; }
        public String? CodiceNazionale { get; set; }
        public String? Regione { get; set; }
        public DateTime? DataIncaricoInstallazioneDitta { get; set; }
        public String? AgenziaRiferimento { get; set; }
        public String? NumeroNCL { get; set; }
        public String? NumeroODA { get; set; }
        public String? IdEntry { get; set; }
        public Double? CostoTotalePreventivo { get; set; }
        public Double? CostoTotaleApparatiPreventivo { get; set; }
        public Double? CostoTotaleApapratiConsuntivo { get; set; }
        public Boolean? PermessoNecessario { get; set; }
        public String? TelefonoRiferimento { get; set; }
        public DateTime? InsertDate { get; set; }
        public Int32? MiniLTE { get; set; }
        public Int32? CompactLTE { get; set; }
        public Int32? FemtoLTE { get; set; }
        public Int32? FemtoGSM { get; set; }
        public Int32? FemtoUMTS { get; set; }
        public Int32? FemtoUMTSLTE { get; set; }
        public Int32? MaxiGSM { get; set; }
        public Int32? MaxiUMTS { get; set; }
        public Int32? MaxiLTE { get; set; }
        public Int32? MaxiUMTSLTE { get; set; }
        public Int32? MaxiGsmUmts { get; set; }
        public Int32? CompactGSMUMTS { get; set; }
        public Int32? CompactLTEUMTS { get; set; }
        public Int32? Mini { get; set; }
        public Int32? MiniGSMUMTS { get; set; }
        public Int32? MiniUMTSLTE { get; set; }
    }
}
