﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_RICHIEDENTE", Schema = "RCD")]
	
	public class EntityRichiedente
    {
		public Int64? Id { get; set; }

		[ForeignKey("TipologiaCliente")]
		public Int64? IdTipologiaCliente { get; set; }
		[ForeignKey("CanaleVendita")]
		public Int64? IdCanaleVendita { get; set; }
		[ForeignKey("CanaleVenditaDettaglio")]
		public Int64? IdCanaleVenditeDettaglio { get; set; }
		[ForeignKey("Area")]
		public Int64? IdArea { get; set; }
		[ForeignKey("AreaVendite")]
		public Int64? IdAreaVendite { get; set; }
		[ForeignKey("Distretto")]
		public Int64? IdDistretto { get; set; }
		public String? RagioneSociale { get; set; }
		public String? CodiceCliente { get; set; }
		public String? PartitaIVA { get; set; }
		public String? AgenziaRiferimento { get; set; }
		public String? CodicePosAgenzia { get; set; }
		public String? CognomeRiferimento { get; set; }
		public String? NomeRiferimento { get; set; }
		[DatabaseGenerated(DatabaseGeneratedOption.Computed)]
		public String? RiferimentoFullName { get; set; } = String.Empty;
		public String? TelefonoRiferimento { get; set; }
		public String? MailRiferimento { get; set; }
		public Int32? NumeroSIM { get; set; }
		public Int32? NumeroInterniVRUC { get; set; }
		public Double? FatturatoMedioBimestrale { get; set; }
		public Int64? IdAreaVenditaOld { get; set; }

		public EntityTipologiaCliente? TipologiaCliente { get; set; }
		public EntityCanaleVendita? CanaleVendita { get; set; }
		public EntityCanaleVenditaDettaglio? CanaleVenditaDettaglio { get; set; }
		public EntityArea? Area { get; set; }
		public EntityAreaVendite? AreaVendite { get; set; }
		public EntityDistretto? Distretto { get; set; }
	}
}
