﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_RUOLO_PRIVILEGIO", Schema = "RCD")]
    public class EntityRuoloPrivilegio
    {
        public Int64? Id { get; set; }
        [ForeignKey("Ruolo")]
        public Int64? IdRuolo { get; set; }
        [ForeignKey("Privilegio")]
        public Int64? IdPrivilegio { get; set; }

        public EntityRuolo? Ruolo { get; set; }
        public EntityPrivilegio? Privilegio { get; set; }
    }
}
