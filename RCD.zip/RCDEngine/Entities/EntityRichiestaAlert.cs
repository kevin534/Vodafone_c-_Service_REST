﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_RICHIESTA_ALERT", Schema = "RCD")]
    public class EntityRichiestaAlert
    {
        public Int64? Id { get; set; }
        public Int64? IdZona { get; set; }
        public Int64? LastStatusId { get; set; }
        public DateTime? LastMailSenderOn { get; set; }
        public Int64? NumberOfMailSended { get; set; }
    }
}
