﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_SOPRALLUOGO_CME", Schema = "RCD")]
    public class EntitySopralluogoCme
    {
        public Int64? Id { get; set; }
        [ForeignKey("Sopralluogo")]
        public Int64? IdSopralluogo { get; set; }
        [ForeignKey("Listino")]
        public Int64? IdListino { get; set; }

        [Column("Quantità")]
        public Decimal? Quantita { get; set; }   //o Quantita ? [Column(TypeName = "decimal(18, 2)")]
        public Decimal? PrezzoTotale { get; set; } // [Column(TypeName = "decimal(18, 2)")]
        public Boolean? CostoSostenuto { get; set; }
        [ForeignKey("SopralluogoApparati")]
        public Int64? IdApparato { get; set; }

        public EntitySopralluogo? Sopralluogo { get; set; }
        public EntityListino? Listino { get; set; }
        //public EntityApparati? Apparato { get; set; }
        public EntitySopralluogoApparati? SopralluogoApparati { get; set; }
    }
}
