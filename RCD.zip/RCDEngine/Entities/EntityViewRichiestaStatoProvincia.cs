﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace RCDEngine.Entities
{
    [Table("VW_RICHIESTE_STATO_PROVINCIA", Schema = "RCD")]
    [Keyless]
    public class EntityViewRichiestaStatoProvincia
    {
        [ForeignKey("Richiesta")]
        public Int64? IdRichiesta { get; set; }
        public Int64? IdStatoRichiesta { get; set; }
        public Int64? IdProvinciaSts { get; set; }

        public EntityRichiesta? Richiesta { get; set; }
    }
}
