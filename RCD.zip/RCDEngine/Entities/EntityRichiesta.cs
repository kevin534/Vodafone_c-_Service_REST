﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{

    [Table("T_RICHIESTA", Schema = "RCD")]
    public class EntityRichiesta
    {
        public Int64? Id { get; set; }

        [ForeignKey("Utente")]
        public Int64? IdUserInsert { get; set; }
        [ForeignKey("RiferimentoVendite")]
        public Int64? IdRiferimentoVendite { get; set; }
        [ForeignKey("RiferimentoAreaManager")]
        public Int64? IdRiferimentoAreaManager { get; set; }
        [ForeignKey("RiferimentoDce")]
        public Int64? IdRiferimentoDce { get; set; }
        [ForeignKey("Richiedente")]
        public Int64? IdRichiedente { get; set; }
        [ForeignKey("Location")]
        public Int64? IdLocation { get; set; }
        [ForeignKey("Sopralluogo")]
        public Int64? IdSopralluogo { get; set; }
        [ForeignKey("Installazione")]
        public Int64? IdInstallazione { get; set; }
        [ForeignKey("PrioritaVendite")]
        public Int64? IdPrioritaVendite { get; set; }
        [ForeignKey("ProgettistaRan")]
        public Int64? IdProgettistaRan { get; set; }
        [ForeignKey("SiteManagerNI")]
        public Int64? IdSiteManagerNI { get; set; }
        [ForeignKey("MotivoRichiesta")]
        public Int64? IdMotivoRichiesta { get; set; }
        [ForeignKey("TipologiaCopertura")]
        public Int64? IdTipologiaCoperturaRichiesta { get; set; }
        [ForeignKey("SistemaRichiesto")]
        public Int64? IdSistemaRichiesto { get; set; }
        [ForeignKey("Servizio")]
        public Int64? IdServizioRichiesto { get; set; }
        [ForeignKey("MancanzaSegnaleEsterno")]
        public Int64? IdMancanzaSegnaleEsternoAzienda { get; set; }
        [ForeignKey("MancanzaSegnaleInterno")]
        public Int64? IdMancanzaSegnaleInternoAzienda { get; set; }

        [Column(TypeName = "ntext")]
        public String? DescrizioneProblema { get; set; }

        public Boolean? PrevistaVruVruc { get; set; }
        [Column(TypeName = "ntext")]
        public String? DescrizioneZonaDaCoprire { get; set; }
        public Int32? MetriQuadriDaCoprire { get; set; }

        public Int32? PianiDaCoprire { get; set; }
        [Column("DisponibilitàOspitareRepeater")]
        public Boolean? DisponibilitaOspitareRepeater { get; set; }
        [Column(TypeName = "ntext")]
        public String? NoteRichiestaSopralluogo { get; set; }
        public Boolean? EventoTemporaneo { get; set; }

        public DateTime? DataRichiesta { get; set; }
        [Column(TypeName = "ntext")]
        public String? NoteRanNi { get; set; }
        [Column(TypeName = "ntext")]
        public String? NoteDeliveryManager { get; set; }
        public String? LastStatus { get; set; }

        public Int64? LastStatusId { get; set; }
        public DateTime? DataUltimaModifica { get; set; }
        public Boolean? SAC_RDA { get; set; }
        public DateTime? SAC_DATA_RDA { get; set; }
        public Boolean? SAC_NCL { get; set; }
        public DateTime? SAC_DATA_NCL { get; set; }



        public EntityUtente? Utente { get; set; }
        public EntityUtente? RiferimentoVendite { get; set; }
        public EntityUtente? RiferimentoAreaManager { get; set; }
        public EntityUtente? RiferimentoDce { get; set; }
        public EntityUtente? ProgettistaRan { get; set; }
        public EntityUtente? SiteManagerNI { get; set; }
        public EntityRichiedente? Richiedente { get; set; }
        public EntityLocation? Location { get; set; }
        public EntitySopralluogo? Sopralluogo { get; set; }
        public EntityInstallazione? Installazione { get; set; }
        public EntityPrioritaVendite? PrioritaVendite { get; set; }
        public EntityMotivoRichiesta? MotivoRichiesta { get; set; }
        public EntityTipologiaCopertura? TipologiaCopertura { get; set; }
        public EntitySistemaRichiesto? SistemaRichiesto { get; set; }
        public EntityServizio? Servizio { get; set; }
        public EntityMancanzaSegnale? MancanzaSegnaleEsterno { get; set; }
        public EntityMancanzaSegnale? MancanzaSegnaleInterno { get; set; }

    }
}
