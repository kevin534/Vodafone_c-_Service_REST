﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_SISTEMA", Schema = "RCD")]
    public class EntitySistema
    {
        public Int64? Id { get; set; }
        public String? Sistema { get; set; } = String.Empty;
    }
}
