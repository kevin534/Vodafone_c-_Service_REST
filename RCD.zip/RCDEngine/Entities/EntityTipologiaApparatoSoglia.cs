﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_TIPOLOGIA_APPARATO_SOGLIA", Schema = "RCD")]
    public class EntityTipologiaApparatoSoglia
    {
        public Int64? Id { get; set; }

        [ForeignKey("Magazzino")]
        public Int64? IdMagazzino { get; set; }

        [ForeignKey("TipologiaApparato")]
        public Int64? IdTipologiaApparato { get; set; } 
        public Double? Soglia { get; set; }

        [JsonIgnore]
        public EntityMagazzino? Magazzino { get; set; }
        public EntityTipologiaApparato? TipologiaApparato { get; set; }
    }
}
