﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;


namespace RCDEngine.Entities
{
    [Table("T_ANAGRAFICA_FORNITORI", Schema = "RCD")]
    public class EntityAnagraficaFornitori
    {
     
        [Key]
        public Int64 IdVendor { get; set; }
        public Int64? IdVendorCompCode { get; set; }
        public Int64? IdVendorPurchaseOrg { get; set; }
        public String? CodiceFornitore { get; set; } = String.Empty;
        public String? DescrizioneFornitore { get; set; } = String.Empty;
        public String? PartitaIva { get; set; } = String.Empty;
        public String? CompanyId { get; set; } = String.Empty;
        public String? IsOneTime { get; set; } = String.Empty;
        public String? Country { get; set; } = String.Empty;
        public String? Localita { get; set; } = String.Empty;
        public String? CodicePostale { get; set; } = String.Empty;
        public String? Provincia { get; set; } = String.Empty;
        public String? Via { get; set; } = String.Empty;
        public String? AccountGroup { get; set; } = String.Empty;
        public String? AccountGroupOneTime { get; set; } = String.Empty;
        public String? CompCode { get; set; } = String.Empty;
        public String? CondizioniPagamento { get; set; } = String.Empty;
        public String? NumeroTelefono { get; set; } = String.Empty;
        public String? BloccoPagamenti { get; set; } = String.Empty;
        public String? IsCancellato { get; set; } = String.Empty;
        public String? PurchaseOrg { get; set; } = String.Empty;

        public String? Zona { get; set; } = String.Empty;


    }
}
