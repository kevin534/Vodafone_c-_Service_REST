﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace RCDEngine.Entities
{
    [Table("T_ZONA", Schema = "RCD")]
    public class EntityZona
    {
       
        public Int64 Id { get; set; }
        public String Zona { get; set; } = String.Empty;
        public Int32 ProgressivoZona { get; set; }
        public Boolean Blocco { get; set; }
        //public EntityRegioneVF? RegioniVF { get; set; }

    }
}
