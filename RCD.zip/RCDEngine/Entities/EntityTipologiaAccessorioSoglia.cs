﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace RCDEngine.Entities
{
    [Table("T_TIPOLOGIA_ACCESSORIO_SOGLIA", Schema = "RCD")]
    public class EntityTipologiaAccessorioSoglia
    {
        public Int64? Id { get; set; }
        [ForeignKey("Magazzino")]
        public Int64? IdMagazzino { get; set; }
        [ForeignKey("TipologiaAccessorio")]
        public Int64? IdTipologiaAccessorio { get; set; }
        public Double? Soglia { get; set; }

        [JsonIgnore]
        public EntityMagazzino? Magazzino { get; set; }
        public EntityTipologiaAccessorio? TipologiaAccessorio{ get; set; }
    }
}
