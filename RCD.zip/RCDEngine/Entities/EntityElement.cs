﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
namespace RCDEngine.Entities
{
	[Table("T_ELEMENT", Schema = "RCD")]
	[Keyless]
	public class EntityElement
    {
		public DateTime? DataInserimento { get; set; }
		public String? Note { get; set; } = String.Empty;
		public Decimal? IdNe { get; set; }
		public Decimal? IdZona { get; set; }
		[ForeignKey("Office")]
		public Decimal? IdOffice { get; set; }
		public String? SiglaDiRete { get; set; } = String.Empty;
		public Decimal? L_IdProgetto { get; set; }
		public Decimal? C_IdVersione { get; set; }
		public Decimal? IdClasse { get; set; }
		public String? Nome { get; set; } = String.Empty;
		public Decimal? ElementInsert { get; set; }
		public Decimal? ElementUpdate { get; set; }
		public Decimal? IdStatoEvolutivo { get; set; }
		public String? Modello { get; set; } = String.Empty;
		public Decimal? IdStatoElemento { get; set; }
		public String? NpSiteId { get; set; } = String.Empty;
		public DateTime? DataVariazione { get; set; }
		public Decimal? SistemaProprietario { get; set; }
		public DateTime? DataStatoElemento { get; set; }
		public String? OotOfService { get; set; } = String.Empty;
		public DateTime? DataOutOfService { get; set; }
		public String? SiglaIt { get; set; } = String.Empty;
		public Decimal? IdFase { get; set; }
		public String? FornitoreHardware { get; set; } = String.Empty;
		public String? FornitoreSoftware { get; set; } = String.Empty;
		public String? ReleaseSoftware { get; set; } = String.Empty;
		public DateTime? DataReleaseSoftware { get; set; }
		public Decimal? NumeroNodi { get; set; }
		public String? VodafoneGlobal { get; set; } = String.Empty;
		public String? Piattaforma { get; set; } = String.Empty;
		public String? AreaGestionale { get; set; } = String.Empty;
		public String? SiglaProvinciaSap { get; set; } = String.Empty;
		public String? TargaTecnicaSap { get; set; } = String.Empty;
		public Decimal? IdCategoria { get; set; }
		public String? Tipologia { get; set; } = String.Empty;
		public Decimal? IdNeLink { get; set; }
		public EntityOffice? Office { get; set; }
	}
}
