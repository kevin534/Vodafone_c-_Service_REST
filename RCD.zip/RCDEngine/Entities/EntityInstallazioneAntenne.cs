﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_INSTALLAZIONE_ANTENNE", Schema = "RCD")]
    public class EntityInstallazioneAntenne
    {
        public Int64? Id { get; set; }
        [ForeignKey("Installazione")]
        public Int64? IdInstallazione { get; set; }
        [ForeignKey("Antenna")]
        public Int64? IdAntenna { get; set; }
        [ForeignKey("TipologiaSegnaleAntenna")]
        public Int64? IdTipologiaSegnaleAntenna { get; set; }
        public String? Codice { get; set; } = String.Empty;
        public String? PotenzaAlConnettore { get; set; } = String.Empty;
        public Double AltezzaBaseAntenna { get; set; }
        public Double AltezzaCentroElettrico { get; set; }
        public Int32? Azimuth { get; set; }
        public String? Localizzazione { get; set; } = String.Empty;
        public String? Accessibilita { get; set; } = String.Empty;
        public Boolean? Piattaforma { get; set; }
        public String? ObiettiviCopertura { get; set; } = String.Empty;

        [Column(TypeName = "ntext")]
        public String? Note { get; set; }
        public Boolean? Riuso { get; set; }
        public Int32? Quantita { get; set; }
        public Decimal PrezzoTotale { get; set; }
        public Boolean? InRecupero { get; set; }
        public Boolean? Recuperato { get; set; }
        [ForeignKey("TTAccessibilitaAntenna")]
        public Int64? IdAccessibilitaAntenna { get; set; }
        [ForeignKey("TTLocalizzazioneAntenna")]
        public Int64? IdLocalizzazioneAntenna { get; set; }
        [ForeignKey("TTInstallazioneAntenna")]
        public Int64? IdInstallazioneAntenna { get; set; }

        public EntityInstallazione? Installazione { get; set; }
        public EntityAntenna? Antenna { get; set; }
        public EntityTipologiaSegnaleAntenna? TipologiaSegnaleAntenna { get; set; }
        public EntityAccessibilitaAntenna? TTAccessibilitaAntenna { get; set; }
        public EntityLocalizzazioneAntenna? TTLocalizzazioneAntenna { get; set; }
        public EntityTTInstallazioneAntenna? TTInstallazioneAntenna { get; set; }
    }
}
