﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_LOCATION_CME", Schema = "RCD")]
    public class EntityLocationCme
    {
        public Int64? Id { get; set; }
        [ForeignKey("Location")]
        public Int64? IdLocation { get; set; }
        public Int64? IdListino { get; set; }
        public Decimal? Quantità { get; set; }
        public Decimal? PrezzoTotale { get; set; }
        public String? TargaTecnica { get; set; } = String.Empty;
        public Int64? IdApparato { get; set; }
        public EntityLocation? Location { get; set; }
    }
}
