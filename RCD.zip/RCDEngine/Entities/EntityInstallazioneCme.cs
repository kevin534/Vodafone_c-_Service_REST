﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_INSTALLAZIONE_CME", Schema = "RCD")]
    public class EntityInstallazioneCme
    {
        public Int64? Id { get; set; }
        [ForeignKey("Installazione")]
        public Int64? IdInstallazione { get; set; }
        [ForeignKey("Listino")]
        public Int64? IdListino { get; set; }
        [Column("Quantità")]
        public Decimal? Quantita { get; set; }
        public Decimal PrezzoTotale { get; set; }
        public String? TargaTecnica { get; set; }

        [ForeignKey("InstallazioneApparati")]
        public Int64? IdApparato { get; set; }

        public EntityInstallazione? Installazione { get; set; }
        public EntityListino? Listino { get; set; }
        //public EntityApparati? Apparato { get; set; }
        public EntityInstallazioneApparati? InstallazioneApparati { get; set; }
    }
}
