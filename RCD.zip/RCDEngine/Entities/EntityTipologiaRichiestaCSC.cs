﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_TIPOLOGIA_RICHIESTA_CSC", Schema = "RCD")]
    public class EntityTipologiaRichiestaCSC
    {
        public Int64? Id { get; set; }
        public String? TipologiaRichiesta { get; set; } = String.Empty;
        public String? AliasRichiesta { get; set; } = String.Empty;
        public Boolean? IsForRichiesta { get; set; }
        public Boolean? Attivo { get; set; }
    }
}
