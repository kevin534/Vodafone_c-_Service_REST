﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("TT_FREQUENZA_LTE", Schema = "RCD")]
    public class EntityFrequenzaLTE
    {
        public Int32? id { get; set; }
        public String? descrizione { get; set; }
    }
}
