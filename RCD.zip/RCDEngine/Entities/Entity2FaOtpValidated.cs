﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_2FA_OTP_VALIDATED", Schema = "RCD")]
    public class Entity2FaOtpValidated
    {
        public Int64? Id { get; set; }
        public Int64? IdDitta { get; set; }
        public String? OTP { get; set; } = String.Empty;
        public DateTime? DataAutenticazione { get; set; }
    }
}
