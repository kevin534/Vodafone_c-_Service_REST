﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_RDA", Schema = "RCD")]
    public class EntityRda
    {
		public Int64? Id { get; set; }
		public Int64? IdFornitore { get; set; }
		public Int64? IdCategoriaCsc { get; set; }
		public Int64? IdIntervento { get; set; }
		public Int64? IdTipoRichiesta { get; set; }
		public Int64? IdStatoAmministrativo { get; set; }
		public Int64? IdUtente { get; set; }
		public Int64? IdUrgenza { get; set; }
		public DateTime? DataInvio { get; set; }
		public DateTime? DataChiusuraLavori { get; set; }
		public DateTime? DataAggiornamento { get; set; }
		public Boolean? FlagReinvio { get; set; }
	}
}
