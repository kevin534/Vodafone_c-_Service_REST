﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_LOCATION_MISURE", Schema = "RCD")]
    public class EntityLocationMisure
    {
        public Int64? Id { get; set; }
        [ForeignKey("Location")]
        public Int64? IdLocation { get; set; }
        [ForeignKey("Sistema")]
        public Int64? IdSistema { get; set; }
        [ForeignKey("TipologiaMisura")]
        public Int64? IdTipologiaMisura { get; set; }
        public String? Descrizione { get; set; } = String.Empty;
        public Double? LivelloAccesso { get; set; }
        public Double? LivelloSpento { get; set; }
        [Column("QualitàEcIoRxQ")]
        public Int32? QualitaEcIoRxQ { get; set; }
        public Int64? CellId { get; set; }
        public Int32? BcchSc { get; set; }

        [Column(TypeName = "ntext")]
        public String? Note { get; set; } = String.Empty;
        public EntityLocation? Location { get; set; }
        public EntitySistema? Sistema { get; set; }
        public EntityTipologiaMisura? TipologiaMisura { get; set; }
    }
}
