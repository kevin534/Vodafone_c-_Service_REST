﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_DITTA_VERIFICA_ACCESSI", Schema = "RCD")]
    public class EntityDittaVerificaAccessi
    {
        public Int32? Id { get; set; }
        public Int64? IdDitta { get; set; }
        public Int32? LoginFailedTentatives { get; set; }
        public DateTime? LastLoginFailedTime { get; set; }
    }
}
