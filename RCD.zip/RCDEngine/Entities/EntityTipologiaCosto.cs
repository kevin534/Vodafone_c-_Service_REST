﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_TIPOLOGIA_COSTO", Schema = "RCD")]
    public class EntityTipologiaCosto
    {
        public Int64? Id { get; set; }
        public String? TipologiaCosto { get; set; } = String.Empty;
    }
}
