﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_PROVINCIA", Schema = "RCD")]
    public class EntityProvincia
    {
        public Int64? Id { get; set; }
        [ForeignKey("RegioneVF")]
        public Int64? IdRegioneVF { get; set; }
        public Boolean? Abilitato { get; set; }
        public EntityRegioneVF? RegioneVF { get; set; }
    }
}
