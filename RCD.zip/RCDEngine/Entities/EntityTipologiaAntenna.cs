﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_TIPOLOGIA_ANTENNA", Schema = "RCD")]
    public class EntityTipologiaAntenna
    {
        public Int64? Id { get; set; }
        public String? TipologiaAntenna { get; set; } = String.Empty;
        public Boolean? Abilitato { get; set; } = true;
    }
}
