﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_ANTENNA_MAGAZZINODITTA", Schema = "RCD")]
    public class EntityAntennaMagazzinoDitta
    {
        public Int64? Id { get; set; }
        [ForeignKey("StatoMateriale")]
        public Int64? IdStatoMateriale { get; set; }
        [ForeignKey("Ditta")]
        public Int64? IdDitta { get; set; }
        [ForeignKey("Antenna")]
        public Int64? IdAntenna { get; set; }
        public DateTime? DataArrivo { get; set; }
        public String? OdA { get; set; } = String.Empty;
        [Column("Quantità")]
        public Int32? Quantita { get; set; }
        [Column(TypeName = "ntext")]
        public String? Note { get; set; }

        public EntityStatoMateriale? StatoMateriale { get; set; }
        // da DB [T_DITTA_old]  ??
        public EntityDitta? Ditta { get; set; }
        public EntityAntenna? Antenna { get; set; }
    }
}
