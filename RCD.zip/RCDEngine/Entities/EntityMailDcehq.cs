﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_MAILDCEHQ", Schema = "RCD")]
    public class EntityMailDcehq
    {
        public Int64? Id { get; set; }
        public String? Mail { get; set; } = String.Empty;
    }
}
