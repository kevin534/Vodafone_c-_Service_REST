﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_DIVISIONE_RUOLO", Schema = "RCD")]
    public class EntityDivisioneRuolo
    {
        public Int64? IdDivisioneRuolo { get; set; }
        public Int64? IdRuolo { get; set; }
        public Int64? IdCanaleVenditaDettaglio { get; set; }
    }
}
