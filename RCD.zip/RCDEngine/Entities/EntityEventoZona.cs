﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace RCDEngine.Entities
{
    [Table("T_EVENTO_ZONA", Schema = "RCD")]
    public class EntityEventoZona
	{ 
		public Int64? Id { get; set; }
		[ForeignKey("Zona")]
		public Int64? IdZona { get; set; }
		[ForeignKey("Evento")]
		public Int64? IdEvento { get; set; }
		public Int32? Soglia { get; set; }
		public Boolean? SendVenditore { get; set; }
		public Boolean? SendRiferimentoKAM { get; set; }
		public Boolean? SendRiferimentoAM { get; set; }
		public Boolean? SendRiferimentoDCE { get; set; }
		public Boolean? SendRAN { get; set; }
		public Boolean? SendNI { get; set; }
		public Boolean? SendTS { get; set; }
		public Boolean? SendCI { get; set; }
		public Boolean? SendNSO { get; set; }
		public Boolean? SendDM { get; set; }
		public Boolean? SendDitta { get; set; }
		public Boolean? HasReminder { get; set; }
		public Int32? DayBetweenMails { get; set; }
		public Int32? MaxMailsToSend { get; set; }

		public EntityEventi? Evento { get; set; }
		
		public EntityZona? Zona { get; set; }
		

	}
}
