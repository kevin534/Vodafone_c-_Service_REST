﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("TT_LOCALIZZAZIONE_ANTENNA", Schema = "RCD")]
    public class EntityLocalizzazioneAntenna
    {
        public Int64? Id { get; set; }
        public String? descrizione { get; set; } = String.Empty;
    }
}
