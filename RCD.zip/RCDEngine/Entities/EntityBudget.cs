﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_BUDGET", Schema = "RCD")]
    public class EntityBudget
    {
        public Int64? Id { get; set; }
        [ForeignKey("AreaVendita")]
        public Int64? IdAreaVendita { get; set; }
        [ForeignKey("BudgetAlert")]
        public Int64? IdBudgetAlert { get; set; }
        public Double? Assegnato { get; set; }
        public Int64? AnnoFiscale { get; set; }
        public Double? Soglia { get; set; }
        [Column("DataInizialeValidità")]
        public DateTime DataInizialeValidita { get; set; }
        [Column("DataFinaleValidità")]
        public DateTime DataFinaleValidita { get; set; }
        public Double InstallatoCancellato { get; set; }
        public Double Approvato { get; set; }
        public Double Pending { get; set; }
        public Int64? FyAttuale { get; set; }
        public Boolean? BloccoRichiesta { get; set; }
        public Int64? SogliaMinima { get; set; }
        public Int64? SogliaMassima { get; set; }

        public EntityAreaVendite? AreaVenditana { get; set; }
        public EntityBudgetAlert? BudgetAlert { get; set; }
    }
}
