﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
	[Table("T_PRIVILEGIO", Schema = "RCD")]
	public class EntityPrivilegio
    {
		public Int64? Id { get; set; }
		public Int64? IdMenu { get; set; }
		public String? Privilegio { get; set; } = String.Empty;
		public String? Nota { get; set; } = String.Empty;
		public String? Gruppo { get; set; } = String.Empty;
		public Int32? Posizione { get; set; }
		public Boolean? Abilitato { get; set; }
	}
}
