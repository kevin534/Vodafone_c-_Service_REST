﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_FORNITORE", Schema = "RCD")]
    public class EntityFornitore
    {
        public Int64? Id { get; set; }

        [Column("Fornitore")]
        public String? RagioneSociale { get; set; } = String.Empty;
        public Boolean? Abilitato { get; set; }
    }
}
