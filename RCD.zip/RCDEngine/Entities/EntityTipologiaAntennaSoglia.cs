﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_TIPOLOGIA_ANTENNA_SOGLIA", Schema = "RCD")]
    public class EntityTipologiaAntennaSoglia
    {
        public Int64? Id { get; set; }

        [ForeignKey("Magazzino")]
        public Int64? IdMagazzino { get; set; }
        [ForeignKey("TipologiaAntenna")]
        public Int64? IdTipologiaAntenna { get; set; }
        public Double? Soglia { get; set; }

        [JsonIgnore]
        public EntityMagazzino? Magazzino { get; set; }
        public EntityTipologiaAntenna? TipologiaAntenna { get; set; }
    }
}
