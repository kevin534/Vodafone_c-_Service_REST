﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_APPARATI", Schema = "RCD")]
    public class EntityApparati
    {
        public Int64? Id { get; set; }
        [ForeignKey("Fornitore")]
        public Int64? IdFornitore { get; set; }
        [ForeignKey("Sistema")]
        public Int64? IdSistema { get; set; }
        [ForeignKey("TipologiaApparato")]
        public Int64? IdTipoApparato { get; set; }
        public String? Modello { get; set; } = String.Empty;
        public String? RfOutputPowerDlUl { get; set; } = String.Empty;
        public Int32? NumeroCanali { get; set; }
        public Boolean? Modem { get; set; }
        public Double? Costo { get; set; }
        public Boolean? Abilitato { get; set; } = true;

        public EntityFornitore? Fornitore { get; set; }
       public EntitySistema? Sistema { get; set; }
       public EntityTipologiaApparato? TipologiaApparato { get; set; }


    }
}
