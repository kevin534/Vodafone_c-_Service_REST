﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_INSTALLAZIONE_APPARATI", Schema = "RCD")]
    public class EntityInstallazioneApparati
    {
        public Int64? Id { get; set; }
        [ForeignKey("Installazione")]
        public Int64? IdInstallazione { get; set; }
        [ForeignKey("Apparati")]
        public Int64? IdApparato { get; set; }
        public Int32? IdClasse { get; set; }
        [ForeignKey("StatoApparati")]
        public Int64? IdStatoApparato { get; set; }
        public Int64? IdZona { get; set; }
        public String? SiglaCodice { get; set; } = String.Empty;
        public String? SiglaProvincia { get; set; } = String.Empty;
        public String? Codice { get; set; } = String.Empty;
        public Int32? ProgressivoCodiceApparato { get; set; }
        public String? NomeApparato { get; set; } = String.Empty;
        public String? PosizioneApparato { get; set; } = String.Empty;
        public Double? AltezzaApparato { get; set; }
        public String? Raggiungibilita { get; set; } = String.Empty;
        public String? SerialeApparato { get; set; } = String.Empty;
        public String? MatricolaApparato { get; set; } = String.Empty;
        public String? NumeroSim { get; set; } = String.Empty;
        public String? SerialeSim { get; set; } = String.Empty;
        public String? CellaRipetuta { get; set; } = String.Empty;
        public String? CellaRipetutaLte { get; set; } = String.Empty;
        public String? BcchSc { get; set; } = String.Empty;
        public DateTime? Refarming { get; set; }
        public Boolean? CheckFrequenze { get; set; }
        public String? Frequenze { get; set; } = String.Empty;
        [Column(TypeName = "ntext")]
        public String? Note { get; set; }
        public Boolean? Riuso { get; set; }
        public Int32? Quantita { get; set; }
        public Decimal PrezzoTotale { get; set; }
        public Boolean? InRecupero { get; set; }
        public Boolean? Recuperato { get; set; }
        [ForeignKey("RaggiungibilitaApparato")]
        public Int64? IdRaggiungibilita { get; set; }
        [ForeignKey("InstallazioneApparato")]
        public Int64? IdPosizioneInstallazioneApparato { get; set; }
        [ForeignKey("PosizioneApparati")]
        public Int64? IdPosizioneApparato { get; set; }
        public DateTime? DataAttivazioneApparato { get; set; }
        public Boolean? ProprietaCliente { get; set; }

        public EntityInstallazione? Installazione { get; set; }
        public EntityApparati? Apparati { get; set; }
        public EntityRaggiungibilitaApparato? RaggiungibilitaApparato { get; set; }
        public EntityPosizioneApparato? PosizioneApparati { get; set; }
        public EntityInstallazioneApparato? InstallazioneApparato { get; set; }
        public EntityStatoApparati? StatoApparati { get; set; }
    }
}
