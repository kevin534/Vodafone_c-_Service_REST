﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_RECUPERO_CME", Schema = "RCD")]
    public class EntityRecuperoCME
    {
        public Int64? Id { get; set; }
        [ForeignKey("Recupero")]
        public Int64? IdRecupero { get; set; }
        [ForeignKey("Listino")]
        public Int64? IdListino { get; set; }
        public Decimal? Quantità { get; set; }
        public Decimal? PrezzoTotale { get; set; }
        public String? TargaTecnica { get; set; } = String.Empty;
        public Int64? IdApparato { get; set; }
        public EntityListino? Listino { get; set; }
        public EntityRecuperi? Recupero { get; set; }
    }
}
