﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_RUOLO", Schema = "RCD")]
    public class EntityRuolo
    {
        public Int64? Id { get; set; }
        public String? DescrizioneRuolo { get; set; } = String.Empty;
       // [Column(TypeName = "ntext")]
        public String? NoteRuolo { get; set; }
        [JsonIgnore]
        public List<EntityRuoloPrivilegio>? listRuoloPrivilegio { get; set; }
    }
}
