﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_MAGAZZINO", Schema = "RCD")]
    public class EntityMagazzino
    {
        public Int64? Id { get; set; }
        [ForeignKey("Zona")]
        public Int64? IdZona { get; set; }
        public String? Magazzino { get; set; } = String.Empty;

        public EntityZona? Zona { get; set; }

        public List<EntityTipologiaApparatoSoglia>? listTipologiaApparatoSoglia { get; set; }
        public List<EntityTipologiaAntennaSoglia>? listTipologiaAntennaSoglia { get; set; }
        public List<EntityTipologiaAccessorioSoglia>? listTipologiaAccessorioSoglia { get; set; }

        //public EntityAccessorioMagazzino? AccessorioMagazzino { get; set; }
        //public EntityAntennaMagazzino? AntennaMagazzino { get; set; }
        //public EntityApparatoMagazzino? ApparatoMagazzino { get; set; }

    }
}
