﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_SOPRALLUOGO_MISURE", Schema = "RCD")]
    public class EntitySopralluogoMisure
    {
        public Int64? Id { get; set; }

        [ForeignKey("Sopralluogo")]
        public Int64? IdSopralluogo { get; set; }
        [ForeignKey("Sistema")]
        public Int64? IdSistema { get; set; }
        [ForeignKey("TipologiaMisura")]
        public Int64? IdTipologiaMisura { get; set; }
        public String? Descrizione { get; set; } = String.Empty;
        public Double? LivelloAccesso { get; set; }
        public Double? LivelloSpento { get; set; }
        [Column("QualitàEcIoRxQ")]
        public Int32? QualitaEcIoRxQ { get; set; }
        public Int64? CellId { get; set; }
        public Int32? BcchSc { get; set; }
        [Column(TypeName = "ntext")]
        public String? Note { get; set; }

        public EntitySopralluogo? Sopralluogo { get; set; }
        public EntitySistema? Sistema { get; set; }
        public EntityTipologiaMisura? TipologiaMisura { get; set; }
    }
}
