﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_SOPRALLUOGO_FEMTO", Schema = "RCD")]
    public class EntitySopralluogoFemto
    {
        public Int64? Id { get; set; }

        [ForeignKey("Sopralluogo")]
        public Int64? IdSopralluogo { get; set; }
        public String? SerialVfBooster { get; set; } = String.Empty;
        public String? NumeroFemtoGroupAppartenenza { get; set; } = String.Empty;
        public Boolean? IsOpen { get; set; }
        [ForeignKey("TipologiaCopertura")]
        public Int64? AmbitoCopertura { get; set; }
        [ForeignKey("TipologiaLan")]
        public Int32? TipoLan { get; set; }
        public String? GestoreLan { get; set; } = String.Empty;
        public Int32? NumeroSimGestite { get; set; }

        public EntitySopralluogo? Sopralluogo { get; set; }
        public EntityTipologiaCopertura? TipologiaCopertura { get; set; }
        public EntityTipologiaLan? TipologiaLan { get; set; }
    }
}
