﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_DITTA", Schema = "RCD")]
    public class EntityDitta
    {
        public Int64? Id { get; set; }
        public String? RagioneSociale { get; set; } 
        public String? PartitaIVA { get; set; } 
        public String? CognomeRiferimento { get; set; } 
        public String? NomeRiferimento { get; set; } 
        public String? TelefonoRiferimento { get; set; } 
        public String? MailRiferimento { get; set; } 
        public Boolean? Abilitato { get; set; } 
        public String? SecureKey { get; set; } 
        [ForeignKey("AnagraficaFornitore")]
        public Int64? IdVendor { get; set; }
        public String? CodiceFornitore { get; set; } 
        public Int64? IdVendorPurchaseOrg { get; set; }
        public String? PurchaseOrg { get; set; } 

        [ForeignKey("Zona")]
        public Int64? IdZona { get; set; }
        public String? Password { get; set; } 
        public Boolean? IsDefaultPasswordChanged { get; set; } 
        public Boolean? IsAccountTemporaryLocked { get; set; } 
        public DateTime? LockedDate { get; set; }
        public Boolean? Is2FAEnabled { get; set; }
        public String? SecretKey { get; set; } 

        public EntityZona? Zona { get; set; }
        public EntityAnagraficaFornitori? AnagraficaFornitore { get; set; }
    }
}
