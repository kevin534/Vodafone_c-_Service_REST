﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_CANALE_VENDITA", Schema = "RCD")]
    public class EntityCanaleVendita
    {
        public Int64? Id { get; set; }
        public String? Canale { get; set; } = String.Empty;
        public Boolean? Abilitato { get; set; }
    }
}
