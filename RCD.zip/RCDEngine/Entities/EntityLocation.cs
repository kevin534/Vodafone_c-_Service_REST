﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_LOCATION", Schema = "RCD")]
    public class EntityLocation
    {
        public Int64? Id { get; set; }

        [ForeignKey("Richiedente")]
        public Int64? IdRichiedente { get; set; }

        [ForeignKey("StsComune")]
        public Int64? IdComune { get; set; }
        [ForeignKey("TipologiaStabile")]
        public Int64? IdTipologiaStabile { get; set; }
        [ForeignKey("AccessibilitaTetto")]
        public Int64? IdDisponibilitaAccessoAlTetto { get; set; }
        [ForeignKey("Gestori")]
        public Int64? IdCoperturaIndoorAltriGestori { get; set; }
        public String? CodiceRepeater { get; set; }
        public String? NomeInstallazione { get; set; }
        public String? Indirizzo { get; set; }
        public String? CAP { get; set; }
        public String? ProprietaEdificio { get; set; }
        public String? ParticellaCatastale { get; set; }
        public Boolean? Vincolo { get; set; }
        public String? Office { get; set; }
        public Int64? ProgressivoOffice { get; set; }
        public Int32? LatitudineGradi { get; set; }
        public Int32? LatitudinePrimi { get; set; }
        public Double? LatitudineSecondi { get; set; }
        public Double? LatitudineUTM { get; set; }
        public Int32? LongitudineGradi { get; set; }
        public Int32? LongitudinePrimi { get; set; }
        public Double? LongitudineSecondi { get; set; }
        public Double? LongitudineUTM { get; set; }
        public Int32? SLM { get; set; }
        public DateTime? DataOnAir { get; set; }
        [Column(TypeName = "ntext")]
        public String? NoteLocation { get; set; }
        public Boolean? DismissioneImpianti { get; set; }
        public Boolean? IsDismesso { get; set; }
        public DateTime? DataDismissioneImpianti { get; set; }
        [Column("StabileDiProprietà")]
        public Boolean? StabileDiProprieta { get; set; }
        [Column(TypeName = "ntext")]
        public String? MotivoDismissione { get; set; }
        [Column(TypeName = "ntext")]
        public String? Note { get; set; }
        public Decimal? IdOffice { get; set; }
        public String? FullNameReferenteLocale { get; set; }
        public String? TelefonoReferenteLocale { get; set; }
        public String? EmailReferenteLocale { get; set; }

        public EntityRichiedente? Richiedente { get; set; }
        public EntityStsComune? StsComune { get; set; }
        public EntityTipologiaStabile? TipologiaStabile { get; set; }
        public EntityAccessibilitaTetto? AccessibilitaTetto { get; set; }
        public EntityGestori? Gestori { get; set; }

        public List<EntityLocationAccessori>? LocationAccessori { get; set; }
        public List<EntityLocationAntenna>? LocationAntenne { get; set; }
        public List<EntityLocationApparato>? LocationApparati { get; set; }
        public List<EntityLocationCme>? LocationCme { get; set; }
        public List<EntityLocationFemTo>? LocationFemTo { get; set; }
        public List<EntityLocationMisure>? LocationMisure { get; set; }
        public List<EntityLocationCrowdcell>? LocationCrowdcell { get; set; }
    }
}
