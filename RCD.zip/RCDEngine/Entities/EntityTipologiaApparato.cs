﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_TIPOLOGIA_APPARATO", Schema = "RCD")]
    public class EntityTipologiaApparato
    {
        public Int64? Id { get; set; }
        public String? Sigla { get; set; } = String.Empty;
        public String? TipologiaApparato { get; set; } = String.Empty;

        public Boolean? Abilitato { get; set; } = true;

    }
}
