﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace RCDEngine.Entities
{
	[Table("VW_RECUPERI", Schema = "RCD")]
	public class EntityViewRecuperi
	{
		[Key]
		public Int64? IdRecupero { get; set; }
		public String? Richiedente { get; set; }
		public String? CodiceCliente { get; set; }
		public String? RagioneSociale { get; set; }
		public String? PartitaIVA { get; set; }
		public String? NomeInstallazione { get; set; }
		public Int32? LatitudineGradi { get; set; }
		public Int32? LatitudinePrimi { get; set; }
		public Double? LatitudineSecondi { get; set; }
		public Int32? LongitudineGradi { get; set; }
		public Int32? LongitudinePrimi { get; set; }
		public Double? LongitudineSecondi { get; set; }
		public String? Indirizzo { get; set; }
		public String? Comune { get; set; }
		public String? Provincia { get; set; }
		public String? Regione { get; set; }
		public String? RegioneVF { get; set; }
		public String? Zona { get; set; }
		public String? Office { get; set; }
		public Boolean? ApparatiInviatiMagazzino { get; set; }
		public Double? CostoApparatiRecuperati { get; set; }
		public Double? CostoStimatoRecupero { get; set; }
		public DateTime? DataInvioRichiestaDisinstallazioneVersoDitta { get; set; }
		public DateTime? DataRecuperoConsuntivata { get; set; }
		public DateTime? DataRecuperoStimata { get; set; }
		public DateTime? DataRichiesta { get; set; }
		public DateTime? DataChiusuraAttivitaDitta { get; set; }
		public Boolean? NcLEmessa { get; set; }
		public Boolean? NominaRLInviataDitta { get; set; }
		public String? CognomeRL { get; set; }
		public String? NomeRL { get; set; }
		public Int32? NumeroCompactGsm { get; set; }
		public Int32? NumeroCompactUmts { get; set; }
		public Int32? NumeroMiniGsm { get; set; }
		public Int32? NumeroMiniUmts { get; set; }
		public Boolean? RdAEmessa { get; set; }
		public String? NumeroRda { get; set; }
		public String? StudioProgettazione { get; set; }
		public Int32? TotaleApparatiDaRecuperare { get; set; }
		public Int32? TotaleSimDaRecuperare { get; set; }
		public Boolean? Vincolo { get; set; }
		public String? InseritoDa { get; set; }
		public String? DittaIncaricata { get; set; }
		public String? ProgettistaRan { get; set; }
		public String? ProvenienzaRichiesta { get; set; }
		public String? SiteManagerNI { get; set; }
		public String? NumeroODA { get; set; }
		public String? NumeroNCL { get; set; }
		public DateTime? DataInvio { get; set; }
		public Decimal? PreventivoRDA { get; set; }
		public String? TipologiaCantiere { get; set; }
		public DateTime? DataDismissioneImpianti { get; set; }
		public Int64? IdProvincia { get; set; }
		public Int64? IdRegioneVF { get; set; }
		public Boolean? IsChiuso { get; set; }
		public String? CanaleVendita { get; set; }
		public String? CanaleVenditaDettaglio { get; set; }
		public Boolean? IsManutenzione { get; set; }				

	}
}
