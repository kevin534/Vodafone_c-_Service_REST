﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace RCDEngine.Entities
{
    [Table("VW_TIPOLOGIAAPPARATOPROGRESSIVO", Schema = "RCD")]
    [Keyless]
    public class EntityView_TipologiaApparatoProgressivo
    {
        public Int64? IdZona { get; set; }
        public String? SiglaCodice { get; set; }
        public Int32? Progressivo { get; set; }
    }
}
