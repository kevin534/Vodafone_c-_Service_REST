﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_LOCATION_FEMTO", Schema = "RCD")]
    public class EntityLocationFemTo
    {
        public Int64? Id { get; set; }
        [ForeignKey("Location")]
        public Int64? IdLocation { get; set; }
        public String? SerialVfBooster { get; set; } = String.Empty;
        public String? NumeroFemtoGroupAppartenenza { get; set; } = String.Empty;
        public Boolean? IsOpen { get; set; }
        [ForeignKey("Copertura")]
        public Int64? AmbitoCopertura { get; set; }
        [ForeignKey("TipologiaLan")]
        public Int32? TipoLan { get; set; }
        public String? GestoreLan { get; set; } = String.Empty;
        public Int32? NumeroSimGestite { get; set; }
        public EntityLocation? Location { get; set; }
        public EntityTipologiaLan? TipologiaLan { get; set; }
        public EntityTipologiaCopertura? Copertura { get; set; }
    }
}
