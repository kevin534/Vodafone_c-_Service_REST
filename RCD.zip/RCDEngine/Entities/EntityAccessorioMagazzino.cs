﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;


namespace RCDEngine.Entities
{
    [Table("T_ACCESSORIO_MAGAZZINO", Schema = "RCD")]
    public class EntityAccessorioMagazzino
    {
        public Int64? Id { get; set; }
        [ForeignKey("StatoMateriale")]
        public Int64? IdStatoMateriale { get; set; }
        [ForeignKey("Magazzino")]
        public Int64? IdMagazzino { get; set; }
        [ForeignKey("Accessorio")]
        public Int64? IdAccessorio { get; set; }
        public DateTime? DataArrivo { get; set; }
        public String? OdA { get; set; } = String.Empty;
        [Column("Quantità")]
        public Int32? Quantita { get; set; }
        [Column(TypeName = "ntext")]
        public String? Note { get; set; }

        public EntityStatoMateriale? StatoMateriale { get; set; }
        public EntityMagazzino? Magazzino { get; set; }
        public EntityAccessorio? Accessorio { get; set; }
    }
}
