﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace RCDEngine.Entities
{
    [Table("T_EVENTI", Schema = "RCD")]
    public class EntityEventi
    {
        public Int64? Id { get; set; }
        public String? DescrizioneEvento { get; set; } = String.Empty;
        [ForeignKey("Stato")]
        public Int64? IdStatoCorrelato { get; set; }
        public Boolean? HasSoglia { get; set; }
        public String? ProcedureName { get; set; } = String.Empty;

        public EntityStato? Stato { get; set; }
    }
}