﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace RCDEngine.Entities
{
    [Table("VW_REPORT_COSTI_RICHIESTE", Schema = "RCD")]
    public class EntityViewReportCostiRichieste
    {
        [Key]
        public Int64? IdVista { get; set; }
        public DateTime? DataRichiesta { get; set; }
        public string? ProgettistaRan { get; set; }
        public string? SiteManagerNi { get; set; }
        public string? RiferimentoDce { get; set; }
        public string? RiferimentoAm { get; set; }
        public string? RiferimentoVendite { get; set; }
        public string? InseritoDa { get; set; }
        public string? RagioneSociale { get; set; }
        public string? CodiceCliente { get; set; }
        public string? PartitaIva { get; set; }
        public string? Richiedente { get; set; }
        public Double? FatturatoMedioBimestrale { get; set; }
        public  Int32? NumeroSim { get; set; }
        public Int32? NumeroInterniVruc { get; set; }
        public string? DittaSopralluogo { get; set; }
        public DateTime? DataSopralluogoConsuntivata { get; set; }
        public string? CodiceInstallazione { get; set; }
        public Double? SpesaStimata { get; set; }
        public string? DittaInstallazione { get; set; }
        public DateTime? DataInstallazione { get; set; }
        public Double? CostoConsuntivato { get; set; }
        public Double? DeltaCostoStimatoConsuntivato { get; set; }
        public string? CanaleVenditaDettaglio { get; set; }
        public string? Zona { get; set; }
        public string? NomeInstallazione { get; set; }
        public string? LastStatus { get; set; }
        public Int64? IdUltimoStato { get; set; }
    }
}


