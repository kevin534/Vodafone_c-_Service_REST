﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_DOCUMENTAZIONE_SOPRALLUOGO", Schema = "RCD")]
    public class EntityDocumentazioneSopralluogo
    {
        public Int64? Id { get; set; }
        [ForeignKey("Sopralluogo")]
        public Int64? IdSopralluogo { get; set; }
        public String? Nome { get; set; } = String.Empty;
        public String? Filename { get; set; } = String.Empty;
        public String? PortalFilename { get; set; } = String.Empty;
        public Int32? Version { get; set; }
        public DateTime DataInserimento { get; set; }
        public Boolean? Active { get; set; }
        public EntitySopralluogo? Sopralluogo { get; set; }
    }
}
