﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace RCDEngine.Entities
{
    [Table("T_CONSEGNA_LETTERE", Schema = "RCD")]
    public class EntityConsegnaLettere
    {
        public Int64? Id { get; set; }
        public String? Descrizione { get; set; } = String.Empty;
    }
}
