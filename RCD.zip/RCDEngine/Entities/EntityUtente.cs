﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_UTENTE", Schema = "RCD")]
    public class EntityUtente
    {
        public Int64? Id { get; set; }
        [ForeignKey("Zona")]
        public Int64? IdZona { get; set; }
        [ForeignKey("CanaleVendita")]
        public Int64? IdCanaleVendita { get; set; }
        [ForeignKey("CanaleVenditaDettaglio")]
        public Int64? IdCanaleVenditaDettaglio { get; set; }
        [ForeignKey("AreaVendita")]
        public Int64? IdAreaVendita { get; set; }
        [ForeignKey("Ruolo")]
        public Int64? IdRuolo { get; set; }
        [ForeignKey("TipologiaUtente")]
        public Int64? IdTipologiaUtente { get; set; }
        public String? Username { get; set; } = String.Empty;
        public String? Cognome { get; set; } = String.Empty;
        public String? Nome { get; set; } = String.Empty;
        [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public String? FullName { get; set; } = String.Empty;
        public String? Telefono { get; set; } = String.Empty;
        public String? Mail { get; set; } = String.Empty;
        public String? Note { get; set; } = String.Empty;
        public Boolean? Abilitato { get; set; }

        public EntityZona? Zona { get; set; }
        public EntityCanaleVendita? CanaleVendita { get; set; }
        public EntityCanaleVenditaDettaglio? CanaleVenditaDettaglio { get; set; }
        public EntityAreaVendite? AreaVendita { get; set; }
        public EntityRuolo? Ruolo { get; set; }
        public EntityTipologiaUtente? TipologiaUtente { get; set; }

       //[NotMapped]
       public List<EntityUtentiProvince>? ListUtenteProvincia { get; set; }
    }
}
