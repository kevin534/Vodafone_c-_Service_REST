﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Entities
{
    [Table("T_GOVERNANCE", Schema = "RCD")]
    public class EntityGovernance
    {
		public Int64? Id { get; set; }
		[ForeignKey("CanaleVenditaDettaglio")]
		public Int64? IdCanaleCommerciale { get; set; }
		[ForeignKey("TipologiaAutorizzazione")]
		public Int64? IdTipologiaAutorizzazioneApplicata { get; set; }
		public Int32? NumeroSimVoce { get; set; }
		public Int32? NumeroInterniVruc { get; set; }
		public Double? FatturatoBimestrale { get; set; }
		public Double? CostoSopralluogo { get; set; }

		public EntityTipologiaAutorizzazione? TipologiaAutorizzazione { get; set; }
		public EntityCanaleVenditaDettaglio? CanaleVenditaDettaglio { get; set; }

	}
}
