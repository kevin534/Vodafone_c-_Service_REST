﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Utilities
{
    public class Utility
    {
        public static object Deserialize(byte[] buffer)
        {
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = new MemoryStream(buffer);
            return formatter.Deserialize(stream);
        }
    }
}
