﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace RCDEngine.Utilities
{
    [DataContract]
    public class BaseException
    {
        public BaseException()
        { }

        public BaseException(Exception ex)
        {
            Message = ex.Message == null ? "" : ex.Message;
            Stack = ex.StackTrace == null ? "" : ex.StackTrace;
            HelpLink = ex.HelpLink == null ? "" : ex.HelpLink;
            Source = ex.Source == null ? "" : ex.Source;
            InnerException = ex.InnerException == null ? null : new BaseException(ex.InnerException);
        }

        [DataMember]
        public string Message { get; set; }
        [DataMember]
        public string Stack { get; set; }
        [DataMember]
        public string HelpLink { get; set; }
        [DataMember]
        public string Source { get; set; }
        [DataMember]
        public BaseException InnerException { get; set; }

    }
}
