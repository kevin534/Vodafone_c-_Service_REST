﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCDEngine.Utilities
{
    public class Logger
    {
        public static void Log(Exception ex, bool trackLogException, params object[] data)
        {
            //Errore err = new Errore();
            //err.TrackException<Exception>(ex, trackLogException, data);
        }
    }
}
