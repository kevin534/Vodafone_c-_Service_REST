﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Mail;
using System.Net;
using System.Configuration;
using System.ComponentModel;

namespace RCDEngine.Utilities
{
    /// <summary>
    /// Classe che gestisce l'invio delle emails.
    /// </summary>
    internal class Mail
    {
        //private const string STRING_EMPTY = "---";
        //private static bool _IsMailEnabled = Convert.ToBoolean(ConfigurationManager.AppSettings.Get("MailEnabled"));

        ///// <summary>
        ///// Invia la mail di avviso di trasizione di stato per una richiesta
        ///// </summary>
        ///// <param name="r">Richiesta che fà scattare l'evento</param>
        ///// <returns>True se la mail è stata inviata, false se c'è stato un problema</returns>
        //public static bool SendFirstMail(Richiesta r)
        //{
        //    List<String> mailTo;
        //    String subject;
        //    String body;
        //    string codiciApparati;
        //    string numeroApparatiFemto = string.Empty;
        //    string numeroApparatiRepeater = string.Empty;
        //    double costoPreventivo;
        //    RCDEngine.Mail email;
        //    string noteDM;
        //    RCDEntities ctx = new RCDEntities();
        //    if (!_IsMailEnabled) return false;



        //    mailTo = getAddresses(r);
        //    if (mailTo.Count > 0)
        //    {
        //        //  RCDEntities ctx = new RCDEntities();
        //        ctx.ContextOptions.LazyLoadingEnabled = true;
        //        Richiesta richiesta = (from richi in ctx.Richieste
        //                               .Include("Location").Include("Location.ComuneSts").Include("Location.ComuneSts.ProvinciaSts").Include("Location.ComuneSts.ProvinciaSts.RegioneSts").Include("Location.ComuneSts.ProvinciaSts.Provincia").Include("Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF")
        //                               .Include("Installazione").Include("Richiedente").Include("StatiRichiesta")
        //                               where richi.Id == r.Id
        //                               select richi).FirstOrDefault<Richiesta>();


        //        Dictionary<string, object> e = new Dictionary<string, object>();
        //        IEnumerable<StatoRichiesta> sr = richiesta.StatiRichiesta.OrderByDescending(s => s.InsertDate).Take(2);
        //        StatoRichiesta actualStatus = sr.FirstOrDefault();
        //        StatoRichiesta previousStatus = sr.Count<StatoRichiesta>() > 1 ? sr.ElementAt(1) : null;
        //        // Qui fare query che discerne quale template usare.

        //        if (actualStatus.IdStato == 7 || actualStatus.IdStato == 8)  // Req. n.10 
        //        {
        //            email = (from m in ctx.Mails
        //                     where m.Id == 11
        //                     select m).FirstOrDefault<RCDEngine.Mail>();

        //            Sopralluogo sopr = ctx.Sopralluoghi.Where(s => s.Id == r.IdSopralluogo).FirstOrDefault();
        //            costoPreventivo = sopr.StimaIntervento.HasValue ? sopr.StimaIntervento.Value : 0;

        //            noteDM = sopr.DescrizioneSopralluogo;

        //            e.Add("<#COSTO_TOTALE_PREVENTIVO>", costoPreventivo);
        //            int wTotaleApparati = sopr.TotaleApparatiNuovi + sopr.TotaleApparatiRiuso;
        //            e.Add("<#NUMERO_REPEATERS>", (wTotaleApparati - sopr.NumeroApparatiFemto).ToString());
        //            e.Add("<#NUMERO_BOOSTER>", sopr.NumeroApparatiFemto.ToString());
        //            e.Add("<#NOTE_DM>", noteDM);

        //        }
        //        else
        //        {
        //            email = (from m in ctx.Mails
        //                     where m.IsForStateChange == true
        //                     select m).FirstOrDefault<RCDEngine.Mail>();
        //        }

        //        subject = email.Subject;
        //        body = email.Body;



        //        codiciApparati = string.Join(", ", (from ist in ctx.InstallazioniCrowdcell
        //                                            where ist.IdInstallazione == richiesta.IdInstallazione && (ist.TargaTecnica != null && ist.TargaTecnica.Trim() != string.Empty)
        //                                            select ist).Select(sa => sa.TargaTecnica));

        //        if (string.IsNullOrWhiteSpace(codiciApparati))
        //            codiciApparati = string.Join(", ", (from ist in ctx.SopralluoghiCrowdcell
        //                                                where ist.IdSopralluogo == richiesta.IdSopralluogo && (ist.TargaTecnica != null && ist.TargaTecnica.Trim() != string.Empty)
        //                                                select ist).Select(sa => sa.TargaTecnica));

        //        if (string.IsNullOrWhiteSpace(codiciApparati))
        //            codiciApparati = string.Join(", ", (from ist in ctx.SopralluoghiApparati
        //                                                where ist.IdSopralluogo == richiesta.IdSopralluogo && (ist.Codice != null && ist.Codice.Trim() != string.Empty)
        //                                                select ist).Select(sa => sa.Codice));


        //        if (!string.IsNullOrWhiteSpace(richiesta.Location.NomeInstallazione))
        //            subject = string.Format("{0} : {1}. ", subject, richiesta.Location.NomeInstallazione);


        //        if (!string.IsNullOrWhiteSpace(codiciApparati))
        //            subject = string.Format("{0} Codice Apparati: {1}. ", subject, codiciApparati);

        //        e.Add("<#CODICE_REPEATER>", codiciApparati);
        //        e.Add("<#NOME_INSTALLAZIONE>", richiesta.Location.NomeInstallazione);
        //        e.Add("<#RAGIONE_SOCIALE_CLIENTE>", richiesta.Richiedente.RagioneSociale);
        //        e.Add("<#CODICE_CLIENTE>", richiesta.Richiedente.CodiceCliente);
        //        e.Add("<#PARTITA_IVA>", richiesta.Richiedente.PartitaIVA);
        //        e.Add("<#INDIRIZZO_CLIENTE>", richiesta.Location.Indirizzo + " - " + richiesta.Location.CAP + " " + richiesta.Location.ComuneSts.Descrizione);
        //        e.Add("<#PROVINCIA>", richiesta.Location.ComuneSts.ProvinciaSts.Sigla);
        //        //ReferenteLocale
        //        e.Add("<#NOME_RIFERIMENTO>", string.IsNullOrWhiteSpace(richiesta.Location.FullNameReferenteLocale) ? richiesta.Richiedente.RiferimentoFullName : richiesta.Location.FullNameReferenteLocale + " (loc)");
        //        e.Add("<#TELEFONO_RIFERIMENTO>", string.IsNullOrWhiteSpace(richiesta.Location.TelefonoReferenteLocale) ? richiesta.Richiedente.TelefonoRiferimento : richiesta.Location.TelefonoReferenteLocale + " (loc)");
        //        e.Add("<#NUOVO_STATO>", actualStatus.Stato.DescrizioneStato);
        //        e.Add("<#VECCHIO_STATO>", previousStatus.Stato.DescrizioneStato);
        //        e.Add("<#REGIONE_VF>", richiesta.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Region);
        //        e.Add("<#UTENTE_PASSAGGIO_DI_STATO>", actualStatus.Utente.FullName);

        //        Replace(ref body, e);
        //        return SendMail(mailTo, subject, body);
        //    }
        //    return true;
        //}

        ///// <summary>
        ///// Provvede all'invio di una mail quando si completa un recupero / manutenzione.
        ///// </summary>
        ///// <param name="recupero"></param>
        ///// <returns></returns>
        //public static bool SendMailChiusuraRecuperiManutenzioni(Recupero recupero)
        //{
        //    if (!_IsMailEnabled) return false;
        //    RCDEntities ctx = new RCDEntities();
        //    ctx.ContextOptions.LazyLoadingEnabled = true;
        //    List<string> mailTo = new List<string>();

        //    Dictionary<string, object> e = new Dictionary<string, object>();
        //    string subject;
        //    string body;
        //    bool isManutenzione;
        //    string codiciApparati;



        //    isManutenzione = recupero.IsManutenzione;

        //    Location location = (from l in ctx.Locations.Include("ComuneSts").Include("ComuneSts.ProvinciaSts")
        //                          .Include("ComuneSts.ProvinciaSts.RegioneSts").Include("ComuneSts.ProvinciaSts.Provincia")
        //                          .Include("ComuneSts.ProvinciaSts.Provincia.RegioneVF")
        //                          .Include("Richiedente")
        //                         where recupero.IdLocation == l.Id
        //                         select l).FirstOrDefault<Location>();

        //    var utenti = from u in ctx.Utenti.Include("Zona")
        //                 where (recupero.IdProgettistaRan.HasValue && u.Id == recupero.IdProgettistaRan.Value) ||
        //                 (recupero.IdSiteManagerNI.HasValue && u.Id == recupero.IdSiteManagerNI.Value) ||
        //                 (u.Id == recupero.IdUserInsert) ||
        //                 (u.TipologiaUtente.DescrizioneTipologiaUtente == "DM" && u.Zona.Id == location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Zona.Id)
        //                 select u;

        //    foreach (Utente u in utenti.Where(ut => ut.Abilitato))
        //        if (!mailTo.Contains(u.Mail))
        //            mailTo.Add(u.Mail);


        //    RCDEngine.Mail email = (from m in ctx.Mails
        //                            where m.Id == 10
        //                            select m).FirstOrDefault<RCDEngine.Mail>();

        //    codiciApparati = string.Join(", ", (from ist in ctx.LocationsApparati
        //                                        where ist.IdLocation == location.Id && (ist.Codice != null && ist.Codice.Trim() != string.Empty
        //                                        ) && ist.Recuperato == true && ist.InRecupero == true
        //                                        select ist).Select(sa => sa.Codice));


        //    subject = email.Subject;

        //    if (!string.IsNullOrWhiteSpace(location.NomeInstallazione))
        //        subject = subject + " : " + location.NomeInstallazione;


        //    if (!string.IsNullOrWhiteSpace(codiciApparati))
        //        subject = subject + ". Codice Apparati: " + codiciApparati;

        //    if (isManutenzione)
        //        subject = subject.Replace("Recupero", "Manutenzione");

        //    body = email.Body;
        //    {
        //        e.Add("<#IS_MANUTENZIONE>", isManutenzione ? "Manutenzione" : "Recupero");
        //        e.Add("<#CODICE_REPEATER>", codiciApparati);
        //        e.Add("<#NOME_INSTALLAZIONE>", location.NomeInstallazione);
        //        e.Add("<#RAGIONE_SOCIALE_CLIENTE>", location.Richiedente.RagioneSociale);
        //        e.Add("<#CODICE_CLIENTE>", location.Richiedente.CodiceCliente);
        //        e.Add("<#INDIRIZZO_CLIENTE>", location.Indirizzo + "-" + location.CAP + " " + location.ComuneSts.Descrizione);
        //        e.Add("<#PROVINCIA>", location.ComuneSts.ProvinciaSts.Sigla);
        //        e.Add("<#NOME_RIFERIMENTO>", string.IsNullOrWhiteSpace(location.FullNameReferenteLocale) ? location.Richiedente.RiferimentoFullName : location.FullNameReferenteLocale + " (loc)");
        //        e.Add("<#TELEFONO_RIFERIMENTO>", string.IsNullOrWhiteSpace(location.TelefonoReferenteLocale) ? location.Richiedente.TelefonoRiferimento : location.TelefonoReferenteLocale + " (loc)");
        //        e.Add("<#NOTE>", location.Note);
        //        e.Add("<#REGIONE_VF>", location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Region);
        //    }

        //    Replace(ref body, e);

        //    return SendMail(mailTo, subject, body);

        //}

        ///// <summary>
        ///// Costruisce la mailing-list in base alle impostazioni dell'evento 
        ///// </summary>
        ///// <param name="r">Richiesta che ha fatto scattare l'evento</param>
        ///// <returns>Lista di indirizzi</returns>
        //private static List<string> getAddresses(Richiesta rr)
        //{
        //    RCDEntities ctx = new RCDEntities();
        //    ctx.ContextOptions.LazyLoadingEnabled = true;
        //    Richiesta r = (from ric in ctx.Richieste
        //                   where ric.Id == rr.Id
        //                   select ric).FirstOrDefault<Richiesta>();
        //    List<string> returnValue = new List<string>();
        //    Stato actualState = (from s in ctx.StatiRichiesta
        //                             .Include("Stato")
        //                             .Include("Stato.Eventi")
        //                             .Include("Stato.Eventi.EventiZona")
        //                             .Include("Stato.Eventi.EventiZona.Zona")
        //                         where s.IdRichiesta == r.Id
        //                         orderby s.InsertDate descending
        //                         select s).FirstOrDefault<StatoRichiesta>().Stato;
        //    Evento ev = actualState.Eventi.FirstOrDefault<Evento>();
        //    Richiesta Rc = (from ric in ctx.Richieste
        //                    .Include("Location").Include("Location.ComuneSts").Include("Location.ComuneSts.ProvinciaSts")
        //                    .Include("Location.ComuneSts.ProvinciaSts.RegioneSts")
        //                    .Include("Location.ComuneSts.ProvinciaSts.Provincia")
        //                    .Include("Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF")
        //                    .Include("Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Zona")
        //                        //.Include("Location.ComuneSts.ProvinciaSts.UtentiProvincia")          5 10 2011 è vuota
        //                    .Include("Sopralluogo").Include("Sopralluogo.Ditta")
        //                    .Include("Utente").Include("RiferimentoVendite").Include("RiferimentoAreaManager")
        //                    .Include("RiferimentoDce")
        //                    where ric.Id == r.Id
        //                    select ric).FirstOrDefault<Richiesta>();
        //    EventiZona ez = ev.EventiZona.Where(e => e.Zona.Id == Rc.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Zona.Id).FirstOrDefault<EventiZona>();
        //    if (ez != null)
        //    {
        //        if (ez.SendVenditore)
        //            returnValue.Add(Rc.Utente.Mail);
        //        if (ez.SendRiferimentoKAM && Rc.Utente.Mail != Rc.RiferimentoVendite.Mail)
        //            returnValue.Add(Rc.RiferimentoVendite.Mail);
        //        if (ez.SendRiferimentoAM && ev.checkCostraint(r))
        //            returnValue.Add(Rc.RiferimentoAreaManager.Mail);
        //        if (ez.SendRiferimentoDCE && ev.checkCostraint(r))
        //            returnValue.Add(Rc.RiferimentoDce.Mail);

        //        if (ez.SendCI)
        //        {
        //            var uteCI = from u in ctx.Utenti
        //                        where u.TipologiaUtente.DescrizioneTipologiaUtente == "CI" && u.Zona.Id == Rc.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.IdZona
        //                        && u.Abilitato == true && u.Username != "zzgd293"
        //                        select u;
        //            foreach (var u in uteCI)
        //                returnValue.Add(u.Mail);
        //        }
        //        if (ez.SendNI)
        //        {
        //            var uteNI = from u in ctx.Utenti
        //                        where u.TipologiaUtente.DescrizioneTipologiaUtente == "NI" && u.Zona.Id == Rc.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.IdZona
        //                        && u.Abilitato == true && u.Username != "zzgd293"
        //                        select u;
        //            foreach (var u in uteNI)
        //                returnValue.Add(u.Mail);
        //        }
        //        if (ez.SendNSO)
        //        {
        //            var uteNSO = from u in ctx.Utenti
        //                         where u.TipologiaUtente.DescrizioneTipologiaUtente == "NSO" && u.Zona.Id == Rc.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.IdZona
        //                         && u.Abilitato == true && u.Username != "zzgd293"
        //                         select u;
        //            foreach (var u in uteNSO)
        //                returnValue.Add(u.Mail);
        //        }
        //        if (ez.SendRAN)
        //        {
        //            var uteRAN = from u in ctx.Utenti
        //                         where u.TipologiaUtente.DescrizioneTipologiaUtente == "RAN" && u.Zona.Id == Rc.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.IdZona
        //                         && u.Abilitato == true && u.Username != "zzgd293"
        //                         select u;
        //            foreach (var u in uteRAN)
        //                returnValue.Add(u.Mail);
        //        }
        //        if (ez.SendTS)
        //        {
        //            var uteTS = from u in ctx.Utenti
        //                        where u.TipologiaUtente.DescrizioneTipologiaUtente == "TS" && u.Zona.Id == Rc.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.IdZona
        //                        && u.Abilitato == true && u.Username != "zzgd293"
        //                        select u;
        //            foreach (var u in uteTS)
        //                returnValue.Add(u.Mail);
        //        }
        //        if (ez.SendDM)
        //        {
        //            var uteDM = from u in ctx.Utenti
        //                        where u.TipologiaUtente.DescrizioneTipologiaUtente == "DM" && u.Zona.Id == Rc.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.IdZona
        //                        && u.Abilitato == true && u.Username != "zzgd293"
        //                        select u;
        //            foreach (var u in uteDM)
        //                returnValue.Add(u.Mail);
        //        }

        //        #region old query: la UtentiProvincia è vuota quindi non trovava i destinatari (5/10/2011)
        //        //if (ez.SendCI)
        //        //{
        //        //    var uteCI = from u in Rc.Location.ComuneSts.ProvinciaSts.UtentiProvincia
        //        //                where u.Utente.TipologiaUtente.DescrizioneTipologiaUtente == "CI"
        //        //                select u;
        //        //    foreach (UtenteProvincia u in uteCI)
        //        //        returnValue.Add(u.Utente.Mail);
        //        //}
        //        //if (ez.SendNI)
        //        //{
        //        //    var uteNI = from u in Rc.Location.ComuneSts.ProvinciaSts.UtentiProvincia
        //        //                where u.Utente.TipologiaUtente.DescrizioneTipologiaUtente == "NI"
        //        //                select u;
        //        //    foreach (UtenteProvincia u in uteNI)
        //        //        returnValue.Add(u.Utente.Mail);
        //        //}
        //        //if (ez.SendNSO)
        //        //{
        //        //    var uteNSO = from u in Rc.Location.ComuneSts.ProvinciaSts.UtentiProvincia
        //        //                 where u.Utente.TipologiaUtente.DescrizioneTipologiaUtente == "NSO"
        //        //                 select u;
        //        //    foreach (UtenteProvincia u in uteNSO)
        //        //        returnValue.Add(u.Utente.Mail);
        //        //}
        //        //if (ez.SendRAN)
        //        //{
        //        //    var uteRAN = from u in Rc.Location.ComuneSts.ProvinciaSts.UtentiProvincia
        //        //                 where u.Utente.TipologiaUtente.DescrizioneTipologiaUtente == "RAN"
        //        //                 select u;
        //        //    foreach (UtenteProvincia u in uteRAN)
        //        //        returnValue.Add(u.Utente.Mail);
        //        //}
        //        //if (ez.SendTS)
        //        //{
        //        //    var uteTS = from u in Rc.Location.ComuneSts.ProvinciaSts.UtentiProvincia
        //        //                where u.Utente.TipologiaUtente.DescrizioneTipologiaUtente == "TS"
        //        //                select u;
        //        //    foreach (UtenteProvincia u in uteTS)
        //        //        returnValue.Add(u.Utente.Mail);
        //        //}
        //        //if (ez.SendDM)
        //        //{
        //        //    var uteDM = from u in Rc.Location.ComuneSts.ProvinciaSts.UtentiProvincia
        //        //                where u.Utente.TipologiaUtente.DescrizioneTipologiaUtente == "DM" && u.Utente.Zona == Rc.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Zona
        //        //                select u;
        //        //    foreach (UtenteProvincia u in uteDM)
        //        //        returnValue.Add(u.Utente.Mail);
        //        //}
        //        #endregion

        //        if (ez.SendDitta)
        //            if (Rc.Installazione != null && Rc.Installazione.Ditta != null)
        //                returnValue.Add(Rc.Installazione.Ditta.MailRiferimento);
        //            else if (Rc.Installazione == null && Rc.Sopralluogo != null && Rc.Sopralluogo.Ditta != null)
        //                returnValue.Add(Rc.Sopralluogo.Ditta.MailRiferimento);
        //    }
        //    return returnValue.Distinct().ToList();
        //}

        ///// <summary>
        ///// Invia la mail in base ai parametri passati
        ///// </summary>
        ///// <param name="addresses">Mailing-list di distribuzione</param>
        ///// <param name="subject">Oggetto della mail</param>
        ///// <param name="body">Corpo della mail</param>
        ///// <returns>True se la mail è stata inviata, false in caso di errore</returns>
        //private static bool SendMail(List<string> addresses, string subject, string body, List<string> mailCc = null)
        //{
        //    MailMessage mail = new MailMessage();
        //    String[] smtpServer = ConfigurationManager.AppSettings.Get("SmtpServer").Split(' ');
        //    String[] froms = ConfigurationManager.AppSettings.Get("MailSenderAndress").Split(' ');

        //    var smtp = (from sm in smtpServer
        //                select new { Domain = smtpServer.FirstOrDefault<string>(), UserName = smtpServer.ElementAtOrDefault<string>(1), Password = smtpServer.ElementAtOrDefault<string>(2) }).FirstOrDefault();
        //    try
        //    {
        //        mail.From = new MailAddress(froms.FirstOrDefault<string>(), string.Join(" ", froms.SkipWhile<string>(e => e == froms.FirstOrDefault())));


        //        foreach (string address in addresses)
        //            mail.To.Add(address);

        //        if (mailCc != null)
        //            foreach (string address in mailCc)
        //                mail.CC.Add(address);

        //        mail.Subject = subject;
        //        //mail.BodyEncoding = Encoding.Unicode;
        //        mail.BodyEncoding = Encoding.UTF8;
        //        mail.IsBodyHtml = true;
        //        mail.Body = body;
        //        mail.Priority = MailPriority.Normal;
        //        SmtpClient client = new SmtpClient(smtp.Domain);
        //        client.Timeout = 1000000;
        //        if (!string.IsNullOrEmpty(smtp.UserName) || !string.IsNullOrEmpty(smtp.Password))
        //            client.Credentials = new NetworkCredential(smtp.UserName, smtp.Password);
        //        client.Send(mail);
        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Log(ex, true, mail, addresses, body, smtpServer);
        //        return false;
        //    }
        //}

        ///// <summary>
        ///// Invia una mail alla ditta incaricata del sopralluogo
        ///// </summary>
        ///// <param name="sopralluogo">Sopralluogo da effettuare</param>
        ///// <returns>True se la mail è stata inviata, false se c'è stato un problema</returns>
        //internal static bool SendMailDittaIncaricataSopralluogo(Sopralluogo sopralluogo)
        //{
        //    if (!_IsMailEnabled) return false;
        //    RCDEntities ctx = new RCDEntities();
        //    ctx.ContextOptions.LazyLoadingEnabled = true;
        //    List<string> mailTo = new List<string>();
        //    List<string> mailCc = new List<string>();
        //    string codiciApparati = string.Empty;
        //    string subject;
        //    string body;

        //    Ditta ditta = (from d in ctx.Ditte
        //                   where d.Id == sopralluogo.IdDittaIncaricata
        //                   select d).FirstOrDefault<Ditta>();

        //    Richiesta richiesta = (from r in ctx.Richieste
        //                           .Include("Location").Include("Location.ComuneSts").Include("Location.ComuneSts.ProvinciaSts")
        //                           .Include("Location.ComuneSts.ProvinciaSts.RegioneSts")
        //                           .Include("Location.ComuneSts.ProvinciaSts.Provincia")
        //                           .Include("Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF")
        //                           .Include("Location.ComuneSts.ProvinciaSts.UtentiProvincia")
        //                           .Include("Installazione").Include("Richiedente")
        //                           .Include("Sopralluogo").Include("Location.TipologiaStabile")
        //                           where r.Sopralluogo.Id == sopralluogo.Id
        //                           select r).FirstOrDefault<Richiesta>();

        //    RCDEngine.Mail email = (from m in ctx.Mails
        //                            where m.Id == 2
        //                            select m).FirstOrDefault<RCDEngine.Mail>();

        //    subject = email.Subject;



        //    if (string.IsNullOrWhiteSpace(codiciApparati))
        //        codiciApparati = string.Join(", ", (from ist in ctx.SopralluoghiApparati
        //                                            where ist.IdSopralluogo == richiesta.IdSopralluogo && (ist.Codice != null && ist.Codice.Trim() != string.Empty)
        //                                            select ist).Select(sa => sa.Codice));


        //    if (!string.IsNullOrWhiteSpace(richiesta.Location.NomeInstallazione))
        //        subject = string.Format("{0} : {1}. ", subject, richiesta.Location.NomeInstallazione);


        //    if (!string.IsNullOrWhiteSpace(codiciApparati))
        //        subject = string.Format("{0} Codice Apparati: {1}. ", subject, codiciApparati);




        //    body = email.Body;
        //    mailTo.Add(ditta.MailRiferimento);


        //    //Aggiungo in Cc i DM,Ran,NI

        //    var utenti = from u in ctx.Utenti.Include("Zona")
        //                 where (richiesta.IdProgettistaRan.HasValue && u.Id == richiesta.IdProgettistaRan.Value) ||
        //                 (richiesta.IdSiteManagerNI.HasValue && u.Id == richiesta.IdSiteManagerNI.Value) ||
        //                 //(u.Id == richiesta.IdUserInsert) ||
        //                 (u.TipologiaUtente.DescrizioneTipologiaUtente == "DM" && u.Username != "zzgd293" && u.Zona.Id == richiesta.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Zona.Id)
        //                 select u;

        //    foreach (Utente u in utenti.Where(ut => ut.Abilitato))
        //        if (!mailTo.Contains(u.Mail))
        //            mailTo.Add(u.Mail);




        //    #region old


        //    //var utenti = from u in ctx.Utenti.Include("Zona").Include("UtenteProvince").Include("UtenteProvince.ProvinciaSts")
        //    //             where (u.TipologiaUtente.DescrizioneTipologiaUtente == "DM" || u.TipologiaUtente.DescrizioneTipologiaUtente == "RAN" || u.TipologiaUtente.DescrizioneTipologiaUtente == "NI" && u.Abilitato == true)
        //    //             select u;

        //    //foreach (Utente u in utenti)
        //    //    if (u.UtenteProvince.Count > 0)
        //    //        foreach (UtenteProvincia p in u.UtenteProvince)
        //    //            if (p.ProvinciaSts.Id == richiesta.Location.ComuneSts.ProvinciaSts.Id)
        //    //            {
        //    //                mailCc.Add(p.Utente.Mail);
        //    //                break;
        //    //            }


        //    //var utZona = from u in utenti
        //    //             where u.Zona.Id == richiesta.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Zona.Id
        //    //             select u;

        //    //var users = from u in richiesta.Location.ComuneSts.ProvinciaSts.UtentiProvincia
        //    //            where u.Utente.TipologiaUtente.DescrizioneTipologiaUtente == "DM" ||
        //    //            u.Utente.TipologiaUtente.DescrizioneTipologiaUtente == "RAN" ||
        //    //              u.Utente.TipologiaUtente.DescrizioneTipologiaUtente == "NI"
        //    //            select u;


        //    //return from u in utenti
        //    //       where u.UtenteProvince.ProvinciaSts.Contains(richiesta.Location.ComuneSts.ProvinciaSts) || u.Zona == richiesta.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Zona
        //    //       select u;



        //    //var utProv = from u in utenti
        //    //             select u.UtenteProvince.Where(c => c.ProvinciaSts.Id == richiesta.Location.ComuneSts.ProvinciaSts.Id).FirstOrDefault().Utente;//.Select(ut => ut.Utente);


        //    //var utProv = from u in utenti
        //    //             where u.UtenteProvince.Count > 0
        //    //             select (from z in u.UtenteProvince
        //    //                     where z.ProvinciaSts.Id == richiesta.Location.ComuneSts.ProvinciaSts.Id 
        //    //                     select z.Utente
        //    //                          ).FirstOrDefault();



        //    ////var utProv = from u in utenti
        //    ////             where u.UtenteProvince.Count > 0
        //    ////           select u.UtenteProvince;

        //    ////var prova = from z in utProv
        //    ////                     where z.ProvinciaSts.Id == richiesta.Location.ComuneSts.ProvinciaSts.Id 
        //    ////                     select z.Utente


        //    //      u.UtenteProvince.Where(c => c.ProvinciaSts.Id == richiesta.Location.ComuneSts.ProvinciaSts.Id).FirstOrDefault().Utente;//.Select(ut => ut.Utente);







        //    //var users = utZona.Union(utProv).Distinct();

        //    //var users = from u in utenti
        //    //            where u.Utente.TipologiaUtente.DescrizioneTipologiaUtente == "DM" ||
        //    //            u.Utente.TipologiaUtente.DescrizioneTipologiaUtente == "RAN" ||
        //    //              u.Utente.TipologiaUtente.DescrizioneTipologiaUtente == "NI"
        //    //            select u;

        //    //var usr = from u in users
        //    //          where u.Utente.Zona.Id == richiesta.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Zona.Id
        //    //          select u;

        //    //foreach (UtenteProvincia u in users)
        //    //    mailCc.Add(u.Utente.Mail);




        //    //var utenti = from u in ctx.Utenti.Include("Zona").Include("UtenteProvince").Include("UtenteProvince.ProvinciaSts")
        //    //where (u.TipologiaUtente.DescrizioneTipologiaUtente == "DM" || u.TipologiaUtente.DescrizioneTipologiaUtente == "RAN" || u.TipologiaUtente.DescrizioneTipologiaUtente == "NI" && u.Abilitato == true )
        //    //select u;

        //    //var usr = from u in utenti
        //    //          where u.Zona.Id == richiesta.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Zona.Id                 
        //    //          select u;

        //    //var usr2 = (utenti.Select( u => u.UtenteProvince.Where(c => c.ProvinciaSts == richiesta.Location.ComuneSts.ProvinciaSts)));
        //    ////.UtenteProvince.Where(c => c.ProvinciaSts.Id == richiesta.Location.ComuneSts.ProvinciaSts.Id);
        //    //// var usr = utenti.UtenteProvince.Where(c => c.ProvinciaSts == richiesta.Location.ComuneSts.ProvinciaSts);

        //    //foreach (UtenteProvincia u in usr2)
        //    //    mailCc.Add(u.Utente.Mail);


        //    //foreach (UtenteProvincia u in users)
        //    //    mailCc.Add(u.Utente.Mail);

        //    //mailTo.AddRange(getAddresses(richiesta));
        //    #endregion   old
        //    Dictionary<string, object> e = new Dictionary<string, object>();

        //    e.Add("<#CODICE_INSTALLAZIONE>", richiesta.Sopralluogo.CodiceInstallazione);
        //    e.Add("<#NOME_CLIENTE>", richiesta.Richiedente.RagioneSociale);
        //    e.Add("<#CODICE_CLIENTE>", richiesta.Richiedente.CodiceCliente);
        //    e.Add("<#NOME_RIFERIMENTO>", string.IsNullOrWhiteSpace(richiesta.Location.FullNameReferenteLocale) ? richiesta.Richiedente.RiferimentoFullName : richiesta.Location.FullNameReferenteLocale + " (loc)");
        //    e.Add("<#TELEFONO_RIFERIMENTO>", string.IsNullOrWhiteSpace(richiesta.Location.TelefonoReferenteLocale) ? richiesta.Richiedente.TelefonoRiferimento : richiesta.Location.TelefonoReferenteLocale + " (loc)");
        //    e.Add("<#INDIRIZZO_CLIENTE>", richiesta.Location.Indirizzo + "-" + richiesta.Location.CAP + " " + richiesta.Location.ComuneSts.Descrizione);
        //    e.Add("<#PROVINCIA>", richiesta.Location.ComuneSts.ProvinciaSts.Sigla);
        //    e.Add("<#SISTEMA_RICHIESTA>", richiesta.SistemaRichiesto.Sistema);
        //    e.Add("<#TIPOLOGIA_STABILE>", richiesta.Location.TipologiaStabile != null ? richiesta.Location.TipologiaStabile.DescrizioneTipologiaStabile : null);
        //    if (!string.IsNullOrEmpty(richiesta.Sopralluogo.NoteRANVO))
        //    {
        //        e.Add("<#NOTE>", richiesta.Location.Note + "\nNote RAN VO: \n" + richiesta.Sopralluogo.NoteRANVO);
        //    }
        //    else
        //    {
        //        e.Add("<#NOTE>", richiesta.Location.Note);
        //    }
        //    e.Add("<#REGIONE_VF>", richiesta.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Region);


        //    Replace(ref body, e);

        //    return SendMail(mailTo, subject, body, mailCc);
        //}

        ///// <summary>
        ///// Invia una mail alla ditta incaricata dell'installazione
        ///// </summary>
        ///// <param name="installazione">Installazione da effettuare</param>
        ///// <returns>True se la mail è stata inviata, false se c'è stato un problema</returns>
        //internal static bool SendMailDittaIncaricataInstallazione(Installazione installazione)
        //{
        //    if (!_IsMailEnabled) return false;
        //    RCDEntities ctx = new RCDEntities();
        //    ctx.ContextOptions.LazyLoadingEnabled = true;
        //    List<string> mailTo = new List<string>();
        //    List<string> mailCc = new List<string>();
        //    string subject;
        //    string codiciApparati;
        //    string body;

        //    Ditta ditta = (from d in ctx.Ditte
        //                   where d.Id == installazione.IdDittaInstallazione
        //                   select d).FirstOrDefault<Ditta>();

        //    Richiesta richiesta = (from r in ctx.Richieste
        //                           .Include("Location").Include("Location.ComuneSts").Include("Location.ComuneSts.ProvinciaSts")
        //                           .Include("Location.ComuneSts.ProvinciaSts.RegioneSts")
        //                           .Include("Location.ComuneSts.ProvinciaSts.Provincia")
        //                           .Include("Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF")
        //                           .Include("Installazione").Include("Richiedente")
        //                           .Include("Utente").Include("RiferimentoVendite").Include("RiferimentoAreaManager")
        //                           .Include("RiferimentoDce")
        //                           where r.Installazione.Id == installazione.Id
        //                           select r).FirstOrDefault<Richiesta>();

        //    RCDEngine.Mail email = (from m in ctx.Mails
        //                            where m.Id == 3
        //                            select m).FirstOrDefault<RCDEngine.Mail>();

        //    subject = email.Subject;

        //    codiciApparati = string.Join(", ", (from ist in ctx.InstallazioniApparati
        //                                        where ist.IdInstallazione == richiesta.IdInstallazione && (ist.Codice != null && ist.Codice.Trim() != string.Empty)
        //                                        select ist).Select(sa => sa.Codice));

        //    if (string.IsNullOrWhiteSpace(codiciApparati))
        //        codiciApparati = string.Join(", ", (from ist in ctx.SopralluoghiApparati
        //                                            where ist.IdSopralluogo == richiesta.IdSopralluogo && (ist.Codice != null && ist.Codice.Trim() != string.Empty)
        //                                            select ist).Select(sa => sa.Codice));


        //    if (!string.IsNullOrWhiteSpace(richiesta.Location.NomeInstallazione))
        //        subject = string.Format("{0} : {1}. ", subject, richiesta.Location.NomeInstallazione);


        //    if (!string.IsNullOrWhiteSpace(codiciApparati))
        //        subject = string.Format("{0} Codice Apparati: {1}. ", subject, codiciApparati);

        //    body = email.Body;

        //    //Aggiungo in Cc i DM,Ran,NI



        //    var utenti = from u in ctx.Utenti.Include("Zona")
        //                 where (richiesta.IdProgettistaRan.HasValue && u.Id == richiesta.IdProgettistaRan.Value) ||
        //                 (richiesta.IdSiteManagerNI.HasValue && u.Id == richiesta.IdSiteManagerNI.Value) ||
        //                 //(u.Id == richiesta.IdUserInsert) ||
        //                 (u.TipologiaUtente.DescrizioneTipologiaUtente == "DM" && u.Username != "zzgd293" && u.Zona.Id == richiesta.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Zona.Id)
        //                 select u;

        //    foreach (Utente u in utenti.Where(ut => ut.Abilitato))
        //        if (!mailCc.Contains(u.Mail))
        //            mailCc.Add(u.Mail);



        //    #region Old
        //    //var utenti = from u in ctx.Utenti.Include("Zona").Include("UtenteProvince").Include("UtenteProvince.ProvinciaSts")
        //    //             where (u.TipologiaUtente.DescrizioneTipologiaUtente == "DM" || u.TipologiaUtente.DescrizioneTipologiaUtente == "RAN" || u.TipologiaUtente.DescrizioneTipologiaUtente == "NI" && u.Abilitato == true)
        //    //             select u;


        //    //foreach (Utente u in utenti)
        //    //    if (u.UtenteProvince.Count > 0)
        //    //        foreach (UtenteProvincia p in u.UtenteProvince)
        //    //            if (p.ProvinciaSts.Id == richiesta.Location.ComuneSts.ProvinciaSts.Id)
        //    //            {
        //    //                mailCc.Add(p.Utente.Mail);
        //    //                break;
        //    //            }


        //    //var utZona = from u in utenti
        //    //             where u.Zona.Id == richiesta.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Zona.Id
        //    //             select u;

        //    //foreach (Utente u in utZona)
        //    //    if (!mailCc.Contains(u.Mail))
        //    //        mailCc.Add(u.Mail);

        //    #endregion

        //    Dictionary<string, object> e = new Dictionary<string, object>();


        //    e.Add("<#CODICE_INSTALLAZIONE>", richiesta.Sopralluogo.CodiceInstallazione);
        //    e.Add("<#NOME_CLIENTE>", richiesta.Richiedente.RagioneSociale);
        //    e.Add("<#CODICE_CLIENTE>", richiesta.Richiedente.CodiceCliente);
        //    e.Add("<#INDIRIZZO_CLIENTE>", richiesta.Location.Indirizzo + "-" + richiesta.Location.CAP + " " + richiesta.Location.ComuneSts.Descrizione);
        //    e.Add("<#PROVINCIA>", richiesta.Location.ComuneSts.ProvinciaSts.Sigla);
        //    e.Add("<#NOTE>", richiesta.Installazione.NoteInstallazione);
        //    e.Add("<#REGIONE_VF>", richiesta.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Region);

        //    Replace(ref body, e);

        //    mailTo.Add(ditta.MailRiferimento);
        //    return SendMail(mailTo, subject, body, mailCc);

        //}

        ///// <summary>
        ///// Invia una mail alla ditta incaricata del recupero
        ///// </summary>
        ///// <param name="recupero">Recupero da effettuare</param>
        ///// <returns>True se la mail è stata inviata, false se c'è stato un problema</returns>
        //internal static bool SendMailDittaIncaricataRecupero(Recupero recupero)
        //{
        //    if (!_IsMailEnabled) return false;
        //    RCDEntities ctx = new RCDEntities();
        //    ctx.ContextOptions.LazyLoadingEnabled = true;
        //    List<string> mailTo = new List<string>();
        //    List<string> mailCc = new List<string>();
        //    Dictionary<string, object> e = new Dictionary<string, object>();
        //    string subject;
        //    string body;
        //    bool isManutenzione;
        //    string codiciApparati;

        //    Ditta ditta = (from d in ctx.Ditte
        //                   where d.Id == recupero.IdDittaInstallazione
        //                   select d).FirstOrDefault<Ditta>();

        //    isManutenzione = recupero.IsManutenzione;

        //    Location location = (from l in ctx.Locations.Include("ComuneSts").Include("ComuneSts.ProvinciaSts")
        //                          .Include("ComuneSts.ProvinciaSts.RegioneSts").Include("ComuneSts.ProvinciaSts.Provincia")
        //                          .Include("ComuneSts.ProvinciaSts.Provincia.RegioneVF")
        //                          .Include("Richiedente")
        //                         where recupero.IdLocation == l.Id
        //                         select l).FirstOrDefault<Location>();

        //    var utenti = from u in ctx.Utenti.Include("Zona")
        //                 where (recupero.IdProgettistaRan.HasValue && u.Id == recupero.IdProgettistaRan.Value) ||
        //                 (recupero.IdSiteManagerNI.HasValue && u.Id == recupero.IdSiteManagerNI.Value) ||
        //                 //(u.Id == recupero.IdUserInsert) ||
        //                 (u.TipologiaUtente.DescrizioneTipologiaUtente == "DM" && u.Username != "zzgd293" && u.Zona.Id == location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Zona.Id)
        //                 select u;

        //    foreach (Utente u in utenti.Where(ut => ut.Abilitato))
        //        if (!mailCc.Contains(u.Mail))
        //            mailCc.Add(u.Mail);


        //    RCDEngine.Mail email = (from m in ctx.Mails
        //                            where m.Id == (isManutenzione ? 8 : 4)
        //                            select m).FirstOrDefault<RCDEngine.Mail>();

        //    codiciApparati = string.Join(", ", (from ist in ctx.LocationsApparati
        //                                        where ist.IdLocation == location.Id && (ist.Codice != null && ist.Codice.Trim() != string.Empty)
        //                                        && ist.Recuperato == false && ist.InRecupero == true
        //                                        select ist).Select(sa => sa.Codice));


        //    //var codiciApparati2 = from ist in ctx.LocationsApparati
        //    //                      where ist.IdLocation == location.Id && (ist.Codice != null && ist.Codice.Trim() != string.Empty)
        //    //                      //  && ist.Recuperato == true && ist.InRecupero == true
        //    //                      select ist;

        //    subject = email.Subject;

        //    if (!string.IsNullOrWhiteSpace(location.NomeInstallazione))
        //        subject = subject + " : " + location.NomeInstallazione;


        //    if (!string.IsNullOrWhiteSpace(codiciApparati))
        //        subject = subject + ". Codice Apparati: " + codiciApparati;

        //    body = email.Body;
        //    {

        //        e.Add("<#CODICE_REPEATER>", codiciApparati);
        //        e.Add("<#NOME_INSTALLAZIONE>", location.NomeInstallazione);
        //        e.Add("<#RAGIONE_SOCIALE_CLIENTE>", location.Richiedente.RagioneSociale);
        //        e.Add("<#CODICE_CLIENTE>", location.Richiedente.CodiceCliente);
        //        e.Add("<#INDIRIZZO_CLIENTE>", location.Indirizzo + "-" + location.CAP + " " + location.ComuneSts.Descrizione);
        //        e.Add("<#PROVINCIA>", location.ComuneSts.ProvinciaSts.Sigla);
        //        e.Add("<#NOME_RIFERIMENTO>", string.IsNullOrWhiteSpace(location.FullNameReferenteLocale) ? location.Richiedente.RiferimentoFullName : location.FullNameReferenteLocale + " (loc)");
        //        e.Add("<#TELEFONO_RIFERIMENTO>", string.IsNullOrWhiteSpace(location.TelefonoReferenteLocale) ? location.Richiedente.TelefonoRiferimento : location.TelefonoReferenteLocale + " (loc)");
        //        e.Add("<#NOTE>", location.Note);
        //        e.Add("<#REGIONE_VF>", location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Region);
        //    }

        //    Replace(ref body, e);
        //    mailTo.Add(ditta.MailRiferimento);

        //    return SendMail(mailTo, subject, body, mailCc);


        //}

        ///// <summary>
        ///// Invia una mail alla FdV per informarla della data on-air stimata
        ///// </summary>
        ///// <param name="installazione">Installazione da effettuare</param>
        ///// <returns>True se la mail è stata inviata, false se c'è stato un problema</returns>
        //internal static bool SendMailFdvForDataOnAir(Installazione installazione)
        //{
        //    if (!_IsMailEnabled) return false;
        //    RCDEntities ctx = new RCDEntities();
        //    ctx.ContextOptions.LazyLoadingEnabled = true;
        //    List<string> mailTo = new List<string>();
        //    Dictionary<string, object> e = new Dictionary<string, object>();
        //    string subject;
        //    string codiciApparati;
        //    string body;

        //    Richiesta richiesta = (from r in ctx.Richieste.Include("Utente").Include("Location").Include("Location.ComuneSts")
        //                           .Include("Location.ComuneSts.ProvinciaSts").Include("Location.ComuneSts.ProvinciaSts.RegioneSts")
        //                           .Include("Location.ComuneSts.ProvinciaSts.Provincia").Include("Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF")
        //                           .Include("Installazione").Include("Richiedente")
        //                           where r.Installazione.Id == installazione.Id
        //                           select r).FirstOrDefault<Richiesta>();



        //    RCDEngine.Mail email = (from m in ctx.Mails
        //                            where m.Id == 6
        //                            select m).FirstOrDefault<RCDEngine.Mail>();

        //    /// TO
        //    mailTo.Add(richiesta.Utente.Mail);

        //    /// CC
        //    List<string> mailCc = (from a in ctx.MailsDCEHQ
        //                           select a.Mail).ToList<string>();

        //    var utenti = from u in ctx.Utenti.Include("Zona")  //03 11 2011
        //                 where
        //                 (richiesta.IdProgettistaRan.HasValue && u.Id == richiesta.IdProgettistaRan.Value) ||
        //                 (richiesta.IdSiteManagerNI.HasValue && u.Id == richiesta.IdSiteManagerNI.Value) ||
        //                 (richiesta.IdRiferimentoDce != null && u.Id == richiesta.IdRiferimentoDce) ||
        //                 (richiesta.IdRiferimentoVendite != null && u.Id == richiesta.IdRiferimentoVendite) ||
        //                 (u.Id == richiesta.IdUserInsert) ||
        //                 (u.TipologiaUtente.DescrizioneTipologiaUtente == "DM" && u.Username != "zzgd293" && u.Zona.Id == richiesta.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Zona.Id)
        //                 select u;

        //    foreach (Utente u in utenti.Where(ut => ut.Abilitato))  //03 11 2011
        //        if (!mailCc.Contains(u.Mail))
        //            mailCc.Add(u.Mail);

        //    /// SUBJECT
        //    subject = email.Subject;

        //    codiciApparati = string.Join(", ", (from ist in ctx.InstallazioniCrowdcell
        //                                        where ist.IdInstallazione == richiesta.IdInstallazione && (ist.TargaTecnica != null && ist.TargaTecnica.Trim() != string.Empty)
        //                                        select ist).Select(sa => sa.TargaTecnica));

        //    if (string.IsNullOrWhiteSpace(codiciApparati))
        //        codiciApparati = string.Join(", ", (from ist in ctx.InstallazioniApparati
        //                                            where ist.IdInstallazione == richiesta.IdInstallazione && (ist.Codice != null && ist.Codice.Trim() != string.Empty)
        //                                            select ist).Select(sa => sa.Codice));

        //    if (!string.IsNullOrWhiteSpace(richiesta.Location.NomeInstallazione))
        //        subject = string.Format("{0} : {1}. ", subject, richiesta.Location.NomeInstallazione);


        //    if (!string.IsNullOrWhiteSpace(codiciApparati))
        //        subject = string.Format("{0} Codice Apparati: {1}. ", subject, codiciApparati);

        //    body = email.Body;

        //    e.Add("<#CODICE_REPEATER>", codiciApparati);
        //    e.Add("<#NOME_INSTALLAZIONE>", richiesta.Location.NomeInstallazione);
        //    e.Add("<#RAGIONE_SOCIALE_CLIENTE>", richiesta.Richiedente.RagioneSociale);
        //    e.Add("<#CODICE_CLIENTE>", richiesta.Richiedente.CodiceCliente);
        //    e.Add("<#INDIRIZZO_CLIENTE>", richiesta.Location.Indirizzo + "-" + richiesta.Location.CAP + " " + richiesta.Location.ComuneSts.Descrizione);
        //    e.Add("<#PROVINCIA>", richiesta.Location.ComuneSts.ProvinciaSts.Sigla);
        //    e.Add("<#NOME_RIFERIMENTO>", richiesta.Location.FullNameReferenteLocale);
        //    e.Add("<#DATA_ONAIR>", richiesta.Installazione.DataOnAirStimata.Value.ToString("dd/MM/yyyy"));
        //    e.Add("<#REGIONE_VF>", richiesta.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Region);

        //    Replace(ref body, e);
        //    return SendMail(mailTo, subject, body, mailCc: mailCc);
        //}

        ///// <summary>
        ///// Invia una mail alla FdV per informarla dell'avvenuta installazione
        ///// </summary>
        ///// <param name="installazione">Installazione effettuata</param>
        ///// <returns>True se la mail è stata inviata, false se c'è stato un problema</returns>
        //internal static bool SendMailFdvForInstallazioneAvvenuta(Installazione installazione)
        //{
        //    if (!_IsMailEnabled) return false;
        //    RCDEntities ctx = new RCDEntities();
        //    ctx.ContextOptions.LazyLoadingEnabled = true;
        //    List<string> mailTo = new List<string>();
        //    string codiciApparati;
        //    string subject;
        //    string body;

        //    Richiesta richiesta = (from r in ctx.Richieste.Include("Utente").Include("Location").Include("Location.ComuneSts").Include("Location.ComuneSts.ProvinciaSts").Include("Location.ComuneSts.ProvinciaSts.RegioneSts").Include("Location.ComuneSts.ProvinciaSts.Provincia").Include("Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF")
        //                           .Include("Installazione").Include("Richiedente")
        //                           where r.Installazione.Id == installazione.Id
        //                           select r).FirstOrDefault<Richiesta>();

        //    RCDEngine.Mail email = (from m in ctx.Mails
        //                            where m.Id == 5
        //                            select m).FirstOrDefault<RCDEngine.Mail>();

        //    mailTo.Add(richiesta.Utente.Mail);
        //    List<string> mailCc = (from a in ctx.MailsDCEHQ
        //                           select a.Mail).ToList<string>();



        //    //Aggiungo in Cc i DM,Ran,NI

        //    var utenti = from u in ctx.Utenti.Include("Zona")
        //                 where (richiesta.IdProgettistaRan.HasValue && u.Id == richiesta.IdProgettistaRan.Value) ||
        //                 (richiesta.IdSiteManagerNI.HasValue && u.Id == richiesta.IdSiteManagerNI.Value) ||
        //                 (u.Id == richiesta.IdUserInsert) ||
        //                 (u.TipologiaUtente.DescrizioneTipologiaUtente == "DM" && u.Username != "zzgd293" && u.Zona.Id == richiesta.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Zona.Id)

        //                 select u;

        //    foreach (Utente u in utenti.Where(ut => ut.Abilitato))
        //        if (!mailCc.Contains(u.Mail))
        //            mailCc.Add(u.Mail);




        //    subject = email.Subject;

        //    codiciApparati = string.Join(", ", (from ist in ctx.InstallazioniCrowdcell
        //                                        where ist.IdInstallazione == richiesta.IdInstallazione && (ist.TargaTecnica != null && ist.TargaTecnica.Trim() != string.Empty)
        //                                        select ist).Select(sa => sa.TargaTecnica));

        //    if (string.IsNullOrWhiteSpace(codiciApparati))
        //        codiciApparati = string.Join(", ", (from ist in ctx.InstallazioniApparati
        //                                            where ist.IdInstallazione == richiesta.IdInstallazione && (ist.Codice != null && ist.Codice.Trim() != string.Empty)
        //                                            select ist).Select(sa => sa.Codice));

        //    if (!string.IsNullOrWhiteSpace(richiesta.Location.NomeInstallazione))
        //        subject = string.Format("{0} : {1}. ", subject, richiesta.Location.NomeInstallazione);


        //    if (!string.IsNullOrWhiteSpace(codiciApparati))
        //        subject = string.Format("{0} Codice Apparati: {1}. ", subject, codiciApparati);

        //    body = email.Body;

        //    Dictionary<string, object> e = new Dictionary<string, object>();
        //    e.Add("<#CODICE_REPEATER>", codiciApparati);
        //    e.Add("<#NOME_INSTALLAZIONE>", richiesta.Location.NomeInstallazione);
        //    e.Add("<#RAGIONE_SOCIALE_CLIENTE>", richiesta.Richiedente.RagioneSociale);
        //    e.Add("<#CODICE_CLIENTE>", richiesta.Richiedente.CodiceCliente);
        //    e.Add("<#INDIRIZZO_CLIENTE>", richiesta.Location.Indirizzo + "-" + richiesta.Location.CAP + " " + richiesta.Location.ComuneSts.Descrizione);
        //    e.Add("<#PROVINCIA>", richiesta.Location.ComuneSts.ProvinciaSts.Sigla);
        //    e.Add("<#NOME_RIFERIMENTO>", richiesta.Richiedente.RiferimentoFullName);
        //    e.Add("<#DATA_ONAIR>", richiesta.Installazione.DataOnAirConsuntivata.Value.ToString("dd/MM/yyyy"));    //TODO: Controllare questo campo,se è lui e se il formato della data è corretto
        //    e.Add("<#REGIONE_VF>", richiesta.Location.ComuneSts.ProvinciaSts.Provincia.RegioneVF.Region);

        //    Replace(ref body, e);

        //    return SendMail(mailTo, subject, body, mailCc: mailCc);
        //}

        //public static bool SendMailSogliaBudget(AreaVendite areaVendita)
        //{
        //    //return(true);
        //    if (!_IsMailEnabled) return false;

        //    RCDEntities ctx = new RCDEntities();
        //    ctx.ContextOptions.LazyLoadingEnabled = true;
        //    List<string> mailTo = new List<string>();
        //    List<string> mailCc = new List<string>();
        //    Budget budget;
        //    string subject;
        //    string body;


        //    RCDEngine.Mail email = (from m in ctx.Mails
        //                            where m.Id == 13
        //                            select m).FirstOrDefault<RCDEngine.Mail>();

        //    // Mail TO
        //    var mail =
        //        from av in
        //            ctx.AreeVendite.Include("AreaVenditaUtenti")
        //        where
        //            av.Id == areaVendita.Id
        //        select
        //            av.AreaVenditaUtenti.FirstOrDefault().UtenteAM.Mail;

        //    if (mail.Count() > 0)
        //        mailTo.Add(mail.FirstOrDefault().ToString());

        //    // Mail CC
        //    mail =
        //        from av in
        //            ctx.AreeVendite.Include("AreaVenditaUtenti")
        //        where
        //            av.Id == areaVendita.Id
        //        select
        //            av.AreaVenditaUtenti.FirstOrDefault().UtenteCRD.Mail;

        //    foreach (string crdMail in mail)
        //    {
        //        mailCc.Add(crdMail);
        //    }


        //    subject = email.Subject;

        //    body = email.Body;

        //    // C'e' da caricare tutto che non c'e'
        //    budget =
        //        (from av in
        //            ctx.AreeVendite.Include("Budget")
        //         where
        //             av.Id == areaVendita.Id
        //         select
        //             av.Budget.FirstOrDefault()).ToList()[0];

        //    Dictionary<string, object> e = new Dictionary<string, object>();
        //    //e.Add("<#AREA>", areaVendita.Descrizione);
        //    //e.Add("<#ASSEGNATO>", areaVendita.Budget.FirstOrDefault().Assegnato.ToString());
        //    //e.Add("<#SPESO>", areaVendita.Budget.FirstOrDefault().InstallatoCancellato.ToString());
        //    //e.Add("<#SOGLIA>", areaVendita.Budget.FirstOrDefault().Soglia.ToString());
        //    e.Add("<#AREA>", areaVendita.Descrizione);
        //    e.Add("<#ASSEGNATO>", budget.Assegnato.ToString());
        //    e.Add("<#SPESO>", budget.InstallatoCancellato.ToString());
        //    e.Add("<#SOGLIA>", budget.Soglia.ToString());

        //    Replace(ref body, e);

        //    return SendMail(mailTo, subject, body, mailCc: mailCc);
        //}


        ///// <summary>
        ///// Gestice i valori vuoti all'interno di un oggetto proventiente dal context e effettua il replace 
        ///// sul body della mail da inviare.
        ///// </summary>
        ///// <param name="inputString">la stringa su cui effettuare il replace (il body della mail)</param>
        ///// <param name="value">Collection </param>
        //private static void Replace(ref string inputString, Dictionary<string, object> value)
        //{
        //    value = value.ToDictionary(d => d.Key, d => object.Equals(null, d.Value) || object.Equals(string.Empty, d.Value.ToString().Trim()) ? (object)(d.Key.Equals("<#NOTE>") ? string.Empty : STRING_EMPTY) : d.Value);

        //    foreach (var s in value)
        //        inputString = inputString.Replace(s.Key, s.Value.ToString());
        //}

        ///// <summary>
        ///// Invio mail ai ruoli
        ///// </summary>
        ///// <param name="addresses"></param>
        ///// <param name="subject"></param>
        ///// <param name="body"></param>
        ///// <param name="mailCc"></param>
        ///// <returns></returns>
        //public static bool SendMailGroupRoles(List<string> addresses, string subject, string body, List<string> mailCc = null)
        //{
        //    // return SendMail(addresses, subject, body, mailCc);
        //    MailMessage mail = new MailMessage();
        //    String[] smtpServer = ConfigurationManager.AppSettings.Get("SmtpServer").Split(' ');
        //    String[] froms = ConfigurationManager.AppSettings.Get("MailSenderAndress").Split(' ');

        //    var smtp = (from sm in smtpServer
        //                select new { Domain = smtpServer.FirstOrDefault<string>(), UserName = smtpServer.ElementAtOrDefault<string>(1), Password = smtpServer.ElementAtOrDefault<string>(2) }).FirstOrDefault();
        //    try
        //    {
        //        mail.From = new MailAddress(froms.FirstOrDefault<string>(), string.Join(" ", froms.SkipWhile<string>(e => e == froms.FirstOrDefault())));

        //        foreach (string address in addresses)
        //            mail.To.Add(address);


        //        if (mailCc != null)
        //            foreach (string address in mailCc)
        //                mail.CC.Add(address);

        //        mail.Subject = subject;
        //        //mail.BodyEncoding = Encoding.Unicode;
        //        mail.BodyEncoding = Encoding.UTF8;
        //        mail.IsBodyHtml = true;
        //        mail.Body = body;
        //        mail.Priority = MailPriority.Normal;
        //        SmtpClient client = new SmtpClient(smtp.Domain);
        //        client.Timeout = 1000000;
        //        if (!string.IsNullOrEmpty(smtp.UserName) || !string.IsNullOrEmpty(smtp.Password))
        //            client.Credentials = new NetworkCredential(smtp.UserName, smtp.Password);


        //        client.SendCompleted += new SendCompletedEventHandler(SendCompletedCallback);
        //        string userState = "test message1";
        //        client.SendAsync(mail, userState);


        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Log(ex, true, mail, addresses, body, smtpServer);
        //        return false;
        //    }
        //}

        //static bool mailSent = false;
        //private static void SendCompletedCallback(object sender, AsyncCompletedEventArgs e)
        //{
        //    // Get the unique identifier for this asynchronous operation.
        //    String token = (string)e.UserState;

        //    if (e.Cancelled)
        //    {
        //        Console.WriteLine("[{0}] Send canceled.", token);
        //    }
        //    if (e.Error != null)
        //    {
        //        Console.WriteLine("[{0}] {1}", token, e.Error.ToString());
        //    }
        //    else
        //    {
        //        Console.WriteLine("Message sent.");
        //    }
        //    mailSent = true;
        //}
    }
}
